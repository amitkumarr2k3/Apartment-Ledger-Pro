--
-- PostgreSQL database dump
--

\restrict hEZE2RO4RMKbuLNtDX7qWI67HuIkJZUkz7dFjMAAqMHWLqkk71QGDdGtPJ0O444

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_line_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_batch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_actor_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_community_id_fkey;
DROP INDEX IF EXISTS public.mv_vendor_ranking_idx;
DROP INDEX IF EXISTS public.mv_monthly_totals_pk;
DROP INDEX IF EXISTS public.mv_cat_monthly_idx;
DROP INDEX IF EXISTS public.line_items_cat_vendor_name_uq;
DROP INDEX IF EXISTS public.idx_txn_vendor_month;
DROP INDEX IF EXISTS public.idx_txn_head_month;
DROP INDEX IF EXISTS public.idx_txn_flat_month;
DROP INDEX IF EXISTS public.idx_txn_community_month;
DROP INDEX IF EXISTS public.idx_txn_category_month;
DROP INDEX IF EXISTS public.idx_audit_entity;
DROP INDEX IF EXISTS public.idx_audit_at;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_pkey;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_name_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_source_source_ref_key;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_month_key;
ALTER TABLE IF EXISTS ONLY public.otp_codes DROP CONSTRAINT IF EXISTS magic_links_pkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_pkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_pkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_kind_name_key;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_pkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_code_key;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.communities DROP CONSTRAINT IF EXISTS communities_pkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_name_key;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_pkey;
ALTER TABLE IF EXISTS ONLY public._migrations DROP CONSTRAINT IF EXISTS _migrations_pkey;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.periods;
DROP TABLE IF EXISTS public.otp_codes;
DROP MATERIALIZED VIEW IF EXISTS public.mv_vendor_ranking;
DROP TABLE IF EXISTS public.vendors;
DROP MATERIALIZED VIEW IF EXISTS public.mv_monthly_totals;
DROP MATERIALIZED VIEW IF EXISTS public.mv_category_monthly;
DROP TABLE IF EXISTS public.transactions;
DROP TABLE IF EXISTS public.line_items;
DROP TABLE IF EXISTS public.import_staging;
DROP TABLE IF EXISTS public.import_rules;
DROP TABLE IF EXISTS public.import_batches;
DROP TABLE IF EXISTS public.heads;
DROP TABLE IF EXISTS public.flats;
DROP TABLE IF EXISTS public.dashboard_settings;
DROP TABLE IF EXISTS public.communities;
DROP TABLE IF EXISTS public.collections_dues;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.balances;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP TABLE IF EXISTS public.allowed_emails;
DROP TABLE IF EXISTS public._migrations;
DROP TYPE IF EXISTS public.vendor_kind;
DROP TYPE IF EXISTS public.head_kind;
DROP TYPE IF EXISTS public.app_role;
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'resident',
    'admin',
    'superadmin'
);


--
-- Name: head_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.head_kind AS ENUM (
    'income',
    'expense'
);


--
-- Name: vendor_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vendor_kind AS ENUM (
    'company',
    'individual'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    name text NOT NULL,
    run_at timestamp with time zone DEFAULT now()
);


--
-- Name: allowed_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allowed_emails (
    email text NOT NULL,
    community_id uuid NOT NULL,
    role public.app_role NOT NULL,
    flat_id uuid,
    name text,
    invited_by text,
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    community_id uuid,
    actor_user_id uuid,
    actor_email text,
    entity text NOT NULL,
    entity_id text,
    action text NOT NULL,
    before jsonb,
    after jsonb,
    at timestamp with time zone DEFAULT now() NOT NULL,
    ip text,
    user_agent text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balances (
    community_id uuid NOT NULL,
    month date NOT NULL,
    opening_paise bigint DEFAULT 0 NOT NULL,
    closing_paise bigint DEFAULT 0 NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    head_id uuid NOT NULL,
    name text NOT NULL
);


--
-- Name: collections_dues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections_dues (
    flat_id uuid NOT NULL,
    period_month date NOT NULL,
    dues_paise bigint DEFAULT 0 NOT NULL,
    paid_paise bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'due'::text NOT NULL
);


--
-- Name: communities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    fy_start_month smallint DEFAULT 4 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dashboard_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_settings (
    community_id uuid NOT NULL,
    dashboard_key text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    hidden_widgets text[] DEFAULT '{}'::text[] NOT NULL
);


--
-- Name: flats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    code text NOT NULL,
    owner_email text
);


--
-- Name: heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind public.head_kind NOT NULL,
    name text NOT NULL
);


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    filename text NOT NULL,
    kind text NOT NULL,
    uploaded_by uuid,
    status text DEFAULT 'staged'::text NOT NULL,
    error text,
    row_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind text NOT NULL,
    match jsonb NOT NULL,
    set_fields jsonb NOT NULL,
    priority integer DEFAULT 100 NOT NULL
);


--
-- Name: import_staging; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_staging (
    batch_id uuid NOT NULL,
    row_no integer NOT NULL,
    raw_json jsonb NOT NULL,
    mapped_json jsonb,
    error text
);


--
-- Name: line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    name text NOT NULL,
    first_seen_month date,
    last_seen_month date
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    txn_date date NOT NULL,
    period_month date NOT NULL,
    head_id uuid NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    line_item_id uuid,
    flat_id uuid,
    amount_paise bigint NOT NULL,
    direction character(1) NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    source_ref text,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT transactions_amount_paise_check CHECK ((amount_paise >= 0)),
    CONSTRAINT transactions_direction_check CHECK ((direction = ANY (ARRAY['C'::bpchar, 'D'::bpchar])))
);


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_category_monthly AS
 SELECT t.community_id,
    t.category_id,
    c.name AS category_name,
    h.kind AS head_kind,
    t.period_month AS month,
    (sum(t.amount_paise))::bigint AS amount_paise
   FROM ((public.transactions t
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON ((h.id = t.head_id)))
  GROUP BY t.community_id, t.category_id, c.name, h.kind, t.period_month
  WITH NO DATA;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_monthly_totals AS
 WITH spine AS (
         SELECT c.id AS community_id,
            (date_trunc('month'::text, gs.gs))::date AS month
           FROM (public.communities c
             CROSS JOIN generate_series((( SELECT COALESCE(min(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, (( SELECT COALESCE(max(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, '1 mon'::interval) gs(gs))
        )
 SELECT s.community_id,
    s.month,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric))::bigint AS collection_paise,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric))::bigint AS expense_paise,
    ((COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric) - COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric)))::bigint AS net_paise
   FROM (spine s
     LEFT JOIN public.transactions t ON (((t.community_id = s.community_id) AND (t.period_month = s.month))))
  GROUP BY s.community_id, s.month
  WITH NO DATA;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    name text NOT NULL,
    kind public.vendor_kind DEFAULT 'company'::public.vendor_kind NOT NULL
);


--
-- Name: TABLE vendors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vendors IS 'Vendor dimension. Read-only from admin UI; populated via CSV import + on-the-fly during transaction ingest.';


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_vendor_ranking AS
 SELECT t.community_id,
    v.id AS vendor_id,
    v.name AS vendor_name,
    v.kind AS vendor_kind,
    COALESCE(string_agg(DISTINCT c.name, ', '::text), ''::text) AS categories,
    (sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)))::bigint AS total_expense_paise,
    count(DISTINCT t.period_month) AS months_active
   FROM (((public.transactions t
     JOIN public.vendors v ON ((v.id = t.vendor_id)))
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON (((h.id = t.head_id) AND (h.kind = 'expense'::public.head_kind))))
  GROUP BY t.community_id, v.id, v.name, v.kind
  WITH NO DATA;


--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_codes (
    email text NOT NULL,
    otp_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone
);


--
-- Name: periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    month date NOT NULL,
    status text DEFAULT 'open'::text NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role public.app_role NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    email text NOT NULL,
    name text,
    password_hash text,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._migrations (name, run_at) FROM stdin;
0001_init.sql	2026-07-13 11:13:56.401452+00
0002_indexes.sql	2026-07-13 11:13:56.401452+00
0003_mviews.sql	2026-07-13 11:13:56.401452+00
0004_otp_rename.sql	2026-07-13 11:20:04.500279+00
0005_etl.sql	2026-08-03 16:34:38.109705+00
0006_drop_etl_sessions.sql	2026-08-03 18:40:10.950432+00
\.


--
-- Data for Name: allowed_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allowed_emails (email, community_id, role, flat_id, name, invited_by, invited_at, revoked_at) FROM stdin;
treasurer@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	admin	\N	Treasurer	system	2026-07-13 11:20:04.55456+00	\N
resident@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	resident	\N	Demo Resident	system	2026-07-13 11:20:04.55456+00	\N
admin@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	superadmin	\N	Super Admin	system	2026-07-13 11:20:04.55456+00	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, community_id, actor_user_id, actor_email, entity, entity_id, action, before, after, at, ip, user_agent) FROM stdin;
1	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	etl_session	16f1a25a-dc37-40a0-8265-6ee9707537a3	import	\N	{"logs": ["[STDERR] Traceback (most recent call last):\\n  File \\"/app/ETL/transform.py\\", line 358, in <module>", "[STDERR] output_df.to_csv(\\n  File \\"/usr/lib/python3.12/site-packages/pandas/util/_decorators.py\\", line 333, in wrapper", "[STDERR] return func(*args, **kwargs)", "[STDERR] ^^^^^^^^^^^^^^^^^^^^^", "[STDERR] File \\"/usr/lib/python3.12/site-packages/pandas/core/generic.py\\", line 3989, in to_csv", "[STDERR] return DataFrameRenderer(formatter).to_csv(\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\"/usr/lib/python3.12/site-packages/pandas/io/formats/format.py\\", line 1014, in to_csv", "[STDERR] csv_formatter.save()\\n  File \\"/usr/lib/python3.12/site-packages/pandas/io/formats/csvs.py\\", line 251, in save", "[STDERR] with get_handle(\\n         ^^^^^^^^^^^", "[STDERR] File \\"/usr/lib/python3.12/site-packages/pandas/io/common.py\\", line 873, in get_handle", "[STDERR] handle = open(\\n             ^^^^", "[STDERR] ^\\nPermissionError: [Errno 13] Permission denied: 'output/transactions.csv'"], "error": "Traceback (most recent call last):\\n  File \\"/app/ETL/transform.py\\", line 358, in <module>\\noutput_df.to_csv(\\n  File \\"/usr/lib/python3.12/site-packages/pandas/util/_decorators.py\\", line 333, in wrapper\\nreturn func(*args, **kwargs)\\n^^^^^^^^^^^^^^^^^^^^^\\nFile \\"/usr/lib/python3.12/site-packages/pandas/core/generic.py\\", line 3989, in to_csv\\nreturn DataFrameRenderer(formatter).to_csv(\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\"/usr/lib/python3.12/site-packages/pandas/io/formats/format.py\\", line 1014, in to_csv\\ncsv_formatter.save()\\n  File \\"/usr/lib/python3.12/site-packages/pandas/io/formats/csvs.py\\", line 251, in save\\nwith get_handle(\\n         ^^^^^^^^^^^\\nFile \\"/usr/lib/python3.12/site-packages/pandas/io/common.py\\", line 873, in get_handle\\nhandle = open(\\n             ^^^^\\n^\\nPermissionError: [Errno 13] Permission denied: 'output/transactions.csv'\\n", "sessionId": "16f1a25a-dc37-40a0-8265-6ee9707537a3", "inputFiles": ["Expense-analysis_expense_1785781080292.xls", "Receipt-analysis_receipt_1785781080306.xls", "Vendor-Bill-Report_vendor_1785781080313.xls"]}	2026-08-03 18:18:01.533604+00	172.26.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
2	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	etl_session	c18c6e81-96af-48c2-aec5-81a57778ae3d	import	\N	{"logs": ["[STDERR] Traceback (most recent call last):\\n  File \\"/app/ETL/transform.py\\", line 358, in <module>", "[STDERR] output_df.to_csv(\\n  File \\"/usr/lib/python3.12/site-packages/pandas/util/_decorators.py\\", line 333, in wrapper", "[STDERR] return func(*args, **kwargs)", "[STDERR] ", "[STDERR] ^^^^^^^^^^^^^^^^^^^^^", "[STDERR] File \\"/usr/lib/python3.12/site-packages/pandas/core/generic.py\\", line 3989, in to_csv", "[STDERR] return DataFrameRenderer(formatter).to_csv(\\n           ^^^^^^^^^^^^^^^^^^^^^^", "[STDERR] ^^^^^^^^^^^^^^\\n  File \\"/usr/lib/python3.12/site-packages/pandas/io/formats/format.py\\", line 1014, in to_csv", "[STDERR] csv_formatter.save()", "[STDERR] File \\"/usr/lib/python3.12/site-packages/pandas/io/formats/csvs.py\\", line 251, in save", "[STDERR] with get_handle(\\n         ^^^^^^^^^^^\\n  File \\"/usr/lib/python3.12/site-packages/pandas/io/common.py\\", line 873, in get_handle", "[STDERR] handle = open(\\n             ^^^", "[STDERR] ^^", "[STDERR] PermissionError:", "[STDERR] [Errno 13] Permission denied: 'output/transactions.csv'"], "error": "Traceback (most recent call last):\\n  File \\"/app/ETL/transform.py\\", line 358, in <module>\\noutput_df.to_csv(\\n  File \\"/usr/lib/python3.12/site-packages/pandas/util/_decorators.py\\", line 333, in wrapper\\nreturn func(*args, **kwargs)\\n\\n^^^^^^^^^^^^^^^^^^^^^\\nFile \\"/usr/lib/python3.12/site-packages/pandas/core/generic.py\\", line 3989, in to_csv\\nreturn DataFrameRenderer(formatter).to_csv(\\n           ^^^^^^^^^^^^^^^^^^^^^^\\n^^^^^^^^^^^^^^\\n  File \\"/usr/lib/python3.12/site-packages/pandas/io/formats/format.py\\", line 1014, in to_csv\\ncsv_formatter.save()\\nFile \\"/usr/lib/python3.12/site-packages/pandas/io/formats/csvs.py\\", line 251, in save\\nwith get_handle(\\n         ^^^^^^^^^^^\\n  File \\"/usr/lib/python3.12/site-packages/pandas/io/common.py\\", line 873, in get_handle\\nhandle = open(\\n             ^^^\\n^^\\nPermissionError:\\n[Errno 13] Permission denied: 'output/transactions.csv'\\n", "sessionId": "c18c6e81-96af-48c2-aec5-81a57778ae3d", "inputFiles": ["Expense-analysis_expense_1785781392067.xls", "Receipt-analysis_receipt_1785781392104.xls", "Vendor-Bill-Report_vendor_1785781392144.xls"]}	2026-08-03 18:23:17.002432+00	172.27.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
3	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	etl_session	78733e59-7d45-4fe7-864e-f7a1212e667a	import	\N	{"rows": 164, "failed": 0, "inserted": 164, "sessionId": "78733e59-7d45-4fe7-864e-f7a1212e667a", "inputFiles": ["Expense-analysis_expense_1785781976190.xls", "Receipt-analysis_receipt_1785781976215.xls", "Vendor-Bill-Report_vendor_1785781976245.xls"], "importBatchId": "e379bbde-856c-486d-934a-29047f10cf49"}	2026-08-03 18:33:00.387859+00	172.27.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
\.


--
-- Data for Name: balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.balances (community_id, month, opening_paise, closing_paise) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, head_id, name) FROM stdin;
445a13ad-d789-43c8-9363-5efe7fb2e312	7936370a-7a31-405b-a996-ff3f3c2efbb8	Cleaning
b651b6fe-42b5-4f5b-90e0-85077abdd5f4	7936370a-7a31-405b-a996-ff3f3c2efbb8	Maintenance
4f38dd81-0e5c-4bca-968d-04cbdade4e75	7936370a-7a31-405b-a996-ff3f3c2efbb8	Housekeeping
e6c10b7b-c30e-4778-a943-63948071ad43	7936370a-7a31-405b-a996-ff3f3c2efbb8	Gardening
cf573b1c-9906-4002-b262-e5afe2f25cbc	7936370a-7a31-405b-a996-ff3f3c2efbb8	Petty Cash
b2e0fca3-2454-4d3a-a063-7a828c2e7769	7936370a-7a31-405b-a996-ff3f3c2efbb8	Accounting Adjustments
9b08e0e8-3a56-4995-b348-538968d9a305	7936370a-7a31-405b-a996-ff3f3c2efbb8	Water Treatment
53cf5f61-e610-46c1-945b-7f2e46e4754d	7936370a-7a31-405b-a996-ff3f3c2efbb8	Office Supplies
a7549b62-113c-499f-a021-3fe892ed9397	7936370a-7a31-405b-a996-ff3f3c2efbb8	Utilities
ad42913d-f55b-46b7-a7c7-1c3737fb109d	7936370a-7a31-405b-a996-ff3f3c2efbb8	Facility Management
b4582c71-8f74-4223-b662-e687cc2a02d9	0ea4c5c9-f917-47eb-b9f9-d58def04755b	Community Contributions
18c54d0c-f7cb-40be-b791-7636371cfeb1	0ea4c5c9-f917-47eb-b9f9-d58def04755b	Recreation & Wellness
786617d2-406e-47c7-8549-cb48082a8f4f	0ea4c5c9-f917-47eb-b9f9-d58def04755b	Events
ead9e32d-60d8-4a4f-91cb-3eaeb1932e2e	0ea4c5c9-f917-47eb-b9f9-d58def04755b	Parking Revenue
e10f843b-66c7-40eb-bbd2-d4730a96e2e7	0ea4c5c9-f917-47eb-b9f9-d58def04755b	Advertisement
9b604036-0610-4951-a32e-bd03f6504379	0ea4c5c9-f917-47eb-b9f9-d58def04755b	Maintenance Collection
144d1ef1-81d3-4f4d-9770-e7534d41467d	0ea4c5c9-f917-47eb-b9f9-d58def04755b	Move Charges
75fa9e93-49f2-446b-b908-07dc56260197	0ea4c5c9-f917-47eb-b9f9-d58def04755b	Facility Rental
4d19088c-90d3-4860-9959-125c588b4a4a	0ea4c5c9-f917-47eb-b9f9-d58def04755b	Penalties
74fbad0f-a4bf-4cc7-9092-1566c2ecffa5	0ea4c5c9-f917-47eb-b9f9-d58def04755b	Tax
\.


--
-- Data for Name: collections_dues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections_dues (flat_id, period_month, dues_paise, paid_paise, status) FROM stdin;
\.


--
-- Data for Name: communities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communities (id, name, currency, fy_start_month, created_at) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	Green Meadows	INR	4	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: dashboard_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_settings (community_id, dashboard_key, enabled, hidden_widgets) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	resident.overview	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.drilldown	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.cashflow	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.income	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.balance	t	{}
\.


--
-- Data for Name: flats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flats (id, community_id, code, owner_email) FROM stdin;
f88d6359-58a8-42b1-8476-24ce41b63802	caa11b01-c3a5-4067-a90c-b73b35075def	A-001	\N
5696d5bf-57f9-44ad-b92d-781cabc4a550	caa11b01-c3a5-4067-a90c-b73b35075def	A-002	\N
5c447f5e-a684-4075-8224-072f1fb12c93	caa11b01-c3a5-4067-a90c-b73b35075def	A-003	\N
6ddf10b7-40ed-44a1-9080-e50c60a08e32	caa11b01-c3a5-4067-a90c-b73b35075def	A-004	\N
5bfe95a5-bc38-4d00-811e-b5a6106e71c7	caa11b01-c3a5-4067-a90c-b73b35075def	A-005	\N
6e67ec18-d2aa-4cd4-8a51-b9a2b33429a2	caa11b01-c3a5-4067-a90c-b73b35075def	A-006	\N
05fbfe69-9195-45aa-bb9a-ef1de36f6fd9	caa11b01-c3a5-4067-a90c-b73b35075def	A-007	\N
7dca9ae9-39f7-4b2c-85b6-f9c820a65f0c	caa11b01-c3a5-4067-a90c-b73b35075def	A-008	\N
24f24d23-6946-4d06-b2d4-7ebe31278f9e	caa11b01-c3a5-4067-a90c-b73b35075def	A-009	\N
39278459-ad85-4e5e-937a-0a36b195c960	caa11b01-c3a5-4067-a90c-b73b35075def	A-010	\N
716bbe4c-f53d-4558-a4b5-caeb642f2c23	caa11b01-c3a5-4067-a90c-b73b35075def	A-011	\N
6dac5232-f75f-44d2-8533-4119c856f0ac	caa11b01-c3a5-4067-a90c-b73b35075def	A-012	\N
ea815ea6-a6d6-4547-bb06-ebfc9497a6f2	caa11b01-c3a5-4067-a90c-b73b35075def	A-013	\N
b441021b-6b42-4350-bd7a-385d23b17015	caa11b01-c3a5-4067-a90c-b73b35075def	A-014	\N
74194275-0229-47a7-9a12-691c228cbf03	caa11b01-c3a5-4067-a90c-b73b35075def	A-015	\N
f9df5252-7643-42fd-9a63-2e839347a52f	caa11b01-c3a5-4067-a90c-b73b35075def	A-016	\N
321b8a10-e82d-4cf6-a6b2-fde3fa7b05b1	caa11b01-c3a5-4067-a90c-b73b35075def	A-017	\N
9c1ddcb5-9b93-4e47-80ac-cbfc3b7f326e	caa11b01-c3a5-4067-a90c-b73b35075def	A-018	\N
f0106df5-f061-40fd-97c8-f6408f268ff9	caa11b01-c3a5-4067-a90c-b73b35075def	A-019	\N
deeb22d9-7a6b-4417-985b-c76049abae2e	caa11b01-c3a5-4067-a90c-b73b35075def	A-020	\N
c2e7bc3c-62db-4d01-aad3-9513cbf2ecbf	caa11b01-c3a5-4067-a90c-b73b35075def	A-021	\N
8c7ed2ff-3fea-4279-a889-c4e44b78ef6e	caa11b01-c3a5-4067-a90c-b73b35075def	A-022	\N
fb52fe46-dded-4f23-975d-3f36184896e9	caa11b01-c3a5-4067-a90c-b73b35075def	A-023	\N
5fc3f4ab-169c-47bc-819a-315c1a244aac	caa11b01-c3a5-4067-a90c-b73b35075def	A-024	\N
\.


--
-- Data for Name: heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heads (id, community_id, kind, name) FROM stdin;
7936370a-7a31-405b-a996-ff3f3c2efbb8	caa11b01-c3a5-4067-a90c-b73b35075def	expense	Expense
0ea4c5c9-f917-47eb-b9f9-d58def04755b	caa11b01-c3a5-4067-a90c-b73b35075def	income	Income
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, community_id, filename, kind, uploaded_by, status, error, row_count, created_at) FROM stdin;
e379bbde-856c-486d-934a-29047f10cf49	caa11b01-c3a5-4067-a90c-b73b35075def	etl-transformed-transactions.csv	transactions	0f0c6024-6c4d-47b3-9012-4f714d448a40	committed	\N	164	2026-08-03 18:33:00.376262+00
\.


--
-- Data for Name: import_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_rules (id, community_id, kind, match, set_fields, priority) FROM stdin;
\.


--
-- Data for Name: import_staging; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_staging (batch_id, row_no, raw_json, mapped_json, error) FROM stdin;
e379bbde-856c-486d-934a-29047f10cf49	1	{"date": "2026-04-01", "head": "expense", "amount": "1214.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	2	{"date": "2026-05-01", "head": "expense", "amount": "1414.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	3	{"date": "2026-06-01", "head": "expense", "amount": "1428.98", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	4	{"date": "2026-07-01", "head": "expense", "amount": "1414.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-07", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	5	{"date": "2026-04-01", "head": "expense", "amount": "61049.0", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-04", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	6	{"date": "2026-05-01", "head": "expense", "amount": "7590.36", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-05", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	7	{"date": "2026-06-01", "head": "expense", "amount": "12018.34", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-06", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	8	{"date": "2026-07-01", "head": "expense", "amount": "4455.04", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-07", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	9	{"date": "2026-04-01", "head": "expense", "amount": "30000.0", "vendor": "JOHNSON LIFTS Pvt Ltd", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	10	{"date": "2026-06-01", "head": "expense", "amount": "150000.0", "vendor": "JOHNSON LIFTS Pvt Ltd", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	11	{"date": "2026-06-01", "head": "expense", "amount": "55000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Annual Compliance Expense", "source_ref": "D|Facility Management|EXOZEN|Annual Compliance Expense|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	12	{"date": "2026-04-01", "head": "expense", "amount": "154999.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	13	{"date": "2026-05-01", "head": "expense", "amount": "175902.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	14	{"date": "2026-04-01", "head": "expense", "amount": "46130.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	15	{"date": "2026-05-01", "head": "expense", "amount": "43011.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	16	{"date": "2026-04-01", "head": "expense", "amount": "79692.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	17	{"date": "2026-05-01", "head": "expense", "amount": "102431.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	18	{"date": "2026-04-01", "head": "expense", "amount": "78966.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	19	{"date": "2026-05-01", "head": "expense", "amount": "101572.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	20	{"date": "2026-04-01", "head": "expense", "amount": "9000.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-04", "vendor_kind": "individual"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	21	{"date": "2026-05-01", "head": "expense", "amount": "19300.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-05", "vendor_kind": "individual"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	22	{"date": "2026-06-01", "head": "expense", "amount": "20400.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-06", "vendor_kind": "individual"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	23	{"date": "2026-06-01", "head": "expense", "amount": "12876.27", "vendor": "KIRLOSKAR OIL ENGINES LTD", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "DG Service", "source_ref": "D|Maintenance|KIRLOSKAR OIL ENGINES LTD|DG Service|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	24	{"date": "2026-04-01", "head": "expense", "amount": "91401.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	25	{"date": "2026-05-01", "head": "expense", "amount": "54822.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	26	{"date": "2026-06-01", "head": "expense", "amount": "59784.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	27	{"date": "2026-07-01", "head": "expense", "amount": "59784.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-07", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	28	{"date": "2026-04-01", "head": "expense", "amount": "75588.3", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	29	{"date": "2026-05-01", "head": "expense", "amount": "82902.54", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	30	{"date": "2026-06-01", "head": "expense", "amount": "86506.61", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	31	{"date": "2026-04-01", "head": "expense", "amount": "59421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	32	{"date": "2026-05-01", "head": "expense", "amount": "59421.11", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	33	{"date": "2026-06-01", "head": "expense", "amount": "59421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	34	{"date": "2026-04-01", "head": "expense", "amount": "14000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	35	{"date": "2026-05-01", "head": "expense", "amount": "24000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	36	{"date": "2026-06-01", "head": "expense", "amount": "24000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	37	{"date": "2026-04-01", "head": "expense", "amount": "20280.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	38	{"date": "2026-05-01", "head": "expense", "amount": "130.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	39	{"date": "2026-07-01", "head": "expense", "amount": "1491.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-07", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	40	{"date": "2026-04-01", "head": "expense", "amount": "83421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	41	{"date": "2026-05-01", "head": "expense", "amount": "87561.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	42	{"date": "2026-06-01", "head": "expense", "amount": "85346.1", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	43	{"date": "2026-04-01", "head": "expense", "amount": "24471.07", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	44	{"date": "2026-05-01", "head": "expense", "amount": "23681.69", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	45	{"date": "2026-06-01", "head": "expense", "amount": "23627.24", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	46	{"date": "2026-04-01", "head": "expense", "amount": "22948.08", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	47	{"date": "2026-05-01", "head": "expense", "amount": "27759.6", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	48	{"date": "2026-06-01", "head": "expense", "amount": "24860.42", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	49	{"date": "2026-04-01", "head": "expense", "amount": "45317.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	50	{"date": "2026-05-01", "head": "expense", "amount": "34857.6", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	51	{"date": "2026-07-01", "head": "expense", "amount": "575.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-07", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	52	{"date": "2026-04-01", "head": "expense", "amount": "236717.04", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	53	{"date": "2026-05-01", "head": "expense", "amount": "313817.43", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	54	{"date": "2026-06-01", "head": "expense", "amount": "323070.45", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	55	{"date": "2026-04-01", "head": "expense", "amount": "24204.09", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	56	{"date": "2026-05-01", "head": "expense", "amount": "16397.01", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	57	{"date": "2026-06-01", "head": "expense", "amount": "23398.07", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	58	{"date": "2026-04-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	59	{"date": "2026-05-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	60	{"date": "2026-06-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	61	{"date": "2026-04-01", "head": "expense", "amount": "2000.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "One Time Operational Procurement", "source_ref": "D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-04", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	62	{"date": "2026-07-01", "head": "expense", "amount": "52694.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "One Time Operational Procurement", "source_ref": "D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-07", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	63	{"date": "2026-04-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	64	{"date": "2026-05-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	65	{"date": "2026-06-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	66	{"date": "2026-04-01", "head": "expense", "amount": "15683.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-04", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	67	{"date": "2026-05-01", "head": "expense", "amount": "20538.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-05", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	68	{"date": "2026-06-01", "head": "expense", "amount": "29600.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-06", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	69	{"date": "2026-07-01", "head": "expense", "amount": "14712.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-07", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	70	{"date": "2026-04-01", "head": "expense", "amount": "295.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-04", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	71	{"date": "2026-05-01", "head": "expense", "amount": "6487.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-05", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	72	{"date": "2026-06-01", "head": "expense", "amount": "5000.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-06", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	73	{"date": "2026-07-01", "head": "expense", "amount": "444.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-07", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	74	{"date": "2026-04-01", "head": "expense", "amount": "755.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-04", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	75	{"date": "2026-05-01", "head": "expense", "amount": "18917.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-05", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	76	{"date": "2026-06-01", "head": "expense", "amount": "5365.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-06", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	77	{"date": "2026-07-01", "head": "expense", "amount": "1015.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-07", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	78	{"date": "2026-04-01", "head": "expense", "amount": "75588.3", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	79	{"date": "2026-05-01", "head": "expense", "amount": "86966.39", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	80	{"date": "2026-06-01", "head": "expense", "amount": "85666.74", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	81	{"date": "2026-04-01", "head": "expense", "amount": "650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	82	{"date": "2026-05-01", "head": "expense", "amount": "6650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	83	{"date": "2026-06-01", "head": "expense", "amount": "650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	84	{"date": "2026-05-01", "head": "expense", "amount": "17334.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Facility Management|EXOZEN|Repair Work|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	85	{"date": "2026-06-01", "head": "expense", "amount": "8000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Facility Management|EXOZEN|Repair Work|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	86	{"date": "2026-04-01", "head": "expense", "amount": "0.41", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-04", "vendor_kind": "system"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	87	{"date": "2026-05-01", "head": "expense", "amount": "0.21", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-05", "vendor_kind": "system"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	88	{"date": "2026-06-01", "head": "expense", "amount": "0.1", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-06", "vendor_kind": "system"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	89	{"date": "2026-04-01", "head": "expense", "amount": "361130.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	90	{"date": "2026-05-01", "head": "expense", "amount": "373679.25", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	91	{"date": "2026-06-01", "head": "expense", "amount": "375840.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	92	{"date": "2026-04-01", "head": "expense", "amount": "22065.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	93	{"date": "2026-05-01", "head": "expense", "amount": "22064.87", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	94	{"date": "2026-06-01", "head": "expense", "amount": "21329.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	95	{"date": "2026-04-01", "head": "expense", "amount": "51642.7", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	96	{"date": "2026-05-01", "head": "expense", "amount": "54211.84", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	97	{"date": "2026-06-01", "head": "expense", "amount": "52518.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	98	{"date": "2026-04-01", "head": "expense", "amount": "86000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	99	{"date": "2026-05-01", "head": "expense", "amount": "94000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	100	{"date": "2026-06-01", "head": "expense", "amount": "118000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	101	{"date": "2026-04-01", "head": "expense", "amount": "67718.7", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	102	{"date": "2026-05-01", "head": "expense", "amount": "70631.52", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	103	{"date": "2026-06-01", "head": "expense", "amount": "75995.43", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	104	{"date": "2026-04-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	105	{"date": "2026-05-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	106	{"date": "2026-06-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	107	{"date": "2026-04-01", "head": "expense", "amount": "63000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Tank Cleaning Charges", "source_ref": "D|Facility Management|EXOZEN|Tank Cleaning Charges|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	108	{"date": "2026-04-01", "head": "expense", "amount": "9032.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-04", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	109	{"date": "2026-05-01", "head": "expense", "amount": "740.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-05", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	110	{"date": "2026-06-01", "head": "expense", "amount": "105.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-06", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	111	{"date": "2026-04-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	112	{"date": "2026-06-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	113	{"date": "2026-04-01", "head": "expense", "amount": "465815.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	114	{"date": "2026-05-01", "head": "expense", "amount": "478995.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	115	{"date": "2026-06-01", "head": "expense", "amount": "515775.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	116	{"date": "2026-04-01", "head": "expense", "amount": "6200.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-04", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	117	{"date": "2026-05-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-05", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	118	{"date": "2026-06-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-06", "vendor_kind": "company"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	119	{"date": "2026-04-01", "head": "income", "amount": "5000.0", "vendor": "Residents", "category": "Community Contributions", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Community Contributions|Residents|Association Fund|2026-04", "vendor_kind": "resident"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	120	{"date": "2026-05-01", "head": "income", "amount": "3700.0", "vendor": "Residents", "category": "Community Contributions", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Community Contributions|Residents|Association Fund|2026-05", "vendor_kind": "resident"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	121	{"date": "2026-06-01", "head": "income", "amount": "19500.0", "vendor": "Residents", "category": "Community Contributions", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Community Contributions|Residents|Association Fund|2026-06", "vendor_kind": "resident"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	122	{"date": "2026-04-01", "head": "income", "amount": "2800.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-04", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	123	{"date": "2026-05-01", "head": "income", "amount": "3500.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-05", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	124	{"date": "2026-06-01", "head": "income", "amount": "2100.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-06", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	125	{"date": "2026-07-01", "head": "income", "amount": "2800.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-07", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	126	{"date": "2026-05-01", "head": "income", "amount": "1120.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Amenities|Business Center|2026-05", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	127	{"date": "2026-06-01", "head": "income", "amount": "1080.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Amenities|Business Center|2026-06", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	128	{"date": "2026-07-01", "head": "income", "amount": "1000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Amenities|Business Center|2026-07", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	129	{"date": "2026-04-01", "head": "income", "amount": "12740.4", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-04", "vendor_kind": "statutory"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	130	{"date": "2026-05-01", "head": "income", "amount": "7592.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-05", "vendor_kind": "statutory"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	131	{"date": "2026-06-01", "head": "income", "amount": "5328.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-06", "vendor_kind": "statutory"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	132	{"date": "2026-07-01", "head": "income", "amount": "8680.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-07", "vendor_kind": "statutory"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	133	{"date": "2026-04-01", "head": "income", "amount": "1000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Common Area Violation", "source_ref": "C|Penalties|Resident Penalties|Common Area Violation|2026-04", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	134	{"date": "2026-06-01", "head": "income", "amount": "6000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Common Area Violation", "source_ref": "C|Penalties|Resident Penalties|Common Area Violation|2026-06", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	135	{"date": "2026-05-01", "head": "income", "amount": "8179.0", "vendor": "Community Events", "category": "Events", "direction": "C", "flat_code": "", "line_item": "Community Curriculum Activities", "source_ref": "C|Events|Community Events|Community Curriculum Activities|2026-05", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	136	{"date": "2026-05-01", "head": "income", "amount": "1000.0", "vendor": "Wellness Programs", "category": "Recreation & Wellness", "direction": "C", "flat_code": "", "line_item": "Fitness Trainers", "source_ref": "C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-05", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	137	{"date": "2026-07-01", "head": "income", "amount": "2304.0", "vendor": "Wellness Programs", "category": "Recreation & Wellness", "direction": "C", "flat_code": "", "line_item": "Fitness Trainers", "source_ref": "C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-07", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	138	{"date": "2026-04-01", "head": "income", "amount": "16000.0", "vendor": "Community Events", "category": "Events", "direction": "C", "flat_code": "", "line_item": "Flee Market", "source_ref": "C|Events|Community Events|Flee Market|2026-04", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	161	{"date": "2026-04-01", "head": "income", "amount": "12740.4", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-04", "vendor_kind": "statutory"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	139	{"date": "2026-07-01", "head": "income", "amount": "1000.0", "vendor": "Parking Services", "category": "Parking Revenue", "direction": "C", "flat_code": "", "line_item": "Guest Parking Rent", "source_ref": "C|Parking Revenue|Parking Services|Guest Parking Rent|2026-07", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	140	{"date": "2026-04-01", "head": "income", "amount": "151725.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-04", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	141	{"date": "2026-05-01", "head": "income", "amount": "95225.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-05", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	142	{"date": "2026-06-01", "head": "income", "amount": "68400.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-06", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	143	{"date": "2026-07-01", "head": "income", "amount": "108175.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-07", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	144	{"date": "2026-04-01", "head": "income", "amount": "9900.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-04", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	145	{"date": "2026-06-01", "head": "income", "amount": "5500.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-06", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	146	{"date": "2026-07-01", "head": "income", "amount": "3300.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-07", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	147	{"date": "2026-04-01", "head": "income", "amount": "2833274.0", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-04", "vendor_kind": "resident"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	148	{"date": "2026-05-01", "head": "income", "amount": "2838854.05", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-05", "vendor_kind": "resident"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	149	{"date": "2026-06-01", "head": "income", "amount": "2707115.06", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-06", "vendor_kind": "resident"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	150	{"date": "2026-07-01", "head": "income", "amount": "2748794.41", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-07", "vendor_kind": "resident"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	151	{"date": "2026-07-01", "head": "income", "amount": "7500.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move In/Out (Manual)", "source_ref": "C|Move Charges|Resident Services|Move In/Out (Manual)|2026-07", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	152	{"date": "2026-04-01", "head": "income", "amount": "35000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-04", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	153	{"date": "2026-05-01", "head": "income", "amount": "20000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-05", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	154	{"date": "2026-06-01", "head": "income", "amount": "30000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-06", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	155	{"date": "2026-07-01", "head": "income", "amount": "5000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-07", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	156	{"date": "2026-04-01", "head": "income", "amount": "12000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-04", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	157	{"date": "2026-05-01", "head": "income", "amount": "27000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-05", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	158	{"date": "2026-06-01", "head": "income", "amount": "21000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-06", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	159	{"date": "2026-07-01", "head": "income", "amount": "24000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-07", "vendor_kind": "internal"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	160	{"date": "2026-06-01", "head": "income", "amount": "1000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Parking Violation", "source_ref": "C|Penalties|Resident Penalties|Parking Violation|2026-06", "vendor_kind": "income_stream"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	162	{"date": "2026-05-01", "head": "income", "amount": "7592.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-05", "vendor_kind": "statutory"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	163	{"date": "2026-06-01", "head": "income", "amount": "5328.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-06", "vendor_kind": "statutory"}	\N	\N
e379bbde-856c-486d-934a-29047f10cf49	164	{"date": "2026-07-01", "head": "income", "amount": "8680.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-07", "vendor_kind": "statutory"}	\N	\N
\.


--
-- Data for Name: line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_items (id, category_id, vendor_id, name, first_seen_month, last_seen_month) FROM stdin;
479ad244-f74e-4ab7-adcb-40d8e8bf9e60	a7549b62-113c-499f-a021-3fe892ed9397	14dd9bc7-f3da-4078-a2de-594ac0bd2179	Airtel Postpaid Connection	2026-04-01	2026-07-01
8805facc-d869-4d4a-adc8-5c59d1492d7b	53cf5f61-e610-46c1-945b-7f2e46e4754d	6bd75c2a-5879-4c10-be28-135d8133d8f1	Amazon Purchase	2026-04-01	2026-07-01
4e104ff6-e52c-477c-8347-b33b2f4e3724	b651b6fe-42b5-4f5b-90e0-85077abdd5f4	86fc9cff-4f24-4d86-84c3-d87e9ac9b393	AMC (Lift)	2026-04-01	2026-06-01
111276b4-d3ba-41ae-bf64-3b069da87ae3	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Annual Compliance Expense	2026-06-01	2026-06-01
641c57b5-b0e4-41dd-b615-a268d75943be	a7549b62-113c-499f-a021-3fe892ed9397	2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	BESCOM A Block	2026-04-01	2026-05-01
9ed0bc9d-6093-47fd-8641-9d496eca5ded	a7549b62-113c-499f-a021-3fe892ed9397	2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	BESCOM B Block	2026-04-01	2026-05-01
e3b01f1f-475f-4538-a42f-99ad5e1ebad1	a7549b62-113c-499f-a021-3fe892ed9397	2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	BESCOM E Block	2026-04-01	2026-05-01
e9ba7392-ae29-497d-9c63-67dddb96286a	a7549b62-113c-499f-a021-3fe892ed9397	2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	BESCOM G Block	2026-04-01	2026-05-01
eb9ef5b3-3602-49c3-8a19-1eab04f4bd01	445a13ad-d789-43c8-9363-5efe7fb2e312	383b2e90-a014-4f30-82e6-1fd5666b0160	Debris Disposal	2026-04-01	2026-06-01
863c67f6-c259-454e-8a00-2c6e8350f9cc	b651b6fe-42b5-4f5b-90e0-85077abdd5f4	4a8ce38d-d651-47b2-b91d-a0e39b435feb	DG Service	2026-06-01	2026-06-01
c1f2891f-92f0-4d84-b71f-efc20f20e3c4	a7549b62-113c-499f-a021-3fe892ed9397	441a4619-a7bb-4ce1-b1c7-ff7032fedf39	Diesel	2026-04-01	2026-07-01
6dd05d16-a6d2-4c7e-8f26-31c6dc8d2cee	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Electricians Salary	2026-04-01	2026-06-01
cb830f20-790d-4857-80f0-4983fa70956d	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Facility Manager	2026-04-01	2026-06-01
3bbb1855-c8da-4862-b28a-29d2872cabf5	4f38dd81-0e5c-4bca-968d-04cbdade4e75	7ebe22e6-a2e8-4f8c-b8fd-232c6bc8130e	Garbage removal	2026-04-01	2026-06-01
e0f2d51b-6920-4ccd-a686-73633b4f66c0	e6c10b7b-c30e-4778-a943-63948071ad43	7e82cb08-a65a-40f5-b796-db0982e22742	Garden Tools	2026-04-01	2026-07-01
db8036a6-9897-4e77-bd1e-5ebd45bb0071	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Gardeners Salary	2026-04-01	2026-06-01
a1df572b-ab68-4315-94a6-0780c8a31cdc	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Gardening Supervisor Salary	2026-04-01	2026-06-01
453aa025-5a8d-47e0-b513-62cc66679b8e	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Help Desk Salary	2026-04-01	2026-06-01
25f9a05b-05ec-4d02-8ea3-34dbcda0bbff	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	HK Materials	2026-04-01	2026-07-01
28c5019f-fce4-4082-82c4-c38a5f690f0b	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	House Keeping Janitor Salary	2026-04-01	2026-06-01
fce6d4c5-9fbd-4f26-9689-1a47267bdfcf	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Housekeeping Supervisor Salary	2026-04-01	2026-06-01
5c0f10a2-55db-46d6-b2c4-c879024b5e10	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Management Fee	2026-04-01	2026-06-01
0f99103c-0fae-42f7-aa71-2357615ef35b	53cf5f61-e610-46c1-945b-7f2e46e4754d	780d88dd-22cf-4524-a66c-f88d23261b15	One Time Operational Procurement	2026-04-01	2026-07-01
298661bd-8bf8-4217-b04b-1c6ebcae7e2d	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Pest Control Services	2026-04-01	2026-06-01
45619c52-3abb-405a-a0f4-1854fffb54a5	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	Petty Cash - Consumables	2026-04-01	2026-07-01
ecada750-25a5-421c-8a55-38e75fd51880	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	Petty Cash - Electricals	2026-04-01	2026-07-01
61952cd1-d52b-4a10-becc-2f5822f9a21b	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	Petty Cash - Hardware	2026-04-01	2026-07-01
51f50722-e7fe-4d7f-b250-aacc233c6b07	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Plumbers Salary	2026-04-01	2026-06-01
6bfb437e-72a8-4882-a334-1ca48ce21450	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Rental Charges Machinery	2026-04-01	2026-06-01
5fdb3800-c0d2-4dfe-a66a-6f209fe2da25	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Repair Work	2026-05-01	2026-06-01
9d206f1e-6bac-4ba7-ab0a-70a47181a2cf	b2e0fca3-2454-4d3a-a063-7a828c2e7769	23de0f0a-6ab1-45f7-9838-681be086d535	Roundoff	2026-04-01	2026-06-01
43346a16-60a0-4ac8-a9ed-7d1dd263c91a	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Security Guards Salary	2026-04-01	2026-06-01
c7f73e14-a309-425b-a937-f333949bc157	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Security Lady Guards Salary	2026-04-01	2026-06-01
cc95475a-89e1-47d8-a31f-c785dde0b0ef	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Security Supervisor Salary	2026-04-01	2026-06-01
4282a0da-031e-48ff-8bc5-9e3406b63d1f	9b08e0e8-3a56-4995-b348-538968d9a305	096b53ec-4640-42d3-a81a-1e5c148b1ec8	STP water collection (Sludge Removal)	2026-04-01	2026-06-01
882bd661-5456-4caa-b03f-e7eb2bfae531	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	STP/WTP Operators Salary	2026-04-01	2026-06-01
cbe7dd19-a0f6-4a7c-99ed-89da1617bcbf	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Swimming Pool Services	2026-04-01	2026-06-01
1c901f91-7ac5-41ef-a6f6-e3433c020b97	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Tank Cleaning Charges	2026-04-01	2026-04-01
675ba1a2-8ab7-4d71-b4e8-dcde2d170dcb	53cf5f61-e610-46c1-945b-7f2e46e4754d	780d88dd-22cf-4524-a66c-f88d23261b15	Tools & Stationary	2026-04-01	2026-06-01
bf5afcb9-9218-4a93-8907-275d8c3cc7db	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Walkie Talkies	2026-04-01	2026-06-01
fb22c951-673c-49a8-9189-25b89b4f762e	a7549b62-113c-499f-a021-3fe892ed9397	b9fd7a25-8774-4719-845c-ca86930b7b0c	Water Supply	2026-04-01	2026-06-01
8f53a4c8-62f8-4158-8483-d4f3c79bf742	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	Water Test Report	2026-04-01	2026-06-01
aeb2fa07-ed15-4da6-adb2-66713bd1cb41	b4582c71-8f74-4223-b662-e687cc2a02d9	c169281b-50da-4e31-9b83-1672ea3da92e	Association Fund	2026-04-01	2026-06-01
61d5786f-27f3-4d01-b6a4-513a882eb698	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	AV room	2026-04-01	2026-07-01
ced455d9-fc70-4830-8aa2-6380e8e6f4e5	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	Business Center	2026-05-01	2026-07-01
3b057770-04fa-44e1-bad0-87df3c49d375	74fbad0f-a4bf-4cc7-9092-1566c2ecffa5	a6ab6752-bf2d-4310-85c9-e099922f6644	CGST Output	2026-04-01	2026-07-01
0e82cec9-bd45-4cea-9c57-0f659283d0e5	4d19088c-90d3-4860-9959-125c588b4a4a	9cf9b1a4-04cc-4952-b1b9-c533d40c7c66	Common Area Violation	2026-04-01	2026-06-01
13bdddd6-d7aa-4c98-a019-8284bd552753	786617d2-406e-47c7-8549-cb48082a8f4f	ba8459be-39bd-4124-817c-39c0ff43eaf1	Community Curriculum Activities	2026-05-01	2026-05-01
05c554b7-3e67-495e-a6ce-e0a267d180d5	18c54d0c-f7cb-40be-b791-7636371cfeb1	ba93a1f5-de89-4992-9430-3a689b11a5c1	Fitness Trainers	2026-05-01	2026-07-01
964be112-bb2b-4355-9c7f-e484d7adc381	786617d2-406e-47c7-8549-cb48082a8f4f	ba8459be-39bd-4124-817c-39c0ff43eaf1	Flee Market	2026-04-01	2026-04-01
4271fee3-2f5c-48c1-9dca-89aee4eca328	ead9e32d-60d8-4a4f-91cb-3eaeb1932e2e	a5b430bb-3948-4657-8189-7b173a4a088f	Guest Parking Rent	2026-07-01	2026-07-01
b2a62471-74de-46ea-a4ee-43123e9bf6d9	4d19088c-90d3-4860-9959-125c588b4a4a	9cf9b1a4-04cc-4952-b1b9-c533d40c7c66	Late Payment Fine	2026-04-01	2026-07-01
fa5d00ff-d54a-4d76-bdb7-591fd0289971	e10f843b-66c7-40eb-bbd2-d4730a96e2e7	9f6a80c0-f487-4841-97f7-b06fa094f69d	Lift Advertisement	2026-04-01	2026-07-01
0282e3ed-5d26-4850-9cbd-d22464346550	9b604036-0610-4951-a32e-bd03f6504379	9f277c34-924b-4eca-8551-8c8e08a783bd	Maintenance Charge	2026-04-01	2026-07-01
110eb848-cc05-4266-b8ca-3f2a88bd34a2	144d1ef1-81d3-4f4d-9770-e7534d41467d	85c8d89d-5aa7-4319-b1f6-0247dbdbdf5c	Move In/Out (Manual)	2026-07-01	2026-07-01
a5457cbd-41d6-4390-9f17-d04e0c340f0c	144d1ef1-81d3-4f4d-9770-e7534d41467d	85c8d89d-5aa7-4319-b1f6-0247dbdbdf5c	Move in/out Charges	2026-04-01	2026-07-01
d17ab99e-5e50-4e62-8b29-0e53525726e6	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	Multipurpose Party Hall/Club House	2026-04-01	2026-07-01
0f6e4457-a177-4cd3-b30a-dfedd6a18c8f	4d19088c-90d3-4860-9959-125c588b4a4a	9cf9b1a4-04cc-4952-b1b9-c533d40c7c66	Parking Violation	2026-06-01	2026-06-01
123be2ff-cb9b-482b-b6a2-701d7bc3c311	74fbad0f-a4bf-4cc7-9092-1566c2ecffa5	a6ab6752-bf2d-4310-85c9-e099922f6644	SGST Output	2026-04-01	2026-07-01
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp_codes (email, otp_hash, expires_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periods (id, community_id, month, status) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, community_id, txn_date, period_month, head_id, category_id, vendor_id, line_item_id, flat_id, amount_paise, direction, source, source_ref, notes, created_by, created_at, updated_at) FROM stdin;
c3836b31-bdad-4492-b4b6-b3f0e2a37f42	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	14dd9bc7-f3da-4078-a2de-594ac0bd2179	479ad244-f74e-4ab7-adcb-40d8e8bf9e60	\N	121482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
3bf061a4-9607-446b-91bb-1eab5b64bfaa	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	14dd9bc7-f3da-4078-a2de-594ac0bd2179	479ad244-f74e-4ab7-adcb-40d8e8bf9e60	\N	141482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
cc4d0b87-3b4a-48ad-b307-088ac2efc724	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	14dd9bc7-f3da-4078-a2de-594ac0bd2179	479ad244-f74e-4ab7-adcb-40d8e8bf9e60	\N	142898	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
e5a05a03-741d-47b6-bf53-15b49e22626b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	14dd9bc7-f3da-4078-a2de-594ac0bd2179	479ad244-f74e-4ab7-adcb-40d8e8bf9e60	\N	141482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
5b585502-4a22-4314-9b68-280c76fc7315	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	53cf5f61-e610-46c1-945b-7f2e46e4754d	6bd75c2a-5879-4c10-be28-135d8133d8f1	8805facc-d869-4d4a-adc8-5c59d1492d7b	\N	6104900	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
fe803f72-0bda-449a-94e0-f924490542de	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	53cf5f61-e610-46c1-945b-7f2e46e4754d	6bd75c2a-5879-4c10-be28-135d8133d8f1	8805facc-d869-4d4a-adc8-5c59d1492d7b	\N	759036	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
04c202e9-1136-43df-83a7-cf156e8aa3c6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	53cf5f61-e610-46c1-945b-7f2e46e4754d	6bd75c2a-5879-4c10-be28-135d8133d8f1	8805facc-d869-4d4a-adc8-5c59d1492d7b	\N	1201834	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
72281a23-99a2-4ec1-8e91-2c45c5391f4a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	53cf5f61-e610-46c1-945b-7f2e46e4754d	6bd75c2a-5879-4c10-be28-135d8133d8f1	8805facc-d869-4d4a-adc8-5c59d1492d7b	\N	445504	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
1df5a98e-038d-498a-87a8-320744a16bc3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	b651b6fe-42b5-4f5b-90e0-85077abdd5f4	86fc9cff-4f24-4d86-84c3-d87e9ac9b393	4e104ff6-e52c-477c-8347-b33b2f4e3724	\N	3000000	D	csv	D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
526a2b8d-1f53-421e-ae39-0e11e2d3980d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	b651b6fe-42b5-4f5b-90e0-85077abdd5f4	86fc9cff-4f24-4d86-84c3-d87e9ac9b393	4e104ff6-e52c-477c-8347-b33b2f4e3724	\N	15000000	D	csv	D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
74b56b32-a48e-4a64-b502-2685df788ff0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	111276b4-d3ba-41ae-bf64-3b069da87ae3	\N	5500000	D	csv	D|Facility Management|EXOZEN|Annual Compliance Expense|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
aa949cb7-4b0b-498e-bf95-fb60e3e6b995	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	641c57b5-b0e4-41dd-b615-a268d75943be	\N	15499900	D	csv	D|Utilities|BESCOM|BESCOM A Block|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
caeeaede-7767-4fc9-a2fc-7930ddf614b7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	641c57b5-b0e4-41dd-b615-a268d75943be	\N	17590200	D	csv	D|Utilities|BESCOM|BESCOM A Block|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
33a6acf4-b33a-47b5-9481-dafabb39ab81	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	9ed0bc9d-6093-47fd-8641-9d496eca5ded	\N	4613000	D	csv	D|Utilities|BESCOM|BESCOM B Block|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
69d825a8-25c3-47bb-96dc-96f08c8b7232	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	9ed0bc9d-6093-47fd-8641-9d496eca5ded	\N	4301100	D	csv	D|Utilities|BESCOM|BESCOM B Block|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
71ca0298-3fe6-4318-9fc9-f0b6b8c2f7d2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	e3b01f1f-475f-4538-a42f-99ad5e1ebad1	\N	7969200	D	csv	D|Utilities|BESCOM|BESCOM E Block|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
07b162e7-6194-47b3-ae14-4caf6a99f8c0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	e3b01f1f-475f-4538-a42f-99ad5e1ebad1	\N	10243100	D	csv	D|Utilities|BESCOM|BESCOM E Block|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
71663786-da42-41fb-9448-a2844926fed3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	e9ba7392-ae29-497d-9c63-67dddb96286a	\N	7896600	D	csv	D|Utilities|BESCOM|BESCOM G Block|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
504ae9ab-d2e4-47da-87a6-10567471b772	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	e9ba7392-ae29-497d-9c63-67dddb96286a	\N	10157200	D	csv	D|Utilities|BESCOM|BESCOM G Block|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
9a725fbd-2605-4501-b05e-68b2f61043a9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	445a13ad-d789-43c8-9363-5efe7fb2e312	383b2e90-a014-4f30-82e6-1fd5666b0160	eb9ef5b3-3602-49c3-8a19-1eab04f4bd01	\N	900000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
13e345d3-deee-4b7a-87a5-208098a8b953	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	445a13ad-d789-43c8-9363-5efe7fb2e312	383b2e90-a014-4f30-82e6-1fd5666b0160	eb9ef5b3-3602-49c3-8a19-1eab04f4bd01	\N	1930000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
efa78866-fb6d-43ed-a35c-eb2fbdb148ba	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	445a13ad-d789-43c8-9363-5efe7fb2e312	383b2e90-a014-4f30-82e6-1fd5666b0160	eb9ef5b3-3602-49c3-8a19-1eab04f4bd01	\N	2040000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
a84754bc-f24e-4c75-9088-dd9ae89fa546	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	b651b6fe-42b5-4f5b-90e0-85077abdd5f4	4a8ce38d-d651-47b2-b91d-a0e39b435feb	863c67f6-c259-454e-8a00-2c6e8350f9cc	\N	1287627	D	csv	D|Maintenance|KIRLOSKAR OIL ENGINES LTD|DG Service|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
bba38ff2-2a53-4ddb-a169-797e40262156	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	441a4619-a7bb-4ce1-b1c7-ff7032fedf39	c1f2891f-92f0-4d84-b71f-efc20f20e3c4	\N	9140100	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
447d7d23-9f73-4ee2-956f-13a1722cdd61	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	441a4619-a7bb-4ce1-b1c7-ff7032fedf39	c1f2891f-92f0-4d84-b71f-efc20f20e3c4	\N	5482200	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
877f12f9-21c1-48ec-8122-eec8f4085dc7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	441a4619-a7bb-4ce1-b1c7-ff7032fedf39	c1f2891f-92f0-4d84-b71f-efc20f20e3c4	\N	5978400	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
d8c8b63f-e768-4abe-b1c5-b43920037fbf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	441a4619-a7bb-4ce1-b1c7-ff7032fedf39	c1f2891f-92f0-4d84-b71f-efc20f20e3c4	\N	5978400	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
a89c42b6-4797-4710-b60d-0b37a3be9bf9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	6dd05d16-a6d2-4c7e-8f26-31c6dc8d2cee	\N	7558830	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
3f020b9f-4079-4948-b970-9856d3b3edf8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	6dd05d16-a6d2-4c7e-8f26-31c6dc8d2cee	\N	8290254	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
7fc38427-6e20-44a0-9fc7-d82261243779	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	6dd05d16-a6d2-4c7e-8f26-31c6dc8d2cee	\N	8650661	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
b72deaba-7a22-4624-aa55-3bfb7fcfacb2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	cb830f20-790d-4857-80f0-4983fa70956d	\N	5942100	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
cb046ceb-2cb8-496a-88c7-7ac917c499d0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	cb830f20-790d-4857-80f0-4983fa70956d	\N	5942111	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
757aa1e1-b4d8-406a-bae0-6ac1755ff23b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	cb830f20-790d-4857-80f0-4983fa70956d	\N	5942100	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
35f28fde-e28f-43d2-b802-6cad2ff4bb26	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	4f38dd81-0e5c-4bca-968d-04cbdade4e75	7ebe22e6-a2e8-4f8c-b8fd-232c6bc8130e	3bbb1855-c8da-4862-b28a-29d2872cabf5	\N	1400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
6d96e1d4-7e12-4c6e-80f1-f4a16bda4bb9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	4f38dd81-0e5c-4bca-968d-04cbdade4e75	7ebe22e6-a2e8-4f8c-b8fd-232c6bc8130e	3bbb1855-c8da-4862-b28a-29d2872cabf5	\N	2400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
84951585-8c15-4989-bdfe-2a42c1556816	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	4f38dd81-0e5c-4bca-968d-04cbdade4e75	7ebe22e6-a2e8-4f8c-b8fd-232c6bc8130e	3bbb1855-c8da-4862-b28a-29d2872cabf5	\N	2400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
567ce237-78a5-45cd-b2f4-4914f50b57d1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	e6c10b7b-c30e-4778-a943-63948071ad43	7e82cb08-a65a-40f5-b796-db0982e22742	e0f2d51b-6920-4ccd-a686-73633b4f66c0	\N	2028000	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
05cd1f3a-830a-4841-9935-b5d4d00d8c84	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	e6c10b7b-c30e-4778-a943-63948071ad43	7e82cb08-a65a-40f5-b796-db0982e22742	e0f2d51b-6920-4ccd-a686-73633b4f66c0	\N	13000	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
e60f78e7-930b-404a-a6bc-4ba9a2d602b8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	e6c10b7b-c30e-4778-a943-63948071ad43	7e82cb08-a65a-40f5-b796-db0982e22742	e0f2d51b-6920-4ccd-a686-73633b4f66c0	\N	149100	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
ab85091d-d7f7-4a06-a74a-ac44c8c2ec0f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	db8036a6-9897-4e77-bd1e-5ebd45bb0071	\N	8342100	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
c12e4a1b-bab6-4228-8d87-bdeaa194061b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	db8036a6-9897-4e77-bd1e-5ebd45bb0071	\N	8756100	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
3352f4e7-6cd1-46ed-8e76-d3147c0cb842	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	db8036a6-9897-4e77-bd1e-5ebd45bb0071	\N	8534610	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
f3845938-3cb6-477c-856f-1fbe69e95721	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	a1df572b-ab68-4315-94a6-0780c8a31cdc	\N	2447107	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
d96b3c77-44eb-4cd0-956d-f593cfcad508	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	a1df572b-ab68-4315-94a6-0780c8a31cdc	\N	2368169	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
c9e1afb2-0df2-402a-a4e1-c2528155e620	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	a1df572b-ab68-4315-94a6-0780c8a31cdc	\N	2362724	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
9ce81bfa-795a-4208-b9a2-1a19874f9864	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	453aa025-5a8d-47e0-b513-62cc66679b8e	\N	2294808	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
4f60ad25-66df-42cc-a13f-5f78f2eb5bdf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	453aa025-5a8d-47e0-b513-62cc66679b8e	\N	2775960	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
8e9bfa55-e0df-4440-9b75-f7c25693828d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	453aa025-5a8d-47e0-b513-62cc66679b8e	\N	2486042	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
031e02a7-b630-4844-b42e-6ab663b6c50c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	25f9a05b-05ec-4d02-8ea3-34dbcda0bbff	\N	4531700	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
615864cd-be1c-4772-9e49-81fd3ced556c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	25f9a05b-05ec-4d02-8ea3-34dbcda0bbff	\N	3485760	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
092b8095-9dac-448f-9ce0-7de529f27585	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	25f9a05b-05ec-4d02-8ea3-34dbcda0bbff	\N	57500	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
2baecafb-f7c5-4564-8171-b110f9d33ec7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	28c5019f-fce4-4082-82c4-c38a5f690f0b	\N	23671704	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
4753ba69-41ed-4de5-b79c-1ff0470a332e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	28c5019f-fce4-4082-82c4-c38a5f690f0b	\N	31381743	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
cedb5f4a-4560-42ff-8678-96979729562c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	28c5019f-fce4-4082-82c4-c38a5f690f0b	\N	32307045	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
4eb9a212-7d08-49eb-be22-e9d7154445b5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	fce6d4c5-9fbd-4f26-9689-1a47267bdfcf	\N	2420409	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
d9873969-1c07-40ad-8044-6b246ed0d6f0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	fce6d4c5-9fbd-4f26-9689-1a47267bdfcf	\N	1639701	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
045a6f61-8da2-4687-b729-c13052dab268	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	fce6d4c5-9fbd-4f26-9689-1a47267bdfcf	\N	2339807	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
aa57bc47-8a7a-4fc1-8987-c02061a91ba5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	5c0f10a2-55db-46d6-b2c4-c879024b5e10	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
858cec25-7e09-4a86-bdcc-89e2172dc3bc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	5c0f10a2-55db-46d6-b2c4-c879024b5e10	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
ca7df229-e28c-4364-9743-0404d314bdd2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	5c0f10a2-55db-46d6-b2c4-c879024b5e10	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
95f4a73e-0120-49e0-8d0c-fa1a3a1caf52	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	53cf5f61-e610-46c1-945b-7f2e46e4754d	780d88dd-22cf-4524-a66c-f88d23261b15	0f99103c-0fae-42f7-aa71-2357615ef35b	\N	200000	D	csv	D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
7ca731d0-e75a-4e1f-8d70-68faf3dd5781	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	53cf5f61-e610-46c1-945b-7f2e46e4754d	780d88dd-22cf-4524-a66c-f88d23261b15	0f99103c-0fae-42f7-aa71-2357615ef35b	\N	5269400	D	csv	D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
092af1ec-267d-454a-80cf-7cbcf9dce389	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	298661bd-8bf8-4217-b04b-1c6ebcae7e2d	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
7760ddc3-9b52-43db-9831-a7177bddb0c8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	298661bd-8bf8-4217-b04b-1c6ebcae7e2d	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
4d741c45-dbed-41ee-811b-b6f2065c6d27	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	298661bd-8bf8-4217-b04b-1c6ebcae7e2d	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
2c7a7fa4-fede-4881-a664-3d493f498ff3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	45619c52-3abb-405a-a0f4-1854fffb54a5	\N	1568300	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
785e06fc-8d8b-4698-a6a9-6d8534718bd7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	45619c52-3abb-405a-a0f4-1854fffb54a5	\N	2053800	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
75889cb4-d1b9-4345-8023-23a6d1308b7d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	45619c52-3abb-405a-a0f4-1854fffb54a5	\N	2960000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
77ec4c22-b406-4611-a366-7e13da5a19cd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	45619c52-3abb-405a-a0f4-1854fffb54a5	\N	1471200	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
7d50f80c-7c04-497c-b1e9-a55d58201445	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	ecada750-25a5-421c-8a55-38e75fd51880	\N	29500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
86f8870a-92b8-4c1e-b4fb-bc2a8f608c9e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	ecada750-25a5-421c-8a55-38e75fd51880	\N	648700	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
4043bf23-6adb-4b66-89d9-96518392fb22	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	ecada750-25a5-421c-8a55-38e75fd51880	\N	500000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
9d0e203d-5dad-44ed-b7c7-0b7eeef74feb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	ecada750-25a5-421c-8a55-38e75fd51880	\N	44400	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
14423363-6523-41a9-a250-d265817e2e18	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	61952cd1-d52b-4a10-becc-2f5822f9a21b	\N	75500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
175c492d-925b-4015-a834-ee251b0ac8f9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	61952cd1-d52b-4a10-becc-2f5822f9a21b	\N	1891700	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
9e45bc57-1bfd-4e4e-bb33-b066cf92595c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	61952cd1-d52b-4a10-becc-2f5822f9a21b	\N	536500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
67e9a7eb-261d-45b6-bd6b-016145937860	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	cf573b1c-9906-4002-b262-e5afe2f25cbc	780d88dd-22cf-4524-a66c-f88d23261b15	61952cd1-d52b-4a10-becc-2f5822f9a21b	\N	101500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
dd1183cb-cac4-4abd-9762-038781b69dd6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	51f50722-e7fe-4d7f-b250-aacc233c6b07	\N	7558830	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
5052ee9c-d93b-4a9c-bb13-90cb21a97f58	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	51f50722-e7fe-4d7f-b250-aacc233c6b07	\N	8696639	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
78c68a3d-5625-4f8d-ae9c-7b6a7b476cfc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	51f50722-e7fe-4d7f-b250-aacc233c6b07	\N	8566674	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
57af0e26-f1b9-40c2-8585-5e5d6063a5dd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	6bfb437e-72a8-4882-a334-1ca48ce21450	\N	65000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
8eeb95e5-3474-4e30-8123-24aa7d889927	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	6bfb437e-72a8-4882-a334-1ca48ce21450	\N	665000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
19707ca5-249d-404b-856d-6d19adb64e19	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	6bfb437e-72a8-4882-a334-1ca48ce21450	\N	65000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
98472ba5-3a04-48e4-81c3-a0aeb9c89b7b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	5fdb3800-c0d2-4dfe-a66a-6f209fe2da25	\N	1733400	D	csv	D|Facility Management|EXOZEN|Repair Work|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
90a79bbe-0b07-406c-945f-e2f525520838	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	5fdb3800-c0d2-4dfe-a66a-6f209fe2da25	\N	800000	D	csv	D|Facility Management|EXOZEN|Repair Work|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
f18e5404-bb0e-4e8b-820c-605a75d44fa0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	b2e0fca3-2454-4d3a-a063-7a828c2e7769	23de0f0a-6ab1-45f7-9838-681be086d535	9d206f1e-6bac-4ba7-ab0a-70a47181a2cf	\N	41	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
e9ce16f8-4f47-47f2-8055-a2429f420d5c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	b2e0fca3-2454-4d3a-a063-7a828c2e7769	23de0f0a-6ab1-45f7-9838-681be086d535	9d206f1e-6bac-4ba7-ab0a-70a47181a2cf	\N	21	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
124a7eae-371d-4c9d-a794-f591fe660239	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	b2e0fca3-2454-4d3a-a063-7a828c2e7769	23de0f0a-6ab1-45f7-9838-681be086d535	9d206f1e-6bac-4ba7-ab0a-70a47181a2cf	\N	10	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
6bebd5cd-268b-4937-a85b-91953545a7eb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	43346a16-60a0-4ac8-a9ed-7d1dd263c91a	\N	36113050	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
6cdf70e1-fce5-4e09-93cd-b02a905966f7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	43346a16-60a0-4ac8-a9ed-7d1dd263c91a	\N	37367925	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
a3d8b296-c80b-4259-abaf-0ed2995b9cb0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	43346a16-60a0-4ac8-a9ed-7d1dd263c91a	\N	37584050	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
9879e757-b6a6-4023-9a8a-d8a096eaa17f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	c7f73e14-a309-425b-a937-f333949bc157	\N	2206500	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
6d6bdfc8-f6c8-488f-8caa-9165d0a3bea1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	c7f73e14-a309-425b-a937-f333949bc157	\N	2206487	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
e317f745-627a-44e4-88dd-46f7217bec45	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	c7f73e14-a309-425b-a937-f333949bc157	\N	2132950	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
dfeeacb7-7d55-4179-afa8-9b061258dd3f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	cc95475a-89e1-47d8-a31f-c785dde0b0ef	\N	5164270	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
57978025-2f17-4523-9d1b-5d739409ecfb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	cc95475a-89e1-47d8-a31f-c785dde0b0ef	\N	5421184	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
21366fd0-0d16-4c03-b8e8-9a8dcd7493fe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	cc95475a-89e1-47d8-a31f-c785dde0b0ef	\N	5251800	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
fbe4287a-1cec-4929-b41c-e19a325ff96f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	9b08e0e8-3a56-4995-b348-538968d9a305	096b53ec-4640-42d3-a81a-1e5c148b1ec8	4282a0da-031e-48ff-8bc5-9e3406b63d1f	\N	8600000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
44e0bdfe-a0b2-4438-85b2-cec15fa6715b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	9b08e0e8-3a56-4995-b348-538968d9a305	096b53ec-4640-42d3-a81a-1e5c148b1ec8	4282a0da-031e-48ff-8bc5-9e3406b63d1f	\N	9400000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
6bafc600-4925-4c8f-ac13-ae959e1a95b8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	9b08e0e8-3a56-4995-b348-538968d9a305	096b53ec-4640-42d3-a81a-1e5c148b1ec8	4282a0da-031e-48ff-8bc5-9e3406b63d1f	\N	11800000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
db1fb2cd-007e-498b-9858-cb0cc381d589	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	882bd661-5456-4caa-b03f-e7eb2bfae531	\N	6771870	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
1631e92b-69d0-4929-8f51-1a53edd3dafb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	882bd661-5456-4caa-b03f-e7eb2bfae531	\N	7063152	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
ce37d762-ab48-465b-9858-c705acefe49b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	882bd661-5456-4caa-b03f-e7eb2bfae531	\N	7599543	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
7bd06439-e330-46e0-a055-ba2d9a99bf35	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	cbe7dd19-a0f6-4a7c-99ed-89da1617bcbf	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
c5832a00-afd4-426a-9bee-25c714438861	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	cbe7dd19-a0f6-4a7c-99ed-89da1617bcbf	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
64d805f6-35a6-4e7d-9970-d3a714f19fe4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	cbe7dd19-a0f6-4a7c-99ed-89da1617bcbf	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
2301ddf9-d21d-4934-9867-7e9501cc04ae	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	1c901f91-7ac5-41ef-a6f6-e3433c020b97	\N	6300000	D	csv	D|Facility Management|EXOZEN|Tank Cleaning Charges|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
9ebb2d2c-d7a7-496a-a0e7-169e4e38f8fc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	53cf5f61-e610-46c1-945b-7f2e46e4754d	780d88dd-22cf-4524-a66c-f88d23261b15	675ba1a2-8ab7-4d71-b4e8-dcde2d170dcb	\N	903200	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
c5274895-33af-4648-a1a0-55dc58cfdb15	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	53cf5f61-e610-46c1-945b-7f2e46e4754d	780d88dd-22cf-4524-a66c-f88d23261b15	675ba1a2-8ab7-4d71-b4e8-dcde2d170dcb	\N	74000	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
d5052ce5-ecdd-47cf-92aa-98fcd1956892	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	53cf5f61-e610-46c1-945b-7f2e46e4754d	780d88dd-22cf-4524-a66c-f88d23261b15	675ba1a2-8ab7-4d71-b4e8-dcde2d170dcb	\N	10500	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
650a09b6-78ab-45be-a450-bd9d672857b8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	bf5afcb9-9218-4a93-8907-275d8c3cc7db	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
944e8395-6282-4a32-90f3-f47cca639ef3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	bf5afcb9-9218-4a93-8907-275d8c3cc7db	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
e2b18554-48a9-4834-8997-1e81031bb543	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	b9fd7a25-8774-4719-845c-ca86930b7b0c	fb22c951-673c-49a8-9189-25b89b4f762e	\N	46581500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
bdba32be-1d93-4694-888e-24dae9118dae	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	b9fd7a25-8774-4719-845c-ca86930b7b0c	fb22c951-673c-49a8-9189-25b89b4f762e	\N	47899500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
8dbe598c-41ea-43c2-a99b-6fc2392d0385	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	a7549b62-113c-499f-a021-3fe892ed9397	b9fd7a25-8774-4719-845c-ca86930b7b0c	fb22c951-673c-49a8-9189-25b89b4f762e	\N	51577500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
98eefc7a-eec9-4199-a4e7-c8688a1a6e2c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	8f53a4c8-62f8-4158-8483-d4f3c79bf742	\N	620000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
320f6042-5bf8-405d-b346-e677c7542ec0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	8f53a4c8-62f8-4158-8483-d4f3c79bf742	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
23799efa-3869-4a7a-b6c7-9888903e9a9d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	7936370a-7a31-405b-a996-ff3f3c2efbb8	ad42913d-f55b-46b7-a7c7-1c3737fb109d	ff576835-443d-4548-9277-ff605f2990cd	8f53a4c8-62f8-4158-8483-d4f3c79bf742	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
503a6f73-a446-46b3-a861-5ee074bf51ea	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	b4582c71-8f74-4223-b662-e687cc2a02d9	c169281b-50da-4e31-9b83-1672ea3da92e	aeb2fa07-ed15-4da6-adb2-66713bd1cb41	\N	500000	C	csv	C|Community Contributions|Residents|Association Fund|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
a5ba715c-6d58-4900-8496-318740ddf15b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	b4582c71-8f74-4223-b662-e687cc2a02d9	c169281b-50da-4e31-9b83-1672ea3da92e	aeb2fa07-ed15-4da6-adb2-66713bd1cb41	\N	370000	C	csv	C|Community Contributions|Residents|Association Fund|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
09d54ac9-0ece-47aa-b2a1-986a7ed3ff31	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	b4582c71-8f74-4223-b662-e687cc2a02d9	c169281b-50da-4e31-9b83-1672ea3da92e	aeb2fa07-ed15-4da6-adb2-66713bd1cb41	\N	1950000	C	csv	C|Community Contributions|Residents|Association Fund|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
7f52cf8f-e7ef-493b-a4a2-a31f30282ad0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	61d5786f-27f3-4d01-b6a4-513a882eb698	\N	280000	C	csv	C|Facility Rental|Amenities|AV room|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
87420a63-879b-4861-af16-c7f8674c2aed	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	61d5786f-27f3-4d01-b6a4-513a882eb698	\N	350000	C	csv	C|Facility Rental|Amenities|AV room|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
7494cff6-8917-4971-805e-9c8b0a79783e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	61d5786f-27f3-4d01-b6a4-513a882eb698	\N	210000	C	csv	C|Facility Rental|Amenities|AV room|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
904d4bc5-9988-40f0-81bb-1ba867bee3b3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	61d5786f-27f3-4d01-b6a4-513a882eb698	\N	280000	C	csv	C|Facility Rental|Amenities|AV room|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
8346ac07-a210-414a-975e-d4234baf530d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	ced455d9-fc70-4830-8aa2-6380e8e6f4e5	\N	112000	C	csv	C|Facility Rental|Amenities|Business Center|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
b3268719-0de7-4376-843a-c8fcddda6c69	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	ced455d9-fc70-4830-8aa2-6380e8e6f4e5	\N	108000	C	csv	C|Facility Rental|Amenities|Business Center|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
d32bc2ab-c7d6-4103-bff6-78cdc4878036	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	ced455d9-fc70-4830-8aa2-6380e8e6f4e5	\N	100000	C	csv	C|Facility Rental|Amenities|Business Center|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
5d34feb6-32a4-4d73-addc-932d064a0c56	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	74fbad0f-a4bf-4cc7-9092-1566c2ecffa5	a6ab6752-bf2d-4310-85c9-e099922f6644	3b057770-04fa-44e1-bad0-87df3c49d375	\N	1274040	C	csv	C|Tax|Tax Collection|CGST Output|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
18222a71-1371-460a-8461-008b3eb956f9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	74fbad0f-a4bf-4cc7-9092-1566c2ecffa5	a6ab6752-bf2d-4310-85c9-e099922f6644	3b057770-04fa-44e1-bad0-87df3c49d375	\N	759200	C	csv	C|Tax|Tax Collection|CGST Output|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
f27390f6-32a3-47eb-937d-3ff503327c2b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	74fbad0f-a4bf-4cc7-9092-1566c2ecffa5	a6ab6752-bf2d-4310-85c9-e099922f6644	3b057770-04fa-44e1-bad0-87df3c49d375	\N	532800	C	csv	C|Tax|Tax Collection|CGST Output|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
169f1cff-bdff-44da-b99b-63690b309e47	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	74fbad0f-a4bf-4cc7-9092-1566c2ecffa5	a6ab6752-bf2d-4310-85c9-e099922f6644	3b057770-04fa-44e1-bad0-87df3c49d375	\N	868000	C	csv	C|Tax|Tax Collection|CGST Output|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
1b84ad68-a84e-4d4d-94b4-ca9b83bfa4af	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	4d19088c-90d3-4860-9959-125c588b4a4a	9cf9b1a4-04cc-4952-b1b9-c533d40c7c66	0e82cec9-bd45-4cea-9c57-0f659283d0e5	\N	100000	C	csv	C|Penalties|Resident Penalties|Common Area Violation|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
dbae9322-c831-4b7e-a2a1-2ba09573cdbe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	4d19088c-90d3-4860-9959-125c588b4a4a	9cf9b1a4-04cc-4952-b1b9-c533d40c7c66	0e82cec9-bd45-4cea-9c57-0f659283d0e5	\N	600000	C	csv	C|Penalties|Resident Penalties|Common Area Violation|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
1dc35d7d-2dc1-4614-93d6-e6b23ad81058	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	786617d2-406e-47c7-8549-cb48082a8f4f	ba8459be-39bd-4124-817c-39c0ff43eaf1	13bdddd6-d7aa-4c98-a019-8284bd552753	\N	817900	C	csv	C|Events|Community Events|Community Curriculum Activities|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
c08f5049-4295-4d0b-9ba0-450280571b5f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	18c54d0c-f7cb-40be-b791-7636371cfeb1	ba93a1f5-de89-4992-9430-3a689b11a5c1	05c554b7-3e67-495e-a6ce-e0a267d180d5	\N	100000	C	csv	C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
0495dfb0-b2db-43a6-92d6-ce23d4d565cd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	18c54d0c-f7cb-40be-b791-7636371cfeb1	ba93a1f5-de89-4992-9430-3a689b11a5c1	05c554b7-3e67-495e-a6ce-e0a267d180d5	\N	230400	C	csv	C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
048b28c7-7699-4240-a638-07772048459a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	786617d2-406e-47c7-8549-cb48082a8f4f	ba8459be-39bd-4124-817c-39c0ff43eaf1	964be112-bb2b-4355-9c7f-e484d7adc381	\N	1600000	C	csv	C|Events|Community Events|Flee Market|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
efbf1f67-3032-4f52-bdd9-11197466e728	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	ead9e32d-60d8-4a4f-91cb-3eaeb1932e2e	a5b430bb-3948-4657-8189-7b173a4a088f	4271fee3-2f5c-48c1-9dca-89aee4eca328	\N	100000	C	csv	C|Parking Revenue|Parking Services|Guest Parking Rent|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
11878f17-3910-476c-bffe-21e55cb4200a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	4d19088c-90d3-4860-9959-125c588b4a4a	9cf9b1a4-04cc-4952-b1b9-c533d40c7c66	b2a62471-74de-46ea-a4ee-43123e9bf6d9	\N	15172500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
fce70e84-1801-4b0b-b768-ef2f975fb27e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	4d19088c-90d3-4860-9959-125c588b4a4a	9cf9b1a4-04cc-4952-b1b9-c533d40c7c66	b2a62471-74de-46ea-a4ee-43123e9bf6d9	\N	9522500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
d9307f4a-030c-4190-9d2f-6bfb3d1b4f18	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	4d19088c-90d3-4860-9959-125c588b4a4a	9cf9b1a4-04cc-4952-b1b9-c533d40c7c66	b2a62471-74de-46ea-a4ee-43123e9bf6d9	\N	6840000	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
ff9ce1ae-3bb7-4b7c-9371-904e80f5d14f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	4d19088c-90d3-4860-9959-125c588b4a4a	9cf9b1a4-04cc-4952-b1b9-c533d40c7c66	b2a62471-74de-46ea-a4ee-43123e9bf6d9	\N	10817500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
16375c83-334f-4d01-a271-3fd08fd70443	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	e10f843b-66c7-40eb-bbd2-d4730a96e2e7	9f6a80c0-f487-4841-97f7-b06fa094f69d	fa5d00ff-d54a-4d76-bdb7-591fd0289971	\N	990000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
34db5800-9fe3-42da-a5c7-f9702a21b162	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	e10f843b-66c7-40eb-bbd2-d4730a96e2e7	9f6a80c0-f487-4841-97f7-b06fa094f69d	fa5d00ff-d54a-4d76-bdb7-591fd0289971	\N	550000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
1a4cf402-f5e1-4657-930a-0b46f9737d32	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	e10f843b-66c7-40eb-bbd2-d4730a96e2e7	9f6a80c0-f487-4841-97f7-b06fa094f69d	fa5d00ff-d54a-4d76-bdb7-591fd0289971	\N	330000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
2b6ddf38-d7ca-4e38-ae8e-8d1deca29073	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	9b604036-0610-4951-a32e-bd03f6504379	9f277c34-924b-4eca-8551-8c8e08a783bd	0282e3ed-5d26-4850-9cbd-d22464346550	\N	283327400	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
81b9ebb7-aa04-4d76-ba82-acc162e12e56	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	9b604036-0610-4951-a32e-bd03f6504379	9f277c34-924b-4eca-8551-8c8e08a783bd	0282e3ed-5d26-4850-9cbd-d22464346550	\N	283885405	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
1bf0c52f-31d9-4325-895c-4c4b6582a37a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	9b604036-0610-4951-a32e-bd03f6504379	9f277c34-924b-4eca-8551-8c8e08a783bd	0282e3ed-5d26-4850-9cbd-d22464346550	\N	270711506	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
6253ba3b-0b38-4820-b3e5-b4a2a1c4a2c1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	9b604036-0610-4951-a32e-bd03f6504379	9f277c34-924b-4eca-8551-8c8e08a783bd	0282e3ed-5d26-4850-9cbd-d22464346550	\N	274879441	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
4c961d8d-16a9-4fa7-9ce3-b8410eb03abf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	144d1ef1-81d3-4f4d-9770-e7534d41467d	85c8d89d-5aa7-4319-b1f6-0247dbdbdf5c	110eb848-cc05-4266-b8ca-3f2a88bd34a2	\N	750000	C	csv	C|Move Charges|Resident Services|Move In/Out (Manual)|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
1b6df278-edc1-45b8-b2ca-489300097ac8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	144d1ef1-81d3-4f4d-9770-e7534d41467d	85c8d89d-5aa7-4319-b1f6-0247dbdbdf5c	a5457cbd-41d6-4390-9f17-d04e0c340f0c	\N	3500000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
a0bbb422-4f0f-4563-825f-6ecefcbed9d2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	144d1ef1-81d3-4f4d-9770-e7534d41467d	85c8d89d-5aa7-4319-b1f6-0247dbdbdf5c	a5457cbd-41d6-4390-9f17-d04e0c340f0c	\N	2000000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
6c987b22-a34b-4f66-8d39-f99705f3c01a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	144d1ef1-81d3-4f4d-9770-e7534d41467d	85c8d89d-5aa7-4319-b1f6-0247dbdbdf5c	a5457cbd-41d6-4390-9f17-d04e0c340f0c	\N	3000000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
ece2509b-96c9-4d91-918c-01f3f7b0c9bb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	144d1ef1-81d3-4f4d-9770-e7534d41467d	85c8d89d-5aa7-4319-b1f6-0247dbdbdf5c	a5457cbd-41d6-4390-9f17-d04e0c340f0c	\N	500000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
8a68bdda-a938-4f08-adad-401fd8ff7c66	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	d17ab99e-5e50-4e62-8b29-0e53525726e6	\N	1200000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
34d0ee7f-b219-482a-bd8f-36a696a7ebf2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	d17ab99e-5e50-4e62-8b29-0e53525726e6	\N	2700000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
9bae3709-66b0-41e1-8680-72f76d9e73f4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	d17ab99e-5e50-4e62-8b29-0e53525726e6	\N	2100000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
a71dd24d-bbb6-495f-9343-10b3541b3460	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	75fa9e93-49f2-446b-b908-07dc56260197	9fc574d3-ed4c-455a-9438-99a3595595b1	d17ab99e-5e50-4e62-8b29-0e53525726e6	\N	2400000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
6f473f20-9c2c-487e-9a54-5cc9492fddc5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	4d19088c-90d3-4860-9959-125c588b4a4a	9cf9b1a4-04cc-4952-b1b9-c533d40c7c66	0f6e4457-a177-4cd3-b30a-dfedd6a18c8f	\N	100000	C	csv	C|Penalties|Resident Penalties|Parking Violation|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
526e4374-714b-49d3-8b57-000afb85dea6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	74fbad0f-a4bf-4cc7-9092-1566c2ecffa5	a6ab6752-bf2d-4310-85c9-e099922f6644	123be2ff-cb9b-482b-b6a2-701d7bc3c311	\N	1274040	C	csv	C|Tax|Tax Collection|SGST Output|2026-04	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
060efb38-992d-450c-b819-5abae4e29f29	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	74fbad0f-a4bf-4cc7-9092-1566c2ecffa5	a6ab6752-bf2d-4310-85c9-e099922f6644	123be2ff-cb9b-482b-b6a2-701d7bc3c311	\N	759200	C	csv	C|Tax|Tax Collection|SGST Output|2026-05	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
e1888389-af14-4c71-a73f-956d141a1c6a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	74fbad0f-a4bf-4cc7-9092-1566c2ecffa5	a6ab6752-bf2d-4310-85c9-e099922f6644	123be2ff-cb9b-482b-b6a2-701d7bc3c311	\N	532800	C	csv	C|Tax|Tax Collection|SGST Output|2026-06	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
31af782e-afb6-4bac-982f-50b9085a1fde	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	0ea4c5c9-f917-47eb-b9f9-d58def04755b	74fbad0f-a4bf-4cc7-9092-1566c2ecffa5	a6ab6752-bf2d-4310-85c9-e099922f6644	123be2ff-cb9b-482b-b6a2-701d7bc3c311	\N	868000	C	csv	C|Tax|Tax Collection|SGST Output|2026-07	\N	\N	2026-08-03 18:33:00.387859+00	2026-08-03 18:33:00.387859+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	superadmin
0f0c6024-6c4d-47b3-9012-4f714d448a40	admin
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, community_id, email, name, password_hash, last_login_at, created_at) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	caa11b01-c3a5-4067-a90c-b73b35075def	admin@example.com	Super Admin	$argon2id$v=19$m=65536,t=3,p=4$p1fZkWHf2gTDwEWxE6CM8Q$uPbhYQcAe8ts/FxPR9LDBPgAe9SFH99hpbhircC2SAE	2026-08-03 17:59:35.207187+00	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, community_id, name, kind) FROM stdin;
14dd9bc7-f3da-4078-a2de-594ac0bd2179	caa11b01-c3a5-4067-a90c-b73b35075def	Airtel Postpaid	company
6bd75c2a-5879-4c10-be28-135d8133d8f1	caa11b01-c3a5-4067-a90c-b73b35075def	Amazon CG Boulevard RWA	individual
86fc9cff-4f24-4d86-84c3-d87e9ac9b393	caa11b01-c3a5-4067-a90c-b73b35075def	JOHNSON LIFTS Pvt Ltd	company
2919ad71-ac42-4fb8-84f6-39c7bbe9dc77	caa11b01-c3a5-4067-a90c-b73b35075def	BESCOM	company
383b2e90-a014-4f30-82e6-1fd5666b0160	caa11b01-c3a5-4067-a90c-b73b35075def	Individual	individual
4a8ce38d-d651-47b2-b91d-a0e39b435feb	caa11b01-c3a5-4067-a90c-b73b35075def	KIRLOSKAR OIL ENGINES LTD	company
441a4619-a7bb-4ce1-b1c7-ff7032fedf39	caa11b01-c3a5-4067-a90c-b73b35075def	Sai Krupa Petroleum	company
7ebe22e6-a2e8-4f8c-b8fd-232c6bc8130e	caa11b01-c3a5-4067-a90c-b73b35075def	Sewa Waste Management	company
7e82cb08-a65a-40f5-b796-db0982e22742	caa11b01-c3a5-4067-a90c-b73b35075def	Kavitha Enterprises	company
23de0f0a-6ab1-45f7-9838-681be086d535	caa11b01-c3a5-4067-a90c-b73b35075def	System Adjustment	individual
096b53ec-4640-42d3-a81a-1e5c148b1ec8	caa11b01-c3a5-4067-a90c-b73b35075def	Sapthagiri Cleaner	company
780d88dd-22cf-4524-a66c-f88d23261b15	caa11b01-c3a5-4067-a90c-b73b35075def	Petty Cash	individual
b9fd7a25-8774-4719-845c-ca86930b7b0c	caa11b01-c3a5-4067-a90c-b73b35075def	BSN Water Supply	company
ff576835-443d-4548-9277-ff605f2990cd	caa11b01-c3a5-4067-a90c-b73b35075def	EXOZEN	company
c169281b-50da-4e31-9b83-1672ea3da92e	caa11b01-c3a5-4067-a90c-b73b35075def	Residents	individual
ba93a1f5-de89-4992-9430-3a689b11a5c1	caa11b01-c3a5-4067-a90c-b73b35075def	Wellness Programs	individual
ba8459be-39bd-4124-817c-39c0ff43eaf1	caa11b01-c3a5-4067-a90c-b73b35075def	Community Events	individual
a5b430bb-3948-4657-8189-7b173a4a088f	caa11b01-c3a5-4067-a90c-b73b35075def	Parking Services	individual
9f6a80c0-f487-4841-97f7-b06fa094f69d	caa11b01-c3a5-4067-a90c-b73b35075def	Advertising Revenue	individual
9f277c34-924b-4eca-8551-8c8e08a783bd	caa11b01-c3a5-4067-a90c-b73b35075def	Apartment Owners	individual
85c8d89d-5aa7-4319-b1f6-0247dbdbdf5c	caa11b01-c3a5-4067-a90c-b73b35075def	Resident Services	individual
9fc574d3-ed4c-455a-9438-99a3595595b1	caa11b01-c3a5-4067-a90c-b73b35075def	Amenities	individual
9cf9b1a4-04cc-4952-b1b9-c533d40c7c66	caa11b01-c3a5-4067-a90c-b73b35075def	Resident Penalties	individual
a6ab6752-bf2d-4310-85c9-e099922f6644	caa11b01-c3a5-4067-a90c-b73b35075def	Tax Collection	individual
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 3, true);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (name);


--
-- Name: allowed_emails allowed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_pkey PRIMARY KEY (email);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: balances balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_pkey PRIMARY KEY (community_id, month);


--
-- Name: categories categories_head_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_name_key UNIQUE (head_id, name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: collections_dues collections_dues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_pkey PRIMARY KEY (flat_id, period_month);


--
-- Name: communities communities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communities
    ADD CONSTRAINT communities_pkey PRIMARY KEY (id);


--
-- Name: dashboard_settings dashboard_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_pkey PRIMARY KEY (community_id, dashboard_key);


--
-- Name: flats flats_community_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_code_key UNIQUE (community_id, code);


--
-- Name: flats flats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_pkey PRIMARY KEY (id);


--
-- Name: heads heads_community_id_kind_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_kind_name_key UNIQUE (community_id, kind, name);


--
-- Name: heads heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_rules import_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_pkey PRIMARY KEY (id);


--
-- Name: import_staging import_staging_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_pkey PRIMARY KEY (batch_id, row_no);


--
-- Name: line_items line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_pkey PRIMARY KEY (id);


--
-- Name: otp_codes magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (email, otp_hash);


--
-- Name: periods periods_community_id_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_month_key UNIQUE (community_id, month);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_source_source_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_source_source_ref_key UNIQUE (source, source_ref);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_community_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_name_key UNIQUE (community_id, name);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_at ON public.audit_log USING btree (at DESC);


--
-- Name: idx_audit_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_entity ON public.audit_log USING btree (entity, entity_id);


--
-- Name: idx_txn_category_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_category_month ON public.transactions USING btree (category_id, period_month);


--
-- Name: idx_txn_community_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_community_month ON public.transactions USING btree (community_id, period_month);


--
-- Name: idx_txn_flat_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_flat_month ON public.transactions USING btree (flat_id, period_month);


--
-- Name: idx_txn_head_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_head_month ON public.transactions USING btree (head_id, period_month);


--
-- Name: idx_txn_vendor_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_vendor_month ON public.transactions USING btree (vendor_id, period_month);


--
-- Name: line_items_cat_vendor_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX line_items_cat_vendor_name_uq ON public.line_items USING btree (category_id, COALESCE(vendor_id, '00000000-0000-0000-0000-000000000000'::uuid), name);


--
-- Name: mv_cat_monthly_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_cat_monthly_idx ON public.mv_category_monthly USING btree (community_id, month);


--
-- Name: mv_monthly_totals_pk; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mv_monthly_totals_pk ON public.mv_monthly_totals USING btree (community_id, month);


--
-- Name: mv_vendor_ranking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_vendor_ranking_idx ON public.mv_vendor_ranking USING btree (community_id, total_expense_paise DESC);


--
-- Name: allowed_emails allowed_emails_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: allowed_emails allowed_emails_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE SET NULL;


--
-- Name: balances balances_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: categories categories_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id) ON DELETE CASCADE;


--
-- Name: collections_dues collections_dues_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE CASCADE;


--
-- Name: dashboard_settings dashboard_settings_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: flats flats_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: heads heads_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: import_rules import_rules_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_staging import_staging_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE SET NULL;


--
-- Name: periods periods_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: transactions transactions_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id);


--
-- Name: transactions transactions_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id);


--
-- Name: transactions transactions_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_line_item_id_fkey FOREIGN KEY (line_item_id) REFERENCES public.line_items(id);


--
-- Name: transactions transactions_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: vendors vendors_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_category_monthly;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_monthly_totals;


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_vendor_ranking;


--
-- PostgreSQL database dump complete
--

\unrestrict hEZE2RO4RMKbuLNtDX7qWI67HuIkJZUkz7dFjMAAqMHWLqkk71QGDdGtPJ0O444

