--
-- PostgreSQL database dump
--

\restrict a5JOiqH4erEU9LPaEIy2OC0Oo433n6aiC8nuhGogF1jbOf0C7hqeX07jkVp43TV

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_line_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_batch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_actor_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_community_id_fkey;
DROP INDEX IF EXISTS public.mv_vendor_ranking_idx;
DROP INDEX IF EXISTS public.mv_monthly_totals_pk;
DROP INDEX IF EXISTS public.mv_cat_monthly_idx;
DROP INDEX IF EXISTS public.line_items_cat_vendor_name_uq;
DROP INDEX IF EXISTS public.idx_txn_vendor_month;
DROP INDEX IF EXISTS public.idx_txn_head_month;
DROP INDEX IF EXISTS public.idx_txn_flat_month;
DROP INDEX IF EXISTS public.idx_txn_community_month;
DROP INDEX IF EXISTS public.idx_txn_category_month;
DROP INDEX IF EXISTS public.idx_audit_entity;
DROP INDEX IF EXISTS public.idx_audit_at;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_pkey;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_name_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_source_source_ref_key;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_month_key;
ALTER TABLE IF EXISTS ONLY public.otp_codes DROP CONSTRAINT IF EXISTS magic_links_pkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_pkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_pkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_kind_name_key;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_pkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_code_key;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.communities DROP CONSTRAINT IF EXISTS communities_pkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_name_key;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_pkey;
ALTER TABLE IF EXISTS ONLY public._migrations DROP CONSTRAINT IF EXISTS _migrations_pkey;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.periods;
DROP TABLE IF EXISTS public.otp_codes;
DROP MATERIALIZED VIEW IF EXISTS public.mv_vendor_ranking;
DROP TABLE IF EXISTS public.vendors;
DROP MATERIALIZED VIEW IF EXISTS public.mv_monthly_totals;
DROP MATERIALIZED VIEW IF EXISTS public.mv_category_monthly;
DROP TABLE IF EXISTS public.transactions;
DROP TABLE IF EXISTS public.line_items;
DROP TABLE IF EXISTS public.import_staging;
DROP TABLE IF EXISTS public.import_rules;
DROP TABLE IF EXISTS public.import_batches;
DROP TABLE IF EXISTS public.heads;
DROP TABLE IF EXISTS public.flats;
DROP TABLE IF EXISTS public.dashboard_settings;
DROP TABLE IF EXISTS public.communities;
DROP TABLE IF EXISTS public.collections_dues;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.balances;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP TABLE IF EXISTS public.allowed_emails;
DROP TABLE IF EXISTS public._migrations;
DROP TYPE IF EXISTS public.vendor_kind;
DROP TYPE IF EXISTS public.head_kind;
DROP TYPE IF EXISTS public.app_role;
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'resident',
    'admin',
    'superadmin'
);


--
-- Name: head_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.head_kind AS ENUM (
    'income',
    'expense'
);


--
-- Name: vendor_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vendor_kind AS ENUM (
    'company',
    'individual'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    name text NOT NULL,
    run_at timestamp with time zone DEFAULT now()
);


--
-- Name: allowed_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allowed_emails (
    email text NOT NULL,
    community_id uuid NOT NULL,
    role public.app_role NOT NULL,
    flat_id uuid,
    name text,
    invited_by text,
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    community_id uuid,
    actor_user_id uuid,
    actor_email text,
    entity text NOT NULL,
    entity_id text,
    action text NOT NULL,
    before jsonb,
    after jsonb,
    at timestamp with time zone DEFAULT now() NOT NULL,
    ip text,
    user_agent text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balances (
    community_id uuid NOT NULL,
    month date NOT NULL,
    opening_paise bigint DEFAULT 0 NOT NULL,
    closing_paise bigint DEFAULT 0 NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    head_id uuid NOT NULL,
    name text NOT NULL
);


--
-- Name: collections_dues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections_dues (
    flat_id uuid NOT NULL,
    period_month date NOT NULL,
    dues_paise bigint DEFAULT 0 NOT NULL,
    paid_paise bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'due'::text NOT NULL
);


--
-- Name: communities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    fy_start_month smallint DEFAULT 4 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dashboard_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_settings (
    community_id uuid NOT NULL,
    dashboard_key text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    hidden_widgets text[] DEFAULT '{}'::text[] NOT NULL
);


--
-- Name: flats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    code text NOT NULL,
    owner_email text
);


--
-- Name: heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind public.head_kind NOT NULL,
    name text NOT NULL
);


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    filename text NOT NULL,
    kind text NOT NULL,
    uploaded_by uuid,
    status text DEFAULT 'staged'::text NOT NULL,
    error text,
    row_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind text NOT NULL,
    match jsonb NOT NULL,
    set_fields jsonb NOT NULL,
    priority integer DEFAULT 100 NOT NULL
);


--
-- Name: import_staging; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_staging (
    batch_id uuid NOT NULL,
    row_no integer NOT NULL,
    raw_json jsonb NOT NULL,
    mapped_json jsonb,
    error text
);


--
-- Name: line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    name text NOT NULL,
    first_seen_month date,
    last_seen_month date
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    txn_date date NOT NULL,
    period_month date NOT NULL,
    head_id uuid NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    line_item_id uuid,
    flat_id uuid,
    amount_paise bigint NOT NULL,
    direction character(1) NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    source_ref text,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT transactions_amount_paise_check CHECK ((amount_paise >= 0)),
    CONSTRAINT transactions_direction_check CHECK ((direction = ANY (ARRAY['C'::bpchar, 'D'::bpchar])))
);


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_category_monthly AS
 SELECT t.community_id,
    t.category_id,
    c.name AS category_name,
    h.kind AS head_kind,
    t.period_month AS month,
    (sum(t.amount_paise))::bigint AS amount_paise
   FROM ((public.transactions t
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON ((h.id = t.head_id)))
  GROUP BY t.community_id, t.category_id, c.name, h.kind, t.period_month
  WITH NO DATA;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_monthly_totals AS
 WITH spine AS (
         SELECT c.id AS community_id,
            (date_trunc('month'::text, gs.gs))::date AS month
           FROM (public.communities c
             CROSS JOIN generate_series((( SELECT COALESCE(min(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, (( SELECT COALESCE(max(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, '1 mon'::interval) gs(gs))
        )
 SELECT s.community_id,
    s.month,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric))::bigint AS collection_paise,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric))::bigint AS expense_paise,
    ((COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric) - COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric)))::bigint AS net_paise
   FROM (spine s
     LEFT JOIN public.transactions t ON (((t.community_id = s.community_id) AND (t.period_month = s.month))))
  GROUP BY s.community_id, s.month
  WITH NO DATA;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    name text NOT NULL,
    kind public.vendor_kind DEFAULT 'company'::public.vendor_kind NOT NULL
);


--
-- Name: TABLE vendors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vendors IS 'Vendor dimension. Read-only from admin UI; populated via CSV import + on-the-fly during transaction ingest.';


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_vendor_ranking AS
 SELECT t.community_id,
    v.id AS vendor_id,
    v.name AS vendor_name,
    v.kind AS vendor_kind,
    COALESCE(string_agg(DISTINCT c.name, ', '::text), ''::text) AS categories,
    (sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)))::bigint AS total_expense_paise,
    count(DISTINCT t.period_month) AS months_active
   FROM (((public.transactions t
     JOIN public.vendors v ON ((v.id = t.vendor_id)))
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON (((h.id = t.head_id) AND (h.kind = 'expense'::public.head_kind))))
  GROUP BY t.community_id, v.id, v.name, v.kind
  WITH NO DATA;


--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_codes (
    email text NOT NULL,
    otp_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone
);


--
-- Name: periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    month date NOT NULL,
    status text DEFAULT 'open'::text NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role public.app_role NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    email text NOT NULL,
    name text,
    password_hash text,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._migrations (name, run_at) FROM stdin;
0001_init.sql	2026-07-13 11:13:56.401452+00
0002_indexes.sql	2026-07-13 11:13:56.401452+00
0003_mviews.sql	2026-07-13 11:13:56.401452+00
0004_otp_rename.sql	2026-07-13 11:20:04.500279+00
0005_etl.sql	2026-08-03 16:34:38.109705+00
0006_drop_etl_sessions.sql	2026-08-03 18:40:10.950432+00
\.


--
-- Data for Name: allowed_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allowed_emails (email, community_id, role, flat_id, name, invited_by, invited_at, revoked_at) FROM stdin;
treasurer@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	admin	\N	Treasurer	system	2026-07-13 11:20:04.55456+00	\N
resident@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	resident	\N	Demo Resident	system	2026-07-13 11:20:04.55456+00	\N
admin@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	superadmin	\N	Super Admin	system	2026-07-13 11:20:04.55456+00	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, community_id, actor_user_id, actor_email, entity, entity_id, action, before, after, at, ip, user_agent) FROM stdin;
1	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	import_batch	56abe794-4290-46cd-af5b-748c67a6f5cd	import	\N	{"rows": 164, "failed": 0, "inserted": 164, "sessionId": "cc8f3dbd-0780-4a77-a704-9d18653cd7a3", "inputFiles": ["Expense-analysis_expense_1785782457093.xls", "Receipt-analysis_receipt_1785782457102.xls", "Vendor-Bill-Report_vendor_1785782457109.xls"], "importBatchId": "56abe794-4290-46cd-af5b-748c67a6f5cd"}	2026-08-03 18:40:59.13682+00	172.29.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
\.


--
-- Data for Name: balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.balances (community_id, month, opening_paise, closing_paise) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, head_id, name) FROM stdin;
66874ef4-7cbd-4195-9839-af7fa22f20ca	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	Cleaning
4ed4bacc-9bd2-4f3e-8b0a-a21084dfb6b9	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	Maintenance
47ebd38d-8024-4d76-9742-0a5ad86c832f	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	Housekeeping
5bbe4a00-7faa-4dca-9cab-9841b5dec408	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	Gardening
6c288b3f-3203-4425-baa8-dcca3c65d16d	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	Petty Cash
6593d2ab-ea1a-46db-a41a-f2497cb57880	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	Accounting Adjustments
a2e014a5-d401-4c03-b9a0-d20886dff37c	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	Water Treatment
77367d14-02aa-4816-92bd-31bc50f0eef7	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	Office Supplies
d115dfec-41c2-431b-af90-55d81eb4e219	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	Utilities
daa207a0-d390-4f97-95e0-0756f13166f5	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	Facility Management
027a9d50-cb8d-412b-a44f-13612bae16af	1e9de341-4235-4e0e-8194-712c8e55c911	Community Contributions
34d8e42b-1840-4396-be99-bffe60f058f9	1e9de341-4235-4e0e-8194-712c8e55c911	Recreation & Wellness
2e4fbc46-93f6-4ebd-8550-c474fff40d48	1e9de341-4235-4e0e-8194-712c8e55c911	Events
8375d868-cc92-4eb6-9df8-64a181423016	1e9de341-4235-4e0e-8194-712c8e55c911	Parking Revenue
412863b7-be65-4ef0-ad87-8e945db549be	1e9de341-4235-4e0e-8194-712c8e55c911	Advertisement
60be9000-e680-4660-92fc-046c443329cf	1e9de341-4235-4e0e-8194-712c8e55c911	Maintenance Collection
aa528b51-471d-4e41-9a0a-e84ef707c72d	1e9de341-4235-4e0e-8194-712c8e55c911	Move Charges
6c146d0b-9f7b-4277-bf8c-20e2eb81b184	1e9de341-4235-4e0e-8194-712c8e55c911	Facility Rental
cdf68e64-668c-4dd0-b973-a673d666011d	1e9de341-4235-4e0e-8194-712c8e55c911	Penalties
ba2ef8a2-2e84-4460-b9dd-d5b1f685cf3d	1e9de341-4235-4e0e-8194-712c8e55c911	Tax
\.


--
-- Data for Name: collections_dues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections_dues (flat_id, period_month, dues_paise, paid_paise, status) FROM stdin;
\.


--
-- Data for Name: communities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communities (id, name, currency, fy_start_month, created_at) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	Green Meadows	INR	4	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: dashboard_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_settings (community_id, dashboard_key, enabled, hidden_widgets) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	resident.overview	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.drilldown	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.cashflow	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.income	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.balance	t	{}
\.


--
-- Data for Name: flats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flats (id, community_id, code, owner_email) FROM stdin;
f88d6359-58a8-42b1-8476-24ce41b63802	caa11b01-c3a5-4067-a90c-b73b35075def	A-001	\N
5696d5bf-57f9-44ad-b92d-781cabc4a550	caa11b01-c3a5-4067-a90c-b73b35075def	A-002	\N
5c447f5e-a684-4075-8224-072f1fb12c93	caa11b01-c3a5-4067-a90c-b73b35075def	A-003	\N
6ddf10b7-40ed-44a1-9080-e50c60a08e32	caa11b01-c3a5-4067-a90c-b73b35075def	A-004	\N
5bfe95a5-bc38-4d00-811e-b5a6106e71c7	caa11b01-c3a5-4067-a90c-b73b35075def	A-005	\N
6e67ec18-d2aa-4cd4-8a51-b9a2b33429a2	caa11b01-c3a5-4067-a90c-b73b35075def	A-006	\N
05fbfe69-9195-45aa-bb9a-ef1de36f6fd9	caa11b01-c3a5-4067-a90c-b73b35075def	A-007	\N
7dca9ae9-39f7-4b2c-85b6-f9c820a65f0c	caa11b01-c3a5-4067-a90c-b73b35075def	A-008	\N
24f24d23-6946-4d06-b2d4-7ebe31278f9e	caa11b01-c3a5-4067-a90c-b73b35075def	A-009	\N
39278459-ad85-4e5e-937a-0a36b195c960	caa11b01-c3a5-4067-a90c-b73b35075def	A-010	\N
716bbe4c-f53d-4558-a4b5-caeb642f2c23	caa11b01-c3a5-4067-a90c-b73b35075def	A-011	\N
6dac5232-f75f-44d2-8533-4119c856f0ac	caa11b01-c3a5-4067-a90c-b73b35075def	A-012	\N
ea815ea6-a6d6-4547-bb06-ebfc9497a6f2	caa11b01-c3a5-4067-a90c-b73b35075def	A-013	\N
b441021b-6b42-4350-bd7a-385d23b17015	caa11b01-c3a5-4067-a90c-b73b35075def	A-014	\N
74194275-0229-47a7-9a12-691c228cbf03	caa11b01-c3a5-4067-a90c-b73b35075def	A-015	\N
f9df5252-7643-42fd-9a63-2e839347a52f	caa11b01-c3a5-4067-a90c-b73b35075def	A-016	\N
321b8a10-e82d-4cf6-a6b2-fde3fa7b05b1	caa11b01-c3a5-4067-a90c-b73b35075def	A-017	\N
9c1ddcb5-9b93-4e47-80ac-cbfc3b7f326e	caa11b01-c3a5-4067-a90c-b73b35075def	A-018	\N
f0106df5-f061-40fd-97c8-f6408f268ff9	caa11b01-c3a5-4067-a90c-b73b35075def	A-019	\N
deeb22d9-7a6b-4417-985b-c76049abae2e	caa11b01-c3a5-4067-a90c-b73b35075def	A-020	\N
c2e7bc3c-62db-4d01-aad3-9513cbf2ecbf	caa11b01-c3a5-4067-a90c-b73b35075def	A-021	\N
8c7ed2ff-3fea-4279-a889-c4e44b78ef6e	caa11b01-c3a5-4067-a90c-b73b35075def	A-022	\N
fb52fe46-dded-4f23-975d-3f36184896e9	caa11b01-c3a5-4067-a90c-b73b35075def	A-023	\N
5fc3f4ab-169c-47bc-819a-315c1a244aac	caa11b01-c3a5-4067-a90c-b73b35075def	A-024	\N
\.


--
-- Data for Name: heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heads (id, community_id, kind, name) FROM stdin;
01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	caa11b01-c3a5-4067-a90c-b73b35075def	expense	Expense
1e9de341-4235-4e0e-8194-712c8e55c911	caa11b01-c3a5-4067-a90c-b73b35075def	income	Income
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, community_id, filename, kind, uploaded_by, status, error, row_count, created_at) FROM stdin;
56abe794-4290-46cd-af5b-748c67a6f5cd	caa11b01-c3a5-4067-a90c-b73b35075def	etl-transformed-transactions.csv	transactions	0f0c6024-6c4d-47b3-9012-4f714d448a40	committed	\N	164	2026-08-03 18:40:59.125361+00
\.


--
-- Data for Name: import_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_rules (id, community_id, kind, match, set_fields, priority) FROM stdin;
\.


--
-- Data for Name: import_staging; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_staging (batch_id, row_no, raw_json, mapped_json, error) FROM stdin;
56abe794-4290-46cd-af5b-748c67a6f5cd	1	{"date": "2026-04-01", "head": "expense", "amount": "1214.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	2	{"date": "2026-05-01", "head": "expense", "amount": "1414.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	3	{"date": "2026-06-01", "head": "expense", "amount": "1428.98", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	4	{"date": "2026-07-01", "head": "expense", "amount": "1414.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-07", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	5	{"date": "2026-04-01", "head": "expense", "amount": "61049.0", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-04", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	6	{"date": "2026-05-01", "head": "expense", "amount": "7590.36", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-05", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	7	{"date": "2026-06-01", "head": "expense", "amount": "12018.34", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-06", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	8	{"date": "2026-07-01", "head": "expense", "amount": "4455.04", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-07", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	9	{"date": "2026-04-01", "head": "expense", "amount": "30000.0", "vendor": "JOHNSON LIFTS Pvt Ltd", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	10	{"date": "2026-06-01", "head": "expense", "amount": "150000.0", "vendor": "JOHNSON LIFTS Pvt Ltd", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	11	{"date": "2026-06-01", "head": "expense", "amount": "55000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Annual Compliance Expense", "source_ref": "D|Facility Management|EXOZEN|Annual Compliance Expense|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	12	{"date": "2026-04-01", "head": "expense", "amount": "154999.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	13	{"date": "2026-05-01", "head": "expense", "amount": "175902.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	14	{"date": "2026-04-01", "head": "expense", "amount": "46130.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	15	{"date": "2026-05-01", "head": "expense", "amount": "43011.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	16	{"date": "2026-04-01", "head": "expense", "amount": "79692.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	17	{"date": "2026-05-01", "head": "expense", "amount": "102431.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	18	{"date": "2026-04-01", "head": "expense", "amount": "78966.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	19	{"date": "2026-05-01", "head": "expense", "amount": "101572.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	20	{"date": "2026-04-01", "head": "expense", "amount": "9000.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-04", "vendor_kind": "individual"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	21	{"date": "2026-05-01", "head": "expense", "amount": "19300.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-05", "vendor_kind": "individual"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	22	{"date": "2026-06-01", "head": "expense", "amount": "20400.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-06", "vendor_kind": "individual"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	23	{"date": "2026-06-01", "head": "expense", "amount": "12876.27", "vendor": "KIRLOSKAR OIL ENGINES LTD", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "DG Service", "source_ref": "D|Maintenance|KIRLOSKAR OIL ENGINES LTD|DG Service|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	24	{"date": "2026-04-01", "head": "expense", "amount": "91401.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	25	{"date": "2026-05-01", "head": "expense", "amount": "54822.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	26	{"date": "2026-06-01", "head": "expense", "amount": "59784.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	27	{"date": "2026-07-01", "head": "expense", "amount": "59784.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-07", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	28	{"date": "2026-04-01", "head": "expense", "amount": "75588.3", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	29	{"date": "2026-05-01", "head": "expense", "amount": "82902.54", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	30	{"date": "2026-06-01", "head": "expense", "amount": "86506.61", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	31	{"date": "2026-04-01", "head": "expense", "amount": "59421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	32	{"date": "2026-05-01", "head": "expense", "amount": "59421.11", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	33	{"date": "2026-06-01", "head": "expense", "amount": "59421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	34	{"date": "2026-04-01", "head": "expense", "amount": "14000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	35	{"date": "2026-05-01", "head": "expense", "amount": "24000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	36	{"date": "2026-06-01", "head": "expense", "amount": "24000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	37	{"date": "2026-04-01", "head": "expense", "amount": "20280.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	38	{"date": "2026-05-01", "head": "expense", "amount": "130.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	39	{"date": "2026-07-01", "head": "expense", "amount": "1491.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-07", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	40	{"date": "2026-04-01", "head": "expense", "amount": "83421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	41	{"date": "2026-05-01", "head": "expense", "amount": "87561.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	42	{"date": "2026-06-01", "head": "expense", "amount": "85346.1", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	43	{"date": "2026-04-01", "head": "expense", "amount": "24471.07", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	44	{"date": "2026-05-01", "head": "expense", "amount": "23681.69", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	45	{"date": "2026-06-01", "head": "expense", "amount": "23627.24", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	46	{"date": "2026-04-01", "head": "expense", "amount": "22948.08", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	47	{"date": "2026-05-01", "head": "expense", "amount": "27759.6", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	48	{"date": "2026-06-01", "head": "expense", "amount": "24860.42", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	49	{"date": "2026-04-01", "head": "expense", "amount": "45317.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	50	{"date": "2026-05-01", "head": "expense", "amount": "34857.6", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	51	{"date": "2026-07-01", "head": "expense", "amount": "575.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-07", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	52	{"date": "2026-04-01", "head": "expense", "amount": "236717.04", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	53	{"date": "2026-05-01", "head": "expense", "amount": "313817.43", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	54	{"date": "2026-06-01", "head": "expense", "amount": "323070.45", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	55	{"date": "2026-04-01", "head": "expense", "amount": "24204.09", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	56	{"date": "2026-05-01", "head": "expense", "amount": "16397.01", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	57	{"date": "2026-06-01", "head": "expense", "amount": "23398.07", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	58	{"date": "2026-04-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	59	{"date": "2026-05-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	60	{"date": "2026-06-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	61	{"date": "2026-04-01", "head": "expense", "amount": "2000.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "One Time Operational Procurement", "source_ref": "D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-04", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	62	{"date": "2026-07-01", "head": "expense", "amount": "52694.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "One Time Operational Procurement", "source_ref": "D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-07", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	63	{"date": "2026-04-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	64	{"date": "2026-05-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	65	{"date": "2026-06-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	66	{"date": "2026-04-01", "head": "expense", "amount": "15683.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-04", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	67	{"date": "2026-05-01", "head": "expense", "amount": "20538.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-05", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	68	{"date": "2026-06-01", "head": "expense", "amount": "29600.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-06", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	69	{"date": "2026-07-01", "head": "expense", "amount": "14712.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-07", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	70	{"date": "2026-04-01", "head": "expense", "amount": "295.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-04", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	71	{"date": "2026-05-01", "head": "expense", "amount": "6487.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-05", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	72	{"date": "2026-06-01", "head": "expense", "amount": "5000.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-06", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	73	{"date": "2026-07-01", "head": "expense", "amount": "444.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-07", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	74	{"date": "2026-04-01", "head": "expense", "amount": "755.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-04", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	75	{"date": "2026-05-01", "head": "expense", "amount": "18917.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-05", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	76	{"date": "2026-06-01", "head": "expense", "amount": "5365.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-06", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	77	{"date": "2026-07-01", "head": "expense", "amount": "1015.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-07", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	78	{"date": "2026-04-01", "head": "expense", "amount": "75588.3", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	79	{"date": "2026-05-01", "head": "expense", "amount": "86966.39", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	80	{"date": "2026-06-01", "head": "expense", "amount": "85666.74", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	81	{"date": "2026-04-01", "head": "expense", "amount": "650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	82	{"date": "2026-05-01", "head": "expense", "amount": "6650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	83	{"date": "2026-06-01", "head": "expense", "amount": "650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	84	{"date": "2026-05-01", "head": "expense", "amount": "17334.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Facility Management|EXOZEN|Repair Work|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	85	{"date": "2026-06-01", "head": "expense", "amount": "8000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Facility Management|EXOZEN|Repair Work|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	86	{"date": "2026-04-01", "head": "expense", "amount": "0.41", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-04", "vendor_kind": "system"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	87	{"date": "2026-05-01", "head": "expense", "amount": "0.21", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-05", "vendor_kind": "system"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	88	{"date": "2026-06-01", "head": "expense", "amount": "0.1", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-06", "vendor_kind": "system"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	89	{"date": "2026-04-01", "head": "expense", "amount": "361130.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	90	{"date": "2026-05-01", "head": "expense", "amount": "373679.25", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	91	{"date": "2026-06-01", "head": "expense", "amount": "375840.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	92	{"date": "2026-04-01", "head": "expense", "amount": "22065.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	93	{"date": "2026-05-01", "head": "expense", "amount": "22064.87", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	94	{"date": "2026-06-01", "head": "expense", "amount": "21329.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	95	{"date": "2026-04-01", "head": "expense", "amount": "51642.7", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	96	{"date": "2026-05-01", "head": "expense", "amount": "54211.84", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	97	{"date": "2026-06-01", "head": "expense", "amount": "52518.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	98	{"date": "2026-04-01", "head": "expense", "amount": "86000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	99	{"date": "2026-05-01", "head": "expense", "amount": "94000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	100	{"date": "2026-06-01", "head": "expense", "amount": "118000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	101	{"date": "2026-04-01", "head": "expense", "amount": "67718.7", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	102	{"date": "2026-05-01", "head": "expense", "amount": "70631.52", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	103	{"date": "2026-06-01", "head": "expense", "amount": "75995.43", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	104	{"date": "2026-04-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	105	{"date": "2026-05-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	106	{"date": "2026-06-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	107	{"date": "2026-04-01", "head": "expense", "amount": "63000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Tank Cleaning Charges", "source_ref": "D|Facility Management|EXOZEN|Tank Cleaning Charges|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	108	{"date": "2026-04-01", "head": "expense", "amount": "9032.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-04", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	109	{"date": "2026-05-01", "head": "expense", "amount": "740.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-05", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	110	{"date": "2026-06-01", "head": "expense", "amount": "105.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-06", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	111	{"date": "2026-04-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	112	{"date": "2026-06-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	113	{"date": "2026-04-01", "head": "expense", "amount": "465815.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	114	{"date": "2026-05-01", "head": "expense", "amount": "478995.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	115	{"date": "2026-06-01", "head": "expense", "amount": "515775.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	116	{"date": "2026-04-01", "head": "expense", "amount": "6200.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-04", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	117	{"date": "2026-05-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-05", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	118	{"date": "2026-06-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-06", "vendor_kind": "company"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	119	{"date": "2026-04-01", "head": "income", "amount": "5000.0", "vendor": "Residents", "category": "Community Contributions", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Community Contributions|Residents|Association Fund|2026-04", "vendor_kind": "resident"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	120	{"date": "2026-05-01", "head": "income", "amount": "3700.0", "vendor": "Residents", "category": "Community Contributions", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Community Contributions|Residents|Association Fund|2026-05", "vendor_kind": "resident"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	121	{"date": "2026-06-01", "head": "income", "amount": "19500.0", "vendor": "Residents", "category": "Community Contributions", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Community Contributions|Residents|Association Fund|2026-06", "vendor_kind": "resident"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	122	{"date": "2026-04-01", "head": "income", "amount": "2800.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-04", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	123	{"date": "2026-05-01", "head": "income", "amount": "3500.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-05", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	124	{"date": "2026-06-01", "head": "income", "amount": "2100.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-06", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	125	{"date": "2026-07-01", "head": "income", "amount": "2800.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-07", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	126	{"date": "2026-05-01", "head": "income", "amount": "1120.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Amenities|Business Center|2026-05", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	127	{"date": "2026-06-01", "head": "income", "amount": "1080.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Amenities|Business Center|2026-06", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	128	{"date": "2026-07-01", "head": "income", "amount": "1000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Amenities|Business Center|2026-07", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	129	{"date": "2026-04-01", "head": "income", "amount": "12740.4", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-04", "vendor_kind": "statutory"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	130	{"date": "2026-05-01", "head": "income", "amount": "7592.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-05", "vendor_kind": "statutory"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	131	{"date": "2026-06-01", "head": "income", "amount": "5328.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-06", "vendor_kind": "statutory"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	132	{"date": "2026-07-01", "head": "income", "amount": "8680.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-07", "vendor_kind": "statutory"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	133	{"date": "2026-04-01", "head": "income", "amount": "1000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Common Area Violation", "source_ref": "C|Penalties|Resident Penalties|Common Area Violation|2026-04", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	134	{"date": "2026-06-01", "head": "income", "amount": "6000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Common Area Violation", "source_ref": "C|Penalties|Resident Penalties|Common Area Violation|2026-06", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	135	{"date": "2026-05-01", "head": "income", "amount": "8179.0", "vendor": "Community Events", "category": "Events", "direction": "C", "flat_code": "", "line_item": "Community Curriculum Activities", "source_ref": "C|Events|Community Events|Community Curriculum Activities|2026-05", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	136	{"date": "2026-05-01", "head": "income", "amount": "1000.0", "vendor": "Wellness Programs", "category": "Recreation & Wellness", "direction": "C", "flat_code": "", "line_item": "Fitness Trainers", "source_ref": "C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-05", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	137	{"date": "2026-07-01", "head": "income", "amount": "2304.0", "vendor": "Wellness Programs", "category": "Recreation & Wellness", "direction": "C", "flat_code": "", "line_item": "Fitness Trainers", "source_ref": "C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-07", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	138	{"date": "2026-04-01", "head": "income", "amount": "16000.0", "vendor": "Community Events", "category": "Events", "direction": "C", "flat_code": "", "line_item": "Flee Market", "source_ref": "C|Events|Community Events|Flee Market|2026-04", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	161	{"date": "2026-04-01", "head": "income", "amount": "12740.4", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-04", "vendor_kind": "statutory"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	139	{"date": "2026-07-01", "head": "income", "amount": "1000.0", "vendor": "Parking Services", "category": "Parking Revenue", "direction": "C", "flat_code": "", "line_item": "Guest Parking Rent", "source_ref": "C|Parking Revenue|Parking Services|Guest Parking Rent|2026-07", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	140	{"date": "2026-04-01", "head": "income", "amount": "151725.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-04", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	141	{"date": "2026-05-01", "head": "income", "amount": "95225.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-05", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	142	{"date": "2026-06-01", "head": "income", "amount": "68400.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-06", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	143	{"date": "2026-07-01", "head": "income", "amount": "108175.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-07", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	144	{"date": "2026-04-01", "head": "income", "amount": "9900.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-04", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	145	{"date": "2026-06-01", "head": "income", "amount": "5500.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-06", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	146	{"date": "2026-07-01", "head": "income", "amount": "3300.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-07", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	147	{"date": "2026-04-01", "head": "income", "amount": "2833274.0", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-04", "vendor_kind": "resident"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	148	{"date": "2026-05-01", "head": "income", "amount": "2838854.05", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-05", "vendor_kind": "resident"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	149	{"date": "2026-06-01", "head": "income", "amount": "2707115.06", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-06", "vendor_kind": "resident"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	150	{"date": "2026-07-01", "head": "income", "amount": "2748794.41", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-07", "vendor_kind": "resident"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	151	{"date": "2026-07-01", "head": "income", "amount": "7500.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move In/Out (Manual)", "source_ref": "C|Move Charges|Resident Services|Move In/Out (Manual)|2026-07", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	152	{"date": "2026-04-01", "head": "income", "amount": "35000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-04", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	153	{"date": "2026-05-01", "head": "income", "amount": "20000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-05", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	154	{"date": "2026-06-01", "head": "income", "amount": "30000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-06", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	155	{"date": "2026-07-01", "head": "income", "amount": "5000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-07", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	156	{"date": "2026-04-01", "head": "income", "amount": "12000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-04", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	157	{"date": "2026-05-01", "head": "income", "amount": "27000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-05", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	158	{"date": "2026-06-01", "head": "income", "amount": "21000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-06", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	159	{"date": "2026-07-01", "head": "income", "amount": "24000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-07", "vendor_kind": "internal"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	160	{"date": "2026-06-01", "head": "income", "amount": "1000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Parking Violation", "source_ref": "C|Penalties|Resident Penalties|Parking Violation|2026-06", "vendor_kind": "income_stream"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	162	{"date": "2026-05-01", "head": "income", "amount": "7592.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-05", "vendor_kind": "statutory"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	163	{"date": "2026-06-01", "head": "income", "amount": "5328.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-06", "vendor_kind": "statutory"}	\N	\N
56abe794-4290-46cd-af5b-748c67a6f5cd	164	{"date": "2026-07-01", "head": "income", "amount": "8680.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-07", "vendor_kind": "statutory"}	\N	\N
\.


--
-- Data for Name: line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_items (id, category_id, vendor_id, name, first_seen_month, last_seen_month) FROM stdin;
93468884-07d3-4ba9-832f-6e665a5ab891	d115dfec-41c2-431b-af90-55d81eb4e219	f1c56ca9-a695-4703-912c-bbb4888a29f2	Airtel Postpaid Connection	2026-04-01	2026-07-01
61bd39f6-4afd-4842-884f-4be8e7322097	77367d14-02aa-4816-92bd-31bc50f0eef7	33133ee3-eb68-4fc5-a84a-13acc9ba7ad5	Amazon Purchase	2026-04-01	2026-07-01
4db73893-4376-4605-aacc-d36eb324b0cb	4ed4bacc-9bd2-4f3e-8b0a-a21084dfb6b9	a170144c-0c0b-43df-a85e-5f0b2aa52a82	AMC (Lift)	2026-04-01	2026-06-01
ac2f6ac5-d66b-4162-8f90-da861b05c4ae	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Annual Compliance Expense	2026-06-01	2026-06-01
f0aa76eb-1732-43a4-877b-dabf624e5f0a	d115dfec-41c2-431b-af90-55d81eb4e219	ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	BESCOM A Block	2026-04-01	2026-05-01
5aca8f51-b24c-4c52-8234-80fa2e0444c3	d115dfec-41c2-431b-af90-55d81eb4e219	ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	BESCOM B Block	2026-04-01	2026-05-01
22b0c4a5-5246-4950-a796-0e72ed66013c	d115dfec-41c2-431b-af90-55d81eb4e219	ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	BESCOM E Block	2026-04-01	2026-05-01
3bbbdbec-5ff2-4be3-ba39-1cded2abedf7	d115dfec-41c2-431b-af90-55d81eb4e219	ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	BESCOM G Block	2026-04-01	2026-05-01
3851fce1-87d4-4523-830b-a7762110cb19	66874ef4-7cbd-4195-9839-af7fa22f20ca	1b868ff6-007a-4ee2-b9b8-8666fd9dacc2	Debris Disposal	2026-04-01	2026-06-01
09d2b0d3-3f11-44f6-b2b7-6ac2ab4635c8	4ed4bacc-9bd2-4f3e-8b0a-a21084dfb6b9	919e2a11-2d9d-41f8-83d6-f76aac1a98a7	DG Service	2026-06-01	2026-06-01
2b2ee681-1654-4236-a37b-bc3e1e06c7d0	d115dfec-41c2-431b-af90-55d81eb4e219	9f30473f-8303-492c-bb43-15409ca47f26	Diesel	2026-04-01	2026-07-01
6d1364c5-5b32-41df-92ab-b68546b082b0	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Electricians Salary	2026-04-01	2026-06-01
ff9a70c5-0006-4787-a559-71897e6b1ac7	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Facility Manager	2026-04-01	2026-06-01
805be3a0-d74f-4a0e-9fdd-342b301809c2	47ebd38d-8024-4d76-9742-0a5ad86c832f	898e9516-91eb-4292-9448-b526ff707bbe	Garbage removal	2026-04-01	2026-06-01
dc8d1b11-ffb1-4264-959e-fe041d0fada4	5bbe4a00-7faa-4dca-9cab-9841b5dec408	ead099e1-d569-47f4-8b86-62a5591fbff0	Garden Tools	2026-04-01	2026-07-01
d47478f9-ef41-4c58-b12b-b69fe34c6811	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Gardeners Salary	2026-04-01	2026-06-01
59503718-138a-4664-a778-db24b88c54c2	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Gardening Supervisor Salary	2026-04-01	2026-06-01
49194db2-caae-47aa-bc72-cab58964bafc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Help Desk Salary	2026-04-01	2026-06-01
093284c6-ac84-4e31-ac40-fdb4923a28cb	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	HK Materials	2026-04-01	2026-07-01
df2045d7-c192-4d46-96e3-f9211c544730	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	House Keeping Janitor Salary	2026-04-01	2026-06-01
b8e7eb6e-b13f-4ac4-8d06-b7b9954e3814	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Housekeeping Supervisor Salary	2026-04-01	2026-06-01
7e0344a1-4f26-419f-b6e3-89e96628e7de	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Management Fee	2026-04-01	2026-06-01
3c64af8f-8ce5-4646-9b67-39706f154c28	77367d14-02aa-4816-92bd-31bc50f0eef7	d589cbea-54e8-47dc-857f-b97a19452929	One Time Operational Procurement	2026-04-01	2026-07-01
7030b8c4-0ca2-4c09-8d29-42fad4141216	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Pest Control Services	2026-04-01	2026-06-01
fbf5cd54-dd8b-4920-bb42-2f7abe3f7b03	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	Petty Cash - Consumables	2026-04-01	2026-07-01
bba9e726-c309-445e-b36c-a9f00984f739	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	Petty Cash - Electricals	2026-04-01	2026-07-01
a44b68f2-ead9-41e2-90b5-cc538568687b	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	Petty Cash - Hardware	2026-04-01	2026-07-01
3f97d249-6644-4cdd-a18c-8e205d2915f7	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Plumbers Salary	2026-04-01	2026-06-01
51a18266-0588-4433-bc21-e7808d9c191d	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Rental Charges Machinery	2026-04-01	2026-06-01
b03a425a-ad0d-46f3-ab37-ddf257bff65e	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Repair Work	2026-05-01	2026-06-01
8b435121-949c-470e-a472-4fe52812adfe	6593d2ab-ea1a-46db-a41a-f2497cb57880	44a6b385-bdc2-4a60-aaf6-e1a77f3a5113	Roundoff	2026-04-01	2026-06-01
c18fbe78-c054-4e5e-be88-ffcff98caaab	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Security Guards Salary	2026-04-01	2026-06-01
b1cbfe6b-3ae5-43c7-bc6b-52a4a9a7c3eb	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Security Lady Guards Salary	2026-04-01	2026-06-01
18d651ce-1cbc-4cab-8f43-d59ff7c4d5b2	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Security Supervisor Salary	2026-04-01	2026-06-01
f31c5e89-2013-4c26-8496-7e0cab72d315	a2e014a5-d401-4c03-b9a0-d20886dff37c	6b8dfcb7-336a-42fe-9077-e37271eac5c5	STP water collection (Sludge Removal)	2026-04-01	2026-06-01
474227a8-e7f1-4d0f-9503-c173265b4a3c	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	STP/WTP Operators Salary	2026-04-01	2026-06-01
417f5aff-198b-4dd5-ab8b-9d4fcd0a6503	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Swimming Pool Services	2026-04-01	2026-06-01
4cfcbc00-1c73-41eb-ac4c-f95ad5fba2c1	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Tank Cleaning Charges	2026-04-01	2026-04-01
6522802d-f983-4fdf-a6f2-4fad7e79164c	77367d14-02aa-4816-92bd-31bc50f0eef7	d589cbea-54e8-47dc-857f-b97a19452929	Tools & Stationary	2026-04-01	2026-06-01
04d06fb8-0c8f-4a22-babc-4635d5e0d4fe	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Walkie Talkies	2026-04-01	2026-06-01
cc628e9e-be6e-4ebd-a672-747a71ac869f	d115dfec-41c2-431b-af90-55d81eb4e219	9a7365ad-f96d-4183-b490-42a0c08024a1	Water Supply	2026-04-01	2026-06-01
3d84e447-0511-48bb-bb3f-339991bd262d	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	Water Test Report	2026-04-01	2026-06-01
f957b4d3-e9e1-451e-ad6a-ba76a70394d5	027a9d50-cb8d-412b-a44f-13612bae16af	a7852e1d-4ba3-4c55-a1e6-2e25c3abc8c8	Association Fund	2026-04-01	2026-06-01
0e0516a6-a5d2-46a7-b981-1f3108c77c57	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	AV room	2026-04-01	2026-07-01
c43bd6ba-5232-4408-a73e-b75479b130c1	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	Business Center	2026-05-01	2026-07-01
27262a13-8515-4471-b92a-7a4a78f0aa49	ba2ef8a2-2e84-4460-b9dd-d5b1f685cf3d	9a5da83f-6182-47e8-9ca0-4b5ba4157ff1	CGST Output	2026-04-01	2026-07-01
a54208ef-b6b0-4284-92bb-70ded4c88fa6	cdf68e64-668c-4dd0-b973-a673d666011d	fb7078c6-89d4-40a5-ab1e-38bfb4c485ec	Common Area Violation	2026-04-01	2026-06-01
b419646f-ce01-4b17-ae04-7e45481c02ca	2e4fbc46-93f6-4ebd-8550-c474fff40d48	de2e61fa-f7e0-487e-8b4d-2493822a8cb6	Community Curriculum Activities	2026-05-01	2026-05-01
7b7eefe5-d4c9-42fb-94ba-15d807cfacfd	34d8e42b-1840-4396-be99-bffe60f058f9	935bf216-9e8d-4cf9-b226-16dfccce279b	Fitness Trainers	2026-05-01	2026-07-01
ed03a05c-baef-48c3-a99f-c41faa5653d0	2e4fbc46-93f6-4ebd-8550-c474fff40d48	de2e61fa-f7e0-487e-8b4d-2493822a8cb6	Flee Market	2026-04-01	2026-04-01
96d2b881-3ec8-4822-a98a-23886526a306	8375d868-cc92-4eb6-9df8-64a181423016	0afeab81-d0b0-4e31-b021-5414962eb209	Guest Parking Rent	2026-07-01	2026-07-01
3f577251-686a-4e36-86bb-202fb49ab8b9	cdf68e64-668c-4dd0-b973-a673d666011d	fb7078c6-89d4-40a5-ab1e-38bfb4c485ec	Late Payment Fine	2026-04-01	2026-07-01
9010a564-5146-4044-a5c7-ed89617ab769	412863b7-be65-4ef0-ad87-8e945db549be	e50dceb4-7bcb-4e6a-9314-38e5a61755e7	Lift Advertisement	2026-04-01	2026-07-01
803f5ca5-446a-4db8-8dfc-65651f7b8c1c	60be9000-e680-4660-92fc-046c443329cf	3d90eec5-d2a5-4059-a49a-16584ef88ce4	Maintenance Charge	2026-04-01	2026-07-01
e4ae0414-eda1-401d-9c31-9a23232e939c	aa528b51-471d-4e41-9a0a-e84ef707c72d	60485916-2f67-48b2-971e-48e008f6cf3c	Move In/Out (Manual)	2026-07-01	2026-07-01
555708f2-84d6-4319-91c9-740f4ad31208	aa528b51-471d-4e41-9a0a-e84ef707c72d	60485916-2f67-48b2-971e-48e008f6cf3c	Move in/out Charges	2026-04-01	2026-07-01
5c7d9c3c-419e-460a-abd5-866d11bdae94	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	Multipurpose Party Hall/Club House	2026-04-01	2026-07-01
e9187c0e-b8dd-4a4f-beed-36597e0e3a07	cdf68e64-668c-4dd0-b973-a673d666011d	fb7078c6-89d4-40a5-ab1e-38bfb4c485ec	Parking Violation	2026-06-01	2026-06-01
733e3129-9c96-4184-8520-703bf3708a30	ba2ef8a2-2e84-4460-b9dd-d5b1f685cf3d	9a5da83f-6182-47e8-9ca0-4b5ba4157ff1	SGST Output	2026-04-01	2026-07-01
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp_codes (email, otp_hash, expires_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periods (id, community_id, month, status) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, community_id, txn_date, period_month, head_id, category_id, vendor_id, line_item_id, flat_id, amount_paise, direction, source, source_ref, notes, created_by, created_at, updated_at) FROM stdin;
cca85ecd-a1c4-4bb1-9147-cbfa32ab32ee	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	f1c56ca9-a695-4703-912c-bbb4888a29f2	93468884-07d3-4ba9-832f-6e665a5ab891	\N	121482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
6a7d2463-2f09-4673-a97e-85c639e3a04c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	f1c56ca9-a695-4703-912c-bbb4888a29f2	93468884-07d3-4ba9-832f-6e665a5ab891	\N	141482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
f8d1e90d-09bd-43cc-a857-a22bbdf5f961	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	f1c56ca9-a695-4703-912c-bbb4888a29f2	93468884-07d3-4ba9-832f-6e665a5ab891	\N	142898	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
39dd4b41-f5a7-469f-8472-ff38cc143dd8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	f1c56ca9-a695-4703-912c-bbb4888a29f2	93468884-07d3-4ba9-832f-6e665a5ab891	\N	141482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
e92b2057-8573-477d-a849-29fb79961ddc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	77367d14-02aa-4816-92bd-31bc50f0eef7	33133ee3-eb68-4fc5-a84a-13acc9ba7ad5	61bd39f6-4afd-4842-884f-4be8e7322097	\N	6104900	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
a9020074-1043-4b39-b687-71c90bc303a0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	77367d14-02aa-4816-92bd-31bc50f0eef7	33133ee3-eb68-4fc5-a84a-13acc9ba7ad5	61bd39f6-4afd-4842-884f-4be8e7322097	\N	759036	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
1a7330d5-5e86-4f5a-9971-843062d0ded7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	77367d14-02aa-4816-92bd-31bc50f0eef7	33133ee3-eb68-4fc5-a84a-13acc9ba7ad5	61bd39f6-4afd-4842-884f-4be8e7322097	\N	1201834	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
1c3ff520-5ccb-4e3e-831a-34da79ef38e8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	77367d14-02aa-4816-92bd-31bc50f0eef7	33133ee3-eb68-4fc5-a84a-13acc9ba7ad5	61bd39f6-4afd-4842-884f-4be8e7322097	\N	445504	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
5fb105b1-a98e-4a81-a04c-6dcdd3b5cdb5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	4ed4bacc-9bd2-4f3e-8b0a-a21084dfb6b9	a170144c-0c0b-43df-a85e-5f0b2aa52a82	4db73893-4376-4605-aacc-d36eb324b0cb	\N	3000000	D	csv	D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
d9b9554e-fd13-4599-afd3-1e7ef5507156	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	4ed4bacc-9bd2-4f3e-8b0a-a21084dfb6b9	a170144c-0c0b-43df-a85e-5f0b2aa52a82	4db73893-4376-4605-aacc-d36eb324b0cb	\N	15000000	D	csv	D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
857ac1cf-de0e-4511-af10-f67cd7ef598a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	ac2f6ac5-d66b-4162-8f90-da861b05c4ae	\N	5500000	D	csv	D|Facility Management|EXOZEN|Annual Compliance Expense|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
8e3cc27d-ece2-424d-b89f-f1073cc3be19	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	f0aa76eb-1732-43a4-877b-dabf624e5f0a	\N	15499900	D	csv	D|Utilities|BESCOM|BESCOM A Block|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
3d00486b-eb62-462b-b6f7-daa053b4df97	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	f0aa76eb-1732-43a4-877b-dabf624e5f0a	\N	17590200	D	csv	D|Utilities|BESCOM|BESCOM A Block|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
2846b73f-0acd-4d9c-8d7a-d1b0d86f3e04	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	5aca8f51-b24c-4c52-8234-80fa2e0444c3	\N	4613000	D	csv	D|Utilities|BESCOM|BESCOM B Block|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
e3551bfe-66c2-4629-9078-a1cd693a6234	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	5aca8f51-b24c-4c52-8234-80fa2e0444c3	\N	4301100	D	csv	D|Utilities|BESCOM|BESCOM B Block|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
a948f993-bab3-417a-8a86-be7abb61c7be	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	22b0c4a5-5246-4950-a796-0e72ed66013c	\N	7969200	D	csv	D|Utilities|BESCOM|BESCOM E Block|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
31bf6f09-4b55-4d1d-9277-d7df31969dc9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	22b0c4a5-5246-4950-a796-0e72ed66013c	\N	10243100	D	csv	D|Utilities|BESCOM|BESCOM E Block|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
e210b2a2-c8a4-4a42-8b84-6600c8eb3994	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	3bbbdbec-5ff2-4be3-ba39-1cded2abedf7	\N	7896600	D	csv	D|Utilities|BESCOM|BESCOM G Block|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
5e7651b7-8250-44de-9c35-703a16da3fea	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	3bbbdbec-5ff2-4be3-ba39-1cded2abedf7	\N	10157200	D	csv	D|Utilities|BESCOM|BESCOM G Block|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
00b00423-22de-4aaa-8b8c-8d3da8be7ee4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	66874ef4-7cbd-4195-9839-af7fa22f20ca	1b868ff6-007a-4ee2-b9b8-8666fd9dacc2	3851fce1-87d4-4523-830b-a7762110cb19	\N	900000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
18e1f073-f34a-469d-af36-1026f8054dc2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	66874ef4-7cbd-4195-9839-af7fa22f20ca	1b868ff6-007a-4ee2-b9b8-8666fd9dacc2	3851fce1-87d4-4523-830b-a7762110cb19	\N	1930000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
5ec0cc6f-fc30-4d79-a50e-74fbb6c9fac1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	66874ef4-7cbd-4195-9839-af7fa22f20ca	1b868ff6-007a-4ee2-b9b8-8666fd9dacc2	3851fce1-87d4-4523-830b-a7762110cb19	\N	2040000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
a693fc1f-1d91-4072-a89f-9bb49982b13a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	4ed4bacc-9bd2-4f3e-8b0a-a21084dfb6b9	919e2a11-2d9d-41f8-83d6-f76aac1a98a7	09d2b0d3-3f11-44f6-b2b7-6ac2ab4635c8	\N	1287627	D	csv	D|Maintenance|KIRLOSKAR OIL ENGINES LTD|DG Service|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
0a09ce8d-6b53-4eec-a02b-62ea22d05742	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	9f30473f-8303-492c-bb43-15409ca47f26	2b2ee681-1654-4236-a37b-bc3e1e06c7d0	\N	9140100	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
0ecec3fd-3c0b-4013-aa3b-d72db747cb6c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	9f30473f-8303-492c-bb43-15409ca47f26	2b2ee681-1654-4236-a37b-bc3e1e06c7d0	\N	5482200	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
cb105639-3124-47bc-be27-809196c15fa2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	9f30473f-8303-492c-bb43-15409ca47f26	2b2ee681-1654-4236-a37b-bc3e1e06c7d0	\N	5978400	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
1363d39e-fa78-4fe4-a55e-c7a67aa4f4d6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	9f30473f-8303-492c-bb43-15409ca47f26	2b2ee681-1654-4236-a37b-bc3e1e06c7d0	\N	5978400	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
3d8abde2-4ca7-4fde-8f5f-e4050d41f618	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	6d1364c5-5b32-41df-92ab-b68546b082b0	\N	7558830	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
017e2a07-b667-4e2c-b337-8b53b44c73d9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	6d1364c5-5b32-41df-92ab-b68546b082b0	\N	8290254	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
c2f73307-f29f-48fa-80d5-4d7c6632372c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	6d1364c5-5b32-41df-92ab-b68546b082b0	\N	8650661	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
0f2d9bd6-e0aa-47b9-9c14-245c03c4f531	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	ff9a70c5-0006-4787-a559-71897e6b1ac7	\N	5942100	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
99c596dc-c30d-4bcf-bdc9-ad9260185acb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	ff9a70c5-0006-4787-a559-71897e6b1ac7	\N	5942111	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
82a4b581-979c-4158-92db-172d1ffe6a2e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	ff9a70c5-0006-4787-a559-71897e6b1ac7	\N	5942100	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
a5807197-41af-4298-9420-a0f74f5dcbbf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	47ebd38d-8024-4d76-9742-0a5ad86c832f	898e9516-91eb-4292-9448-b526ff707bbe	805be3a0-d74f-4a0e-9fdd-342b301809c2	\N	1400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
a26a7887-c571-409c-ba88-ff6374964a4f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	47ebd38d-8024-4d76-9742-0a5ad86c832f	898e9516-91eb-4292-9448-b526ff707bbe	805be3a0-d74f-4a0e-9fdd-342b301809c2	\N	2400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
8fd159f9-8fcc-46ca-9c2a-73eecc9fba91	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	47ebd38d-8024-4d76-9742-0a5ad86c832f	898e9516-91eb-4292-9448-b526ff707bbe	805be3a0-d74f-4a0e-9fdd-342b301809c2	\N	2400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
837e4a8e-d08a-4237-b74c-ad78aec26ed1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	5bbe4a00-7faa-4dca-9cab-9841b5dec408	ead099e1-d569-47f4-8b86-62a5591fbff0	dc8d1b11-ffb1-4264-959e-fe041d0fada4	\N	2028000	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
f829b357-7f20-4958-9ea8-7ed37a1fac93	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	5bbe4a00-7faa-4dca-9cab-9841b5dec408	ead099e1-d569-47f4-8b86-62a5591fbff0	dc8d1b11-ffb1-4264-959e-fe041d0fada4	\N	13000	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
1e352bd4-5f72-4a79-a497-8ff4e6c17edc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	5bbe4a00-7faa-4dca-9cab-9841b5dec408	ead099e1-d569-47f4-8b86-62a5591fbff0	dc8d1b11-ffb1-4264-959e-fe041d0fada4	\N	149100	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
8c2874a4-2a6f-47b1-b07f-1831ebe5a018	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	d47478f9-ef41-4c58-b12b-b69fe34c6811	\N	8342100	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
3eadb37a-46af-4a10-95d4-b9fc7c6cec87	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	d47478f9-ef41-4c58-b12b-b69fe34c6811	\N	8756100	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
5aa865d2-9637-4123-946b-4ca98f9feefb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	d47478f9-ef41-4c58-b12b-b69fe34c6811	\N	8534610	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
1816b11e-359a-4c5b-ba58-97c4e29989f2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	59503718-138a-4664-a778-db24b88c54c2	\N	2447107	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
05aee837-fe7e-4f5c-a429-1d596871b220	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	59503718-138a-4664-a778-db24b88c54c2	\N	2368169	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
f80a0fa4-1887-4ddb-8e3c-92f623a812c0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	59503718-138a-4664-a778-db24b88c54c2	\N	2362724	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
74f16b2a-0d17-46ea-b0b9-e1aa8b0448ba	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	49194db2-caae-47aa-bc72-cab58964bafc	\N	2294808	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
1b84529c-0f60-4b68-a3ff-9dc28a842477	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	49194db2-caae-47aa-bc72-cab58964bafc	\N	2775960	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
46742c6d-c323-4077-b12c-2f1f000310fa	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	49194db2-caae-47aa-bc72-cab58964bafc	\N	2486042	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
48a9a1c4-31d4-4783-ab74-76db30ba435c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	093284c6-ac84-4e31-ac40-fdb4923a28cb	\N	4531700	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
7395618d-ad14-4d0a-81a4-d5671b93998c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	093284c6-ac84-4e31-ac40-fdb4923a28cb	\N	3485760	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
3c800889-9116-4feb-926c-8ef93b57eaff	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	093284c6-ac84-4e31-ac40-fdb4923a28cb	\N	57500	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
34b8f5d0-3e7b-42af-a77f-edafda18f529	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	df2045d7-c192-4d46-96e3-f9211c544730	\N	23671704	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
9cd8547f-4497-4eca-bde1-ce113b27fcf0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	df2045d7-c192-4d46-96e3-f9211c544730	\N	31381743	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
3e2d6287-ef50-414c-ae74-d2c593c99a3f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	df2045d7-c192-4d46-96e3-f9211c544730	\N	32307045	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
e1f161fe-ea80-44f8-802c-7b2e3928a101	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	b8e7eb6e-b13f-4ac4-8d06-b7b9954e3814	\N	2420409	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
3819e675-4ebd-4a62-9536-0c57d65386b3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	b8e7eb6e-b13f-4ac4-8d06-b7b9954e3814	\N	1639701	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
d8a975ef-8f65-43c8-afb6-343943f439f1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	b8e7eb6e-b13f-4ac4-8d06-b7b9954e3814	\N	2339807	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
35ddddd4-0f81-4947-b17e-b32667527ee8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	7e0344a1-4f26-419f-b6e3-89e96628e7de	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
33a76d14-26c1-40d9-9067-cd41310407bd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	7e0344a1-4f26-419f-b6e3-89e96628e7de	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
c430bb52-2bf3-4cc2-b5c2-8a404f077f69	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	7e0344a1-4f26-419f-b6e3-89e96628e7de	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
69c99ed3-bc2c-4f07-9e05-874b90818a29	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	77367d14-02aa-4816-92bd-31bc50f0eef7	d589cbea-54e8-47dc-857f-b97a19452929	3c64af8f-8ce5-4646-9b67-39706f154c28	\N	200000	D	csv	D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
9d08ffba-52da-43b1-99af-57b464d9f27f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	77367d14-02aa-4816-92bd-31bc50f0eef7	d589cbea-54e8-47dc-857f-b97a19452929	3c64af8f-8ce5-4646-9b67-39706f154c28	\N	5269400	D	csv	D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
d020dd85-2a47-46a3-a46c-2f491175541e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	7030b8c4-0ca2-4c09-8d29-42fad4141216	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
3ca1da81-8eff-4e14-91de-faa0521bdd63	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	7030b8c4-0ca2-4c09-8d29-42fad4141216	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
3782acd1-3110-40b7-9747-0b71014be315	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	7030b8c4-0ca2-4c09-8d29-42fad4141216	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
1016ffcc-9f09-411e-a350-18728c3c6cee	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	fbf5cd54-dd8b-4920-bb42-2f7abe3f7b03	\N	1568300	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
0b6c6341-88a1-4eb2-9c7c-80e0f6948527	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	fbf5cd54-dd8b-4920-bb42-2f7abe3f7b03	\N	2053800	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
53e24ff4-2fd3-42b2-ad18-84cba64ca239	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	fbf5cd54-dd8b-4920-bb42-2f7abe3f7b03	\N	2960000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
4faa1e35-4ff0-45f1-99a8-f8af8d647953	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	fbf5cd54-dd8b-4920-bb42-2f7abe3f7b03	\N	1471200	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
ab8c36a8-3bf0-41c3-8316-003889339db4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	bba9e726-c309-445e-b36c-a9f00984f739	\N	29500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
fea8ed0e-21e8-46f8-89f2-d009771d5b2a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	bba9e726-c309-445e-b36c-a9f00984f739	\N	648700	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
fc823224-6a26-400b-bb62-71db12a46004	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	bba9e726-c309-445e-b36c-a9f00984f739	\N	500000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
b6292b2d-b7b3-45da-9196-56c74a0a6cbe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	bba9e726-c309-445e-b36c-a9f00984f739	\N	44400	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
05d58e9d-d859-417b-83a9-918ec8d746bd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	a44b68f2-ead9-41e2-90b5-cc538568687b	\N	75500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
c96359f8-fd45-4747-8cfe-aff1d71c12ba	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	a44b68f2-ead9-41e2-90b5-cc538568687b	\N	1891700	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
9d2a56f2-c660-4abc-8361-c71214851b80	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	a44b68f2-ead9-41e2-90b5-cc538568687b	\N	536500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
8ed3b666-aa4f-41b5-993c-5334b0267407	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6c288b3f-3203-4425-baa8-dcca3c65d16d	d589cbea-54e8-47dc-857f-b97a19452929	a44b68f2-ead9-41e2-90b5-cc538568687b	\N	101500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
9f4e1c24-2bf2-4771-8c1e-a85e612f8c82	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	3f97d249-6644-4cdd-a18c-8e205d2915f7	\N	7558830	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
5b62eae9-530a-43f0-b945-d528fddfff33	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	3f97d249-6644-4cdd-a18c-8e205d2915f7	\N	8696639	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
93cadaba-5468-46e0-93f0-081ef6bb774a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	3f97d249-6644-4cdd-a18c-8e205d2915f7	\N	8566674	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
0151529f-bf55-4d08-9875-168b2022de87	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	51a18266-0588-4433-bc21-e7808d9c191d	\N	65000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
810f556c-c7c8-45c4-9791-b894da7c11a5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	51a18266-0588-4433-bc21-e7808d9c191d	\N	665000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
0f083ee8-c611-41cb-8702-bff45637946b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	51a18266-0588-4433-bc21-e7808d9c191d	\N	65000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
f7e0736b-c605-4e95-939c-773966d46f2c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	b03a425a-ad0d-46f3-ab37-ddf257bff65e	\N	1733400	D	csv	D|Facility Management|EXOZEN|Repair Work|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
217390e1-8900-4774-bca3-3e7b5490e9a0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	b03a425a-ad0d-46f3-ab37-ddf257bff65e	\N	800000	D	csv	D|Facility Management|EXOZEN|Repair Work|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
237a2f52-1480-4d76-baec-5ec1c103c45d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6593d2ab-ea1a-46db-a41a-f2497cb57880	44a6b385-bdc2-4a60-aaf6-e1a77f3a5113	8b435121-949c-470e-a472-4fe52812adfe	\N	41	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
481e0f0a-22b7-4acd-b2c6-f4a0f7914ff8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6593d2ab-ea1a-46db-a41a-f2497cb57880	44a6b385-bdc2-4a60-aaf6-e1a77f3a5113	8b435121-949c-470e-a472-4fe52812adfe	\N	21	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
9acbf233-4557-42b9-b191-7c485f9ea4e4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	6593d2ab-ea1a-46db-a41a-f2497cb57880	44a6b385-bdc2-4a60-aaf6-e1a77f3a5113	8b435121-949c-470e-a472-4fe52812adfe	\N	10	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
822fee17-88ff-4d01-9f64-0436010287c3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	c18fbe78-c054-4e5e-be88-ffcff98caaab	\N	36113050	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
ce239044-cc15-4c8c-94f5-a990207ee7bf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	c18fbe78-c054-4e5e-be88-ffcff98caaab	\N	37367925	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
cec0ad08-e036-4244-b8ad-5f4355713318	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	c18fbe78-c054-4e5e-be88-ffcff98caaab	\N	37584050	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
6c7a845c-649b-4c47-8d0c-b6ff065b0310	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	b1cbfe6b-3ae5-43c7-bc6b-52a4a9a7c3eb	\N	2206500	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
198dbb9d-ce18-4481-8cf2-3888f75936ce	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	b1cbfe6b-3ae5-43c7-bc6b-52a4a9a7c3eb	\N	2206487	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
c4697a5e-cdf2-4c00-8ab8-818f9933ab0a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	b1cbfe6b-3ae5-43c7-bc6b-52a4a9a7c3eb	\N	2132950	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
536569a9-6c44-4850-ab1c-e28f81b88b50	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	18d651ce-1cbc-4cab-8f43-d59ff7c4d5b2	\N	5164270	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
9ed108e0-1965-4ec4-b126-39153cd2d40c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	18d651ce-1cbc-4cab-8f43-d59ff7c4d5b2	\N	5421184	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
9fd8f317-1de3-47bf-90de-466b0f8e8989	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	18d651ce-1cbc-4cab-8f43-d59ff7c4d5b2	\N	5251800	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
0d212d91-e75e-4d5b-a820-4015dfc4485c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	a2e014a5-d401-4c03-b9a0-d20886dff37c	6b8dfcb7-336a-42fe-9077-e37271eac5c5	f31c5e89-2013-4c26-8496-7e0cab72d315	\N	8600000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
781650e1-ccbe-482f-bd5d-78f7fea1d8f4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	a2e014a5-d401-4c03-b9a0-d20886dff37c	6b8dfcb7-336a-42fe-9077-e37271eac5c5	f31c5e89-2013-4c26-8496-7e0cab72d315	\N	9400000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
c9ebdedb-01ef-4ceb-9dcb-6956fbe7f9ed	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	a2e014a5-d401-4c03-b9a0-d20886dff37c	6b8dfcb7-336a-42fe-9077-e37271eac5c5	f31c5e89-2013-4c26-8496-7e0cab72d315	\N	11800000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
090634a8-fc07-47e5-814a-2e0d04c4088b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	474227a8-e7f1-4d0f-9503-c173265b4a3c	\N	6771870	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
5b8b5550-02af-4da7-a2c4-8ce597b1b159	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	474227a8-e7f1-4d0f-9503-c173265b4a3c	\N	7063152	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
15cd3f23-f8bd-4e17-9431-f9ce6833eba5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	474227a8-e7f1-4d0f-9503-c173265b4a3c	\N	7599543	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
089c4ee9-6e68-4b59-80c1-ed1205a08fe4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	417f5aff-198b-4dd5-ab8b-9d4fcd0a6503	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
8ab31ee0-1831-4f33-8460-a210691aeafe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	417f5aff-198b-4dd5-ab8b-9d4fcd0a6503	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
7c49cd8e-8dd7-48b0-aa5c-04d1646a7128	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	417f5aff-198b-4dd5-ab8b-9d4fcd0a6503	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
b13e5bf9-3ebe-4cb3-a2f6-4d26c8985931	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	4cfcbc00-1c73-41eb-ac4c-f95ad5fba2c1	\N	6300000	D	csv	D|Facility Management|EXOZEN|Tank Cleaning Charges|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
e8cdcb9c-0d52-4c83-be2d-d1437a848461	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	77367d14-02aa-4816-92bd-31bc50f0eef7	d589cbea-54e8-47dc-857f-b97a19452929	6522802d-f983-4fdf-a6f2-4fad7e79164c	\N	903200	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
55827e16-12f0-42f9-9f21-a34abaa28d87	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	77367d14-02aa-4816-92bd-31bc50f0eef7	d589cbea-54e8-47dc-857f-b97a19452929	6522802d-f983-4fdf-a6f2-4fad7e79164c	\N	74000	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
f83cde0c-5512-49f1-a7be-67e21c7df258	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	77367d14-02aa-4816-92bd-31bc50f0eef7	d589cbea-54e8-47dc-857f-b97a19452929	6522802d-f983-4fdf-a6f2-4fad7e79164c	\N	10500	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
d6e7e041-5aaf-46f5-8fe1-4f04673a737a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	04d06fb8-0c8f-4a22-babc-4635d5e0d4fe	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
16bb63e8-8e88-4cc9-bac8-324fb39f87e5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	04d06fb8-0c8f-4a22-babc-4635d5e0d4fe	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
6f97dc0e-5475-4f3b-a132-bb36268fb8b8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	9a7365ad-f96d-4183-b490-42a0c08024a1	cc628e9e-be6e-4ebd-a672-747a71ac869f	\N	46581500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
41faecbc-8bb0-4fa1-b254-50c35875de14	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	9a7365ad-f96d-4183-b490-42a0c08024a1	cc628e9e-be6e-4ebd-a672-747a71ac869f	\N	47899500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
d2e535e3-0df6-4f0f-8729-fbcb29650277	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	d115dfec-41c2-431b-af90-55d81eb4e219	9a7365ad-f96d-4183-b490-42a0c08024a1	cc628e9e-be6e-4ebd-a672-747a71ac869f	\N	51577500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
c8a6f7a1-bacd-4969-a919-e511fef1b280	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	3d84e447-0511-48bb-bb3f-339991bd262d	\N	620000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
81b3e60f-a2c1-42f8-87fb-b17a0a0dee0d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	3d84e447-0511-48bb-bb3f-339991bd262d	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
a3c5d668-173b-4b74-8e91-f0a2051c9519	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	01d7bd69-6f08-4a37-98ba-bf2aabd1cfbc	daa207a0-d390-4f97-95e0-0756f13166f5	6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	3d84e447-0511-48bb-bb3f-339991bd262d	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
78575f77-5b35-46ca-8032-3281e491fe48	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	1e9de341-4235-4e0e-8194-712c8e55c911	027a9d50-cb8d-412b-a44f-13612bae16af	a7852e1d-4ba3-4c55-a1e6-2e25c3abc8c8	f957b4d3-e9e1-451e-ad6a-ba76a70394d5	\N	500000	C	csv	C|Community Contributions|Residents|Association Fund|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
97128155-984a-4e1b-9284-e7f5c03e7475	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	1e9de341-4235-4e0e-8194-712c8e55c911	027a9d50-cb8d-412b-a44f-13612bae16af	a7852e1d-4ba3-4c55-a1e6-2e25c3abc8c8	f957b4d3-e9e1-451e-ad6a-ba76a70394d5	\N	370000	C	csv	C|Community Contributions|Residents|Association Fund|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
08402fa1-5424-4191-bef3-b10e4ec537d3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	1e9de341-4235-4e0e-8194-712c8e55c911	027a9d50-cb8d-412b-a44f-13612bae16af	a7852e1d-4ba3-4c55-a1e6-2e25c3abc8c8	f957b4d3-e9e1-451e-ad6a-ba76a70394d5	\N	1950000	C	csv	C|Community Contributions|Residents|Association Fund|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
1d96aea6-cc05-4f39-8ff4-270eab932d1c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	1e9de341-4235-4e0e-8194-712c8e55c911	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	0e0516a6-a5d2-46a7-b981-1f3108c77c57	\N	280000	C	csv	C|Facility Rental|Amenities|AV room|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
b37f5434-000b-49a2-a2ce-8d2ba85ffd27	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	1e9de341-4235-4e0e-8194-712c8e55c911	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	0e0516a6-a5d2-46a7-b981-1f3108c77c57	\N	350000	C	csv	C|Facility Rental|Amenities|AV room|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
0bc7733f-debc-49f7-a0cf-e79a24bfede5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	1e9de341-4235-4e0e-8194-712c8e55c911	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	0e0516a6-a5d2-46a7-b981-1f3108c77c57	\N	210000	C	csv	C|Facility Rental|Amenities|AV room|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
44985831-5067-4b04-9ea4-31910a7fd805	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	1e9de341-4235-4e0e-8194-712c8e55c911	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	0e0516a6-a5d2-46a7-b981-1f3108c77c57	\N	280000	C	csv	C|Facility Rental|Amenities|AV room|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
2ae4fdb1-28d2-476b-a9a8-8bc8a66ef78c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	1e9de341-4235-4e0e-8194-712c8e55c911	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	c43bd6ba-5232-4408-a73e-b75479b130c1	\N	112000	C	csv	C|Facility Rental|Amenities|Business Center|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
5e03e261-36ca-49c7-8f30-606abc87db78	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	1e9de341-4235-4e0e-8194-712c8e55c911	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	c43bd6ba-5232-4408-a73e-b75479b130c1	\N	108000	C	csv	C|Facility Rental|Amenities|Business Center|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
3f9beff5-6fbd-40cc-a57f-05cbfa5eaaf4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	1e9de341-4235-4e0e-8194-712c8e55c911	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	c43bd6ba-5232-4408-a73e-b75479b130c1	\N	100000	C	csv	C|Facility Rental|Amenities|Business Center|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
6d28cda0-9b78-44ea-9416-0c06293bc322	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	1e9de341-4235-4e0e-8194-712c8e55c911	ba2ef8a2-2e84-4460-b9dd-d5b1f685cf3d	9a5da83f-6182-47e8-9ca0-4b5ba4157ff1	27262a13-8515-4471-b92a-7a4a78f0aa49	\N	1274040	C	csv	C|Tax|Tax Collection|CGST Output|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
0dbb0e57-82a6-42d1-a0d0-1d221e921895	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	1e9de341-4235-4e0e-8194-712c8e55c911	ba2ef8a2-2e84-4460-b9dd-d5b1f685cf3d	9a5da83f-6182-47e8-9ca0-4b5ba4157ff1	27262a13-8515-4471-b92a-7a4a78f0aa49	\N	759200	C	csv	C|Tax|Tax Collection|CGST Output|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
ba25cf39-7a5c-4767-b39e-ded77bc01677	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	1e9de341-4235-4e0e-8194-712c8e55c911	ba2ef8a2-2e84-4460-b9dd-d5b1f685cf3d	9a5da83f-6182-47e8-9ca0-4b5ba4157ff1	27262a13-8515-4471-b92a-7a4a78f0aa49	\N	532800	C	csv	C|Tax|Tax Collection|CGST Output|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
3896a816-2d40-4423-8e58-775e83d1ac1a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	1e9de341-4235-4e0e-8194-712c8e55c911	ba2ef8a2-2e84-4460-b9dd-d5b1f685cf3d	9a5da83f-6182-47e8-9ca0-4b5ba4157ff1	27262a13-8515-4471-b92a-7a4a78f0aa49	\N	868000	C	csv	C|Tax|Tax Collection|CGST Output|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
2e2cb0f5-5c69-499c-8110-fc789fb9f63e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	1e9de341-4235-4e0e-8194-712c8e55c911	cdf68e64-668c-4dd0-b973-a673d666011d	fb7078c6-89d4-40a5-ab1e-38bfb4c485ec	a54208ef-b6b0-4284-92bb-70ded4c88fa6	\N	100000	C	csv	C|Penalties|Resident Penalties|Common Area Violation|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
66dea02f-80a1-48bc-ab26-c7881d6008b9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	1e9de341-4235-4e0e-8194-712c8e55c911	cdf68e64-668c-4dd0-b973-a673d666011d	fb7078c6-89d4-40a5-ab1e-38bfb4c485ec	a54208ef-b6b0-4284-92bb-70ded4c88fa6	\N	600000	C	csv	C|Penalties|Resident Penalties|Common Area Violation|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
87af8ccb-ef85-42cc-b873-a8a2a14115ab	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	1e9de341-4235-4e0e-8194-712c8e55c911	2e4fbc46-93f6-4ebd-8550-c474fff40d48	de2e61fa-f7e0-487e-8b4d-2493822a8cb6	b419646f-ce01-4b17-ae04-7e45481c02ca	\N	817900	C	csv	C|Events|Community Events|Community Curriculum Activities|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
b051f312-9209-41dd-b2fc-a8fa40d87d88	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	1e9de341-4235-4e0e-8194-712c8e55c911	34d8e42b-1840-4396-be99-bffe60f058f9	935bf216-9e8d-4cf9-b226-16dfccce279b	7b7eefe5-d4c9-42fb-94ba-15d807cfacfd	\N	100000	C	csv	C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
d690b627-6cfd-4225-a38e-7bddae30c921	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	1e9de341-4235-4e0e-8194-712c8e55c911	34d8e42b-1840-4396-be99-bffe60f058f9	935bf216-9e8d-4cf9-b226-16dfccce279b	7b7eefe5-d4c9-42fb-94ba-15d807cfacfd	\N	230400	C	csv	C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
89df0694-ef3b-446b-99d3-fb6c80ccccc7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	1e9de341-4235-4e0e-8194-712c8e55c911	2e4fbc46-93f6-4ebd-8550-c474fff40d48	de2e61fa-f7e0-487e-8b4d-2493822a8cb6	ed03a05c-baef-48c3-a99f-c41faa5653d0	\N	1600000	C	csv	C|Events|Community Events|Flee Market|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
28545227-465f-4861-93dd-3268c790a66e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	1e9de341-4235-4e0e-8194-712c8e55c911	8375d868-cc92-4eb6-9df8-64a181423016	0afeab81-d0b0-4e31-b021-5414962eb209	96d2b881-3ec8-4822-a98a-23886526a306	\N	100000	C	csv	C|Parking Revenue|Parking Services|Guest Parking Rent|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
7ae11c51-c57d-4bc8-87d8-04011a89fcbb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	1e9de341-4235-4e0e-8194-712c8e55c911	cdf68e64-668c-4dd0-b973-a673d666011d	fb7078c6-89d4-40a5-ab1e-38bfb4c485ec	3f577251-686a-4e36-86bb-202fb49ab8b9	\N	15172500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
ee7fe3c5-5e4f-45e2-add2-45aea1bd0838	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	1e9de341-4235-4e0e-8194-712c8e55c911	cdf68e64-668c-4dd0-b973-a673d666011d	fb7078c6-89d4-40a5-ab1e-38bfb4c485ec	3f577251-686a-4e36-86bb-202fb49ab8b9	\N	9522500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
223fb941-1bf4-459d-bdf9-7daa25143053	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	1e9de341-4235-4e0e-8194-712c8e55c911	cdf68e64-668c-4dd0-b973-a673d666011d	fb7078c6-89d4-40a5-ab1e-38bfb4c485ec	3f577251-686a-4e36-86bb-202fb49ab8b9	\N	6840000	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
22fa7539-5d41-4dda-b8fc-072de2313315	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	1e9de341-4235-4e0e-8194-712c8e55c911	cdf68e64-668c-4dd0-b973-a673d666011d	fb7078c6-89d4-40a5-ab1e-38bfb4c485ec	3f577251-686a-4e36-86bb-202fb49ab8b9	\N	10817500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
dcf2c12d-22e3-49c4-af97-c30c2d759e2f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	1e9de341-4235-4e0e-8194-712c8e55c911	412863b7-be65-4ef0-ad87-8e945db549be	e50dceb4-7bcb-4e6a-9314-38e5a61755e7	9010a564-5146-4044-a5c7-ed89617ab769	\N	990000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
56ac4548-0b23-4a19-bf04-1fa7bd7f4411	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	1e9de341-4235-4e0e-8194-712c8e55c911	412863b7-be65-4ef0-ad87-8e945db549be	e50dceb4-7bcb-4e6a-9314-38e5a61755e7	9010a564-5146-4044-a5c7-ed89617ab769	\N	550000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
530b62d8-c2e6-4814-832a-7931bdd323ff	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	1e9de341-4235-4e0e-8194-712c8e55c911	412863b7-be65-4ef0-ad87-8e945db549be	e50dceb4-7bcb-4e6a-9314-38e5a61755e7	9010a564-5146-4044-a5c7-ed89617ab769	\N	330000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
b723b6c4-c7bc-4413-8aa2-2d7786f64135	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	1e9de341-4235-4e0e-8194-712c8e55c911	60be9000-e680-4660-92fc-046c443329cf	3d90eec5-d2a5-4059-a49a-16584ef88ce4	803f5ca5-446a-4db8-8dfc-65651f7b8c1c	\N	283327400	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
9e06ea0e-c408-41fc-923d-4d007d51253b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	1e9de341-4235-4e0e-8194-712c8e55c911	60be9000-e680-4660-92fc-046c443329cf	3d90eec5-d2a5-4059-a49a-16584ef88ce4	803f5ca5-446a-4db8-8dfc-65651f7b8c1c	\N	283885405	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
656ea7a4-54b0-4d30-af0f-1d2833e4fe9d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	1e9de341-4235-4e0e-8194-712c8e55c911	60be9000-e680-4660-92fc-046c443329cf	3d90eec5-d2a5-4059-a49a-16584ef88ce4	803f5ca5-446a-4db8-8dfc-65651f7b8c1c	\N	270711506	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
582c0e7e-efa4-46fb-ae4c-6996b0d27bac	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	1e9de341-4235-4e0e-8194-712c8e55c911	60be9000-e680-4660-92fc-046c443329cf	3d90eec5-d2a5-4059-a49a-16584ef88ce4	803f5ca5-446a-4db8-8dfc-65651f7b8c1c	\N	274879441	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
6b9a50a4-7af4-49e5-bbdf-fc1b8162559b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	1e9de341-4235-4e0e-8194-712c8e55c911	aa528b51-471d-4e41-9a0a-e84ef707c72d	60485916-2f67-48b2-971e-48e008f6cf3c	e4ae0414-eda1-401d-9c31-9a23232e939c	\N	750000	C	csv	C|Move Charges|Resident Services|Move In/Out (Manual)|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
698863c4-7fde-471d-ac00-2c6ec2d312e4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	1e9de341-4235-4e0e-8194-712c8e55c911	aa528b51-471d-4e41-9a0a-e84ef707c72d	60485916-2f67-48b2-971e-48e008f6cf3c	555708f2-84d6-4319-91c9-740f4ad31208	\N	3500000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
a1172f4d-0447-4567-acb1-7d6fd9815741	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	1e9de341-4235-4e0e-8194-712c8e55c911	aa528b51-471d-4e41-9a0a-e84ef707c72d	60485916-2f67-48b2-971e-48e008f6cf3c	555708f2-84d6-4319-91c9-740f4ad31208	\N	2000000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
e10729e4-e0c6-4832-8d48-146acea3d3a5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	1e9de341-4235-4e0e-8194-712c8e55c911	aa528b51-471d-4e41-9a0a-e84ef707c72d	60485916-2f67-48b2-971e-48e008f6cf3c	555708f2-84d6-4319-91c9-740f4ad31208	\N	3000000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
716f2778-8d5d-4142-a7d2-671d0058657d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	1e9de341-4235-4e0e-8194-712c8e55c911	aa528b51-471d-4e41-9a0a-e84ef707c72d	60485916-2f67-48b2-971e-48e008f6cf3c	555708f2-84d6-4319-91c9-740f4ad31208	\N	500000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
e6ef084c-185b-451f-9a79-09aa124c6186	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	1e9de341-4235-4e0e-8194-712c8e55c911	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	5c7d9c3c-419e-460a-abd5-866d11bdae94	\N	1200000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
b25610d1-2178-4d05-add1-1d764e2e061a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	1e9de341-4235-4e0e-8194-712c8e55c911	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	5c7d9c3c-419e-460a-abd5-866d11bdae94	\N	2700000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
dd370878-efad-425e-abe5-205a6ea02272	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	1e9de341-4235-4e0e-8194-712c8e55c911	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	5c7d9c3c-419e-460a-abd5-866d11bdae94	\N	2100000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
41b4b2fb-897b-46ef-9ab0-0d8fb7fc4075	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	1e9de341-4235-4e0e-8194-712c8e55c911	6c146d0b-9f7b-4277-bf8c-20e2eb81b184	88d3adb4-83d8-44a3-88c7-8550fbdc4716	5c7d9c3c-419e-460a-abd5-866d11bdae94	\N	2400000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
850e0960-7278-478f-b139-42746dbad816	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	1e9de341-4235-4e0e-8194-712c8e55c911	cdf68e64-668c-4dd0-b973-a673d666011d	fb7078c6-89d4-40a5-ab1e-38bfb4c485ec	e9187c0e-b8dd-4a4f-beed-36597e0e3a07	\N	100000	C	csv	C|Penalties|Resident Penalties|Parking Violation|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
1ad372d3-5e80-4827-bc78-18ecc35e2e71	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	1e9de341-4235-4e0e-8194-712c8e55c911	ba2ef8a2-2e84-4460-b9dd-d5b1f685cf3d	9a5da83f-6182-47e8-9ca0-4b5ba4157ff1	733e3129-9c96-4184-8520-703bf3708a30	\N	1274040	C	csv	C|Tax|Tax Collection|SGST Output|2026-04	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
cae54a64-daf9-4222-babe-be7c53943736	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	1e9de341-4235-4e0e-8194-712c8e55c911	ba2ef8a2-2e84-4460-b9dd-d5b1f685cf3d	9a5da83f-6182-47e8-9ca0-4b5ba4157ff1	733e3129-9c96-4184-8520-703bf3708a30	\N	759200	C	csv	C|Tax|Tax Collection|SGST Output|2026-05	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
dcb75308-7c2e-41a9-a531-f42556313ba2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	1e9de341-4235-4e0e-8194-712c8e55c911	ba2ef8a2-2e84-4460-b9dd-d5b1f685cf3d	9a5da83f-6182-47e8-9ca0-4b5ba4157ff1	733e3129-9c96-4184-8520-703bf3708a30	\N	532800	C	csv	C|Tax|Tax Collection|SGST Output|2026-06	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
65af3b02-a613-4e2f-8b18-d75d2e97dc08	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	1e9de341-4235-4e0e-8194-712c8e55c911	ba2ef8a2-2e84-4460-b9dd-d5b1f685cf3d	9a5da83f-6182-47e8-9ca0-4b5ba4157ff1	733e3129-9c96-4184-8520-703bf3708a30	\N	868000	C	csv	C|Tax|Tax Collection|SGST Output|2026-07	\N	\N	2026-08-03 18:40:59.13682+00	2026-08-03 18:40:59.13682+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	superadmin
0f0c6024-6c4d-47b3-9012-4f714d448a40	admin
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, community_id, email, name, password_hash, last_login_at, created_at) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	caa11b01-c3a5-4067-a90c-b73b35075def	admin@example.com	Super Admin	$argon2id$v=19$m=65536,t=3,p=4$p1fZkWHf2gTDwEWxE6CM8Q$uPbhYQcAe8ts/FxPR9LDBPgAe9SFH99hpbhircC2SAE	2026-08-03 17:59:35.207187+00	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, community_id, name, kind) FROM stdin;
f1c56ca9-a695-4703-912c-bbb4888a29f2	caa11b01-c3a5-4067-a90c-b73b35075def	Airtel Postpaid	company
33133ee3-eb68-4fc5-a84a-13acc9ba7ad5	caa11b01-c3a5-4067-a90c-b73b35075def	Amazon CG Boulevard RWA	individual
a170144c-0c0b-43df-a85e-5f0b2aa52a82	caa11b01-c3a5-4067-a90c-b73b35075def	JOHNSON LIFTS Pvt Ltd	company
ee9ede54-044d-4c2f-a370-4fd3eb97bfdb	caa11b01-c3a5-4067-a90c-b73b35075def	BESCOM	company
1b868ff6-007a-4ee2-b9b8-8666fd9dacc2	caa11b01-c3a5-4067-a90c-b73b35075def	Individual	individual
919e2a11-2d9d-41f8-83d6-f76aac1a98a7	caa11b01-c3a5-4067-a90c-b73b35075def	KIRLOSKAR OIL ENGINES LTD	company
9f30473f-8303-492c-bb43-15409ca47f26	caa11b01-c3a5-4067-a90c-b73b35075def	Sai Krupa Petroleum	company
898e9516-91eb-4292-9448-b526ff707bbe	caa11b01-c3a5-4067-a90c-b73b35075def	Sewa Waste Management	company
ead099e1-d569-47f4-8b86-62a5591fbff0	caa11b01-c3a5-4067-a90c-b73b35075def	Kavitha Enterprises	company
44a6b385-bdc2-4a60-aaf6-e1a77f3a5113	caa11b01-c3a5-4067-a90c-b73b35075def	System Adjustment	individual
6b8dfcb7-336a-42fe-9077-e37271eac5c5	caa11b01-c3a5-4067-a90c-b73b35075def	Sapthagiri Cleaner	company
d589cbea-54e8-47dc-857f-b97a19452929	caa11b01-c3a5-4067-a90c-b73b35075def	Petty Cash	individual
9a7365ad-f96d-4183-b490-42a0c08024a1	caa11b01-c3a5-4067-a90c-b73b35075def	BSN Water Supply	company
6ffc9170-28b5-4d92-9bdf-7c17dddbdeb8	caa11b01-c3a5-4067-a90c-b73b35075def	EXOZEN	company
a7852e1d-4ba3-4c55-a1e6-2e25c3abc8c8	caa11b01-c3a5-4067-a90c-b73b35075def	Residents	individual
935bf216-9e8d-4cf9-b226-16dfccce279b	caa11b01-c3a5-4067-a90c-b73b35075def	Wellness Programs	individual
de2e61fa-f7e0-487e-8b4d-2493822a8cb6	caa11b01-c3a5-4067-a90c-b73b35075def	Community Events	individual
0afeab81-d0b0-4e31-b021-5414962eb209	caa11b01-c3a5-4067-a90c-b73b35075def	Parking Services	individual
e50dceb4-7bcb-4e6a-9314-38e5a61755e7	caa11b01-c3a5-4067-a90c-b73b35075def	Advertising Revenue	individual
3d90eec5-d2a5-4059-a49a-16584ef88ce4	caa11b01-c3a5-4067-a90c-b73b35075def	Apartment Owners	individual
60485916-2f67-48b2-971e-48e008f6cf3c	caa11b01-c3a5-4067-a90c-b73b35075def	Resident Services	individual
88d3adb4-83d8-44a3-88c7-8550fbdc4716	caa11b01-c3a5-4067-a90c-b73b35075def	Amenities	individual
fb7078c6-89d4-40a5-ab1e-38bfb4c485ec	caa11b01-c3a5-4067-a90c-b73b35075def	Resident Penalties	individual
9a5da83f-6182-47e8-9ca0-4b5ba4157ff1	caa11b01-c3a5-4067-a90c-b73b35075def	Tax Collection	individual
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, true);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (name);


--
-- Name: allowed_emails allowed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_pkey PRIMARY KEY (email);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: balances balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_pkey PRIMARY KEY (community_id, month);


--
-- Name: categories categories_head_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_name_key UNIQUE (head_id, name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: collections_dues collections_dues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_pkey PRIMARY KEY (flat_id, period_month);


--
-- Name: communities communities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communities
    ADD CONSTRAINT communities_pkey PRIMARY KEY (id);


--
-- Name: dashboard_settings dashboard_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_pkey PRIMARY KEY (community_id, dashboard_key);


--
-- Name: flats flats_community_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_code_key UNIQUE (community_id, code);


--
-- Name: flats flats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_pkey PRIMARY KEY (id);


--
-- Name: heads heads_community_id_kind_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_kind_name_key UNIQUE (community_id, kind, name);


--
-- Name: heads heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_rules import_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_pkey PRIMARY KEY (id);


--
-- Name: import_staging import_staging_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_pkey PRIMARY KEY (batch_id, row_no);


--
-- Name: line_items line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_pkey PRIMARY KEY (id);


--
-- Name: otp_codes magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (email, otp_hash);


--
-- Name: periods periods_community_id_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_month_key UNIQUE (community_id, month);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_source_source_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_source_source_ref_key UNIQUE (source, source_ref);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_community_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_name_key UNIQUE (community_id, name);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_at ON public.audit_log USING btree (at DESC);


--
-- Name: idx_audit_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_entity ON public.audit_log USING btree (entity, entity_id);


--
-- Name: idx_txn_category_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_category_month ON public.transactions USING btree (category_id, period_month);


--
-- Name: idx_txn_community_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_community_month ON public.transactions USING btree (community_id, period_month);


--
-- Name: idx_txn_flat_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_flat_month ON public.transactions USING btree (flat_id, period_month);


--
-- Name: idx_txn_head_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_head_month ON public.transactions USING btree (head_id, period_month);


--
-- Name: idx_txn_vendor_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_vendor_month ON public.transactions USING btree (vendor_id, period_month);


--
-- Name: line_items_cat_vendor_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX line_items_cat_vendor_name_uq ON public.line_items USING btree (category_id, COALESCE(vendor_id, '00000000-0000-0000-0000-000000000000'::uuid), name);


--
-- Name: mv_cat_monthly_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_cat_monthly_idx ON public.mv_category_monthly USING btree (community_id, month);


--
-- Name: mv_monthly_totals_pk; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mv_monthly_totals_pk ON public.mv_monthly_totals USING btree (community_id, month);


--
-- Name: mv_vendor_ranking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_vendor_ranking_idx ON public.mv_vendor_ranking USING btree (community_id, total_expense_paise DESC);


--
-- Name: allowed_emails allowed_emails_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: allowed_emails allowed_emails_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE SET NULL;


--
-- Name: balances balances_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: categories categories_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id) ON DELETE CASCADE;


--
-- Name: collections_dues collections_dues_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE CASCADE;


--
-- Name: dashboard_settings dashboard_settings_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: flats flats_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: heads heads_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: import_rules import_rules_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_staging import_staging_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE SET NULL;


--
-- Name: periods periods_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: transactions transactions_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id);


--
-- Name: transactions transactions_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id);


--
-- Name: transactions transactions_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_line_item_id_fkey FOREIGN KEY (line_item_id) REFERENCES public.line_items(id);


--
-- Name: transactions transactions_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: vendors vendors_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_category_monthly;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_monthly_totals;


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_vendor_ranking;


--
-- PostgreSQL database dump complete
--

\unrestrict a5JOiqH4erEU9LPaEIy2OC0Oo433n6aiC8nuhGogF1jbOf0C7hqeX07jkVp43TV

