--
-- PostgreSQL database dump
--

\restrict cakXDrMdlJmc3pcn4yhLcSieRm9bIA5e0aUjjJuchljAJsWJX3R4vsBaWp6h3XA

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_line_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_batch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_actor_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_community_id_fkey;
DROP INDEX IF EXISTS public.mv_vendor_ranking_idx;
DROP INDEX IF EXISTS public.mv_monthly_totals_pk;
DROP INDEX IF EXISTS public.mv_cat_monthly_idx;
DROP INDEX IF EXISTS public.line_items_cat_vendor_name_uq;
DROP INDEX IF EXISTS public.idx_txn_vendor_month;
DROP INDEX IF EXISTS public.idx_txn_head_month;
DROP INDEX IF EXISTS public.idx_txn_flat_month;
DROP INDEX IF EXISTS public.idx_txn_community_month;
DROP INDEX IF EXISTS public.idx_txn_category_month;
DROP INDEX IF EXISTS public.idx_audit_entity;
DROP INDEX IF EXISTS public.idx_audit_at;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_pkey;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_name_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_source_source_ref_key;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_month_key;
ALTER TABLE IF EXISTS ONLY public.otp_codes DROP CONSTRAINT IF EXISTS magic_links_pkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_pkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_pkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_kind_name_key;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_pkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_code_key;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.communities DROP CONSTRAINT IF EXISTS communities_pkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_name_key;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_pkey;
ALTER TABLE IF EXISTS ONLY public._migrations DROP CONSTRAINT IF EXISTS _migrations_pkey;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.periods;
DROP TABLE IF EXISTS public.otp_codes;
DROP MATERIALIZED VIEW IF EXISTS public.mv_vendor_ranking;
DROP TABLE IF EXISTS public.vendors;
DROP MATERIALIZED VIEW IF EXISTS public.mv_monthly_totals;
DROP MATERIALIZED VIEW IF EXISTS public.mv_category_monthly;
DROP TABLE IF EXISTS public.transactions;
DROP TABLE IF EXISTS public.line_items;
DROP TABLE IF EXISTS public.import_staging;
DROP TABLE IF EXISTS public.import_rules;
DROP TABLE IF EXISTS public.import_batches;
DROP TABLE IF EXISTS public.heads;
DROP TABLE IF EXISTS public.flats;
DROP TABLE IF EXISTS public.dashboard_settings;
DROP TABLE IF EXISTS public.communities;
DROP TABLE IF EXISTS public.collections_dues;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.balances;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP TABLE IF EXISTS public.allowed_emails;
DROP TABLE IF EXISTS public._migrations;
DROP TYPE IF EXISTS public.vendor_kind;
DROP TYPE IF EXISTS public.head_kind;
DROP TYPE IF EXISTS public.app_role;
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'resident',
    'admin',
    'superadmin'
);


--
-- Name: head_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.head_kind AS ENUM (
    'income',
    'expense'
);


--
-- Name: vendor_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vendor_kind AS ENUM (
    'company',
    'individual'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    name text NOT NULL,
    run_at timestamp with time zone DEFAULT now()
);


--
-- Name: allowed_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allowed_emails (
    email text NOT NULL,
    community_id uuid NOT NULL,
    role public.app_role NOT NULL,
    flat_id uuid,
    name text,
    invited_by text,
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    community_id uuid,
    actor_user_id uuid,
    actor_email text,
    entity text NOT NULL,
    entity_id text,
    action text NOT NULL,
    before jsonb,
    after jsonb,
    at timestamp with time zone DEFAULT now() NOT NULL,
    ip text,
    user_agent text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balances (
    community_id uuid NOT NULL,
    month date NOT NULL,
    opening_paise bigint DEFAULT 0 NOT NULL,
    closing_paise bigint DEFAULT 0 NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    head_id uuid NOT NULL,
    name text NOT NULL
);


--
-- Name: collections_dues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections_dues (
    flat_id uuid NOT NULL,
    period_month date NOT NULL,
    dues_paise bigint DEFAULT 0 NOT NULL,
    paid_paise bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'due'::text NOT NULL
);


--
-- Name: communities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    fy_start_month smallint DEFAULT 4 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dashboard_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_settings (
    community_id uuid NOT NULL,
    dashboard_key text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    hidden_widgets text[] DEFAULT '{}'::text[] NOT NULL
);


--
-- Name: flats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    code text NOT NULL,
    owner_email text
);


--
-- Name: heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind public.head_kind NOT NULL,
    name text NOT NULL
);


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    filename text NOT NULL,
    kind text NOT NULL,
    uploaded_by uuid,
    status text DEFAULT 'staged'::text NOT NULL,
    error text,
    row_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind text NOT NULL,
    match jsonb NOT NULL,
    set_fields jsonb NOT NULL,
    priority integer DEFAULT 100 NOT NULL
);


--
-- Name: import_staging; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_staging (
    batch_id uuid NOT NULL,
    row_no integer NOT NULL,
    raw_json jsonb NOT NULL,
    mapped_json jsonb,
    error text
);


--
-- Name: line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    name text NOT NULL,
    first_seen_month date,
    last_seen_month date
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    txn_date date NOT NULL,
    period_month date NOT NULL,
    head_id uuid NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    line_item_id uuid,
    flat_id uuid,
    amount_paise bigint NOT NULL,
    direction character(1) NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    source_ref text,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT transactions_amount_paise_check CHECK ((amount_paise >= 0)),
    CONSTRAINT transactions_direction_check CHECK ((direction = ANY (ARRAY['C'::bpchar, 'D'::bpchar])))
);


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_category_monthly AS
 SELECT t.community_id,
    t.category_id,
    c.name AS category_name,
    h.kind AS head_kind,
    t.period_month AS month,
    (sum(t.amount_paise))::bigint AS amount_paise
   FROM ((public.transactions t
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON ((h.id = t.head_id)))
  GROUP BY t.community_id, t.category_id, c.name, h.kind, t.period_month
  WITH NO DATA;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_monthly_totals AS
 WITH spine AS (
         SELECT c.id AS community_id,
            (date_trunc('month'::text, gs.gs))::date AS month
           FROM (public.communities c
             CROSS JOIN generate_series((( SELECT COALESCE(min(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, (( SELECT COALESCE(max(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, '1 mon'::interval) gs(gs))
        )
 SELECT s.community_id,
    s.month,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric))::bigint AS collection_paise,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric))::bigint AS expense_paise,
    ((COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric) - COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric)))::bigint AS net_paise
   FROM (spine s
     LEFT JOIN public.transactions t ON (((t.community_id = s.community_id) AND (t.period_month = s.month))))
  GROUP BY s.community_id, s.month
  WITH NO DATA;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    name text NOT NULL,
    kind public.vendor_kind DEFAULT 'company'::public.vendor_kind NOT NULL
);


--
-- Name: TABLE vendors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vendors IS 'Vendor dimension. Read-only from admin UI; populated via CSV import + on-the-fly during transaction ingest.';


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_vendor_ranking AS
 SELECT t.community_id,
    v.id AS vendor_id,
    v.name AS vendor_name,
    v.kind AS vendor_kind,
    COALESCE(string_agg(DISTINCT c.name, ', '::text), ''::text) AS categories,
    (sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)))::bigint AS total_expense_paise,
    count(DISTINCT t.period_month) AS months_active
   FROM (((public.transactions t
     JOIN public.vendors v ON ((v.id = t.vendor_id)))
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON (((h.id = t.head_id) AND (h.kind = 'expense'::public.head_kind))))
  GROUP BY t.community_id, v.id, v.name, v.kind
  WITH NO DATA;


--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_codes (
    email text NOT NULL,
    otp_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone
);


--
-- Name: periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    month date NOT NULL,
    status text DEFAULT 'open'::text NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role public.app_role NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    email text NOT NULL,
    name text,
    password_hash text,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._migrations (name, run_at) FROM stdin;
0001_init.sql	2026-07-13 11:13:56.401452+00
0002_indexes.sql	2026-07-13 11:13:56.401452+00
0003_mviews.sql	2026-07-13 11:13:56.401452+00
0004_otp_rename.sql	2026-07-13 11:20:04.500279+00
0005_etl.sql	2026-08-03 16:34:38.109705+00
0006_drop_etl_sessions.sql	2026-08-03 18:40:10.950432+00
\.


--
-- Data for Name: allowed_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allowed_emails (email, community_id, role, flat_id, name, invited_by, invited_at, revoked_at) FROM stdin;
treasurer@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	admin	\N	Treasurer	system	2026-07-13 11:20:04.55456+00	\N
resident@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	resident	\N	Demo Resident	system	2026-07-13 11:20:04.55456+00	\N
admin@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	superadmin	\N	Super Admin	system	2026-07-13 11:20:04.55456+00	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, community_id, actor_user_id, actor_email, entity, entity_id, action, before, after, at, ip, user_agent) FROM stdin;
1	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	import_batch	63aebf66-7368-4ff4-bc88-60bbea1d8806	import	\N	{"rows": 164, "failed": 0, "inserted": 164, "sessionId": "89417297-76ec-4441-ac76-9354425512d2", "inputFiles": ["Expense-analysis_expense_1785782827406.xls", "Receipt-analysis_receipt_1785782827417.xls", "Vendor-Bill-Report_vendor_1785782827422.xls"], "importBatchId": "63aebf66-7368-4ff4-bc88-60bbea1d8806"}	2026-08-03 18:47:09.707376+00	172.30.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
\.


--
-- Data for Name: balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.balances (community_id, month, opening_paise, closing_paise) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, head_id, name) FROM stdin;
a55bc1a7-ab52-4f6a-aa75-ea5c7f567423	560632eb-563e-4d46-b6d9-88d70fc35081	Cleaning
db69faf5-e86f-4182-8de5-1ca79904e43c	560632eb-563e-4d46-b6d9-88d70fc35081	Maintenance
f4b24c3b-8a27-44b8-a51b-c9c136ad875b	560632eb-563e-4d46-b6d9-88d70fc35081	Housekeeping
6a6579a5-6c68-4efe-a855-3f5a4fc08f14	560632eb-563e-4d46-b6d9-88d70fc35081	Gardening
a8c39cbd-bfc0-417c-b8ba-343bc81885ca	560632eb-563e-4d46-b6d9-88d70fc35081	Petty Cash
3a56857c-639b-48fc-aa82-c2452c2ff999	560632eb-563e-4d46-b6d9-88d70fc35081	Accounting Adjustments
93149bcc-9b99-4c96-94b3-db0e88873ac7	560632eb-563e-4d46-b6d9-88d70fc35081	Water Treatment
c8727001-744d-487b-b322-a5041c5f5486	560632eb-563e-4d46-b6d9-88d70fc35081	Office Supplies
48ccd2a6-4e9c-4c38-8315-b973681d97a2	560632eb-563e-4d46-b6d9-88d70fc35081	Utilities
4278ab8c-27f6-4072-8ea2-8947cb103852	560632eb-563e-4d46-b6d9-88d70fc35081	Facility Management
da332500-8487-4d76-88ff-01a1abc95c76	a1c1e377-5cbc-4b1d-9224-7010318527a7	Community Contributions
c93b7894-0c90-4736-a589-bbcd7bd47848	a1c1e377-5cbc-4b1d-9224-7010318527a7	Recreation & Wellness
b0fd1332-e97d-4e31-a784-c77f18f95be6	a1c1e377-5cbc-4b1d-9224-7010318527a7	Events
996bf1ee-09a8-4112-aadf-c95a41614f6a	a1c1e377-5cbc-4b1d-9224-7010318527a7	Parking Revenue
a4906be6-ea53-4237-a413-63d94d72a178	a1c1e377-5cbc-4b1d-9224-7010318527a7	Advertisement
57f68b05-38c1-4b36-a988-198ad13f7eb5	a1c1e377-5cbc-4b1d-9224-7010318527a7	Maintenance Collection
a323bbb4-4a07-4c23-970a-cb657385f63a	a1c1e377-5cbc-4b1d-9224-7010318527a7	Move Charges
09b263d8-f075-414d-aed2-8c43807d6993	a1c1e377-5cbc-4b1d-9224-7010318527a7	Facility Rental
204e0bf5-d665-4b41-bf2b-5d41435b82df	a1c1e377-5cbc-4b1d-9224-7010318527a7	Penalties
217c2705-b8dd-46a6-8e97-d1bf90b56ed9	a1c1e377-5cbc-4b1d-9224-7010318527a7	Tax
\.


--
-- Data for Name: collections_dues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections_dues (flat_id, period_month, dues_paise, paid_paise, status) FROM stdin;
\.


--
-- Data for Name: communities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communities (id, name, currency, fy_start_month, created_at) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	Green Meadows	INR	4	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: dashboard_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_settings (community_id, dashboard_key, enabled, hidden_widgets) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	resident.overview	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.drilldown	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.cashflow	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.income	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.balance	t	{}
\.


--
-- Data for Name: flats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flats (id, community_id, code, owner_email) FROM stdin;
f88d6359-58a8-42b1-8476-24ce41b63802	caa11b01-c3a5-4067-a90c-b73b35075def	A-001	\N
5696d5bf-57f9-44ad-b92d-781cabc4a550	caa11b01-c3a5-4067-a90c-b73b35075def	A-002	\N
5c447f5e-a684-4075-8224-072f1fb12c93	caa11b01-c3a5-4067-a90c-b73b35075def	A-003	\N
6ddf10b7-40ed-44a1-9080-e50c60a08e32	caa11b01-c3a5-4067-a90c-b73b35075def	A-004	\N
5bfe95a5-bc38-4d00-811e-b5a6106e71c7	caa11b01-c3a5-4067-a90c-b73b35075def	A-005	\N
6e67ec18-d2aa-4cd4-8a51-b9a2b33429a2	caa11b01-c3a5-4067-a90c-b73b35075def	A-006	\N
05fbfe69-9195-45aa-bb9a-ef1de36f6fd9	caa11b01-c3a5-4067-a90c-b73b35075def	A-007	\N
7dca9ae9-39f7-4b2c-85b6-f9c820a65f0c	caa11b01-c3a5-4067-a90c-b73b35075def	A-008	\N
24f24d23-6946-4d06-b2d4-7ebe31278f9e	caa11b01-c3a5-4067-a90c-b73b35075def	A-009	\N
39278459-ad85-4e5e-937a-0a36b195c960	caa11b01-c3a5-4067-a90c-b73b35075def	A-010	\N
716bbe4c-f53d-4558-a4b5-caeb642f2c23	caa11b01-c3a5-4067-a90c-b73b35075def	A-011	\N
6dac5232-f75f-44d2-8533-4119c856f0ac	caa11b01-c3a5-4067-a90c-b73b35075def	A-012	\N
ea815ea6-a6d6-4547-bb06-ebfc9497a6f2	caa11b01-c3a5-4067-a90c-b73b35075def	A-013	\N
b441021b-6b42-4350-bd7a-385d23b17015	caa11b01-c3a5-4067-a90c-b73b35075def	A-014	\N
74194275-0229-47a7-9a12-691c228cbf03	caa11b01-c3a5-4067-a90c-b73b35075def	A-015	\N
f9df5252-7643-42fd-9a63-2e839347a52f	caa11b01-c3a5-4067-a90c-b73b35075def	A-016	\N
321b8a10-e82d-4cf6-a6b2-fde3fa7b05b1	caa11b01-c3a5-4067-a90c-b73b35075def	A-017	\N
9c1ddcb5-9b93-4e47-80ac-cbfc3b7f326e	caa11b01-c3a5-4067-a90c-b73b35075def	A-018	\N
f0106df5-f061-40fd-97c8-f6408f268ff9	caa11b01-c3a5-4067-a90c-b73b35075def	A-019	\N
deeb22d9-7a6b-4417-985b-c76049abae2e	caa11b01-c3a5-4067-a90c-b73b35075def	A-020	\N
c2e7bc3c-62db-4d01-aad3-9513cbf2ecbf	caa11b01-c3a5-4067-a90c-b73b35075def	A-021	\N
8c7ed2ff-3fea-4279-a889-c4e44b78ef6e	caa11b01-c3a5-4067-a90c-b73b35075def	A-022	\N
fb52fe46-dded-4f23-975d-3f36184896e9	caa11b01-c3a5-4067-a90c-b73b35075def	A-023	\N
5fc3f4ab-169c-47bc-819a-315c1a244aac	caa11b01-c3a5-4067-a90c-b73b35075def	A-024	\N
\.


--
-- Data for Name: heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heads (id, community_id, kind, name) FROM stdin;
560632eb-563e-4d46-b6d9-88d70fc35081	caa11b01-c3a5-4067-a90c-b73b35075def	expense	Expense
a1c1e377-5cbc-4b1d-9224-7010318527a7	caa11b01-c3a5-4067-a90c-b73b35075def	income	Income
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, community_id, filename, kind, uploaded_by, status, error, row_count, created_at) FROM stdin;
63aebf66-7368-4ff4-bc88-60bbea1d8806	caa11b01-c3a5-4067-a90c-b73b35075def	etl-transformed-transactions.csv	transactions	0f0c6024-6c4d-47b3-9012-4f714d448a40	committed	\N	164	2026-08-03 18:47:09.682539+00
\.


--
-- Data for Name: import_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_rules (id, community_id, kind, match, set_fields, priority) FROM stdin;
\.


--
-- Data for Name: import_staging; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_staging (batch_id, row_no, raw_json, mapped_json, error) FROM stdin;
63aebf66-7368-4ff4-bc88-60bbea1d8806	1	{"date": "2026-04-01", "head": "expense", "amount": "1214.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	2	{"date": "2026-05-01", "head": "expense", "amount": "1414.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	3	{"date": "2026-06-01", "head": "expense", "amount": "1428.98", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	4	{"date": "2026-07-01", "head": "expense", "amount": "1414.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-07", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	5	{"date": "2026-04-01", "head": "expense", "amount": "61049.0", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-04", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	6	{"date": "2026-05-01", "head": "expense", "amount": "7590.36", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-05", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	7	{"date": "2026-06-01", "head": "expense", "amount": "12018.34", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-06", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	8	{"date": "2026-07-01", "head": "expense", "amount": "4455.04", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-07", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	9	{"date": "2026-04-01", "head": "expense", "amount": "30000.0", "vendor": "JOHNSON LIFTS Pvt Ltd", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	10	{"date": "2026-06-01", "head": "expense", "amount": "150000.0", "vendor": "JOHNSON LIFTS Pvt Ltd", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	11	{"date": "2026-06-01", "head": "expense", "amount": "55000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Annual Compliance Expense", "source_ref": "D|Facility Management|EXOZEN|Annual Compliance Expense|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	12	{"date": "2026-04-01", "head": "expense", "amount": "154999.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	13	{"date": "2026-05-01", "head": "expense", "amount": "175902.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	14	{"date": "2026-04-01", "head": "expense", "amount": "46130.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	15	{"date": "2026-05-01", "head": "expense", "amount": "43011.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	16	{"date": "2026-04-01", "head": "expense", "amount": "79692.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	17	{"date": "2026-05-01", "head": "expense", "amount": "102431.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	18	{"date": "2026-04-01", "head": "expense", "amount": "78966.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	19	{"date": "2026-05-01", "head": "expense", "amount": "101572.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	20	{"date": "2026-04-01", "head": "expense", "amount": "9000.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-04", "vendor_kind": "individual"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	21	{"date": "2026-05-01", "head": "expense", "amount": "19300.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-05", "vendor_kind": "individual"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	22	{"date": "2026-06-01", "head": "expense", "amount": "20400.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-06", "vendor_kind": "individual"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	23	{"date": "2026-06-01", "head": "expense", "amount": "12876.27", "vendor": "KIRLOSKAR OIL ENGINES LTD", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "DG Service", "source_ref": "D|Maintenance|KIRLOSKAR OIL ENGINES LTD|DG Service|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	24	{"date": "2026-04-01", "head": "expense", "amount": "91401.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	25	{"date": "2026-05-01", "head": "expense", "amount": "54822.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	26	{"date": "2026-06-01", "head": "expense", "amount": "59784.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	27	{"date": "2026-07-01", "head": "expense", "amount": "59784.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-07", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	28	{"date": "2026-04-01", "head": "expense", "amount": "75588.3", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	29	{"date": "2026-05-01", "head": "expense", "amount": "82902.54", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	30	{"date": "2026-06-01", "head": "expense", "amount": "86506.61", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	31	{"date": "2026-04-01", "head": "expense", "amount": "59421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	32	{"date": "2026-05-01", "head": "expense", "amount": "59421.11", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	33	{"date": "2026-06-01", "head": "expense", "amount": "59421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	34	{"date": "2026-04-01", "head": "expense", "amount": "14000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	35	{"date": "2026-05-01", "head": "expense", "amount": "24000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	36	{"date": "2026-06-01", "head": "expense", "amount": "24000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	37	{"date": "2026-04-01", "head": "expense", "amount": "20280.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	38	{"date": "2026-05-01", "head": "expense", "amount": "130.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	39	{"date": "2026-07-01", "head": "expense", "amount": "1491.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-07", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	40	{"date": "2026-04-01", "head": "expense", "amount": "83421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	41	{"date": "2026-05-01", "head": "expense", "amount": "87561.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	42	{"date": "2026-06-01", "head": "expense", "amount": "85346.1", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	43	{"date": "2026-04-01", "head": "expense", "amount": "24471.07", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	44	{"date": "2026-05-01", "head": "expense", "amount": "23681.69", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	45	{"date": "2026-06-01", "head": "expense", "amount": "23627.24", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	46	{"date": "2026-04-01", "head": "expense", "amount": "22948.08", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	47	{"date": "2026-05-01", "head": "expense", "amount": "27759.6", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	48	{"date": "2026-06-01", "head": "expense", "amount": "24860.42", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	49	{"date": "2026-04-01", "head": "expense", "amount": "45317.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	50	{"date": "2026-05-01", "head": "expense", "amount": "34857.6", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	51	{"date": "2026-07-01", "head": "expense", "amount": "575.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-07", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	52	{"date": "2026-04-01", "head": "expense", "amount": "236717.04", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	53	{"date": "2026-05-01", "head": "expense", "amount": "313817.43", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	54	{"date": "2026-06-01", "head": "expense", "amount": "323070.45", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	55	{"date": "2026-04-01", "head": "expense", "amount": "24204.09", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	56	{"date": "2026-05-01", "head": "expense", "amount": "16397.01", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	57	{"date": "2026-06-01", "head": "expense", "amount": "23398.07", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	58	{"date": "2026-04-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	59	{"date": "2026-05-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	60	{"date": "2026-06-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	61	{"date": "2026-04-01", "head": "expense", "amount": "2000.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "One Time Operational Procurement", "source_ref": "D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-04", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	62	{"date": "2026-07-01", "head": "expense", "amount": "52694.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "One Time Operational Procurement", "source_ref": "D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-07", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	63	{"date": "2026-04-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	64	{"date": "2026-05-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	65	{"date": "2026-06-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	66	{"date": "2026-04-01", "head": "expense", "amount": "15683.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-04", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	67	{"date": "2026-05-01", "head": "expense", "amount": "20538.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-05", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	68	{"date": "2026-06-01", "head": "expense", "amount": "29600.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-06", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	69	{"date": "2026-07-01", "head": "expense", "amount": "14712.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-07", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	70	{"date": "2026-04-01", "head": "expense", "amount": "295.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-04", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	71	{"date": "2026-05-01", "head": "expense", "amount": "6487.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-05", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	72	{"date": "2026-06-01", "head": "expense", "amount": "5000.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-06", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	73	{"date": "2026-07-01", "head": "expense", "amount": "444.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-07", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	74	{"date": "2026-04-01", "head": "expense", "amount": "755.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-04", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	75	{"date": "2026-05-01", "head": "expense", "amount": "18917.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-05", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	76	{"date": "2026-06-01", "head": "expense", "amount": "5365.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-06", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	77	{"date": "2026-07-01", "head": "expense", "amount": "1015.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-07", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	78	{"date": "2026-04-01", "head": "expense", "amount": "75588.3", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	79	{"date": "2026-05-01", "head": "expense", "amount": "86966.39", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	80	{"date": "2026-06-01", "head": "expense", "amount": "85666.74", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	81	{"date": "2026-04-01", "head": "expense", "amount": "650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	82	{"date": "2026-05-01", "head": "expense", "amount": "6650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	83	{"date": "2026-06-01", "head": "expense", "amount": "650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	84	{"date": "2026-05-01", "head": "expense", "amount": "17334.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Facility Management|EXOZEN|Repair Work|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	85	{"date": "2026-06-01", "head": "expense", "amount": "8000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Facility Management|EXOZEN|Repair Work|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	86	{"date": "2026-04-01", "head": "expense", "amount": "0.41", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-04", "vendor_kind": "system"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	87	{"date": "2026-05-01", "head": "expense", "amount": "0.21", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-05", "vendor_kind": "system"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	88	{"date": "2026-06-01", "head": "expense", "amount": "0.1", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-06", "vendor_kind": "system"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	89	{"date": "2026-04-01", "head": "expense", "amount": "361130.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	90	{"date": "2026-05-01", "head": "expense", "amount": "373679.25", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	91	{"date": "2026-06-01", "head": "expense", "amount": "375840.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	92	{"date": "2026-04-01", "head": "expense", "amount": "22065.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	93	{"date": "2026-05-01", "head": "expense", "amount": "22064.87", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	94	{"date": "2026-06-01", "head": "expense", "amount": "21329.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	95	{"date": "2026-04-01", "head": "expense", "amount": "51642.7", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	96	{"date": "2026-05-01", "head": "expense", "amount": "54211.84", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	97	{"date": "2026-06-01", "head": "expense", "amount": "52518.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	98	{"date": "2026-04-01", "head": "expense", "amount": "86000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	99	{"date": "2026-05-01", "head": "expense", "amount": "94000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	100	{"date": "2026-06-01", "head": "expense", "amount": "118000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	101	{"date": "2026-04-01", "head": "expense", "amount": "67718.7", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	102	{"date": "2026-05-01", "head": "expense", "amount": "70631.52", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	103	{"date": "2026-06-01", "head": "expense", "amount": "75995.43", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	104	{"date": "2026-04-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	105	{"date": "2026-05-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	106	{"date": "2026-06-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	107	{"date": "2026-04-01", "head": "expense", "amount": "63000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Tank Cleaning Charges", "source_ref": "D|Facility Management|EXOZEN|Tank Cleaning Charges|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	108	{"date": "2026-04-01", "head": "expense", "amount": "9032.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-04", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	109	{"date": "2026-05-01", "head": "expense", "amount": "740.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-05", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	110	{"date": "2026-06-01", "head": "expense", "amount": "105.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-06", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	111	{"date": "2026-04-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	112	{"date": "2026-06-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	113	{"date": "2026-04-01", "head": "expense", "amount": "465815.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	114	{"date": "2026-05-01", "head": "expense", "amount": "478995.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	115	{"date": "2026-06-01", "head": "expense", "amount": "515775.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	116	{"date": "2026-04-01", "head": "expense", "amount": "6200.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-04", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	117	{"date": "2026-05-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-05", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	118	{"date": "2026-06-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-06", "vendor_kind": "company"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	119	{"date": "2026-04-01", "head": "income", "amount": "5000.0", "vendor": "Residents", "category": "Community Contributions", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Community Contributions|Residents|Association Fund|2026-04", "vendor_kind": "resident"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	120	{"date": "2026-05-01", "head": "income", "amount": "3700.0", "vendor": "Residents", "category": "Community Contributions", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Community Contributions|Residents|Association Fund|2026-05", "vendor_kind": "resident"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	121	{"date": "2026-06-01", "head": "income", "amount": "19500.0", "vendor": "Residents", "category": "Community Contributions", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Community Contributions|Residents|Association Fund|2026-06", "vendor_kind": "resident"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	122	{"date": "2026-04-01", "head": "income", "amount": "2800.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-04", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	123	{"date": "2026-05-01", "head": "income", "amount": "3500.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-05", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	124	{"date": "2026-06-01", "head": "income", "amount": "2100.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-06", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	125	{"date": "2026-07-01", "head": "income", "amount": "2800.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-07", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	126	{"date": "2026-05-01", "head": "income", "amount": "1120.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Amenities|Business Center|2026-05", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	127	{"date": "2026-06-01", "head": "income", "amount": "1080.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Amenities|Business Center|2026-06", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	128	{"date": "2026-07-01", "head": "income", "amount": "1000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Amenities|Business Center|2026-07", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	129	{"date": "2026-04-01", "head": "income", "amount": "12740.4", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-04", "vendor_kind": "statutory"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	130	{"date": "2026-05-01", "head": "income", "amount": "7592.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-05", "vendor_kind": "statutory"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	131	{"date": "2026-06-01", "head": "income", "amount": "5328.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-06", "vendor_kind": "statutory"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	132	{"date": "2026-07-01", "head": "income", "amount": "8680.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-07", "vendor_kind": "statutory"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	133	{"date": "2026-04-01", "head": "income", "amount": "1000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Common Area Violation", "source_ref": "C|Penalties|Resident Penalties|Common Area Violation|2026-04", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	134	{"date": "2026-06-01", "head": "income", "amount": "6000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Common Area Violation", "source_ref": "C|Penalties|Resident Penalties|Common Area Violation|2026-06", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	135	{"date": "2026-05-01", "head": "income", "amount": "8179.0", "vendor": "Community Events", "category": "Events", "direction": "C", "flat_code": "", "line_item": "Community Curriculum Activities", "source_ref": "C|Events|Community Events|Community Curriculum Activities|2026-05", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	136	{"date": "2026-05-01", "head": "income", "amount": "1000.0", "vendor": "Wellness Programs", "category": "Recreation & Wellness", "direction": "C", "flat_code": "", "line_item": "Fitness Trainers", "source_ref": "C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-05", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	137	{"date": "2026-07-01", "head": "income", "amount": "2304.0", "vendor": "Wellness Programs", "category": "Recreation & Wellness", "direction": "C", "flat_code": "", "line_item": "Fitness Trainers", "source_ref": "C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-07", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	138	{"date": "2026-04-01", "head": "income", "amount": "16000.0", "vendor": "Community Events", "category": "Events", "direction": "C", "flat_code": "", "line_item": "Flee Market", "source_ref": "C|Events|Community Events|Flee Market|2026-04", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	161	{"date": "2026-04-01", "head": "income", "amount": "12740.4", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-04", "vendor_kind": "statutory"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	139	{"date": "2026-07-01", "head": "income", "amount": "1000.0", "vendor": "Parking Services", "category": "Parking Revenue", "direction": "C", "flat_code": "", "line_item": "Guest Parking Rent", "source_ref": "C|Parking Revenue|Parking Services|Guest Parking Rent|2026-07", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	140	{"date": "2026-04-01", "head": "income", "amount": "151725.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-04", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	141	{"date": "2026-05-01", "head": "income", "amount": "95225.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-05", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	142	{"date": "2026-06-01", "head": "income", "amount": "68400.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-06", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	143	{"date": "2026-07-01", "head": "income", "amount": "108175.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-07", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	144	{"date": "2026-04-01", "head": "income", "amount": "9900.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-04", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	145	{"date": "2026-06-01", "head": "income", "amount": "5500.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-06", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	146	{"date": "2026-07-01", "head": "income", "amount": "3300.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-07", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	147	{"date": "2026-04-01", "head": "income", "amount": "2833274.0", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-04", "vendor_kind": "resident"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	148	{"date": "2026-05-01", "head": "income", "amount": "2838854.05", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-05", "vendor_kind": "resident"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	149	{"date": "2026-06-01", "head": "income", "amount": "2707115.06", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-06", "vendor_kind": "resident"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	150	{"date": "2026-07-01", "head": "income", "amount": "2748794.41", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-07", "vendor_kind": "resident"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	151	{"date": "2026-07-01", "head": "income", "amount": "7500.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move In/Out (Manual)", "source_ref": "C|Move Charges|Resident Services|Move In/Out (Manual)|2026-07", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	152	{"date": "2026-04-01", "head": "income", "amount": "35000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-04", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	153	{"date": "2026-05-01", "head": "income", "amount": "20000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-05", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	154	{"date": "2026-06-01", "head": "income", "amount": "30000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-06", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	155	{"date": "2026-07-01", "head": "income", "amount": "5000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-07", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	156	{"date": "2026-04-01", "head": "income", "amount": "12000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-04", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	157	{"date": "2026-05-01", "head": "income", "amount": "27000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-05", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	158	{"date": "2026-06-01", "head": "income", "amount": "21000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-06", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	159	{"date": "2026-07-01", "head": "income", "amount": "24000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-07", "vendor_kind": "internal"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	160	{"date": "2026-06-01", "head": "income", "amount": "1000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Parking Violation", "source_ref": "C|Penalties|Resident Penalties|Parking Violation|2026-06", "vendor_kind": "income_stream"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	162	{"date": "2026-05-01", "head": "income", "amount": "7592.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-05", "vendor_kind": "statutory"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	163	{"date": "2026-06-01", "head": "income", "amount": "5328.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-06", "vendor_kind": "statutory"}	\N	\N
63aebf66-7368-4ff4-bc88-60bbea1d8806	164	{"date": "2026-07-01", "head": "income", "amount": "8680.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-07", "vendor_kind": "statutory"}	\N	\N
\.


--
-- Data for Name: line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_items (id, category_id, vendor_id, name, first_seen_month, last_seen_month) FROM stdin;
ff06be79-c571-4eeb-9476-39af5fb6215c	48ccd2a6-4e9c-4c38-8315-b973681d97a2	b8cb70f3-de8f-4d12-b3e5-730bfc1fab54	Airtel Postpaid Connection	2026-04-01	2026-07-01
2ba58f95-78e7-4865-90a7-fb73902bfe74	c8727001-744d-487b-b322-a5041c5f5486	d92e9928-ff4c-4c68-be4c-d2b814b71f7f	Amazon Purchase	2026-04-01	2026-07-01
f0ef73d2-489a-4371-a14d-d2a92678169c	db69faf5-e86f-4182-8de5-1ca79904e43c	983d0e00-2e85-4b4e-9537-6708dfd53d8d	AMC (Lift)	2026-04-01	2026-06-01
c9f40172-7d7a-46b8-88a8-c93be6cc9bda	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Annual Compliance Expense	2026-06-01	2026-06-01
862ed5ee-6b3e-4d8b-964a-324e7811c8a1	48ccd2a6-4e9c-4c38-8315-b973681d97a2	d07ed74f-cb56-401e-a52c-cf8dff72632e	BESCOM A Block	2026-04-01	2026-05-01
580a407a-d4eb-4e18-a95c-f5c9939e2110	48ccd2a6-4e9c-4c38-8315-b973681d97a2	d07ed74f-cb56-401e-a52c-cf8dff72632e	BESCOM B Block	2026-04-01	2026-05-01
b3e5daf4-cb68-4fac-9567-619687b600e9	48ccd2a6-4e9c-4c38-8315-b973681d97a2	d07ed74f-cb56-401e-a52c-cf8dff72632e	BESCOM E Block	2026-04-01	2026-05-01
4ec1f899-0a5b-4f46-9b22-a1af1ffcdbea	48ccd2a6-4e9c-4c38-8315-b973681d97a2	d07ed74f-cb56-401e-a52c-cf8dff72632e	BESCOM G Block	2026-04-01	2026-05-01
783740fb-73a0-483a-b978-ef7ffa7aa8b6	a55bc1a7-ab52-4f6a-aa75-ea5c7f567423	8a5a8fe8-49cf-44e4-83b4-650314ba69f9	Debris Disposal	2026-04-01	2026-06-01
1fc45ff5-5f50-4a60-98f3-15376630e4de	db69faf5-e86f-4182-8de5-1ca79904e43c	1561c541-7b99-41b4-9615-fb51793db72e	DG Service	2026-06-01	2026-06-01
cbb9af9d-0e8d-4ab0-874d-49d208caff9c	48ccd2a6-4e9c-4c38-8315-b973681d97a2	c3cc38d3-fe2e-4f17-b595-5f6653fafc62	Diesel	2026-04-01	2026-07-01
10ca761c-6157-44d0-9b18-7fb639ee3c6b	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Electricians Salary	2026-04-01	2026-06-01
ea313bb9-2caa-410a-8e3c-ca4b8ca6b849	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Facility Manager	2026-04-01	2026-06-01
9f669f19-7231-4941-9054-6c78f6ab0f3d	f4b24c3b-8a27-44b8-a51b-c9c136ad875b	0548410e-944b-4ab6-ae4a-59f966705a14	Garbage removal	2026-04-01	2026-06-01
c1c9b78f-b2fe-4ad8-98f5-3392b7a3bc63	6a6579a5-6c68-4efe-a855-3f5a4fc08f14	9702f057-72ac-4068-a1b9-4606f3946a3d	Garden Tools	2026-04-01	2026-07-01
ecb5da0a-cd5f-4c6e-82c7-8ab52e71a436	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Gardeners Salary	2026-04-01	2026-06-01
318d7ac0-4a6a-4c46-a66f-8f5e8e9a4ead	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Gardening Supervisor Salary	2026-04-01	2026-06-01
2658b37d-b21a-4ae4-b218-6c330c35d21e	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Help Desk Salary	2026-04-01	2026-06-01
ce01d9b8-b697-4df3-a8d4-37e041da1fca	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	HK Materials	2026-04-01	2026-07-01
2a327a9c-3a0d-45a6-b8c9-a8d7d7eebe62	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	House Keeping Janitor Salary	2026-04-01	2026-06-01
4878a32e-3502-4674-804e-d7449fb10a51	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Housekeeping Supervisor Salary	2026-04-01	2026-06-01
adcfb9fc-e234-4604-a256-604d1fa1715e	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Management Fee	2026-04-01	2026-06-01
c938cea4-b064-4525-8a29-a8dd001623d7	c8727001-744d-487b-b322-a5041c5f5486	46f7c3d0-934a-4f17-a086-d0631bbd68df	One Time Operational Procurement	2026-04-01	2026-07-01
0793ffa6-2387-4e4e-a413-154a86f2a7a4	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Pest Control Services	2026-04-01	2026-06-01
12f645c4-83ab-4e93-a1a8-147422b1ab3e	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	Petty Cash - Consumables	2026-04-01	2026-07-01
b0f547ec-8678-4093-9fb6-a1f8e5a8ca59	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	Petty Cash - Electricals	2026-04-01	2026-07-01
7a8d88cc-ef88-41b0-8413-f241f42bc9bf	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	Petty Cash - Hardware	2026-04-01	2026-07-01
8e2dbde6-8770-4808-a973-359058af18bf	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Plumbers Salary	2026-04-01	2026-06-01
8c89e527-c1c7-448c-8da8-102edb9f6c71	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Rental Charges Machinery	2026-04-01	2026-06-01
83464dcd-391a-4082-95a8-470f086e0d2a	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Repair Work	2026-05-01	2026-06-01
1d1eef2a-83d7-4611-b08b-c6cfba6a68f0	3a56857c-639b-48fc-aa82-c2452c2ff999	112c9a31-d132-497e-9c20-898cce64e20b	Roundoff	2026-04-01	2026-06-01
05ec294d-67c3-406c-863b-6d3f7728f579	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Security Guards Salary	2026-04-01	2026-06-01
653d6c78-bd19-43da-b305-43d5f2c4e85e	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Security Lady Guards Salary	2026-04-01	2026-06-01
3f906d80-3f9a-4108-9b9e-c33e3ef4393c	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Security Supervisor Salary	2026-04-01	2026-06-01
e2442bb7-001e-48a3-80b5-3def5d3a5998	93149bcc-9b99-4c96-94b3-db0e88873ac7	18d3e29f-792f-471f-be1c-5d7643616109	STP water collection (Sludge Removal)	2026-04-01	2026-06-01
09a6d9b3-c1fd-4553-8876-658dd9947871	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	STP/WTP Operators Salary	2026-04-01	2026-06-01
3e75155c-08a1-4806-86e3-1783ec75d747	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Swimming Pool Services	2026-04-01	2026-06-01
c8c93357-3219-4a05-86d0-65dd4ca553c0	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Tank Cleaning Charges	2026-04-01	2026-04-01
e1dd01a7-52bd-41bb-8e64-e2e746338e9e	c8727001-744d-487b-b322-a5041c5f5486	46f7c3d0-934a-4f17-a086-d0631bbd68df	Tools & Stationary	2026-04-01	2026-06-01
90ef3b41-4a60-4633-9254-e9d13dedb930	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Walkie Talkies	2026-04-01	2026-06-01
2613fbaf-1eb9-4801-95f0-dd8580f0db5d	48ccd2a6-4e9c-4c38-8315-b973681d97a2	61b56ad6-6e20-42d4-a1d1-79688f7bf89d	Water Supply	2026-04-01	2026-06-01
b7b0a7c9-8047-45ef-9384-9caa80156d99	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	Water Test Report	2026-04-01	2026-06-01
b87ff949-0e7e-4e81-88ab-692fd61a07d6	da332500-8487-4d76-88ff-01a1abc95c76	a3959c90-89da-4a51-aae0-27f3771f5ad9	Association Fund	2026-04-01	2026-06-01
de0b0793-8428-4ec8-b46c-69568bc1a82e	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	AV room	2026-04-01	2026-07-01
f55c077a-88aa-45be-9ca6-05aec1fcb7f0	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	Business Center	2026-05-01	2026-07-01
30294e30-d793-4f16-bc38-970b2ea4f235	217c2705-b8dd-46a6-8e97-d1bf90b56ed9	82d75633-69f9-45df-849f-0e0897d54e80	CGST Output	2026-04-01	2026-07-01
2d161c02-9091-4f7c-aec8-ccda21dd8f3f	204e0bf5-d665-4b41-bf2b-5d41435b82df	08287f21-5bbe-4ec6-8038-b88edc9cd70d	Common Area Violation	2026-04-01	2026-06-01
bcb00dad-ac39-4c89-b8cb-469a5660b76f	b0fd1332-e97d-4e31-a784-c77f18f95be6	edf42993-3fcc-4dde-bb53-f549cff58f21	Community Curriculum Activities	2026-05-01	2026-05-01
e29f34c3-8d62-4452-a6aa-c40bd3d747a8	c93b7894-0c90-4736-a589-bbcd7bd47848	29846594-7bfc-4141-9afe-c92b48823f8c	Fitness Trainers	2026-05-01	2026-07-01
8f328f95-0eba-4d51-8d0b-733a30d044ed	b0fd1332-e97d-4e31-a784-c77f18f95be6	edf42993-3fcc-4dde-bb53-f549cff58f21	Flee Market	2026-04-01	2026-04-01
0ab89b84-46cb-4850-8677-227a6e44bddf	996bf1ee-09a8-4112-aadf-c95a41614f6a	d748b338-1215-4ecb-a18e-9c46c06019a7	Guest Parking Rent	2026-07-01	2026-07-01
fe234164-f788-46c4-832b-540508369803	204e0bf5-d665-4b41-bf2b-5d41435b82df	08287f21-5bbe-4ec6-8038-b88edc9cd70d	Late Payment Fine	2026-04-01	2026-07-01
ebfc7e39-97cd-4fb4-b684-ddabd8668baf	a4906be6-ea53-4237-a413-63d94d72a178	cb3df385-a389-47fd-9f94-14c8e4464d4c	Lift Advertisement	2026-04-01	2026-07-01
20920cba-fecc-4a21-ae61-9f2865bfaad9	57f68b05-38c1-4b36-a988-198ad13f7eb5	34c19556-843d-4919-bbb6-e60a1d25dc65	Maintenance Charge	2026-04-01	2026-07-01
7f90940d-a45a-4701-abc2-1b661b7b4eb0	a323bbb4-4a07-4c23-970a-cb657385f63a	8b3b7e7e-e6c4-493c-9b35-ddda3c06d7a7	Move In/Out (Manual)	2026-07-01	2026-07-01
db61eebd-1e3d-434a-a22e-7536b9ac508b	a323bbb4-4a07-4c23-970a-cb657385f63a	8b3b7e7e-e6c4-493c-9b35-ddda3c06d7a7	Move in/out Charges	2026-04-01	2026-07-01
667fc1c9-c55c-49a0-a818-ae7fcdfdc91b	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	Multipurpose Party Hall/Club House	2026-04-01	2026-07-01
f947be51-3973-4abe-b1c3-1538607f451d	204e0bf5-d665-4b41-bf2b-5d41435b82df	08287f21-5bbe-4ec6-8038-b88edc9cd70d	Parking Violation	2026-06-01	2026-06-01
06d8ac01-03bc-4625-92e0-2b175bc2afc0	217c2705-b8dd-46a6-8e97-d1bf90b56ed9	82d75633-69f9-45df-849f-0e0897d54e80	SGST Output	2026-04-01	2026-07-01
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp_codes (email, otp_hash, expires_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periods (id, community_id, month, status) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, community_id, txn_date, period_month, head_id, category_id, vendor_id, line_item_id, flat_id, amount_paise, direction, source, source_ref, notes, created_by, created_at, updated_at) FROM stdin;
d89e36b3-7e14-458c-ade2-0e81d474d680	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	b8cb70f3-de8f-4d12-b3e5-730bfc1fab54	ff06be79-c571-4eeb-9476-39af5fb6215c	\N	121482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
90d41a6d-1d9d-4350-82d1-378662070eef	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	b8cb70f3-de8f-4d12-b3e5-730bfc1fab54	ff06be79-c571-4eeb-9476-39af5fb6215c	\N	141482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
2b79bc75-fd1d-44a9-82df-3f6257722a24	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	b8cb70f3-de8f-4d12-b3e5-730bfc1fab54	ff06be79-c571-4eeb-9476-39af5fb6215c	\N	142898	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
ed67fda2-4e1d-4fb8-9926-3ab2d593f064	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	b8cb70f3-de8f-4d12-b3e5-730bfc1fab54	ff06be79-c571-4eeb-9476-39af5fb6215c	\N	141482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
ef237597-1559-4a5a-8128-caf7d0d9175b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	c8727001-744d-487b-b322-a5041c5f5486	d92e9928-ff4c-4c68-be4c-d2b814b71f7f	2ba58f95-78e7-4865-90a7-fb73902bfe74	\N	6104900	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
3b05ae71-dca8-4d91-940e-9f2505d274de	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	c8727001-744d-487b-b322-a5041c5f5486	d92e9928-ff4c-4c68-be4c-d2b814b71f7f	2ba58f95-78e7-4865-90a7-fb73902bfe74	\N	759036	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
70283a0c-54dd-4253-a574-0fa986277d85	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	c8727001-744d-487b-b322-a5041c5f5486	d92e9928-ff4c-4c68-be4c-d2b814b71f7f	2ba58f95-78e7-4865-90a7-fb73902bfe74	\N	1201834	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
0fdf3ddf-b211-497c-b766-076a05e1d91b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	560632eb-563e-4d46-b6d9-88d70fc35081	c8727001-744d-487b-b322-a5041c5f5486	d92e9928-ff4c-4c68-be4c-d2b814b71f7f	2ba58f95-78e7-4865-90a7-fb73902bfe74	\N	445504	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
7859db4a-8217-4726-9b89-7cf0b3bc4ac3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	db69faf5-e86f-4182-8de5-1ca79904e43c	983d0e00-2e85-4b4e-9537-6708dfd53d8d	f0ef73d2-489a-4371-a14d-d2a92678169c	\N	3000000	D	csv	D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
d5a6eaf6-7777-4a40-9305-2bc33901aef3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	db69faf5-e86f-4182-8de5-1ca79904e43c	983d0e00-2e85-4b4e-9537-6708dfd53d8d	f0ef73d2-489a-4371-a14d-d2a92678169c	\N	15000000	D	csv	D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
d748b580-6756-422e-8034-4b6958810d6c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	c9f40172-7d7a-46b8-88a8-c93be6cc9bda	\N	5500000	D	csv	D|Facility Management|EXOZEN|Annual Compliance Expense|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
1b172050-0ee6-48d3-bd50-45669fc33ada	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	d07ed74f-cb56-401e-a52c-cf8dff72632e	862ed5ee-6b3e-4d8b-964a-324e7811c8a1	\N	15499900	D	csv	D|Utilities|BESCOM|BESCOM A Block|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
da60d45b-aebe-4af5-80b8-b651f72dd942	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	d07ed74f-cb56-401e-a52c-cf8dff72632e	862ed5ee-6b3e-4d8b-964a-324e7811c8a1	\N	17590200	D	csv	D|Utilities|BESCOM|BESCOM A Block|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
cbe8fcff-7aa3-4988-beee-14d91c098b81	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	d07ed74f-cb56-401e-a52c-cf8dff72632e	580a407a-d4eb-4e18-a95c-f5c9939e2110	\N	4613000	D	csv	D|Utilities|BESCOM|BESCOM B Block|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
8cedb578-7cc0-4bad-be86-86eb889970c1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	d07ed74f-cb56-401e-a52c-cf8dff72632e	580a407a-d4eb-4e18-a95c-f5c9939e2110	\N	4301100	D	csv	D|Utilities|BESCOM|BESCOM B Block|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
01faf03d-7f16-4c29-aa9a-a4fd0e276ae3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	d07ed74f-cb56-401e-a52c-cf8dff72632e	b3e5daf4-cb68-4fac-9567-619687b600e9	\N	7969200	D	csv	D|Utilities|BESCOM|BESCOM E Block|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
e819981b-2e54-4fa7-b02f-f96bc02f39b3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	d07ed74f-cb56-401e-a52c-cf8dff72632e	b3e5daf4-cb68-4fac-9567-619687b600e9	\N	10243100	D	csv	D|Utilities|BESCOM|BESCOM E Block|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
b70a79ba-08d9-4b98-bbbf-59d08fe20dfd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	d07ed74f-cb56-401e-a52c-cf8dff72632e	4ec1f899-0a5b-4f46-9b22-a1af1ffcdbea	\N	7896600	D	csv	D|Utilities|BESCOM|BESCOM G Block|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
c05c8209-7de8-4768-acd4-a8d4256763bd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	d07ed74f-cb56-401e-a52c-cf8dff72632e	4ec1f899-0a5b-4f46-9b22-a1af1ffcdbea	\N	10157200	D	csv	D|Utilities|BESCOM|BESCOM G Block|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
7045c5fe-beb9-41fa-a2bf-f7380f34392c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	a55bc1a7-ab52-4f6a-aa75-ea5c7f567423	8a5a8fe8-49cf-44e4-83b4-650314ba69f9	783740fb-73a0-483a-b978-ef7ffa7aa8b6	\N	900000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
19b40519-ce67-4ec9-b370-e993e524744e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	a55bc1a7-ab52-4f6a-aa75-ea5c7f567423	8a5a8fe8-49cf-44e4-83b4-650314ba69f9	783740fb-73a0-483a-b978-ef7ffa7aa8b6	\N	1930000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
8797c657-812d-43d8-b362-0be7aab45afc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	a55bc1a7-ab52-4f6a-aa75-ea5c7f567423	8a5a8fe8-49cf-44e4-83b4-650314ba69f9	783740fb-73a0-483a-b978-ef7ffa7aa8b6	\N	2040000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
8ea2a52a-b3e1-466b-b994-edca609f989e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	db69faf5-e86f-4182-8de5-1ca79904e43c	1561c541-7b99-41b4-9615-fb51793db72e	1fc45ff5-5f50-4a60-98f3-15376630e4de	\N	1287627	D	csv	D|Maintenance|KIRLOSKAR OIL ENGINES LTD|DG Service|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
895e846b-b2aa-4fed-835e-95376eab1677	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	c3cc38d3-fe2e-4f17-b595-5f6653fafc62	cbb9af9d-0e8d-4ab0-874d-49d208caff9c	\N	9140100	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
704cb3a6-e600-48c1-8089-1a3237163b57	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	c3cc38d3-fe2e-4f17-b595-5f6653fafc62	cbb9af9d-0e8d-4ab0-874d-49d208caff9c	\N	5482200	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
f695fd6e-f5e3-4b83-a5bd-034c0860e26a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	c3cc38d3-fe2e-4f17-b595-5f6653fafc62	cbb9af9d-0e8d-4ab0-874d-49d208caff9c	\N	5978400	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
955f1c67-aff1-45f6-93ea-250dc4dcdaf4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	c3cc38d3-fe2e-4f17-b595-5f6653fafc62	cbb9af9d-0e8d-4ab0-874d-49d208caff9c	\N	5978400	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
e9fc15a2-40eb-4f7a-bc89-fc8962b5665b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	10ca761c-6157-44d0-9b18-7fb639ee3c6b	\N	7558830	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
87d5e1f9-fece-4174-95a4-e0e27044ede0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	10ca761c-6157-44d0-9b18-7fb639ee3c6b	\N	8290254	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
e4a04bbf-4cf1-4ba1-a0b7-2f463d33bde3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	10ca761c-6157-44d0-9b18-7fb639ee3c6b	\N	8650661	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
5f198e4b-30c2-46be-b03e-4871bd861b6f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	ea313bb9-2caa-410a-8e3c-ca4b8ca6b849	\N	5942100	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
8ae49af9-9f44-4979-90d7-71368c525310	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	ea313bb9-2caa-410a-8e3c-ca4b8ca6b849	\N	5942111	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
f4afd4c6-edad-4034-8bad-8a958cd70018	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	ea313bb9-2caa-410a-8e3c-ca4b8ca6b849	\N	5942100	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
782cac53-998b-4ae3-ac4b-415dd3fc19a9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	f4b24c3b-8a27-44b8-a51b-c9c136ad875b	0548410e-944b-4ab6-ae4a-59f966705a14	9f669f19-7231-4941-9054-6c78f6ab0f3d	\N	1400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
97155197-4f2c-4f38-8a96-9975146e8dfe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	f4b24c3b-8a27-44b8-a51b-c9c136ad875b	0548410e-944b-4ab6-ae4a-59f966705a14	9f669f19-7231-4941-9054-6c78f6ab0f3d	\N	2400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
b9535d4d-b8d6-49d2-9d51-8d6c3a56f030	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	f4b24c3b-8a27-44b8-a51b-c9c136ad875b	0548410e-944b-4ab6-ae4a-59f966705a14	9f669f19-7231-4941-9054-6c78f6ab0f3d	\N	2400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
f3bdf6ac-967a-453b-9604-82b36e91b466	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	6a6579a5-6c68-4efe-a855-3f5a4fc08f14	9702f057-72ac-4068-a1b9-4606f3946a3d	c1c9b78f-b2fe-4ad8-98f5-3392b7a3bc63	\N	2028000	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
345800a8-31c1-43d7-9d9c-e18ac1892787	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	6a6579a5-6c68-4efe-a855-3f5a4fc08f14	9702f057-72ac-4068-a1b9-4606f3946a3d	c1c9b78f-b2fe-4ad8-98f5-3392b7a3bc63	\N	13000	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
70979ed6-cfaa-4169-b33d-d30a1c38ba3d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	560632eb-563e-4d46-b6d9-88d70fc35081	6a6579a5-6c68-4efe-a855-3f5a4fc08f14	9702f057-72ac-4068-a1b9-4606f3946a3d	c1c9b78f-b2fe-4ad8-98f5-3392b7a3bc63	\N	149100	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
667f321f-a71d-4bfb-928c-d3063604a615	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	ecb5da0a-cd5f-4c6e-82c7-8ab52e71a436	\N	8342100	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
0a200d06-72b3-457e-a551-6d625e3498b2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	ecb5da0a-cd5f-4c6e-82c7-8ab52e71a436	\N	8756100	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
1ad56fa3-b24f-42ea-86c7-ba9612d636b6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	ecb5da0a-cd5f-4c6e-82c7-8ab52e71a436	\N	8534610	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
ddbc1024-d425-410a-97bd-2e58bbf4fc1a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	318d7ac0-4a6a-4c46-a66f-8f5e8e9a4ead	\N	2447107	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
7b0d7d1f-1002-4a26-b561-4b26d9f077a9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	318d7ac0-4a6a-4c46-a66f-8f5e8e9a4ead	\N	2368169	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
f5b9e323-accb-4c26-a816-d7e3de276a55	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	318d7ac0-4a6a-4c46-a66f-8f5e8e9a4ead	\N	2362724	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
f19985c6-5ef8-4c06-9a5f-c8520394a972	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	2658b37d-b21a-4ae4-b218-6c330c35d21e	\N	2294808	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
5bc9e740-49f1-4377-9abd-286e23c357d6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	2658b37d-b21a-4ae4-b218-6c330c35d21e	\N	2775960	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
aa0d6feb-56b4-43e8-a95f-3854a77750a9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	2658b37d-b21a-4ae4-b218-6c330c35d21e	\N	2486042	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
cac174c4-087c-4bb8-bf6a-45fba19ddff6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	ce01d9b8-b697-4df3-a8d4-37e041da1fca	\N	4531700	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
559b4725-360e-48c0-a8d8-8eff23fb4664	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	ce01d9b8-b697-4df3-a8d4-37e041da1fca	\N	3485760	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
b83ff3bf-bc8e-477c-babd-88af17c70abb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	ce01d9b8-b697-4df3-a8d4-37e041da1fca	\N	57500	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
6e115a1a-3d2a-40ba-85c9-c830b4ef285c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	2a327a9c-3a0d-45a6-b8c9-a8d7d7eebe62	\N	23671704	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
abbd87fc-7191-408c-a35f-ba4420ae8b4c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	2a327a9c-3a0d-45a6-b8c9-a8d7d7eebe62	\N	31381743	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
4dab366f-7e38-4fb6-a9e9-bd02ab286641	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	2a327a9c-3a0d-45a6-b8c9-a8d7d7eebe62	\N	32307045	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
d62df6ea-18cb-4701-8d1f-c6bddfc33faf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	4878a32e-3502-4674-804e-d7449fb10a51	\N	2420409	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
f348dd50-67a9-4db9-816a-27682f7f395f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	4878a32e-3502-4674-804e-d7449fb10a51	\N	1639701	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
23b802a9-9616-4200-9764-0729c52f373e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	4878a32e-3502-4674-804e-d7449fb10a51	\N	2339807	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
45e39a27-6228-41e6-bc7f-aae6db44fc73	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	adcfb9fc-e234-4604-a256-604d1fa1715e	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
2e5ac26f-5ca8-434a-a015-607b89ea009b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	adcfb9fc-e234-4604-a256-604d1fa1715e	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
241ee136-67bf-48f3-b05f-2a8a5b18a829	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	adcfb9fc-e234-4604-a256-604d1fa1715e	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
f5789bfd-df7c-496b-a4b1-3357e0e46fcf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	c8727001-744d-487b-b322-a5041c5f5486	46f7c3d0-934a-4f17-a086-d0631bbd68df	c938cea4-b064-4525-8a29-a8dd001623d7	\N	200000	D	csv	D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
1ede4feb-fa99-4a13-908a-e93ff10071f8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	560632eb-563e-4d46-b6d9-88d70fc35081	c8727001-744d-487b-b322-a5041c5f5486	46f7c3d0-934a-4f17-a086-d0631bbd68df	c938cea4-b064-4525-8a29-a8dd001623d7	\N	5269400	D	csv	D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
191aa720-0c9d-40a9-a0e4-0dc95619d098	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	0793ffa6-2387-4e4e-a413-154a86f2a7a4	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
2cee0b52-7726-4f58-93b6-f8b1d7c58300	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	0793ffa6-2387-4e4e-a413-154a86f2a7a4	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
6ab482c4-9c81-4854-81e6-c2b55f8ba80c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	0793ffa6-2387-4e4e-a413-154a86f2a7a4	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
16d7590a-26fd-4547-b35b-3ae4b8cb594b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	12f645c4-83ab-4e93-a1a8-147422b1ab3e	\N	1568300	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
23b335fa-b489-4c75-81ba-78ef51b08d75	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	12f645c4-83ab-4e93-a1a8-147422b1ab3e	\N	2053800	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
82dc2c89-40d8-4fc6-ac4a-dcd5cf528c0f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	12f645c4-83ab-4e93-a1a8-147422b1ab3e	\N	2960000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
b176df4a-46d3-4148-8ba0-faca16b4930b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	560632eb-563e-4d46-b6d9-88d70fc35081	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	12f645c4-83ab-4e93-a1a8-147422b1ab3e	\N	1471200	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
5e84266f-115a-4de4-b490-03f99c367ec7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	b0f547ec-8678-4093-9fb6-a1f8e5a8ca59	\N	29500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
bf61c971-2072-45b3-9549-072ab6703c4f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	b0f547ec-8678-4093-9fb6-a1f8e5a8ca59	\N	648700	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
960691d6-35da-45c6-aa61-32f83fc280a0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	b0f547ec-8678-4093-9fb6-a1f8e5a8ca59	\N	500000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
c7dd8fe9-ede9-4ad7-a3b8-e37cf1a247b6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	560632eb-563e-4d46-b6d9-88d70fc35081	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	b0f547ec-8678-4093-9fb6-a1f8e5a8ca59	\N	44400	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
dfb3a44e-cdb1-4b0e-b1eb-12321216381e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	7a8d88cc-ef88-41b0-8413-f241f42bc9bf	\N	75500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
c8894971-dd5e-45d2-bc48-e60939036def	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	7a8d88cc-ef88-41b0-8413-f241f42bc9bf	\N	1891700	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
cffd28b2-110c-40f5-885d-01204603d96d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	7a8d88cc-ef88-41b0-8413-f241f42bc9bf	\N	536500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
2b380133-18c5-42b9-8a28-1c2b04f6df5f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	560632eb-563e-4d46-b6d9-88d70fc35081	a8c39cbd-bfc0-417c-b8ba-343bc81885ca	46f7c3d0-934a-4f17-a086-d0631bbd68df	7a8d88cc-ef88-41b0-8413-f241f42bc9bf	\N	101500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
5c2bcbf4-29ff-4ad8-8b8b-d50d7f40f22f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	8e2dbde6-8770-4808-a973-359058af18bf	\N	7558830	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
7e3bf35a-f521-4da6-bf7d-d650f7bb1540	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	8e2dbde6-8770-4808-a973-359058af18bf	\N	8696639	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
3e4b0fc3-8fc6-40aa-97db-70dc5186caa4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	8e2dbde6-8770-4808-a973-359058af18bf	\N	8566674	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
9e38c062-13a1-46c1-8212-073a3ac46679	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	8c89e527-c1c7-448c-8da8-102edb9f6c71	\N	65000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
a0e812d1-bfdb-4916-bf54-3f5fc745869f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	8c89e527-c1c7-448c-8da8-102edb9f6c71	\N	665000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
9c1612c0-3ab9-48a8-a5a4-941565f7743a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	8c89e527-c1c7-448c-8da8-102edb9f6c71	\N	65000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
daaf84b5-0a76-4072-8e98-5a3ba968d12a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	83464dcd-391a-4082-95a8-470f086e0d2a	\N	1733400	D	csv	D|Facility Management|EXOZEN|Repair Work|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
d55ed4db-b139-46ea-a9af-e03107686b1b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	83464dcd-391a-4082-95a8-470f086e0d2a	\N	800000	D	csv	D|Facility Management|EXOZEN|Repair Work|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
0787a3d3-a378-4b66-af7b-1e926a1158c6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	3a56857c-639b-48fc-aa82-c2452c2ff999	112c9a31-d132-497e-9c20-898cce64e20b	1d1eef2a-83d7-4611-b08b-c6cfba6a68f0	\N	41	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
0d234909-79b7-4906-a205-1b667111c533	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	3a56857c-639b-48fc-aa82-c2452c2ff999	112c9a31-d132-497e-9c20-898cce64e20b	1d1eef2a-83d7-4611-b08b-c6cfba6a68f0	\N	21	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
062a525c-d2c8-49b5-bf30-715a452c592b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	3a56857c-639b-48fc-aa82-c2452c2ff999	112c9a31-d132-497e-9c20-898cce64e20b	1d1eef2a-83d7-4611-b08b-c6cfba6a68f0	\N	10	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
5a69035d-5fa4-49d8-9234-5582c1eb54a7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	05ec294d-67c3-406c-863b-6d3f7728f579	\N	36113050	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
ae351de4-47ec-47be-8246-b39a37026dfa	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	05ec294d-67c3-406c-863b-6d3f7728f579	\N	37367925	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
1e692eee-c3ff-40a8-8744-dc30f61f8661	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	05ec294d-67c3-406c-863b-6d3f7728f579	\N	37584050	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
c48de29b-551e-4729-a905-6526ecbb25d1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	653d6c78-bd19-43da-b305-43d5f2c4e85e	\N	2206500	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
8be9d65f-faa8-43c4-9bea-057feea018d4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	653d6c78-bd19-43da-b305-43d5f2c4e85e	\N	2206487	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
a58fdfbd-1ab1-4f88-b0ea-eaef3361fffe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	653d6c78-bd19-43da-b305-43d5f2c4e85e	\N	2132950	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
d6be08c4-db98-4b38-9aa8-d41f12f90d84	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	3f906d80-3f9a-4108-9b9e-c33e3ef4393c	\N	5164270	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
feaa4407-623e-4e11-bb41-3a978a1577d7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	3f906d80-3f9a-4108-9b9e-c33e3ef4393c	\N	5421184	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
bc2234ee-cf49-491b-a241-4df5f812221a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	3f906d80-3f9a-4108-9b9e-c33e3ef4393c	\N	5251800	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
a85da783-76a2-4817-a4f9-bbf0cb91c970	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	93149bcc-9b99-4c96-94b3-db0e88873ac7	18d3e29f-792f-471f-be1c-5d7643616109	e2442bb7-001e-48a3-80b5-3def5d3a5998	\N	8600000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
45f8a23f-0995-4694-9317-6703bb9da4a9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	93149bcc-9b99-4c96-94b3-db0e88873ac7	18d3e29f-792f-471f-be1c-5d7643616109	e2442bb7-001e-48a3-80b5-3def5d3a5998	\N	9400000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
d448ded5-e206-465f-9023-f647292c8fa3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	93149bcc-9b99-4c96-94b3-db0e88873ac7	18d3e29f-792f-471f-be1c-5d7643616109	e2442bb7-001e-48a3-80b5-3def5d3a5998	\N	11800000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
12434b3c-674d-4966-8a69-03c12eec57f0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	09a6d9b3-c1fd-4553-8876-658dd9947871	\N	6771870	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
d55253a0-0e4a-42a5-97e6-3bc9b28ae251	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	09a6d9b3-c1fd-4553-8876-658dd9947871	\N	7063152	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
64bf6468-3581-44d5-ae5a-2fa1120f1bd7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	09a6d9b3-c1fd-4553-8876-658dd9947871	\N	7599543	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
28e60b65-762a-4025-bbd4-9c80bc5ef1f3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	3e75155c-08a1-4806-86e3-1783ec75d747	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
a8ff2b50-ab0d-499c-818b-186c3ab5620b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	3e75155c-08a1-4806-86e3-1783ec75d747	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
656fbdcb-46f5-4083-b355-224a00314346	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	3e75155c-08a1-4806-86e3-1783ec75d747	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
4cba2f0b-022e-44cf-b85d-ac296a48093f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	c8c93357-3219-4a05-86d0-65dd4ca553c0	\N	6300000	D	csv	D|Facility Management|EXOZEN|Tank Cleaning Charges|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
04ff85c0-6125-4e3d-8793-acdad5be288c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	c8727001-744d-487b-b322-a5041c5f5486	46f7c3d0-934a-4f17-a086-d0631bbd68df	e1dd01a7-52bd-41bb-8e64-e2e746338e9e	\N	903200	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
a87ea351-51be-46d6-822c-6116f24b67b3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	c8727001-744d-487b-b322-a5041c5f5486	46f7c3d0-934a-4f17-a086-d0631bbd68df	e1dd01a7-52bd-41bb-8e64-e2e746338e9e	\N	74000	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
b4b39096-b169-444f-8acb-38e8c6ea5194	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	c8727001-744d-487b-b322-a5041c5f5486	46f7c3d0-934a-4f17-a086-d0631bbd68df	e1dd01a7-52bd-41bb-8e64-e2e746338e9e	\N	10500	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
3223837b-c90f-4195-a3f6-36f49c1617a5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	90ef3b41-4a60-4633-9254-e9d13dedb930	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
3915fe1a-1d62-44a6-b70e-fdc400b571a4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	90ef3b41-4a60-4633-9254-e9d13dedb930	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
9c065a71-ae9f-4460-8336-b7aa557a65c1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	61b56ad6-6e20-42d4-a1d1-79688f7bf89d	2613fbaf-1eb9-4801-95f0-dd8580f0db5d	\N	46581500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
9cd7ad68-0056-494a-bcce-0db10481cac3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	61b56ad6-6e20-42d4-a1d1-79688f7bf89d	2613fbaf-1eb9-4801-95f0-dd8580f0db5d	\N	47899500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
efdf4dd9-3d65-4bea-95cb-917d437176aa	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	48ccd2a6-4e9c-4c38-8315-b973681d97a2	61b56ad6-6e20-42d4-a1d1-79688f7bf89d	2613fbaf-1eb9-4801-95f0-dd8580f0db5d	\N	51577500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
82b75093-4485-40ec-b6d5-8213022d5a98	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	b7b0a7c9-8047-45ef-9384-9caa80156d99	\N	620000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
06078540-1821-4739-b9ab-dc8be70d8bf9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	b7b0a7c9-8047-45ef-9384-9caa80156d99	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
a0e56061-fd69-4ce2-9147-3c1210d152b1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	560632eb-563e-4d46-b6d9-88d70fc35081	4278ab8c-27f6-4072-8ea2-8947cb103852	9e25088c-a87d-4ea7-b052-1d7d263a7cf4	b7b0a7c9-8047-45ef-9384-9caa80156d99	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
4aa0134d-6955-42d2-a517-e9e250ca67d6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	da332500-8487-4d76-88ff-01a1abc95c76	a3959c90-89da-4a51-aae0-27f3771f5ad9	b87ff949-0e7e-4e81-88ab-692fd61a07d6	\N	500000	C	csv	C|Community Contributions|Residents|Association Fund|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
d4b23afe-9097-470f-a9fa-d51d9b9f7a5a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	da332500-8487-4d76-88ff-01a1abc95c76	a3959c90-89da-4a51-aae0-27f3771f5ad9	b87ff949-0e7e-4e81-88ab-692fd61a07d6	\N	370000	C	csv	C|Community Contributions|Residents|Association Fund|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
444e8dae-21b3-47b4-add9-ba7c660ae4ea	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	da332500-8487-4d76-88ff-01a1abc95c76	a3959c90-89da-4a51-aae0-27f3771f5ad9	b87ff949-0e7e-4e81-88ab-692fd61a07d6	\N	1950000	C	csv	C|Community Contributions|Residents|Association Fund|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
59141f78-8b59-4520-9355-20363e1fe7eb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	de0b0793-8428-4ec8-b46c-69568bc1a82e	\N	280000	C	csv	C|Facility Rental|Amenities|AV room|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
d8fe582c-8f1f-4910-b99e-b3db6f7a322a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	de0b0793-8428-4ec8-b46c-69568bc1a82e	\N	350000	C	csv	C|Facility Rental|Amenities|AV room|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
d8d8e149-eb4b-40b0-9b27-4109229307d2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	de0b0793-8428-4ec8-b46c-69568bc1a82e	\N	210000	C	csv	C|Facility Rental|Amenities|AV room|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
492e854d-c7e4-46f7-be8b-6d0f04dba8df	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	de0b0793-8428-4ec8-b46c-69568bc1a82e	\N	280000	C	csv	C|Facility Rental|Amenities|AV room|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
ccbaaab8-7705-4289-8aae-d7c7110b6c37	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	f55c077a-88aa-45be-9ca6-05aec1fcb7f0	\N	112000	C	csv	C|Facility Rental|Amenities|Business Center|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
6be05b3e-ddf8-4fd6-bc71-1ce0a5cb0186	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	f55c077a-88aa-45be-9ca6-05aec1fcb7f0	\N	108000	C	csv	C|Facility Rental|Amenities|Business Center|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
2a4eb2c6-6708-44c3-b201-09c6a3f36790	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	f55c077a-88aa-45be-9ca6-05aec1fcb7f0	\N	100000	C	csv	C|Facility Rental|Amenities|Business Center|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
dc743484-9034-40e0-a7a7-90a730c5efbc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	217c2705-b8dd-46a6-8e97-d1bf90b56ed9	82d75633-69f9-45df-849f-0e0897d54e80	30294e30-d793-4f16-bc38-970b2ea4f235	\N	1274040	C	csv	C|Tax|Tax Collection|CGST Output|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
c76a8bb7-e1a2-4a2d-8871-51d8b6c9e11a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	217c2705-b8dd-46a6-8e97-d1bf90b56ed9	82d75633-69f9-45df-849f-0e0897d54e80	30294e30-d793-4f16-bc38-970b2ea4f235	\N	759200	C	csv	C|Tax|Tax Collection|CGST Output|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
6116d659-65ec-4c58-a73a-4e52e341fba7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	217c2705-b8dd-46a6-8e97-d1bf90b56ed9	82d75633-69f9-45df-849f-0e0897d54e80	30294e30-d793-4f16-bc38-970b2ea4f235	\N	532800	C	csv	C|Tax|Tax Collection|CGST Output|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
103d10aa-5fe1-4ad4-b4ed-622b6216ada1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	217c2705-b8dd-46a6-8e97-d1bf90b56ed9	82d75633-69f9-45df-849f-0e0897d54e80	30294e30-d793-4f16-bc38-970b2ea4f235	\N	868000	C	csv	C|Tax|Tax Collection|CGST Output|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
f2136727-b08d-496a-9004-edcc0c7889aa	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	204e0bf5-d665-4b41-bf2b-5d41435b82df	08287f21-5bbe-4ec6-8038-b88edc9cd70d	2d161c02-9091-4f7c-aec8-ccda21dd8f3f	\N	100000	C	csv	C|Penalties|Resident Penalties|Common Area Violation|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
8ac93854-e86f-409b-89ab-6e716b8e2b9a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	204e0bf5-d665-4b41-bf2b-5d41435b82df	08287f21-5bbe-4ec6-8038-b88edc9cd70d	2d161c02-9091-4f7c-aec8-ccda21dd8f3f	\N	600000	C	csv	C|Penalties|Resident Penalties|Common Area Violation|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
b09e8a9a-cb1b-4a08-8185-0da89b3a1b12	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	b0fd1332-e97d-4e31-a784-c77f18f95be6	edf42993-3fcc-4dde-bb53-f549cff58f21	bcb00dad-ac39-4c89-b8cb-469a5660b76f	\N	817900	C	csv	C|Events|Community Events|Community Curriculum Activities|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
02374b13-ae36-4970-b27d-e7656666a488	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	c93b7894-0c90-4736-a589-bbcd7bd47848	29846594-7bfc-4141-9afe-c92b48823f8c	e29f34c3-8d62-4452-a6aa-c40bd3d747a8	\N	100000	C	csv	C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
be3691b6-66b9-40c7-a075-3629bfb3bee1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	c93b7894-0c90-4736-a589-bbcd7bd47848	29846594-7bfc-4141-9afe-c92b48823f8c	e29f34c3-8d62-4452-a6aa-c40bd3d747a8	\N	230400	C	csv	C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
72ed6e36-401f-4708-abfb-2cbb075c6d70	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	b0fd1332-e97d-4e31-a784-c77f18f95be6	edf42993-3fcc-4dde-bb53-f549cff58f21	8f328f95-0eba-4d51-8d0b-733a30d044ed	\N	1600000	C	csv	C|Events|Community Events|Flee Market|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
f6808168-033f-45b2-ae06-73e64f7f9fcd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	996bf1ee-09a8-4112-aadf-c95a41614f6a	d748b338-1215-4ecb-a18e-9c46c06019a7	0ab89b84-46cb-4850-8677-227a6e44bddf	\N	100000	C	csv	C|Parking Revenue|Parking Services|Guest Parking Rent|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
137b1da1-42dc-4447-807b-1c2410c15235	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	204e0bf5-d665-4b41-bf2b-5d41435b82df	08287f21-5bbe-4ec6-8038-b88edc9cd70d	fe234164-f788-46c4-832b-540508369803	\N	15172500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
44673657-520b-45fc-945e-f6ebaebe513a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	204e0bf5-d665-4b41-bf2b-5d41435b82df	08287f21-5bbe-4ec6-8038-b88edc9cd70d	fe234164-f788-46c4-832b-540508369803	\N	9522500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
34bba99a-06b9-4002-9434-0a24bb0f1f53	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	204e0bf5-d665-4b41-bf2b-5d41435b82df	08287f21-5bbe-4ec6-8038-b88edc9cd70d	fe234164-f788-46c4-832b-540508369803	\N	6840000	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
9bce50ac-5d4f-4c61-b1da-c223240ab72b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	204e0bf5-d665-4b41-bf2b-5d41435b82df	08287f21-5bbe-4ec6-8038-b88edc9cd70d	fe234164-f788-46c4-832b-540508369803	\N	10817500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
f2f7d0aa-9821-476d-90f3-2f4b24b15192	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	a4906be6-ea53-4237-a413-63d94d72a178	cb3df385-a389-47fd-9f94-14c8e4464d4c	ebfc7e39-97cd-4fb4-b684-ddabd8668baf	\N	990000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
2d65c776-46a8-4334-b731-6fb111a7774a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	a4906be6-ea53-4237-a413-63d94d72a178	cb3df385-a389-47fd-9f94-14c8e4464d4c	ebfc7e39-97cd-4fb4-b684-ddabd8668baf	\N	550000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
103ac307-cb3c-4c55-9c71-64853d986bb7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	a4906be6-ea53-4237-a413-63d94d72a178	cb3df385-a389-47fd-9f94-14c8e4464d4c	ebfc7e39-97cd-4fb4-b684-ddabd8668baf	\N	330000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
68372829-588a-470a-a6c7-e868a42a93dd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	57f68b05-38c1-4b36-a988-198ad13f7eb5	34c19556-843d-4919-bbb6-e60a1d25dc65	20920cba-fecc-4a21-ae61-9f2865bfaad9	\N	283327400	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
1496b42e-722d-44a9-8a1b-321746aaca39	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	57f68b05-38c1-4b36-a988-198ad13f7eb5	34c19556-843d-4919-bbb6-e60a1d25dc65	20920cba-fecc-4a21-ae61-9f2865bfaad9	\N	283885405	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
9aaa9709-62d2-40ab-a33b-add81b0e1f16	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	57f68b05-38c1-4b36-a988-198ad13f7eb5	34c19556-843d-4919-bbb6-e60a1d25dc65	20920cba-fecc-4a21-ae61-9f2865bfaad9	\N	270711506	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
6e3db0cb-90b7-4984-bb70-a88e5d43e050	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	57f68b05-38c1-4b36-a988-198ad13f7eb5	34c19556-843d-4919-bbb6-e60a1d25dc65	20920cba-fecc-4a21-ae61-9f2865bfaad9	\N	274879441	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
c6a441d0-d8bd-47ae-a70a-e418286184d2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	a323bbb4-4a07-4c23-970a-cb657385f63a	8b3b7e7e-e6c4-493c-9b35-ddda3c06d7a7	7f90940d-a45a-4701-abc2-1b661b7b4eb0	\N	750000	C	csv	C|Move Charges|Resident Services|Move In/Out (Manual)|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
49fb9ece-a570-4f61-a351-de1a69015345	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	a323bbb4-4a07-4c23-970a-cb657385f63a	8b3b7e7e-e6c4-493c-9b35-ddda3c06d7a7	db61eebd-1e3d-434a-a22e-7536b9ac508b	\N	3500000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
2ebbe08f-470b-4a48-b645-016ca70e0721	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	a323bbb4-4a07-4c23-970a-cb657385f63a	8b3b7e7e-e6c4-493c-9b35-ddda3c06d7a7	db61eebd-1e3d-434a-a22e-7536b9ac508b	\N	2000000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
7421ed05-e6ad-4f04-adad-9bba9079b9d6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	a323bbb4-4a07-4c23-970a-cb657385f63a	8b3b7e7e-e6c4-493c-9b35-ddda3c06d7a7	db61eebd-1e3d-434a-a22e-7536b9ac508b	\N	3000000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
be5c8fd6-cd63-409e-8f66-33c7b2e5e675	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	a323bbb4-4a07-4c23-970a-cb657385f63a	8b3b7e7e-e6c4-493c-9b35-ddda3c06d7a7	db61eebd-1e3d-434a-a22e-7536b9ac508b	\N	500000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
35bad696-e3bc-43d9-8274-b6bfaaf492b3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	667fc1c9-c55c-49a0-a818-ae7fcdfdc91b	\N	1200000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
a8c052cf-2729-4368-8df4-458f379236c1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	667fc1c9-c55c-49a0-a818-ae7fcdfdc91b	\N	2700000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
2e51aea4-6dd4-481d-88df-288408aa01de	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	667fc1c9-c55c-49a0-a818-ae7fcdfdc91b	\N	2100000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
cd7891dc-65da-475a-b9c4-ededde6d67f9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	09b263d8-f075-414d-aed2-8c43807d6993	ce294a29-4589-4850-9274-8934c52740b5	667fc1c9-c55c-49a0-a818-ae7fcdfdc91b	\N	2400000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
01342d17-b43a-4724-b919-4813d2573106	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	204e0bf5-d665-4b41-bf2b-5d41435b82df	08287f21-5bbe-4ec6-8038-b88edc9cd70d	f947be51-3973-4abe-b1c3-1538607f451d	\N	100000	C	csv	C|Penalties|Resident Penalties|Parking Violation|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
0d6ce502-2727-4dd6-9c4e-3dad548dcee8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	217c2705-b8dd-46a6-8e97-d1bf90b56ed9	82d75633-69f9-45df-849f-0e0897d54e80	06d8ac01-03bc-4625-92e0-2b175bc2afc0	\N	1274040	C	csv	C|Tax|Tax Collection|SGST Output|2026-04	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
3da223e1-ba2f-4b8a-9501-cf38bbe8ed74	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	217c2705-b8dd-46a6-8e97-d1bf90b56ed9	82d75633-69f9-45df-849f-0e0897d54e80	06d8ac01-03bc-4625-92e0-2b175bc2afc0	\N	759200	C	csv	C|Tax|Tax Collection|SGST Output|2026-05	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
68a01e71-3367-4f62-b83d-724b8970e429	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	217c2705-b8dd-46a6-8e97-d1bf90b56ed9	82d75633-69f9-45df-849f-0e0897d54e80	06d8ac01-03bc-4625-92e0-2b175bc2afc0	\N	532800	C	csv	C|Tax|Tax Collection|SGST Output|2026-06	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
a60aa63c-be26-4494-980d-306354514b5a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	a1c1e377-5cbc-4b1d-9224-7010318527a7	217c2705-b8dd-46a6-8e97-d1bf90b56ed9	82d75633-69f9-45df-849f-0e0897d54e80	06d8ac01-03bc-4625-92e0-2b175bc2afc0	\N	868000	C	csv	C|Tax|Tax Collection|SGST Output|2026-07	\N	\N	2026-08-03 18:47:09.707376+00	2026-08-03 18:47:09.707376+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	superadmin
0f0c6024-6c4d-47b3-9012-4f714d448a40	admin
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, community_id, email, name, password_hash, last_login_at, created_at) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	caa11b01-c3a5-4067-a90c-b73b35075def	admin@example.com	Super Admin	$argon2id$v=19$m=65536,t=3,p=4$Kt8SvlyKldOGy2SFQJ9Yuw$40zQ1q5mIAI2WmbT/RBJX2sqOv0H86FnsvWN2OIHOx8	2026-08-03 17:59:35.207187+00	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, community_id, name, kind) FROM stdin;
b8cb70f3-de8f-4d12-b3e5-730bfc1fab54	caa11b01-c3a5-4067-a90c-b73b35075def	Airtel Postpaid	company
d92e9928-ff4c-4c68-be4c-d2b814b71f7f	caa11b01-c3a5-4067-a90c-b73b35075def	Amazon CG Boulevard RWA	individual
983d0e00-2e85-4b4e-9537-6708dfd53d8d	caa11b01-c3a5-4067-a90c-b73b35075def	JOHNSON LIFTS Pvt Ltd	company
d07ed74f-cb56-401e-a52c-cf8dff72632e	caa11b01-c3a5-4067-a90c-b73b35075def	BESCOM	company
8a5a8fe8-49cf-44e4-83b4-650314ba69f9	caa11b01-c3a5-4067-a90c-b73b35075def	Individual	individual
1561c541-7b99-41b4-9615-fb51793db72e	caa11b01-c3a5-4067-a90c-b73b35075def	KIRLOSKAR OIL ENGINES LTD	company
c3cc38d3-fe2e-4f17-b595-5f6653fafc62	caa11b01-c3a5-4067-a90c-b73b35075def	Sai Krupa Petroleum	company
0548410e-944b-4ab6-ae4a-59f966705a14	caa11b01-c3a5-4067-a90c-b73b35075def	Sewa Waste Management	company
9702f057-72ac-4068-a1b9-4606f3946a3d	caa11b01-c3a5-4067-a90c-b73b35075def	Kavitha Enterprises	company
112c9a31-d132-497e-9c20-898cce64e20b	caa11b01-c3a5-4067-a90c-b73b35075def	System Adjustment	individual
18d3e29f-792f-471f-be1c-5d7643616109	caa11b01-c3a5-4067-a90c-b73b35075def	Sapthagiri Cleaner	company
46f7c3d0-934a-4f17-a086-d0631bbd68df	caa11b01-c3a5-4067-a90c-b73b35075def	Petty Cash	individual
61b56ad6-6e20-42d4-a1d1-79688f7bf89d	caa11b01-c3a5-4067-a90c-b73b35075def	BSN Water Supply	company
9e25088c-a87d-4ea7-b052-1d7d263a7cf4	caa11b01-c3a5-4067-a90c-b73b35075def	EXOZEN	company
a3959c90-89da-4a51-aae0-27f3771f5ad9	caa11b01-c3a5-4067-a90c-b73b35075def	Residents	individual
29846594-7bfc-4141-9afe-c92b48823f8c	caa11b01-c3a5-4067-a90c-b73b35075def	Wellness Programs	individual
edf42993-3fcc-4dde-bb53-f549cff58f21	caa11b01-c3a5-4067-a90c-b73b35075def	Community Events	individual
d748b338-1215-4ecb-a18e-9c46c06019a7	caa11b01-c3a5-4067-a90c-b73b35075def	Parking Services	individual
cb3df385-a389-47fd-9f94-14c8e4464d4c	caa11b01-c3a5-4067-a90c-b73b35075def	Advertising Revenue	individual
34c19556-843d-4919-bbb6-e60a1d25dc65	caa11b01-c3a5-4067-a90c-b73b35075def	Apartment Owners	individual
8b3b7e7e-e6c4-493c-9b35-ddda3c06d7a7	caa11b01-c3a5-4067-a90c-b73b35075def	Resident Services	individual
ce294a29-4589-4850-9274-8934c52740b5	caa11b01-c3a5-4067-a90c-b73b35075def	Amenities	individual
08287f21-5bbe-4ec6-8038-b88edc9cd70d	caa11b01-c3a5-4067-a90c-b73b35075def	Resident Penalties	individual
82d75633-69f9-45df-849f-0e0897d54e80	caa11b01-c3a5-4067-a90c-b73b35075def	Tax Collection	individual
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, true);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (name);


--
-- Name: allowed_emails allowed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_pkey PRIMARY KEY (email);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: balances balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_pkey PRIMARY KEY (community_id, month);


--
-- Name: categories categories_head_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_name_key UNIQUE (head_id, name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: collections_dues collections_dues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_pkey PRIMARY KEY (flat_id, period_month);


--
-- Name: communities communities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communities
    ADD CONSTRAINT communities_pkey PRIMARY KEY (id);


--
-- Name: dashboard_settings dashboard_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_pkey PRIMARY KEY (community_id, dashboard_key);


--
-- Name: flats flats_community_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_code_key UNIQUE (community_id, code);


--
-- Name: flats flats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_pkey PRIMARY KEY (id);


--
-- Name: heads heads_community_id_kind_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_kind_name_key UNIQUE (community_id, kind, name);


--
-- Name: heads heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_rules import_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_pkey PRIMARY KEY (id);


--
-- Name: import_staging import_staging_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_pkey PRIMARY KEY (batch_id, row_no);


--
-- Name: line_items line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_pkey PRIMARY KEY (id);


--
-- Name: otp_codes magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (email, otp_hash);


--
-- Name: periods periods_community_id_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_month_key UNIQUE (community_id, month);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_source_source_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_source_source_ref_key UNIQUE (source, source_ref);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_community_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_name_key UNIQUE (community_id, name);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_at ON public.audit_log USING btree (at DESC);


--
-- Name: idx_audit_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_entity ON public.audit_log USING btree (entity, entity_id);


--
-- Name: idx_txn_category_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_category_month ON public.transactions USING btree (category_id, period_month);


--
-- Name: idx_txn_community_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_community_month ON public.transactions USING btree (community_id, period_month);


--
-- Name: idx_txn_flat_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_flat_month ON public.transactions USING btree (flat_id, period_month);


--
-- Name: idx_txn_head_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_head_month ON public.transactions USING btree (head_id, period_month);


--
-- Name: idx_txn_vendor_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_vendor_month ON public.transactions USING btree (vendor_id, period_month);


--
-- Name: line_items_cat_vendor_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX line_items_cat_vendor_name_uq ON public.line_items USING btree (category_id, COALESCE(vendor_id, '00000000-0000-0000-0000-000000000000'::uuid), name);


--
-- Name: mv_cat_monthly_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_cat_monthly_idx ON public.mv_category_monthly USING btree (community_id, month);


--
-- Name: mv_monthly_totals_pk; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mv_monthly_totals_pk ON public.mv_monthly_totals USING btree (community_id, month);


--
-- Name: mv_vendor_ranking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_vendor_ranking_idx ON public.mv_vendor_ranking USING btree (community_id, total_expense_paise DESC);


--
-- Name: allowed_emails allowed_emails_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: allowed_emails allowed_emails_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE SET NULL;


--
-- Name: balances balances_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: categories categories_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id) ON DELETE CASCADE;


--
-- Name: collections_dues collections_dues_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE CASCADE;


--
-- Name: dashboard_settings dashboard_settings_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: flats flats_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: heads heads_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: import_rules import_rules_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_staging import_staging_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE SET NULL;


--
-- Name: periods periods_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: transactions transactions_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id);


--
-- Name: transactions transactions_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id);


--
-- Name: transactions transactions_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_line_item_id_fkey FOREIGN KEY (line_item_id) REFERENCES public.line_items(id);


--
-- Name: transactions transactions_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: vendors vendors_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_category_monthly;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_monthly_totals;


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_vendor_ranking;


--
-- PostgreSQL database dump complete
--

\unrestrict cakXDrMdlJmc3pcn4yhLcSieRm9bIA5e0aUjjJuchljAJsWJX3R4vsBaWp6h3XA

