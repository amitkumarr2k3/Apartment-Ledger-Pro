--
-- PostgreSQL database dump
--

\restrict AWC4Dv2nkMZJCKv8gfGvjU5JcZkQrX2Pif82jsNTbGGmEPeFPfachuPV9Y8mP2z

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_line_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_batch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_actor_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_community_id_fkey;
DROP INDEX IF EXISTS public.mv_vendor_ranking_idx;
DROP INDEX IF EXISTS public.mv_monthly_totals_pk;
DROP INDEX IF EXISTS public.mv_cat_monthly_idx;
DROP INDEX IF EXISTS public.line_items_cat_vendor_name_uq;
DROP INDEX IF EXISTS public.idx_txn_vendor_month;
DROP INDEX IF EXISTS public.idx_txn_head_month;
DROP INDEX IF EXISTS public.idx_txn_flat_month;
DROP INDEX IF EXISTS public.idx_txn_community_month;
DROP INDEX IF EXISTS public.idx_txn_category_month;
DROP INDEX IF EXISTS public.idx_audit_entity;
DROP INDEX IF EXISTS public.idx_audit_at;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_pkey;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_name_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_source_source_ref_key;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_month_key;
ALTER TABLE IF EXISTS ONLY public.otp_codes DROP CONSTRAINT IF EXISTS magic_links_pkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_pkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_pkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_kind_name_key;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_pkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_code_key;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.communities DROP CONSTRAINT IF EXISTS communities_pkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_name_key;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_pkey;
ALTER TABLE IF EXISTS ONLY public._migrations DROP CONSTRAINT IF EXISTS _migrations_pkey;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.periods;
DROP TABLE IF EXISTS public.otp_codes;
DROP MATERIALIZED VIEW IF EXISTS public.mv_vendor_ranking;
DROP TABLE IF EXISTS public.vendors;
DROP MATERIALIZED VIEW IF EXISTS public.mv_monthly_totals;
DROP MATERIALIZED VIEW IF EXISTS public.mv_category_monthly;
DROP TABLE IF EXISTS public.transactions;
DROP TABLE IF EXISTS public.line_items;
DROP TABLE IF EXISTS public.import_staging;
DROP TABLE IF EXISTS public.import_rules;
DROP TABLE IF EXISTS public.import_batches;
DROP TABLE IF EXISTS public.heads;
DROP TABLE IF EXISTS public.flats;
DROP TABLE IF EXISTS public.dashboard_settings;
DROP TABLE IF EXISTS public.communities;
DROP TABLE IF EXISTS public.collections_dues;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.balances;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP TABLE IF EXISTS public.allowed_emails;
DROP TABLE IF EXISTS public._migrations;
DROP TYPE IF EXISTS public.vendor_kind;
DROP TYPE IF EXISTS public.head_kind;
DROP TYPE IF EXISTS public.app_role;
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'resident',
    'admin',
    'superadmin'
);


--
-- Name: head_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.head_kind AS ENUM (
    'income',
    'expense'
);


--
-- Name: vendor_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vendor_kind AS ENUM (
    'company',
    'individual'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    name text NOT NULL,
    run_at timestamp with time zone DEFAULT now()
);


--
-- Name: allowed_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allowed_emails (
    email text NOT NULL,
    community_id uuid NOT NULL,
    role public.app_role NOT NULL,
    flat_id uuid,
    name text,
    invited_by text,
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    community_id uuid,
    actor_user_id uuid,
    actor_email text,
    entity text NOT NULL,
    entity_id text,
    action text NOT NULL,
    before jsonb,
    after jsonb,
    at timestamp with time zone DEFAULT now() NOT NULL,
    ip text,
    user_agent text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balances (
    community_id uuid NOT NULL,
    month date NOT NULL,
    opening_paise bigint DEFAULT 0 NOT NULL,
    closing_paise bigint DEFAULT 0 NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    head_id uuid NOT NULL,
    name text NOT NULL
);


--
-- Name: collections_dues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections_dues (
    flat_id uuid NOT NULL,
    period_month date NOT NULL,
    dues_paise bigint DEFAULT 0 NOT NULL,
    paid_paise bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'due'::text NOT NULL
);


--
-- Name: communities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    fy_start_month smallint DEFAULT 4 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dashboard_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_settings (
    community_id uuid NOT NULL,
    dashboard_key text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    hidden_widgets text[] DEFAULT '{}'::text[] NOT NULL
);


--
-- Name: flats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    code text NOT NULL,
    owner_email text
);


--
-- Name: heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind public.head_kind NOT NULL,
    name text NOT NULL
);


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    filename text NOT NULL,
    kind text NOT NULL,
    uploaded_by uuid,
    status text DEFAULT 'staged'::text NOT NULL,
    error text,
    row_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind text NOT NULL,
    match jsonb NOT NULL,
    set_fields jsonb NOT NULL,
    priority integer DEFAULT 100 NOT NULL
);


--
-- Name: import_staging; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_staging (
    batch_id uuid NOT NULL,
    row_no integer NOT NULL,
    raw_json jsonb NOT NULL,
    mapped_json jsonb,
    error text
);


--
-- Name: line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    name text NOT NULL,
    first_seen_month date,
    last_seen_month date
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    txn_date date NOT NULL,
    period_month date NOT NULL,
    head_id uuid NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    line_item_id uuid,
    flat_id uuid,
    amount_paise bigint NOT NULL,
    direction character(1) NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    source_ref text,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT transactions_amount_paise_check CHECK ((amount_paise >= 0)),
    CONSTRAINT transactions_direction_check CHECK ((direction = ANY (ARRAY['C'::bpchar, 'D'::bpchar])))
);


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_category_monthly AS
 SELECT t.community_id,
    t.category_id,
    c.name AS category_name,
    h.kind AS head_kind,
    t.period_month AS month,
    (sum(t.amount_paise))::bigint AS amount_paise
   FROM ((public.transactions t
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON ((h.id = t.head_id)))
  GROUP BY t.community_id, t.category_id, c.name, h.kind, t.period_month
  WITH NO DATA;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_monthly_totals AS
 WITH spine AS (
         SELECT c.id AS community_id,
            (date_trunc('month'::text, gs.gs))::date AS month
           FROM (public.communities c
             CROSS JOIN generate_series((( SELECT COALESCE(min(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, (( SELECT COALESCE(max(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, '1 mon'::interval) gs(gs))
        )
 SELECT s.community_id,
    s.month,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric))::bigint AS collection_paise,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric))::bigint AS expense_paise,
    ((COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric) - COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric)))::bigint AS net_paise
   FROM (spine s
     LEFT JOIN public.transactions t ON (((t.community_id = s.community_id) AND (t.period_month = s.month))))
  GROUP BY s.community_id, s.month
  WITH NO DATA;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    name text NOT NULL,
    kind public.vendor_kind DEFAULT 'company'::public.vendor_kind NOT NULL
);


--
-- Name: TABLE vendors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vendors IS 'Vendor dimension. Read-only from admin UI; populated via CSV import + on-the-fly during transaction ingest.';


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_vendor_ranking AS
 SELECT t.community_id,
    v.id AS vendor_id,
    v.name AS vendor_name,
    v.kind AS vendor_kind,
    COALESCE(string_agg(DISTINCT c.name, ', '::text), ''::text) AS categories,
    (sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)))::bigint AS total_expense_paise,
    count(DISTINCT t.period_month) AS months_active
   FROM (((public.transactions t
     JOIN public.vendors v ON ((v.id = t.vendor_id)))
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON (((h.id = t.head_id) AND (h.kind = 'expense'::public.head_kind))))
  GROUP BY t.community_id, v.id, v.name, v.kind
  WITH NO DATA;


--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_codes (
    email text NOT NULL,
    otp_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone
);


--
-- Name: periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    month date NOT NULL,
    status text DEFAULT 'open'::text NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role public.app_role NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    email text NOT NULL,
    name text,
    password_hash text,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._migrations (name, run_at) FROM stdin;
0001_init.sql	2026-07-13 11:13:56.401452+00
0002_indexes.sql	2026-07-13 11:13:56.401452+00
0003_mviews.sql	2026-07-13 11:13:56.401452+00
0004_otp_rename.sql	2026-07-13 11:20:04.500279+00
0005_etl.sql	2026-08-03 16:34:38.109705+00
0006_drop_etl_sessions.sql	2026-08-03 18:40:10.950432+00
\.


--
-- Data for Name: allowed_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allowed_emails (email, community_id, role, flat_id, name, invited_by, invited_at, revoked_at) FROM stdin;
treasurer@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	admin	\N	Treasurer	system	2026-07-13 11:20:04.55456+00	\N
resident@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	resident	\N	Demo Resident	system	2026-07-13 11:20:04.55456+00	\N
admin@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	superadmin	\N	Super Admin	system	2026-07-13 11:20:04.55456+00	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, community_id, actor_user_id, actor_email, entity, entity_id, action, before, after, at, ip, user_agent) FROM stdin;
1	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	import_batch	99677e60-a26f-459a-840d-896a338a8ac5	import	\N	{"kind": "transactions", "rows": 404, "failed": 0, "filename": "transactions.csv", "inserted": 404}	2026-08-03 18:50:45.125015+00	172.30.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
2	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	auth	\N	login	\N	\N	2026-08-10 17:23:56.73883+00	172.18.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36
3	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	import_batch	f5476189-c8ca-4a28-add9-eda04017ada6	import	\N	{"kind": "transactions", "rows": 404, "failed": 0, "filename": "transactions.csv", "inserted": 404}	2026-08-10 17:24:15.863954+00	172.18.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36
\.


--
-- Data for Name: balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.balances (community_id, month, opening_paise, closing_paise) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, head_id, name) FROM stdin;
b787f534-196a-4914-8172-9563c09b9971	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Professional Services
1f6f324a-4ef5-46f5-b01b-85a6478be869	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Events
77e00431-dd28-4ac2-8141-8e011f73f332	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Cleaning
60fdea52-667e-4553-aa66-a429cbe2e89b	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Gardening
386378b4-b93e-48e7-8094-b667d71d83b9	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Accounting Adjustments
93856faa-0c1a-4632-b8e2-f821d60e0f51	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Security
f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Maintenance
5253d1ba-f944-4641-b6e8-bb6280e088c1	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Housekeeping
1e20c166-0399-4b6e-aa16-3ce316ae5979	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Petty Cash
17fb8810-848d-4e53-98bb-0477324e69e4	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Uncategorized
f951fe7b-e843-4130-8d21-994a29a24a1f	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Water Treatment
9314eb17-eb68-4961-ba6f-8c6579a271f7	08829c33-ddf3-437f-b05b-83a5b106e7bf	Uncategorized
d898a0ee-ea3e-4a39-bae0-59f5fcd66978	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Office Supplies
cc7452d1-7de7-4c2b-89c0-53fe88a38060	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Utilities
5826db79-e049-42ec-b928-0a7447b894b4	2af7724b-5dfe-40e6-88e2-88db1981ecb2	Facility Management
18ef50a3-c7e6-4598-b2cf-5e75c727113d	08829c33-ddf3-437f-b05b-83a5b106e7bf	Community Contributions
ca57194d-2453-4138-a962-bd15e95b15f5	08829c33-ddf3-437f-b05b-83a5b106e7bf	Recreation & Wellness
80949065-cad3-436e-a1a1-f8ff65634a27	08829c33-ddf3-437f-b05b-83a5b106e7bf	Events
91bf7cbb-d70a-4a93-9116-8884a92f8968	08829c33-ddf3-437f-b05b-83a5b106e7bf	Parking Revenue
90cb34c1-56bd-4609-afd3-bbf1d6b021de	08829c33-ddf3-437f-b05b-83a5b106e7bf	Penalties
db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	08829c33-ddf3-437f-b05b-83a5b106e7bf	Advertisement
746213f5-eb70-4bfd-be95-c719831dddf3	08829c33-ddf3-437f-b05b-83a5b106e7bf	Maintenance Collection
2cef7ba9-4bda-479a-93e1-94498cfc3725	08829c33-ddf3-437f-b05b-83a5b106e7bf	Move Charges
f7499fee-7b2d-446a-8d9a-99452fe75cd5	08829c33-ddf3-437f-b05b-83a5b106e7bf	Facility Rental
ba7f14db-b217-41ed-bd79-0e71b404070a	08829c33-ddf3-437f-b05b-83a5b106e7bf	Tax
\.


--
-- Data for Name: collections_dues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections_dues (flat_id, period_month, dues_paise, paid_paise, status) FROM stdin;
\.


--
-- Data for Name: communities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communities (id, name, currency, fy_start_month, created_at) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	Green Meadows	INR	4	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: dashboard_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_settings (community_id, dashboard_key, enabled, hidden_widgets) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	resident.overview	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.drilldown	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.cashflow	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.income	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.balance	t	{}
\.


--
-- Data for Name: flats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flats (id, community_id, code, owner_email) FROM stdin;
f88d6359-58a8-42b1-8476-24ce41b63802	caa11b01-c3a5-4067-a90c-b73b35075def	A-001	\N
5696d5bf-57f9-44ad-b92d-781cabc4a550	caa11b01-c3a5-4067-a90c-b73b35075def	A-002	\N
5c447f5e-a684-4075-8224-072f1fb12c93	caa11b01-c3a5-4067-a90c-b73b35075def	A-003	\N
6ddf10b7-40ed-44a1-9080-e50c60a08e32	caa11b01-c3a5-4067-a90c-b73b35075def	A-004	\N
5bfe95a5-bc38-4d00-811e-b5a6106e71c7	caa11b01-c3a5-4067-a90c-b73b35075def	A-005	\N
6e67ec18-d2aa-4cd4-8a51-b9a2b33429a2	caa11b01-c3a5-4067-a90c-b73b35075def	A-006	\N
05fbfe69-9195-45aa-bb9a-ef1de36f6fd9	caa11b01-c3a5-4067-a90c-b73b35075def	A-007	\N
7dca9ae9-39f7-4b2c-85b6-f9c820a65f0c	caa11b01-c3a5-4067-a90c-b73b35075def	A-008	\N
24f24d23-6946-4d06-b2d4-7ebe31278f9e	caa11b01-c3a5-4067-a90c-b73b35075def	A-009	\N
39278459-ad85-4e5e-937a-0a36b195c960	caa11b01-c3a5-4067-a90c-b73b35075def	A-010	\N
716bbe4c-f53d-4558-a4b5-caeb642f2c23	caa11b01-c3a5-4067-a90c-b73b35075def	A-011	\N
6dac5232-f75f-44d2-8533-4119c856f0ac	caa11b01-c3a5-4067-a90c-b73b35075def	A-012	\N
ea815ea6-a6d6-4547-bb06-ebfc9497a6f2	caa11b01-c3a5-4067-a90c-b73b35075def	A-013	\N
b441021b-6b42-4350-bd7a-385d23b17015	caa11b01-c3a5-4067-a90c-b73b35075def	A-014	\N
74194275-0229-47a7-9a12-691c228cbf03	caa11b01-c3a5-4067-a90c-b73b35075def	A-015	\N
f9df5252-7643-42fd-9a63-2e839347a52f	caa11b01-c3a5-4067-a90c-b73b35075def	A-016	\N
321b8a10-e82d-4cf6-a6b2-fde3fa7b05b1	caa11b01-c3a5-4067-a90c-b73b35075def	A-017	\N
9c1ddcb5-9b93-4e47-80ac-cbfc3b7f326e	caa11b01-c3a5-4067-a90c-b73b35075def	A-018	\N
f0106df5-f061-40fd-97c8-f6408f268ff9	caa11b01-c3a5-4067-a90c-b73b35075def	A-019	\N
deeb22d9-7a6b-4417-985b-c76049abae2e	caa11b01-c3a5-4067-a90c-b73b35075def	A-020	\N
c2e7bc3c-62db-4d01-aad3-9513cbf2ecbf	caa11b01-c3a5-4067-a90c-b73b35075def	A-021	\N
8c7ed2ff-3fea-4279-a889-c4e44b78ef6e	caa11b01-c3a5-4067-a90c-b73b35075def	A-022	\N
fb52fe46-dded-4f23-975d-3f36184896e9	caa11b01-c3a5-4067-a90c-b73b35075def	A-023	\N
5fc3f4ab-169c-47bc-819a-315c1a244aac	caa11b01-c3a5-4067-a90c-b73b35075def	A-024	\N
\.


--
-- Data for Name: heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heads (id, community_id, kind, name) FROM stdin;
2af7724b-5dfe-40e6-88e2-88db1981ecb2	caa11b01-c3a5-4067-a90c-b73b35075def	expense	Expense
08829c33-ddf3-437f-b05b-83a5b106e7bf	caa11b01-c3a5-4067-a90c-b73b35075def	income	Income
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, community_id, filename, kind, uploaded_by, status, error, row_count, created_at) FROM stdin;
99677e60-a26f-459a-840d-896a338a8ac5	caa11b01-c3a5-4067-a90c-b73b35075def	transactions.csv	transactions	0f0c6024-6c4d-47b3-9012-4f714d448a40	committed	\N	404	2026-08-03 18:50:45.117328+00
f5476189-c8ca-4a28-add9-eda04017ada6	caa11b01-c3a5-4067-a90c-b73b35075def	transactions.csv	transactions	0f0c6024-6c4d-47b3-9012-4f714d448a40	committed	\N	404	2026-08-10 17:24:15.860136+00
\.


--
-- Data for Name: import_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_rules (id, community_id, kind, match, set_fields, priority) FROM stdin;
\.


--
-- Data for Name: import_staging; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_staging (batch_id, row_no, raw_json, mapped_json, error) FROM stdin;
99677e60-a26f-459a-840d-896a338a8ac5	1	{"date": "2026-04-01", "head": "expense", "amount": "1214.82", "vendor": "Airtel", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel|Airtel Postpaid Connection|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	2	{"date": "2026-05-01", "head": "expense", "amount": "1414.82", "vendor": "Airtel", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel|Airtel Postpaid Connection|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	3	{"date": "2026-06-01", "head": "expense", "amount": "1428.98", "vendor": "Airtel", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel|Airtel Postpaid Connection|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	4	{"date": "2026-07-01", "head": "expense", "amount": "1414.82", "vendor": "Airtel", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel|Airtel Postpaid Connection|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	5	{"date": "2026-04-01", "head": "expense", "amount": "61049", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Uncategorized|Individual|Amazon Purchase|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	6	{"date": "2026-05-01", "head": "expense", "amount": "7590.36", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Uncategorized|Individual|Amazon Purchase|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	7	{"date": "2026-06-01", "head": "expense", "amount": "12018.34", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Uncategorized|Individual|Amazon Purchase|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	8	{"date": "2026-07-01", "head": "expense", "amount": "4455.04", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Uncategorized|Individual|Amazon Purchase|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	9	{"date": "2026-04-01", "head": "expense", "amount": "30000", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|Individual|AMC (Lift)|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	10	{"date": "2026-06-01", "head": "expense", "amount": "150000", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|Individual|AMC (Lift)|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	11	{"date": "2026-06-01", "head": "expense", "amount": "55000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Annual Compliance Expense", "source_ref": "D|Uncategorized|Individual|Annual Compliance Expense|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	12	{"date": "2026-04-01", "head": "expense", "amount": "154999", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	13	{"date": "2026-05-01", "head": "expense", "amount": "175902", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	14	{"date": "2026-04-01", "head": "expense", "amount": "46130", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	15	{"date": "2026-05-01", "head": "expense", "amount": "43011", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	16	{"date": "2026-04-01", "head": "expense", "amount": "79692", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	17	{"date": "2026-05-01", "head": "expense", "amount": "102431", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	18	{"date": "2026-04-01", "head": "expense", "amount": "78966", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	19	{"date": "2026-05-01", "head": "expense", "amount": "101572", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	20	{"date": "2026-04-01", "head": "expense", "amount": "9000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Uncategorized|Individual|Debris Disposal|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	21	{"date": "2026-05-01", "head": "expense", "amount": "19300", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Uncategorized|Individual|Debris Disposal|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	22	{"date": "2026-06-01", "head": "expense", "amount": "20400", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Uncategorized|Individual|Debris Disposal|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	23	{"date": "2026-06-01", "head": "expense", "amount": "12876.27", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "DG Service", "source_ref": "D|Maintenance|Individual|DG Service|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	24	{"date": "2026-04-01", "head": "expense", "amount": "91401", "vendor": "Individual", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Individual|Diesel|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	25	{"date": "2026-05-01", "head": "expense", "amount": "54822", "vendor": "Individual", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Individual|Diesel|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	26	{"date": "2026-06-01", "head": "expense", "amount": "59784", "vendor": "Individual", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Individual|Diesel|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	27	{"date": "2026-07-01", "head": "expense", "amount": "59784", "vendor": "Individual", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Individual|Diesel|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	28	{"date": "2026-04-01", "head": "expense", "amount": "75588.3", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Uncategorized|Individual|Electricians Salary|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	29	{"date": "2026-05-01", "head": "expense", "amount": "82902.54", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Uncategorized|Individual|Electricians Salary|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	30	{"date": "2026-06-01", "head": "expense", "amount": "86506.61", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Uncategorized|Individual|Electricians Salary|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	31	{"date": "2026-04-01", "head": "expense", "amount": "59421", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Uncategorized|Individual|Facility Manager|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	32	{"date": "2026-05-01", "head": "expense", "amount": "59421.11", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Uncategorized|Individual|Facility Manager|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	33	{"date": "2026-06-01", "head": "expense", "amount": "59421", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Uncategorized|Individual|Facility Manager|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	34	{"date": "2026-04-01", "head": "expense", "amount": "14000", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Individual|Garbage removal|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	35	{"date": "2026-05-01", "head": "expense", "amount": "24000", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Individual|Garbage removal|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	36	{"date": "2026-06-01", "head": "expense", "amount": "24000", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Individual|Garbage removal|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	37	{"date": "2026-04-01", "head": "expense", "amount": "20280", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Individual|Garden Tools|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	38	{"date": "2026-05-01", "head": "expense", "amount": "130", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Individual|Garden Tools|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	39	{"date": "2026-07-01", "head": "expense", "amount": "1491", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Individual|Garden Tools|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	40	{"date": "2026-04-01", "head": "expense", "amount": "83421", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Gardening|Individual|Gardeners Salary|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	41	{"date": "2026-05-01", "head": "expense", "amount": "87561", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Gardening|Individual|Gardeners Salary|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	42	{"date": "2026-06-01", "head": "expense", "amount": "85346.1", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Gardening|Individual|Gardeners Salary|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	43	{"date": "2026-04-01", "head": "expense", "amount": "24471.07", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Gardening|Individual|Gardening Supervisor Salary|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	44	{"date": "2026-05-01", "head": "expense", "amount": "23681.69", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Gardening|Individual|Gardening Supervisor Salary|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	45	{"date": "2026-06-01", "head": "expense", "amount": "23627.24", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Gardening|Individual|Gardening Supervisor Salary|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	46	{"date": "2026-04-01", "head": "expense", "amount": "22948.08", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Uncategorized|Individual|Help Desk Salary|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	47	{"date": "2026-05-01", "head": "expense", "amount": "27759.6", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Uncategorized|Individual|Help Desk Salary|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	48	{"date": "2026-06-01", "head": "expense", "amount": "24860.42", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Uncategorized|Individual|Help Desk Salary|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	49	{"date": "2026-04-01", "head": "expense", "amount": "45317", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Housekeeping|Individual|HK Materials|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	50	{"date": "2026-05-01", "head": "expense", "amount": "34857.6", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Housekeeping|Individual|HK Materials|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	51	{"date": "2026-07-01", "head": "expense", "amount": "575", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Housekeeping|Individual|HK Materials|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	52	{"date": "2026-04-01", "head": "expense", "amount": "236717.04", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Housekeeping|Individual|House Keeping Janitor Salary|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	53	{"date": "2026-05-01", "head": "expense", "amount": "313817.43", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Housekeeping|Individual|House Keeping Janitor Salary|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	54	{"date": "2026-06-01", "head": "expense", "amount": "323070.45", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Housekeeping|Individual|House Keeping Janitor Salary|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	55	{"date": "2026-04-01", "head": "expense", "amount": "24204.09", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Housekeeping|Individual|Housekeeping Supervisor Salary|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	56	{"date": "2026-05-01", "head": "expense", "amount": "16397.01", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Housekeeping|Individual|Housekeeping Supervisor Salary|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	57	{"date": "2026-06-01", "head": "expense", "amount": "23398.07", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Housekeeping|Individual|Housekeeping Supervisor Salary|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	58	{"date": "2026-04-01", "head": "expense", "amount": "90000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Uncategorized|Individual|Management Fee|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	59	{"date": "2026-05-01", "head": "expense", "amount": "90000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Uncategorized|Individual|Management Fee|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	60	{"date": "2026-06-01", "head": "expense", "amount": "90000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Uncategorized|Individual|Management Fee|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	61	{"date": "2026-04-01", "head": "expense", "amount": "2000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "One Time Operational Procurement", "source_ref": "D|Uncategorized|Individual|One Time Operational Procurement|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	62	{"date": "2026-07-01", "head": "expense", "amount": "52694", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "One Time Operational Procurement", "source_ref": "D|Uncategorized|Individual|One Time Operational Procurement|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	63	{"date": "2026-04-01", "head": "expense", "amount": "21000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Uncategorized|Individual|Pest Control Services|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	64	{"date": "2026-05-01", "head": "expense", "amount": "21000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Uncategorized|Individual|Pest Control Services|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	65	{"date": "2026-06-01", "head": "expense", "amount": "21000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Uncategorized|Individual|Pest Control Services|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	66	{"date": "2026-04-01", "head": "expense", "amount": "15683", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Individual|Petty Cash - Consumables|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	67	{"date": "2026-05-01", "head": "expense", "amount": "20538", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Individual|Petty Cash - Consumables|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	68	{"date": "2026-06-01", "head": "expense", "amount": "29600", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Individual|Petty Cash - Consumables|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	69	{"date": "2026-07-01", "head": "expense", "amount": "14712", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Individual|Petty Cash - Consumables|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	70	{"date": "2026-04-01", "head": "expense", "amount": "295", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Individual|Petty Cash - Electricals|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	71	{"date": "2026-05-01", "head": "expense", "amount": "6487", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Individual|Petty Cash - Electricals|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	72	{"date": "2026-06-01", "head": "expense", "amount": "5000", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Individual|Petty Cash - Electricals|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	73	{"date": "2026-07-01", "head": "expense", "amount": "444", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Individual|Petty Cash - Electricals|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	74	{"date": "2026-04-01", "head": "expense", "amount": "755", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Individual|Petty Cash - Hardware|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	75	{"date": "2026-05-01", "head": "expense", "amount": "18917", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Individual|Petty Cash - Hardware|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	76	{"date": "2026-06-01", "head": "expense", "amount": "5365", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Individual|Petty Cash - Hardware|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	77	{"date": "2026-07-01", "head": "expense", "amount": "1015", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Individual|Petty Cash - Hardware|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	78	{"date": "2026-04-01", "head": "expense", "amount": "75588.3", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Uncategorized|Individual|Plumbers Salary|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	79	{"date": "2026-05-01", "head": "expense", "amount": "86966.39", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Uncategorized|Individual|Plumbers Salary|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	80	{"date": "2026-06-01", "head": "expense", "amount": "85666.74", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Uncategorized|Individual|Plumbers Salary|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	81	{"date": "2026-04-01", "head": "expense", "amount": "650", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Maintenance|Individual|Rental Charges Machinery|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	82	{"date": "2026-05-01", "head": "expense", "amount": "6650", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Maintenance|Individual|Rental Charges Machinery|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	83	{"date": "2026-06-01", "head": "expense", "amount": "650", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Maintenance|Individual|Rental Charges Machinery|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	84	{"date": "2026-05-01", "head": "expense", "amount": "17334", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Maintenance|Individual|Repair Work|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	85	{"date": "2026-06-01", "head": "expense", "amount": "8000", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Maintenance|Individual|Repair Work|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	86	{"date": "2026-04-01", "head": "expense", "amount": "0.41", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Uncategorized|Individual|Roundoff|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	87	{"date": "2026-05-01", "head": "expense", "amount": "0.21", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Uncategorized|Individual|Roundoff|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	88	{"date": "2026-06-01", "head": "expense", "amount": "0.1", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Uncategorized|Individual|Roundoff|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	89	{"date": "2026-04-01", "head": "expense", "amount": "361130.5", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Security|Individual|Security Guards Salary|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	90	{"date": "2026-05-01", "head": "expense", "amount": "373679.25", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Security|Individual|Security Guards Salary|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	91	{"date": "2026-06-01", "head": "expense", "amount": "375840.5", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Security|Individual|Security Guards Salary|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	92	{"date": "2026-04-01", "head": "expense", "amount": "22065", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Security|Individual|Security Lady Guards Salary|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	93	{"date": "2026-05-01", "head": "expense", "amount": "22064.87", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Security|Individual|Security Lady Guards Salary|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	94	{"date": "2026-06-01", "head": "expense", "amount": "21329.5", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Security|Individual|Security Lady Guards Salary|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	95	{"date": "2026-04-01", "head": "expense", "amount": "51642.7", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Security|Individual|Security Supervisor Salary|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	96	{"date": "2026-05-01", "head": "expense", "amount": "54211.84", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Security|Individual|Security Supervisor Salary|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	97	{"date": "2026-06-01", "head": "expense", "amount": "52518", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Security|Individual|Security Supervisor Salary|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	98	{"date": "2026-04-01", "head": "expense", "amount": "86000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Uncategorized|Individual|STP water collection (Sludge Removal)|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	99	{"date": "2026-05-01", "head": "expense", "amount": "94000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Uncategorized|Individual|STP water collection (Sludge Removal)|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	100	{"date": "2026-06-01", "head": "expense", "amount": "118000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Uncategorized|Individual|STP water collection (Sludge Removal)|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	101	{"date": "2026-04-01", "head": "expense", "amount": "67718.7", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Uncategorized|Individual|STP/WTP Operators Salary|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	102	{"date": "2026-05-01", "head": "expense", "amount": "70631.52", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Uncategorized|Individual|STP/WTP Operators Salary|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	103	{"date": "2026-06-01", "head": "expense", "amount": "75995.43", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Uncategorized|Individual|STP/WTP Operators Salary|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	104	{"date": "2026-04-01", "head": "expense", "amount": "17500", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Uncategorized|Individual|Swimming Pool Services|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	105	{"date": "2026-05-01", "head": "expense", "amount": "17500", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Uncategorized|Individual|Swimming Pool Services|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	106	{"date": "2026-06-01", "head": "expense", "amount": "17500", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Uncategorized|Individual|Swimming Pool Services|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	107	{"date": "2026-04-01", "head": "expense", "amount": "63000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Tank Cleaning Charges", "source_ref": "D|Uncategorized|Individual|Tank Cleaning Charges|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	108	{"date": "2026-04-01", "head": "expense", "amount": "9032", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Uncategorized|Individual|Tools & Stationary|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	109	{"date": "2026-05-01", "head": "expense", "amount": "740", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Uncategorized|Individual|Tools & Stationary|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	110	{"date": "2026-06-01", "head": "expense", "amount": "105", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Uncategorized|Individual|Tools & Stationary|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	111	{"date": "2026-04-01", "head": "expense", "amount": "6000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Uncategorized|Individual|Walkie Talkies|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	112	{"date": "2026-06-01", "head": "expense", "amount": "6000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Uncategorized|Individual|Walkie Talkies|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	113	{"date": "2026-04-01", "head": "expense", "amount": "465815", "vendor": "Water Supplier", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|Water Supplier|Water Supply|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	114	{"date": "2026-05-01", "head": "expense", "amount": "478995", "vendor": "Water Supplier", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|Water Supplier|Water Supply|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	115	{"date": "2026-06-01", "head": "expense", "amount": "515775", "vendor": "Water Supplier", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|Water Supplier|Water Supply|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	116	{"date": "2026-04-01", "head": "expense", "amount": "6200", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Uncategorized|Individual|Water Test Report|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	117	{"date": "2026-05-01", "head": "expense", "amount": "3700", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Uncategorized|Individual|Water Test Report|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	118	{"date": "2026-06-01", "head": "expense", "amount": "3700", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Uncategorized|Individual|Water Test Report|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	119	{"date": "2026-01-01", "head": "expense", "amount": "930.24", "vendor": "Airtel", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel|Airtel Postpaid Connection|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	120	{"date": "2026-02-01", "head": "expense", "amount": "1214.82", "vendor": "Airtel", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel|Airtel Postpaid Connection|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	121	{"date": "2026-03-01", "head": "expense", "amount": "1214.84", "vendor": "Airtel", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel|Airtel Postpaid Connection|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	122	{"date": "2025-12-01", "head": "expense", "amount": "65516.12", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Uncategorized|Individual|Amazon Purchase|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	123	{"date": "2026-02-01", "head": "expense", "amount": "21920.87", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Uncategorized|Individual|Amazon Purchase|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	124	{"date": "2026-03-01", "head": "expense", "amount": "45686.25", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Uncategorized|Individual|Amazon Purchase|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	125	{"date": "2026-03-01", "head": "expense", "amount": "168150", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (AC)", "source_ref": "D|Maintenance|Individual|AMC (AC)|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	126	{"date": "2026-01-01", "head": "expense", "amount": "77200", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (DG)", "source_ref": "D|Maintenance|Individual|AMC (DG)|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	127	{"date": "2025-11-01", "head": "expense", "amount": "180000", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|Individual|AMC (Lift)|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	128	{"date": "2026-01-01", "head": "expense", "amount": "120000", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|Individual|AMC (Lift)|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	129	{"date": "2026-03-01", "head": "expense", "amount": "30000", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|Individual|AMC (Lift)|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	130	{"date": "2025-10-01", "head": "expense", "amount": "166867", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	131	{"date": "2025-11-01", "head": "expense", "amount": "161447", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	132	{"date": "2025-12-01", "head": "expense", "amount": "177869", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	133	{"date": "2026-01-01", "head": "expense", "amount": "109898", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	134	{"date": "2026-02-01", "head": "expense", "amount": "153761", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	135	{"date": "2026-03-01", "head": "expense", "amount": "182719", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	136	{"date": "2025-12-01", "head": "expense", "amount": "148642", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	137	{"date": "2026-01-01", "head": "expense", "amount": "21654", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	138	{"date": "2026-02-01", "head": "expense", "amount": "35093", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	139	{"date": "2026-03-01", "head": "expense", "amount": "42948", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	140	{"date": "2025-10-01", "head": "expense", "amount": "80010", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	141	{"date": "2025-11-01", "head": "expense", "amount": "86552", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	142	{"date": "2025-12-01", "head": "expense", "amount": "94830", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	143	{"date": "2026-01-01", "head": "expense", "amount": "52025", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	144	{"date": "2026-02-01", "head": "expense", "amount": "74040", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	145	{"date": "2026-03-01", "head": "expense", "amount": "85007", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	146	{"date": "2025-10-01", "head": "expense", "amount": "84067", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	147	{"date": "2025-11-01", "head": "expense", "amount": "90504", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	148	{"date": "2025-12-01", "head": "expense", "amount": "104716", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	149	{"date": "2026-01-01", "head": "expense", "amount": "60456", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	150	{"date": "2026-02-01", "head": "expense", "amount": "86048", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	151	{"date": "2026-03-01", "head": "expense", "amount": "95777", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	152	{"date": "2026-02-01", "head": "expense", "amount": "100000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Chartered Accountant", "source_ref": "D|Uncategorized|Individual|Chartered Accountant|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	153	{"date": "2026-02-01", "head": "expense", "amount": "33837", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Uncategorized|Individual|Debris Disposal|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	154	{"date": "2026-03-01", "head": "expense", "amount": "6000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Uncategorized|Individual|Debris Disposal|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	155	{"date": "2026-01-01", "head": "expense", "amount": "23234.75", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "DG Service", "source_ref": "D|Maintenance|Individual|DG Service|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	156	{"date": "2025-11-01", "head": "expense", "amount": "40000", "vendor": "Individual", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Individual|Diesel|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	157	{"date": "2026-01-01", "head": "expense", "amount": "36548", "vendor": "Individual", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Individual|Diesel|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	158	{"date": "2026-03-01", "head": "expense", "amount": "36548", "vendor": "Individual", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Individual|Diesel|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	159	{"date": "2025-10-01", "head": "expense", "amount": "75587.61", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Uncategorized|Individual|Electricians Salary|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	160	{"date": "2025-11-01", "head": "expense", "amount": "75587.61", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Uncategorized|Individual|Electricians Salary|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	161	{"date": "2025-12-01", "head": "expense", "amount": "74775", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Uncategorized|Individual|Electricians Salary|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	162	{"date": "2026-01-01", "head": "expense", "amount": "75587.61", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Uncategorized|Individual|Electricians Salary|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	163	{"date": "2026-02-01", "head": "expense", "amount": "75588.24", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Uncategorized|Individual|Electricians Salary|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	164	{"date": "2026-03-01", "head": "expense", "amount": "74774.84", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Uncategorized|Individual|Electricians Salary|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	165	{"date": "2025-11-01", "head": "expense", "amount": "55460", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Uncategorized|Individual|Facility Manager|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	166	{"date": "2025-12-01", "head": "expense", "amount": "59421", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Uncategorized|Individual|Facility Manager|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	167	{"date": "2026-01-01", "head": "expense", "amount": "59421.11", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Uncategorized|Individual|Facility Manager|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	168	{"date": "2026-02-01", "head": "expense", "amount": "59421.11", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Uncategorized|Individual|Facility Manager|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	169	{"date": "2026-03-01", "head": "expense", "amount": "59421.11", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Uncategorized|Individual|Facility Manager|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	170	{"date": "2025-10-01", "head": "expense", "amount": "14000", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Individual|Garbage removal|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	171	{"date": "2025-11-01", "head": "expense", "amount": "14000", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Individual|Garbage removal|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	172	{"date": "2025-12-01", "head": "expense", "amount": "14000", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Individual|Garbage removal|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	173	{"date": "2026-01-01", "head": "expense", "amount": "14000", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Individual|Garbage removal|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	174	{"date": "2026-02-01", "head": "expense", "amount": "14000", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Individual|Garbage removal|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	175	{"date": "2026-03-01", "head": "expense", "amount": "14000", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Individual|Garbage removal|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	176	{"date": "2025-10-01", "head": "expense", "amount": "22765", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Individual|Garden Tools|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	177	{"date": "2025-11-01", "head": "expense", "amount": "1300", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Individual|Garden Tools|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	178	{"date": "2025-12-01", "head": "expense", "amount": "7015", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Individual|Garden Tools|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	179	{"date": "2026-01-01", "head": "expense", "amount": "8880", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Individual|Garden Tools|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	180	{"date": "2026-03-01", "head": "expense", "amount": "23360", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Individual|Garden Tools|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	181	{"date": "2025-10-01", "head": "expense", "amount": "93771", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Gardening|Individual|Gardeners Salary|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	182	{"date": "2025-11-01", "head": "expense", "amount": "94330", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Gardening|Individual|Gardeners Salary|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	183	{"date": "2025-12-01", "head": "expense", "amount": "90045", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Gardening|Individual|Gardeners Salary|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	184	{"date": "2026-01-01", "head": "expense", "amount": "96255", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Gardening|Individual|Gardeners Salary|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	185	{"date": "2026-02-01", "head": "expense", "amount": "88692.66", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Gardening|Individual|Gardeners Salary|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	186	{"date": "2026-03-01", "head": "expense", "amount": "83835", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Gardening|Individual|Gardeners Salary|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	187	{"date": "2025-10-01", "head": "expense", "amount": "19598.64", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Gardening|Individual|Gardening Supervisor Salary|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	188	{"date": "2025-11-01", "head": "expense", "amount": "25315", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Gardening|Individual|Gardening Supervisor Salary|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	189	{"date": "2025-12-01", "head": "expense", "amount": "25315", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Gardening|Individual|Gardening Supervisor Salary|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	190	{"date": "2026-01-01", "head": "expense", "amount": "25314.91", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Gardening|Individual|Gardening Supervisor Salary|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	191	{"date": "2026-02-01", "head": "expense", "amount": "24410.97", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Gardening|Individual|Gardening Supervisor Salary|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	192	{"date": "2026-03-01", "head": "expense", "amount": "24498.3", "vendor": "Individual", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Gardening|Individual|Gardening Supervisor Salary|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	193	{"date": "2025-10-01", "head": "expense", "amount": "28684.92", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Uncategorized|Individual|Help Desk Salary|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	194	{"date": "2025-11-01", "head": "expense", "amount": "25816", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Uncategorized|Individual|Help Desk Salary|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	195	{"date": "2025-12-01", "head": "expense", "amount": "26834", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Uncategorized|Individual|Help Desk Salary|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	196	{"date": "2026-01-01", "head": "expense", "amount": "26834.28", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Uncategorized|Individual|Help Desk Salary|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	197	{"date": "2026-02-01", "head": "expense", "amount": "25611.5", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Uncategorized|Individual|Help Desk Salary|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	198	{"date": "2026-03-01", "head": "expense", "amount": "26834.28", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Uncategorized|Individual|Help Desk Salary|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	199	{"date": "2025-10-01", "head": "expense", "amount": "68540", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Housekeeping|Individual|HK Materials|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	200	{"date": "2025-11-01", "head": "expense", "amount": "4370", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Housekeeping|Individual|HK Materials|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	201	{"date": "2025-12-01", "head": "expense", "amount": "8050", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Housekeeping|Individual|HK Materials|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	202	{"date": "2026-01-01", "head": "expense", "amount": "650", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Housekeeping|Individual|HK Materials|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	203	{"date": "2026-02-01", "head": "expense", "amount": "5450", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Housekeeping|Individual|HK Materials|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	204	{"date": "2026-03-01", "head": "expense", "amount": "28390", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Housekeeping|Individual|HK Materials|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	205	{"date": "2025-10-01", "head": "expense", "amount": "270357", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Housekeeping|Individual|House Keeping Janitor Salary|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	206	{"date": "2025-11-01", "head": "expense", "amount": "292876", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Housekeeping|Individual|House Keeping Janitor Salary|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	207	{"date": "2025-12-01", "head": "expense", "amount": "314986", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Housekeeping|Individual|House Keeping Janitor Salary|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	208	{"date": "2026-01-01", "head": "expense", "amount": "309726.7", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Housekeeping|Individual|House Keeping Janitor Salary|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	209	{"date": "2026-02-01", "head": "expense", "amount": "306031", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Housekeeping|Individual|House Keeping Janitor Salary|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	210	{"date": "2026-03-01", "head": "expense", "amount": "302129.63", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Housekeeping|Individual|House Keeping Janitor Salary|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	211	{"date": "2025-10-01", "head": "expense", "amount": "24205.11", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Housekeeping|Individual|Housekeeping Supervisor Salary|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	212	{"date": "2025-11-01", "head": "expense", "amount": "24205.11", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Housekeeping|Individual|Housekeeping Supervisor Salary|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	213	{"date": "2025-12-01", "head": "expense", "amount": "21863", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Housekeeping|Individual|Housekeeping Supervisor Salary|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	214	{"date": "2026-01-01", "head": "expense", "amount": "24205.11", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Housekeeping|Individual|Housekeeping Supervisor Salary|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	215	{"date": "2026-02-01", "head": "expense", "amount": "24204.88", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Housekeeping|Individual|Housekeeping Supervisor Salary|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	216	{"date": "2026-03-01", "head": "expense", "amount": "23424.3", "vendor": "Individual", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Housekeeping|Individual|Housekeeping Supervisor Salary|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	217	{"date": "2026-02-01", "head": "expense", "amount": "15000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Legal Consultant", "source_ref": "D|Uncategorized|Individual|Legal Consultant|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	218	{"date": "2025-10-01", "head": "expense", "amount": "90000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Uncategorized|Individual|Management Fee|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	219	{"date": "2025-11-01", "head": "expense", "amount": "90000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Uncategorized|Individual|Management Fee|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	220	{"date": "2025-12-01", "head": "expense", "amount": "90000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Uncategorized|Individual|Management Fee|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	221	{"date": "2026-01-01", "head": "expense", "amount": "90000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Uncategorized|Individual|Management Fee|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	222	{"date": "2026-02-01", "head": "expense", "amount": "90000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Uncategorized|Individual|Management Fee|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	223	{"date": "2026-03-01", "head": "expense", "amount": "90000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Uncategorized|Individual|Management Fee|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	224	{"date": "2025-10-01", "head": "expense", "amount": "21000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Uncategorized|Individual|Pest Control Services|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	225	{"date": "2025-11-01", "head": "expense", "amount": "21000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Uncategorized|Individual|Pest Control Services|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	226	{"date": "2025-12-01", "head": "expense", "amount": "21000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Uncategorized|Individual|Pest Control Services|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	227	{"date": "2026-01-01", "head": "expense", "amount": "21000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Uncategorized|Individual|Pest Control Services|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	228	{"date": "2026-02-01", "head": "expense", "amount": "21000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Uncategorized|Individual|Pest Control Services|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	229	{"date": "2026-03-01", "head": "expense", "amount": "21000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Uncategorized|Individual|Pest Control Services|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	230	{"date": "2025-10-01", "head": "expense", "amount": "6495", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Individual|Petty Cash - Consumables|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	231	{"date": "2025-11-01", "head": "expense", "amount": "6675", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Individual|Petty Cash - Consumables|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	232	{"date": "2025-12-01", "head": "expense", "amount": "11763", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Individual|Petty Cash - Consumables|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	233	{"date": "2026-01-01", "head": "expense", "amount": "21309.5", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Individual|Petty Cash - Consumables|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	234	{"date": "2026-02-01", "head": "expense", "amount": "7751.41", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Individual|Petty Cash - Consumables|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	235	{"date": "2026-03-01", "head": "expense", "amount": "6443.83", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Individual|Petty Cash - Consumables|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	236	{"date": "2025-10-01", "head": "expense", "amount": "165", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Cultural Event", "source_ref": "D|Uncategorized|Individual|Petty Cash - Cultural Event|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	237	{"date": "2026-01-01", "head": "expense", "amount": "210", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Cultural Event", "source_ref": "D|Uncategorized|Individual|Petty Cash - Cultural Event|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	238	{"date": "2026-03-01", "head": "expense", "amount": "51083", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Cultural Event", "source_ref": "D|Uncategorized|Individual|Petty Cash - Cultural Event|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	239	{"date": "2025-10-01", "head": "expense", "amount": "445", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Individual|Petty Cash - Electricals|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	240	{"date": "2025-11-01", "head": "expense", "amount": "3625", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Individual|Petty Cash - Electricals|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	241	{"date": "2025-12-01", "head": "expense", "amount": "260", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Individual|Petty Cash - Electricals|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	242	{"date": "2026-01-01", "head": "expense", "amount": "3029", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Individual|Petty Cash - Electricals|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	243	{"date": "2026-02-01", "head": "expense", "amount": "150", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Individual|Petty Cash - Electricals|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	244	{"date": "2026-03-01", "head": "expense", "amount": "1775", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Individual|Petty Cash - Electricals|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	245	{"date": "2025-10-01", "head": "expense", "amount": "3998", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Individual|Petty Cash - Hardware|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	246	{"date": "2025-11-01", "head": "expense", "amount": "360", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Individual|Petty Cash - Hardware|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	247	{"date": "2025-12-01", "head": "expense", "amount": "990", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Individual|Petty Cash - Hardware|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	248	{"date": "2026-01-01", "head": "expense", "amount": "4805", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Individual|Petty Cash - Hardware|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	249	{"date": "2026-02-01", "head": "expense", "amount": "15125", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Individual|Petty Cash - Hardware|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	250	{"date": "2026-03-01", "head": "expense", "amount": "9295", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Individual|Petty Cash - Hardware|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	251	{"date": "2026-01-01", "head": "expense", "amount": "180", "vendor": "Individual", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Office Supplies", "source_ref": "D|Petty Cash|Individual|Petty Cash - Office Supplies|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	252	{"date": "2025-10-01", "head": "expense", "amount": "75587.61", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Uncategorized|Individual|Plumbers Salary|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	253	{"date": "2025-11-01", "head": "expense", "amount": "75587.61", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Uncategorized|Individual|Plumbers Salary|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	254	{"date": "2025-12-01", "head": "expense", "amount": "75588", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Uncategorized|Individual|Plumbers Salary|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	255	{"date": "2026-01-01", "head": "expense", "amount": "76400.38", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Uncategorized|Individual|Plumbers Salary|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	256	{"date": "2026-02-01", "head": "expense", "amount": "75588.24", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Uncategorized|Individual|Plumbers Salary|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	257	{"date": "2026-03-01", "head": "expense", "amount": "75587.61", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Uncategorized|Individual|Plumbers Salary|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	258	{"date": "2026-02-01", "head": "expense", "amount": "650", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Maintenance|Individual|Rental Charges Machinery|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	259	{"date": "2026-03-01", "head": "expense", "amount": "650", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Maintenance|Individual|Rental Charges Machinery|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	260	{"date": "2026-02-01", "head": "expense", "amount": "36666", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Maintenance|Individual|Repair Work|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	261	{"date": "2026-03-01", "head": "expense", "amount": "35050", "vendor": "Individual", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Maintenance|Individual|Repair Work|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	262	{"date": "2025-10-01", "head": "expense", "amount": "0.39", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Uncategorized|Individual|Roundoff|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	263	{"date": "2026-02-01", "head": "expense", "amount": "0.1", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Uncategorized|Individual|Roundoff|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	264	{"date": "2025-10-01", "head": "expense", "amount": "370832.17", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Security|Individual|Security Guards Salary|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	265	{"date": "2025-11-01", "head": "expense", "amount": "383195", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Security|Individual|Security Guards Salary|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	266	{"date": "2025-12-01", "head": "expense", "amount": "375103", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Security|Individual|Security Guards Salary|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	267	{"date": "2026-01-01", "head": "expense", "amount": "348767.3", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Security|Individual|Security Guards Salary|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	268	{"date": "2026-02-01", "head": "expense", "amount": "359346.24", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Security|Individual|Security Guards Salary|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	269	{"date": "2026-03-01", "head": "expense", "amount": "365541.38", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Security|Individual|Security Guards Salary|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	270	{"date": "2025-10-01", "head": "expense", "amount": "19217.79", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Security|Individual|Security Lady Guards Salary|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	271	{"date": "2025-11-01", "head": "expense", "amount": "22065", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Security|Individual|Security Lady Guards Salary|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	272	{"date": "2025-12-01", "head": "expense", "amount": "22065", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Security|Individual|Security Lady Guards Salary|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	273	{"date": "2026-01-01", "head": "expense", "amount": "22064.87", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Security|Individual|Security Lady Guards Salary|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	274	{"date": "2026-02-01", "head": "expense", "amount": "22065.12", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Security|Individual|Security Lady Guards Salary|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	275	{"date": "2026-03-01", "head": "expense", "amount": "21335.1", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Security|Individual|Security Lady Guards Salary|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	276	{"date": "2025-10-01", "head": "expense", "amount": "52517.72", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Security|Individual|Security Supervisor Salary|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	277	{"date": "2025-11-01", "head": "expense", "amount": "35012", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Security|Individual|Security Supervisor Salary|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	278	{"date": "2025-12-01", "head": "expense", "amount": "51671", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Security|Individual|Security Supervisor Salary|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	279	{"date": "2026-01-01", "head": "expense", "amount": "52517.72", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Security|Individual|Security Supervisor Salary|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	280	{"date": "2026-02-01", "head": "expense", "amount": "52517.92", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Security|Individual|Security Supervisor Salary|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	281	{"date": "2026-03-01", "head": "expense", "amount": "50823.6", "vendor": "Individual", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Security|Individual|Security Supervisor Salary|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	282	{"date": "2025-10-01", "head": "expense", "amount": "240000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Uncategorized|Individual|STP water collection (Sludge Removal)|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	283	{"date": "2025-11-01", "head": "expense", "amount": "208000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Uncategorized|Individual|STP water collection (Sludge Removal)|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	284	{"date": "2025-12-01", "head": "expense", "amount": "178000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Uncategorized|Individual|STP water collection (Sludge Removal)|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	285	{"date": "2026-01-01", "head": "expense", "amount": "102435", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Uncategorized|Individual|STP water collection (Sludge Removal)|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	286	{"date": "2026-02-01", "head": "expense", "amount": "90000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Uncategorized|Individual|STP water collection (Sludge Removal)|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	287	{"date": "2026-03-01", "head": "expense", "amount": "104000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Uncategorized|Individual|STP water collection (Sludge Removal)|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	288	{"date": "2025-10-01", "head": "expense", "amount": "81553.92", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Uncategorized|Individual|STP/WTP Operators Salary|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	289	{"date": "2025-11-01", "head": "expense", "amount": "67718", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Uncategorized|Individual|STP/WTP Operators Salary|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	290	{"date": "2025-12-01", "head": "expense", "amount": "67719", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Uncategorized|Individual|STP/WTP Operators Salary|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	291	{"date": "2026-01-01", "head": "expense", "amount": "66990.72", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Uncategorized|Individual|STP/WTP Operators Salary|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	292	{"date": "2026-02-01", "head": "expense", "amount": "66912.94", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Uncategorized|Individual|STP/WTP Operators Salary|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	293	{"date": "2026-03-01", "head": "expense", "amount": "67718.88", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Uncategorized|Individual|STP/WTP Operators Salary|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	294	{"date": "2025-10-01", "head": "expense", "amount": "17500", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Uncategorized|Individual|Swimming Pool Services|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	295	{"date": "2025-11-01", "head": "expense", "amount": "17500", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Uncategorized|Individual|Swimming Pool Services|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	296	{"date": "2025-12-01", "head": "expense", "amount": "17500", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Uncategorized|Individual|Swimming Pool Services|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	297	{"date": "2026-01-01", "head": "expense", "amount": "17500", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Uncategorized|Individual|Swimming Pool Services|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	298	{"date": "2026-02-01", "head": "expense", "amount": "17500", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Uncategorized|Individual|Swimming Pool Services|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	299	{"date": "2026-03-01", "head": "expense", "amount": "17500", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Uncategorized|Individual|Swimming Pool Services|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	300	{"date": "2025-10-01", "head": "expense", "amount": "80101", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Uncategorized|Individual|Tools & Stationary|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	301	{"date": "2025-11-01", "head": "expense", "amount": "3751", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Uncategorized|Individual|Tools & Stationary|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	302	{"date": "2025-12-01", "head": "expense", "amount": "50", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Uncategorized|Individual|Tools & Stationary|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	303	{"date": "2026-01-01", "head": "expense", "amount": "32186", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Uncategorized|Individual|Tools & Stationary|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	304	{"date": "2026-02-01", "head": "expense", "amount": "1641", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Uncategorized|Individual|Tools & Stationary|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	305	{"date": "2026-03-01", "head": "expense", "amount": "10800", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Uncategorized|Individual|Tools & Stationary|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	306	{"date": "2025-10-01", "head": "expense", "amount": "6000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Uncategorized|Individual|Walkie Talkies|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	307	{"date": "2025-11-01", "head": "expense", "amount": "6000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Uncategorized|Individual|Walkie Talkies|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	308	{"date": "2025-12-01", "head": "expense", "amount": "6000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Uncategorized|Individual|Walkie Talkies|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	309	{"date": "2026-01-01", "head": "expense", "amount": "6000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Uncategorized|Individual|Walkie Talkies|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	310	{"date": "2026-02-01", "head": "expense", "amount": "6000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Uncategorized|Individual|Walkie Talkies|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	311	{"date": "2026-03-01", "head": "expense", "amount": "6000", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Uncategorized|Individual|Walkie Talkies|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	312	{"date": "2025-10-01", "head": "expense", "amount": "382390", "vendor": "Water Supplier", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|Water Supplier|Water Supply|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	313	{"date": "2025-11-01", "head": "expense", "amount": "382250", "vendor": "Water Supplier", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|Water Supplier|Water Supply|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	314	{"date": "2025-12-01", "head": "expense", "amount": "358365", "vendor": "Water Supplier", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|Water Supplier|Water Supply|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	315	{"date": "2026-01-01", "head": "expense", "amount": "373695", "vendor": "Water Supplier", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|Water Supplier|Water Supply|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	316	{"date": "2026-02-01", "head": "expense", "amount": "377480", "vendor": "Water Supplier", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|Water Supplier|Water Supply|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	317	{"date": "2026-03-01", "head": "expense", "amount": "451865", "vendor": "Water Supplier", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|Water Supplier|Water Supply|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	318	{"date": "2025-11-01", "head": "expense", "amount": "3700", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Uncategorized|Individual|Water Test Report|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	319	{"date": "2025-12-01", "head": "expense", "amount": "3700", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Uncategorized|Individual|Water Test Report|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	320	{"date": "2026-01-01", "head": "expense", "amount": "3700", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Uncategorized|Individual|Water Test Report|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	321	{"date": "2026-02-01", "head": "expense", "amount": "3700", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Uncategorized|Individual|Water Test Report|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	322	{"date": "2026-03-01", "head": "expense", "amount": "3700", "vendor": "Individual", "category": "Uncategorized", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Uncategorized|Individual|Water Test Report|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	323	{"date": "2026-04-01", "head": "income", "amount": "5000", "vendor": "Individual", "category": "Uncategorized", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Uncategorized|Individual|Association Fund|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	324	{"date": "2026-05-01", "head": "income", "amount": "3700", "vendor": "Individual", "category": "Uncategorized", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Uncategorized|Individual|Association Fund|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	325	{"date": "2026-06-01", "head": "income", "amount": "19500", "vendor": "Individual", "category": "Uncategorized", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Uncategorized|Individual|Association Fund|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	326	{"date": "2026-04-01", "head": "income", "amount": "2800", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Residents|AV room|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	327	{"date": "2026-05-01", "head": "income", "amount": "3500", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Residents|AV room|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	328	{"date": "2026-06-01", "head": "income", "amount": "2100", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Residents|AV room|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	329	{"date": "2026-07-01", "head": "income", "amount": "2800", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Residents|AV room|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	330	{"date": "2026-05-01", "head": "income", "amount": "1120", "vendor": "Individual", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Individual|Business Center|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	331	{"date": "2026-06-01", "head": "income", "amount": "1080", "vendor": "Individual", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Individual|Business Center|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	332	{"date": "2026-07-01", "head": "income", "amount": "1000", "vendor": "Individual", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Individual|Business Center|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	333	{"date": "2026-04-01", "head": "income", "amount": "12740.4", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Individual|CGST Output|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	334	{"date": "2026-05-01", "head": "income", "amount": "7592", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Individual|CGST Output|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	335	{"date": "2026-06-01", "head": "income", "amount": "5328", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Individual|CGST Output|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	336	{"date": "2026-07-01", "head": "income", "amount": "8680", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Individual|CGST Output|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	337	{"date": "2026-04-01", "head": "income", "amount": "1000", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Common Area Violation", "source_ref": "C|Penalties|Individual|Common Area Violation|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	338	{"date": "2026-06-01", "head": "income", "amount": "6000", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Common Area Violation", "source_ref": "C|Penalties|Individual|Common Area Violation|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	339	{"date": "2026-05-01", "head": "income", "amount": "8179", "vendor": "Individual", "category": "Events", "direction": "C", "flat_code": "", "line_item": "Community Curriculum Activities", "source_ref": "C|Events|Individual|Community Curriculum Activities|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	340	{"date": "2026-05-01", "head": "income", "amount": "1000", "vendor": "Individual", "category": "Uncategorized", "direction": "C", "flat_code": "", "line_item": "Fitness Trainers", "source_ref": "C|Uncategorized|Individual|Fitness Trainers|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	341	{"date": "2026-07-01", "head": "income", "amount": "2304", "vendor": "Individual", "category": "Uncategorized", "direction": "C", "flat_code": "", "line_item": "Fitness Trainers", "source_ref": "C|Uncategorized|Individual|Fitness Trainers|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	342	{"date": "2026-04-01", "head": "income", "amount": "16000", "vendor": "Individual", "category": "Events", "direction": "C", "flat_code": "", "line_item": "Flee Market", "source_ref": "C|Events|Individual|Flee Market|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	343	{"date": "2026-07-01", "head": "income", "amount": "1000", "vendor": "Individual", "category": "Uncategorized", "direction": "C", "flat_code": "", "line_item": "Guest Parking Rent", "source_ref": "C|Uncategorized|Individual|Guest Parking Rent|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	344	{"date": "2026-04-01", "head": "income", "amount": "151725", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Individual|Late Payment Fine|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	345	{"date": "2026-05-01", "head": "income", "amount": "95225", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Individual|Late Payment Fine|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	346	{"date": "2026-06-01", "head": "income", "amount": "68400", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Individual|Late Payment Fine|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	347	{"date": "2026-07-01", "head": "income", "amount": "108175", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Individual|Late Payment Fine|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	348	{"date": "2026-04-01", "head": "income", "amount": "9900", "vendor": "Advertiser", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertiser|Lift Advertisement|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	349	{"date": "2026-06-01", "head": "income", "amount": "5500", "vendor": "Advertiser", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertiser|Lift Advertisement|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	350	{"date": "2026-07-01", "head": "income", "amount": "3300", "vendor": "Advertiser", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertiser|Lift Advertisement|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	351	{"date": "2026-04-01", "head": "income", "amount": "2833274", "vendor": "Flat Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	352	{"date": "2026-05-01", "head": "income", "amount": "2838854.05", "vendor": "Flat Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	353	{"date": "2026-06-01", "head": "income", "amount": "2707115.06", "vendor": "Flat Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	354	{"date": "2026-07-01", "head": "income", "amount": "2748794.41", "vendor": "Flat Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	355	{"date": "2026-07-01", "head": "income", "amount": "7500", "vendor": "Individual", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move In/Out (Manual)", "source_ref": "C|Move Charges|Individual|Move In/Out (Manual)|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	356	{"date": "2026-04-01", "head": "income", "amount": "35000", "vendor": "Individual", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Individual|Move in/out Charges|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	357	{"date": "2026-05-01", "head": "income", "amount": "20000", "vendor": "Individual", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Individual|Move in/out Charges|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	358	{"date": "2026-06-01", "head": "income", "amount": "30000", "vendor": "Individual", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Individual|Move in/out Charges|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	359	{"date": "2026-07-01", "head": "income", "amount": "5000", "vendor": "Individual", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Individual|Move in/out Charges|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	360	{"date": "2026-04-01", "head": "income", "amount": "12000", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	361	{"date": "2026-05-01", "head": "income", "amount": "27000", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	362	{"date": "2026-06-01", "head": "income", "amount": "21000", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	363	{"date": "2026-07-01", "head": "income", "amount": "24000", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	364	{"date": "2026-06-01", "head": "income", "amount": "1000", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Parking Violation", "source_ref": "C|Penalties|Individual|Parking Violation|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	365	{"date": "2026-04-01", "head": "income", "amount": "12740.4", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Individual|SGST Output|2026-04"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	366	{"date": "2026-05-01", "head": "income", "amount": "7592", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Individual|SGST Output|2026-05"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	367	{"date": "2026-06-01", "head": "income", "amount": "5328", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Individual|SGST Output|2026-06"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	368	{"date": "2026-07-01", "head": "income", "amount": "8680", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Individual|SGST Output|2026-07"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	369	{"date": "2025-11-01", "head": "income", "amount": "2800", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Residents|AV room|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	370	{"date": "2025-12-01", "head": "income", "amount": "2800", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Residents|AV room|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	371	{"date": "2026-01-01", "head": "income", "amount": "2800", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Residents|AV room|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	372	{"date": "2026-02-01", "head": "income", "amount": "1400", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Residents|AV room|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	373	{"date": "2026-03-01", "head": "income", "amount": "2800", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Residents|AV room|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	374	{"date": "2025-12-01", "head": "income", "amount": "8345.88", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Individual|CGST Output|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	375	{"date": "2026-01-01", "head": "income", "amount": "30540.06", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Individual|CGST Output|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	376	{"date": "2026-02-01", "head": "income", "amount": "3940", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Individual|CGST Output|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	377	{"date": "2026-03-01", "head": "income", "amount": "9199", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Individual|CGST Output|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	378	{"date": "2026-03-01", "head": "income", "amount": "3000", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Common Area Violation", "source_ref": "C|Penalties|Individual|Common Area Violation|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	379	{"date": "2025-11-01", "head": "income", "amount": "26750", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Individual|Late Payment Fine|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	380	{"date": "2025-12-01", "head": "income", "amount": "40050", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Individual|Late Payment Fine|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	381	{"date": "2026-01-01", "head": "income", "amount": "38650", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Individual|Late Payment Fine|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	382	{"date": "2026-02-01", "head": "income", "amount": "93100", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Individual|Late Payment Fine|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	383	{"date": "2026-03-01", "head": "income", "amount": "147875", "vendor": "Individual", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Individual|Late Payment Fine|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	384	{"date": "2026-01-01", "head": "income", "amount": "15400", "vendor": "Advertiser", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertiser|Lift Advertisement|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	385	{"date": "2026-02-01", "head": "income", "amount": "11000", "vendor": "Advertiser", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertiser|Lift Advertisement|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	386	{"date": "2026-03-01", "head": "income", "amount": "4000", "vendor": "Advertiser", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertiser|Lift Advertisement|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	387	{"date": "2025-10-01", "head": "income", "amount": "18470", "vendor": "Flat Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Flat Owners|Maintenance Charge|2025-10"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	388	{"date": "2025-11-01", "head": "income", "amount": "1552953", "vendor": "Flat Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Flat Owners|Maintenance Charge|2025-11"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	389	{"date": "2025-12-01", "head": "income", "amount": "3059180", "vendor": "Flat Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Flat Owners|Maintenance Charge|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	390	{"date": "2026-01-01", "head": "income", "amount": "4795572.82", "vendor": "Flat Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	391	{"date": "2026-02-01", "head": "income", "amount": "2721950.8", "vendor": "Flat Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	392	{"date": "2026-03-01", "head": "income", "amount": "2747405", "vendor": "Flat Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	393	{"date": "2025-12-01", "head": "income", "amount": "7500", "vendor": "Individual", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Individual|Move in/out Charges|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	394	{"date": "2026-01-01", "head": "income", "amount": "7500", "vendor": "Individual", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Individual|Move in/out Charges|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	395	{"date": "2026-02-01", "head": "income", "amount": "17500", "vendor": "Individual", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Individual|Move in/out Charges|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	396	{"date": "2026-03-01", "head": "income", "amount": "37500", "vendor": "Individual", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Individual|Move in/out Charges|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	397	{"date": "2025-12-01", "head": "income", "amount": "18000", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	398	{"date": "2026-01-01", "head": "income", "amount": "33000", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	399	{"date": "2026-02-01", "head": "income", "amount": "21000", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	400	{"date": "2026-03-01", "head": "income", "amount": "27000", "vendor": "Residents", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-03"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	401	{"date": "2025-12-01", "head": "income", "amount": "8345.88", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Individual|SGST Output|2025-12"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	402	{"date": "2026-01-01", "head": "income", "amount": "30540.06", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Individual|SGST Output|2026-01"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	403	{"date": "2026-02-01", "head": "income", "amount": "3940", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Individual|SGST Output|2026-02"}	\N	\N
99677e60-a26f-459a-840d-896a338a8ac5	404	{"date": "2026-03-01", "head": "income", "amount": "9199", "vendor": "Individual", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Individual|SGST Output|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	1	{"date": "2026-01-01", "head": "expense", "amount": "930.24", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	2	{"date": "2026-02-01", "head": "expense", "amount": "1214.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	3	{"date": "2026-03-01", "head": "expense", "amount": "1214.84", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	4	{"date": "2025-12-01", "head": "expense", "amount": "65516.12", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	5	{"date": "2026-02-01", "head": "expense", "amount": "21920.87", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	6	{"date": "2026-03-01", "head": "expense", "amount": "45686.25", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	7	{"date": "2026-03-01", "head": "expense", "amount": "168150.0", "vendor": "KNND ASSOCIATES PVT LTD", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (AC)", "source_ref": "D|Maintenance|KNND ASSOCIATES PVT LTD|AMC (AC)|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	8	{"date": "2026-01-01", "head": "expense", "amount": "77200.0", "vendor": "KIRLOSKAR OIL ENGINES LTD", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (DG)", "source_ref": "D|Maintenance|KIRLOSKAR OIL ENGINES LTD|AMC (DG)|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	9	{"date": "2025-11-01", "head": "expense", "amount": "180000.0", "vendor": "JOHNSON LIFTS Pvt Ltd", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	10	{"date": "2026-01-01", "head": "expense", "amount": "120000.0", "vendor": "JOHNSON LIFTS Pvt Ltd", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	11	{"date": "2026-03-01", "head": "expense", "amount": "30000.0", "vendor": "JOHNSON LIFTS Pvt Ltd", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	12	{"date": "2025-10-01", "head": "expense", "amount": "166867.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	13	{"date": "2025-11-01", "head": "expense", "amount": "161447.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	14	{"date": "2025-12-01", "head": "expense", "amount": "177869.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	15	{"date": "2026-01-01", "head": "expense", "amount": "109898.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	16	{"date": "2026-02-01", "head": "expense", "amount": "153761.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	17	{"date": "2026-03-01", "head": "expense", "amount": "182719.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	18	{"date": "2025-12-01", "head": "expense", "amount": "148642.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	19	{"date": "2026-01-01", "head": "expense", "amount": "21654.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	20	{"date": "2026-02-01", "head": "expense", "amount": "35093.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	21	{"date": "2026-03-01", "head": "expense", "amount": "42948.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	22	{"date": "2025-10-01", "head": "expense", "amount": "80010.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	23	{"date": "2025-11-01", "head": "expense", "amount": "86552.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	24	{"date": "2025-12-01", "head": "expense", "amount": "94830.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	25	{"date": "2026-01-01", "head": "expense", "amount": "52025.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	26	{"date": "2026-02-01", "head": "expense", "amount": "74040.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	27	{"date": "2026-03-01", "head": "expense", "amount": "85007.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	28	{"date": "2025-10-01", "head": "expense", "amount": "84067.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	29	{"date": "2025-11-01", "head": "expense", "amount": "90504.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	30	{"date": "2025-12-01", "head": "expense", "amount": "104716.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	31	{"date": "2026-01-01", "head": "expense", "amount": "60456.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	32	{"date": "2026-02-01", "head": "expense", "amount": "86048.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	33	{"date": "2026-03-01", "head": "expense", "amount": "95777.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	34	{"date": "2026-02-01", "head": "expense", "amount": "100000.0", "vendor": "Professional Consultant", "category": "Professional Services", "direction": "D", "flat_code": "", "line_item": "Chartered Accountant", "source_ref": "D|Professional Services|Professional Consultant|Chartered Accountant|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	35	{"date": "2026-02-01", "head": "expense", "amount": "33837.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	36	{"date": "2026-03-01", "head": "expense", "amount": "6000.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	37	{"date": "2026-01-01", "head": "expense", "amount": "23234.75", "vendor": "KIRLOSKAR OIL ENGINES LTD", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "DG Service", "source_ref": "D|Maintenance|KIRLOSKAR OIL ENGINES LTD|DG Service|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	38	{"date": "2025-11-01", "head": "expense", "amount": "40000.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	39	{"date": "2026-01-01", "head": "expense", "amount": "36548.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	40	{"date": "2026-03-01", "head": "expense", "amount": "36548.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	41	{"date": "2025-10-01", "head": "expense", "amount": "75587.61", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	42	{"date": "2025-11-01", "head": "expense", "amount": "75587.61", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	43	{"date": "2025-12-01", "head": "expense", "amount": "74775.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	44	{"date": "2026-01-01", "head": "expense", "amount": "75587.61", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	45	{"date": "2026-02-01", "head": "expense", "amount": "75588.24", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	46	{"date": "2026-03-01", "head": "expense", "amount": "74774.84", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	47	{"date": "2025-11-01", "head": "expense", "amount": "55460.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	48	{"date": "2025-12-01", "head": "expense", "amount": "59421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	49	{"date": "2026-01-01", "head": "expense", "amount": "59421.11", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	50	{"date": "2026-02-01", "head": "expense", "amount": "59421.11", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	51	{"date": "2026-03-01", "head": "expense", "amount": "59421.11", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	52	{"date": "2025-10-01", "head": "expense", "amount": "14000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	53	{"date": "2025-11-01", "head": "expense", "amount": "14000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	54	{"date": "2025-12-01", "head": "expense", "amount": "14000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	55	{"date": "2026-01-01", "head": "expense", "amount": "14000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	56	{"date": "2026-02-01", "head": "expense", "amount": "14000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	57	{"date": "2026-03-01", "head": "expense", "amount": "14000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	58	{"date": "2025-10-01", "head": "expense", "amount": "22765.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	59	{"date": "2025-11-01", "head": "expense", "amount": "1300.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	60	{"date": "2025-12-01", "head": "expense", "amount": "7015.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	61	{"date": "2026-01-01", "head": "expense", "amount": "8880.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	62	{"date": "2026-03-01", "head": "expense", "amount": "23360.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	63	{"date": "2025-10-01", "head": "expense", "amount": "93771.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	64	{"date": "2025-11-01", "head": "expense", "amount": "94330.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	65	{"date": "2025-12-01", "head": "expense", "amount": "90045.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	66	{"date": "2026-01-01", "head": "expense", "amount": "96255.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	67	{"date": "2026-02-01", "head": "expense", "amount": "88692.66", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	68	{"date": "2026-03-01", "head": "expense", "amount": "83835.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	69	{"date": "2025-10-01", "head": "expense", "amount": "19598.64", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	70	{"date": "2025-11-01", "head": "expense", "amount": "25315.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	71	{"date": "2025-12-01", "head": "expense", "amount": "25315.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	72	{"date": "2026-01-01", "head": "expense", "amount": "25314.91", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	73	{"date": "2026-02-01", "head": "expense", "amount": "24410.97", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	74	{"date": "2026-03-01", "head": "expense", "amount": "24498.3", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	75	{"date": "2025-10-01", "head": "expense", "amount": "28684.92", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	76	{"date": "2025-11-01", "head": "expense", "amount": "25816.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	77	{"date": "2025-12-01", "head": "expense", "amount": "26834.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	78	{"date": "2026-01-01", "head": "expense", "amount": "26834.28", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	79	{"date": "2026-02-01", "head": "expense", "amount": "25611.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	80	{"date": "2026-03-01", "head": "expense", "amount": "26834.28", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	81	{"date": "2025-10-01", "head": "expense", "amount": "68540.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	82	{"date": "2025-11-01", "head": "expense", "amount": "4370.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	83	{"date": "2025-12-01", "head": "expense", "amount": "8050.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	84	{"date": "2026-01-01", "head": "expense", "amount": "650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	85	{"date": "2026-02-01", "head": "expense", "amount": "5450.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	86	{"date": "2026-03-01", "head": "expense", "amount": "28390.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	87	{"date": "2025-10-01", "head": "expense", "amount": "270357.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	88	{"date": "2025-11-01", "head": "expense", "amount": "292876.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	89	{"date": "2025-12-01", "head": "expense", "amount": "314986.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	90	{"date": "2026-01-01", "head": "expense", "amount": "309726.7", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	91	{"date": "2026-02-01", "head": "expense", "amount": "306031.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	92	{"date": "2026-03-01", "head": "expense", "amount": "302129.63", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	93	{"date": "2025-10-01", "head": "expense", "amount": "24205.11", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	94	{"date": "2025-11-01", "head": "expense", "amount": "24205.11", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	95	{"date": "2025-12-01", "head": "expense", "amount": "21863.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	96	{"date": "2026-01-01", "head": "expense", "amount": "24205.11", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	97	{"date": "2026-02-01", "head": "expense", "amount": "24204.88", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	98	{"date": "2026-03-01", "head": "expense", "amount": "23424.3", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	99	{"date": "2026-02-01", "head": "expense", "amount": "15000.0", "vendor": "Professional Consultant", "category": "Professional Services", "direction": "D", "flat_code": "", "line_item": "Legal Consultant", "source_ref": "D|Professional Services|Professional Consultant|Legal Consultant|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	100	{"date": "2025-10-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	101	{"date": "2025-11-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	102	{"date": "2025-12-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	103	{"date": "2026-01-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	104	{"date": "2026-02-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	105	{"date": "2026-03-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	106	{"date": "2025-10-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	107	{"date": "2025-11-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	108	{"date": "2025-12-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	109	{"date": "2026-01-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	110	{"date": "2026-02-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	111	{"date": "2026-03-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	112	{"date": "2025-10-01", "head": "expense", "amount": "6495.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	113	{"date": "2025-11-01", "head": "expense", "amount": "6675.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	114	{"date": "2025-12-01", "head": "expense", "amount": "11763.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	115	{"date": "2026-01-01", "head": "expense", "amount": "21309.5", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	116	{"date": "2026-02-01", "head": "expense", "amount": "7751.41", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	117	{"date": "2026-03-01", "head": "expense", "amount": "6443.83", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	118	{"date": "2025-10-01", "head": "expense", "amount": "165.0", "vendor": "Petty Cash", "category": "Events", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Cultural Event", "source_ref": "D|Events|Petty Cash|Petty Cash - Cultural Event|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	119	{"date": "2026-01-01", "head": "expense", "amount": "210.0", "vendor": "Petty Cash", "category": "Events", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Cultural Event", "source_ref": "D|Events|Petty Cash|Petty Cash - Cultural Event|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	120	{"date": "2026-03-01", "head": "expense", "amount": "51083.0", "vendor": "Petty Cash", "category": "Events", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Cultural Event", "source_ref": "D|Events|Petty Cash|Petty Cash - Cultural Event|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	121	{"date": "2025-10-01", "head": "expense", "amount": "445.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	122	{"date": "2025-11-01", "head": "expense", "amount": "3625.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	123	{"date": "2025-12-01", "head": "expense", "amount": "260.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	124	{"date": "2026-01-01", "head": "expense", "amount": "3029.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	125	{"date": "2026-02-01", "head": "expense", "amount": "150.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	126	{"date": "2026-03-01", "head": "expense", "amount": "1775.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	127	{"date": "2025-10-01", "head": "expense", "amount": "3998.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	128	{"date": "2025-11-01", "head": "expense", "amount": "360.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	129	{"date": "2025-12-01", "head": "expense", "amount": "990.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	130	{"date": "2026-01-01", "head": "expense", "amount": "4805.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	131	{"date": "2026-02-01", "head": "expense", "amount": "15125.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	132	{"date": "2026-03-01", "head": "expense", "amount": "9295.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	133	{"date": "2026-01-01", "head": "expense", "amount": "180.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Office Supplies", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Office Supplies|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	134	{"date": "2025-10-01", "head": "expense", "amount": "75587.61", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	135	{"date": "2025-11-01", "head": "expense", "amount": "75587.61", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	136	{"date": "2025-12-01", "head": "expense", "amount": "75588.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	137	{"date": "2026-01-01", "head": "expense", "amount": "76400.38", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	138	{"date": "2026-02-01", "head": "expense", "amount": "75588.24", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	139	{"date": "2026-03-01", "head": "expense", "amount": "75587.61", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	140	{"date": "2026-02-01", "head": "expense", "amount": "650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	141	{"date": "2026-03-01", "head": "expense", "amount": "650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	142	{"date": "2026-02-01", "head": "expense", "amount": "36666.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Facility Management|EXOZEN|Repair Work|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	143	{"date": "2026-03-01", "head": "expense", "amount": "35050.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Facility Management|EXOZEN|Repair Work|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	144	{"date": "2025-10-01", "head": "expense", "amount": "0.39", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	145	{"date": "2026-02-01", "head": "expense", "amount": "0.1", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	146	{"date": "2025-10-01", "head": "expense", "amount": "370832.17", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	147	{"date": "2025-11-01", "head": "expense", "amount": "383195.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	148	{"date": "2025-12-01", "head": "expense", "amount": "375103.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	149	{"date": "2026-01-01", "head": "expense", "amount": "348767.3", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	150	{"date": "2026-02-01", "head": "expense", "amount": "359346.24", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	151	{"date": "2026-03-01", "head": "expense", "amount": "365541.38", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	152	{"date": "2025-10-01", "head": "expense", "amount": "19217.79", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	153	{"date": "2025-11-01", "head": "expense", "amount": "22065.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	154	{"date": "2025-12-01", "head": "expense", "amount": "22065.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	155	{"date": "2026-01-01", "head": "expense", "amount": "22064.87", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	156	{"date": "2026-02-01", "head": "expense", "amount": "22065.12", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	157	{"date": "2026-03-01", "head": "expense", "amount": "21335.1", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	158	{"date": "2025-10-01", "head": "expense", "amount": "52517.72", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	159	{"date": "2025-11-01", "head": "expense", "amount": "35012.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	160	{"date": "2025-12-01", "head": "expense", "amount": "51671.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	161	{"date": "2026-01-01", "head": "expense", "amount": "52517.72", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	162	{"date": "2026-02-01", "head": "expense", "amount": "52517.92", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	163	{"date": "2026-03-01", "head": "expense", "amount": "50823.6", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	164	{"date": "2025-10-01", "head": "expense", "amount": "240000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	165	{"date": "2025-11-01", "head": "expense", "amount": "208000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	166	{"date": "2025-12-01", "head": "expense", "amount": "178000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	167	{"date": "2026-01-01", "head": "expense", "amount": "102435.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	168	{"date": "2026-02-01", "head": "expense", "amount": "90000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	169	{"date": "2026-03-01", "head": "expense", "amount": "104000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	170	{"date": "2025-10-01", "head": "expense", "amount": "81553.92", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	171	{"date": "2025-11-01", "head": "expense", "amount": "67718.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	172	{"date": "2025-12-01", "head": "expense", "amount": "67719.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	173	{"date": "2026-01-01", "head": "expense", "amount": "66990.72", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	174	{"date": "2026-02-01", "head": "expense", "amount": "66912.94", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	175	{"date": "2026-03-01", "head": "expense", "amount": "67718.88", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	176	{"date": "2025-10-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	177	{"date": "2025-11-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	178	{"date": "2025-12-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	179	{"date": "2026-01-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	180	{"date": "2026-02-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	181	{"date": "2026-03-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	182	{"date": "2025-10-01", "head": "expense", "amount": "80101.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	183	{"date": "2025-11-01", "head": "expense", "amount": "3751.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	184	{"date": "2025-12-01", "head": "expense", "amount": "50.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	185	{"date": "2026-01-01", "head": "expense", "amount": "32186.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	186	{"date": "2026-02-01", "head": "expense", "amount": "1641.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	187	{"date": "2026-03-01", "head": "expense", "amount": "10800.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	188	{"date": "2025-10-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	189	{"date": "2025-11-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	190	{"date": "2025-12-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	191	{"date": "2026-01-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	192	{"date": "2026-02-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	193	{"date": "2026-03-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	194	{"date": "2025-10-01", "head": "expense", "amount": "382390.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	195	{"date": "2025-11-01", "head": "expense", "amount": "382250.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	196	{"date": "2025-12-01", "head": "expense", "amount": "358365.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	197	{"date": "2026-01-01", "head": "expense", "amount": "373695.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	198	{"date": "2026-02-01", "head": "expense", "amount": "377480.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	199	{"date": "2026-03-01", "head": "expense", "amount": "451865.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	200	{"date": "2025-11-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	201	{"date": "2025-12-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	202	{"date": "2026-01-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	203	{"date": "2026-02-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	204	{"date": "2026-03-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	205	{"date": "2026-04-01", "head": "expense", "amount": "1214.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	206	{"date": "2026-05-01", "head": "expense", "amount": "1414.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	207	{"date": "2026-06-01", "head": "expense", "amount": "1428.98", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	208	{"date": "2026-07-01", "head": "expense", "amount": "1414.82", "vendor": "Airtel Postpaid", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Airtel Postpaid Connection", "source_ref": "D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	335	{"date": "2026-06-01", "head": "income", "amount": "5328.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	209	{"date": "2026-04-01", "head": "expense", "amount": "61049.0", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	210	{"date": "2026-05-01", "head": "expense", "amount": "7590.36", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	211	{"date": "2026-06-01", "head": "expense", "amount": "12018.34", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	212	{"date": "2026-07-01", "head": "expense", "amount": "4455.04", "vendor": "Amazon CG Boulevard RWA", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Amazon Purchase", "source_ref": "D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	213	{"date": "2026-04-01", "head": "expense", "amount": "30000.0", "vendor": "JOHNSON LIFTS Pvt Ltd", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	214	{"date": "2026-06-01", "head": "expense", "amount": "150000.0", "vendor": "JOHNSON LIFTS Pvt Ltd", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "AMC (Lift)", "source_ref": "D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	215	{"date": "2026-06-01", "head": "expense", "amount": "55000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Annual Compliance Expense", "source_ref": "D|Facility Management|EXOZEN|Annual Compliance Expense|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	216	{"date": "2026-04-01", "head": "expense", "amount": "154999.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	217	{"date": "2026-05-01", "head": "expense", "amount": "175902.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM A Block", "source_ref": "D|Utilities|BESCOM|BESCOM A Block|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	218	{"date": "2026-04-01", "head": "expense", "amount": "46130.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	219	{"date": "2026-05-01", "head": "expense", "amount": "43011.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM B Block", "source_ref": "D|Utilities|BESCOM|BESCOM B Block|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	220	{"date": "2026-04-01", "head": "expense", "amount": "79692.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	221	{"date": "2026-05-01", "head": "expense", "amount": "102431.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM E Block", "source_ref": "D|Utilities|BESCOM|BESCOM E Block|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	222	{"date": "2026-04-01", "head": "expense", "amount": "78966.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	223	{"date": "2026-05-01", "head": "expense", "amount": "101572.0", "vendor": "BESCOM", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "BESCOM G Block", "source_ref": "D|Utilities|BESCOM|BESCOM G Block|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	224	{"date": "2026-04-01", "head": "expense", "amount": "9000.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	225	{"date": "2026-05-01", "head": "expense", "amount": "19300.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	226	{"date": "2026-06-01", "head": "expense", "amount": "20400.0", "vendor": "Individual", "category": "Cleaning", "direction": "D", "flat_code": "", "line_item": "Debris Disposal", "source_ref": "D|Cleaning|Individual|Debris Disposal|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	227	{"date": "2026-06-01", "head": "expense", "amount": "12876.27", "vendor": "KIRLOSKAR OIL ENGINES LTD", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "DG Service", "source_ref": "D|Maintenance|KIRLOSKAR OIL ENGINES LTD|DG Service|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	228	{"date": "2026-04-01", "head": "expense", "amount": "91401.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	229	{"date": "2026-05-01", "head": "expense", "amount": "54822.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	230	{"date": "2026-06-01", "head": "expense", "amount": "59784.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	231	{"date": "2026-07-01", "head": "expense", "amount": "59784.0", "vendor": "Sai Krupa Petroleum", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Diesel", "source_ref": "D|Utilities|Sai Krupa Petroleum|Diesel|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	232	{"date": "2026-04-01", "head": "expense", "amount": "75588.3", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	233	{"date": "2026-05-01", "head": "expense", "amount": "82902.54", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	234	{"date": "2026-06-01", "head": "expense", "amount": "86506.61", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Electricians Salary", "source_ref": "D|Facility Management|EXOZEN|Electricians Salary|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	235	{"date": "2026-04-01", "head": "expense", "amount": "59421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	236	{"date": "2026-05-01", "head": "expense", "amount": "59421.11", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	237	{"date": "2026-06-01", "head": "expense", "amount": "59421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Facility Manager", "source_ref": "D|Facility Management|EXOZEN|Facility Manager|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	238	{"date": "2026-04-01", "head": "expense", "amount": "14000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	239	{"date": "2026-05-01", "head": "expense", "amount": "24000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	240	{"date": "2026-06-01", "head": "expense", "amount": "24000.0", "vendor": "Sewa Waste Management", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Garbage removal", "source_ref": "D|Housekeeping|Sewa Waste Management|Garbage removal|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	241	{"date": "2026-04-01", "head": "expense", "amount": "20280.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	242	{"date": "2026-05-01", "head": "expense", "amount": "130.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	243	{"date": "2026-07-01", "head": "expense", "amount": "1491.0", "vendor": "Kavitha Enterprises", "category": "Gardening", "direction": "D", "flat_code": "", "line_item": "Garden Tools", "source_ref": "D|Gardening|Kavitha Enterprises|Garden Tools|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	244	{"date": "2026-04-01", "head": "expense", "amount": "83421.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	245	{"date": "2026-05-01", "head": "expense", "amount": "87561.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	246	{"date": "2026-06-01", "head": "expense", "amount": "85346.1", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardeners Salary", "source_ref": "D|Facility Management|EXOZEN|Gardeners Salary|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	247	{"date": "2026-04-01", "head": "expense", "amount": "24471.07", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	248	{"date": "2026-05-01", "head": "expense", "amount": "23681.69", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	249	{"date": "2026-06-01", "head": "expense", "amount": "23627.24", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Gardening Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	250	{"date": "2026-04-01", "head": "expense", "amount": "22948.08", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	251	{"date": "2026-05-01", "head": "expense", "amount": "27759.6", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	252	{"date": "2026-06-01", "head": "expense", "amount": "24860.42", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Help Desk Salary", "source_ref": "D|Facility Management|EXOZEN|Help Desk Salary|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	253	{"date": "2026-04-01", "head": "expense", "amount": "45317.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	254	{"date": "2026-05-01", "head": "expense", "amount": "34857.6", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	255	{"date": "2026-07-01", "head": "expense", "amount": "575.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "HK Materials", "source_ref": "D|Facility Management|EXOZEN|HK Materials|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	256	{"date": "2026-04-01", "head": "expense", "amount": "236717.04", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	257	{"date": "2026-05-01", "head": "expense", "amount": "313817.43", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	258	{"date": "2026-06-01", "head": "expense", "amount": "323070.45", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "House Keeping Janitor Salary", "source_ref": "D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	259	{"date": "2026-04-01", "head": "expense", "amount": "24204.09", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	260	{"date": "2026-05-01", "head": "expense", "amount": "16397.01", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	261	{"date": "2026-06-01", "head": "expense", "amount": "23398.07", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Housekeeping Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	262	{"date": "2026-04-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	263	{"date": "2026-05-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	264	{"date": "2026-06-01", "head": "expense", "amount": "90000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Management Fee", "source_ref": "D|Facility Management|EXOZEN|Management Fee|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	265	{"date": "2026-04-01", "head": "expense", "amount": "2000.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "One Time Operational Procurement", "source_ref": "D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	266	{"date": "2026-07-01", "head": "expense", "amount": "52694.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "One Time Operational Procurement", "source_ref": "D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	267	{"date": "2026-04-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	268	{"date": "2026-05-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	269	{"date": "2026-06-01", "head": "expense", "amount": "21000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Pest Control Services", "source_ref": "D|Facility Management|EXOZEN|Pest Control Services|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	270	{"date": "2026-04-01", "head": "expense", "amount": "15683.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	271	{"date": "2026-05-01", "head": "expense", "amount": "20538.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	272	{"date": "2026-06-01", "head": "expense", "amount": "29600.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	273	{"date": "2026-07-01", "head": "expense", "amount": "14712.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Consumables", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	274	{"date": "2026-04-01", "head": "expense", "amount": "295.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	275	{"date": "2026-05-01", "head": "expense", "amount": "6487.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	276	{"date": "2026-06-01", "head": "expense", "amount": "5000.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	277	{"date": "2026-07-01", "head": "expense", "amount": "444.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Electricals", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	278	{"date": "2026-04-01", "head": "expense", "amount": "755.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	279	{"date": "2026-05-01", "head": "expense", "amount": "18917.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	280	{"date": "2026-06-01", "head": "expense", "amount": "5365.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	281	{"date": "2026-07-01", "head": "expense", "amount": "1015.0", "vendor": "Petty Cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Petty Cash - Hardware", "source_ref": "D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	282	{"date": "2026-04-01", "head": "expense", "amount": "75588.3", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	283	{"date": "2026-05-01", "head": "expense", "amount": "86966.39", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	284	{"date": "2026-06-01", "head": "expense", "amount": "85666.74", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Plumbers Salary", "source_ref": "D|Facility Management|EXOZEN|Plumbers Salary|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	285	{"date": "2026-04-01", "head": "expense", "amount": "650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	286	{"date": "2026-05-01", "head": "expense", "amount": "6650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	287	{"date": "2026-06-01", "head": "expense", "amount": "650.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Rental Charges Machinery", "source_ref": "D|Facility Management|EXOZEN|Rental Charges Machinery|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	288	{"date": "2026-05-01", "head": "expense", "amount": "17334.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Facility Management|EXOZEN|Repair Work|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	289	{"date": "2026-06-01", "head": "expense", "amount": "8000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Repair Work", "source_ref": "D|Facility Management|EXOZEN|Repair Work|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	290	{"date": "2026-04-01", "head": "expense", "amount": "0.41", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	291	{"date": "2026-05-01", "head": "expense", "amount": "0.21", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	292	{"date": "2026-06-01", "head": "expense", "amount": "0.1", "vendor": "System Adjustment", "category": "Accounting Adjustments", "direction": "D", "flat_code": "", "line_item": "Roundoff", "source_ref": "D|Accounting Adjustments|System Adjustment|Roundoff|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	293	{"date": "2026-04-01", "head": "expense", "amount": "361130.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	294	{"date": "2026-05-01", "head": "expense", "amount": "373679.25", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	295	{"date": "2026-06-01", "head": "expense", "amount": "375840.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Guards Salary|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	296	{"date": "2026-04-01", "head": "expense", "amount": "22065.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	297	{"date": "2026-05-01", "head": "expense", "amount": "22064.87", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	298	{"date": "2026-06-01", "head": "expense", "amount": "21329.5", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Lady Guards Salary", "source_ref": "D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	299	{"date": "2026-04-01", "head": "expense", "amount": "51642.7", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	300	{"date": "2026-05-01", "head": "expense", "amount": "54211.84", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	301	{"date": "2026-06-01", "head": "expense", "amount": "52518.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Security Supervisor Salary", "source_ref": "D|Facility Management|EXOZEN|Security Supervisor Salary|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	302	{"date": "2026-04-01", "head": "expense", "amount": "86000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	303	{"date": "2026-05-01", "head": "expense", "amount": "94000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	304	{"date": "2026-06-01", "head": "expense", "amount": "118000.0", "vendor": "Sapthagiri Cleaner", "category": "Water Treatment", "direction": "D", "flat_code": "", "line_item": "STP water collection (Sludge Removal)", "source_ref": "D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	305	{"date": "2026-04-01", "head": "expense", "amount": "67718.7", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	306	{"date": "2026-05-01", "head": "expense", "amount": "70631.52", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	307	{"date": "2026-06-01", "head": "expense", "amount": "75995.43", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "STP/WTP Operators Salary", "source_ref": "D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	308	{"date": "2026-04-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	309	{"date": "2026-05-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	310	{"date": "2026-06-01", "head": "expense", "amount": "17500.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Swimming Pool Services", "source_ref": "D|Facility Management|EXOZEN|Swimming Pool Services|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	311	{"date": "2026-04-01", "head": "expense", "amount": "63000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Tank Cleaning Charges", "source_ref": "D|Facility Management|EXOZEN|Tank Cleaning Charges|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	312	{"date": "2026-04-01", "head": "expense", "amount": "9032.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	313	{"date": "2026-05-01", "head": "expense", "amount": "740.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	314	{"date": "2026-06-01", "head": "expense", "amount": "105.0", "vendor": "Petty Cash", "category": "Office Supplies", "direction": "D", "flat_code": "", "line_item": "Tools & Stationary", "source_ref": "D|Office Supplies|Petty Cash|Tools & Stationary|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	315	{"date": "2026-04-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	316	{"date": "2026-06-01", "head": "expense", "amount": "6000.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Walkie Talkies", "source_ref": "D|Facility Management|EXOZEN|Walkie Talkies|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	317	{"date": "2026-04-01", "head": "expense", "amount": "465815.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	318	{"date": "2026-05-01", "head": "expense", "amount": "478995.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	319	{"date": "2026-06-01", "head": "expense", "amount": "515775.0", "vendor": "BSN Water Supply", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water Supply", "source_ref": "D|Utilities|BSN Water Supply|Water Supply|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	320	{"date": "2026-04-01", "head": "expense", "amount": "6200.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	321	{"date": "2026-05-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	322	{"date": "2026-06-01", "head": "expense", "amount": "3700.0", "vendor": "EXOZEN", "category": "Facility Management", "direction": "D", "flat_code": "", "line_item": "Water Test Report", "source_ref": "D|Facility Management|EXOZEN|Water Test Report|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	323	{"date": "2026-04-01", "head": "income", "amount": "5000.0", "vendor": "Residents", "category": "Community Contributions", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Community Contributions|Residents|Association Fund|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	324	{"date": "2026-05-01", "head": "income", "amount": "3700.0", "vendor": "Residents", "category": "Community Contributions", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Community Contributions|Residents|Association Fund|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	325	{"date": "2026-06-01", "head": "income", "amount": "19500.0", "vendor": "Residents", "category": "Community Contributions", "direction": "C", "flat_code": "", "line_item": "Association Fund", "source_ref": "C|Community Contributions|Residents|Association Fund|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	326	{"date": "2026-04-01", "head": "income", "amount": "2800.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	327	{"date": "2026-05-01", "head": "income", "amount": "3500.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	328	{"date": "2026-06-01", "head": "income", "amount": "2100.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	329	{"date": "2026-07-01", "head": "income", "amount": "2800.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	330	{"date": "2026-05-01", "head": "income", "amount": "1120.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Amenities|Business Center|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	331	{"date": "2026-06-01", "head": "income", "amount": "1080.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Amenities|Business Center|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	332	{"date": "2026-07-01", "head": "income", "amount": "1000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Business Center", "source_ref": "C|Facility Rental|Amenities|Business Center|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	333	{"date": "2026-04-01", "head": "income", "amount": "12740.4", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	334	{"date": "2026-05-01", "head": "income", "amount": "7592.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	336	{"date": "2026-07-01", "head": "income", "amount": "8680.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	337	{"date": "2026-04-01", "head": "income", "amount": "1000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Common Area Violation", "source_ref": "C|Penalties|Resident Penalties|Common Area Violation|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	338	{"date": "2026-06-01", "head": "income", "amount": "6000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Common Area Violation", "source_ref": "C|Penalties|Resident Penalties|Common Area Violation|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	339	{"date": "2026-05-01", "head": "income", "amount": "8179.0", "vendor": "Community Events", "category": "Events", "direction": "C", "flat_code": "", "line_item": "Community Curriculum Activities", "source_ref": "C|Events|Community Events|Community Curriculum Activities|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	340	{"date": "2026-05-01", "head": "income", "amount": "1000.0", "vendor": "Wellness Programs", "category": "Recreation & Wellness", "direction": "C", "flat_code": "", "line_item": "Fitness Trainers", "source_ref": "C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	341	{"date": "2026-07-01", "head": "income", "amount": "2304.0", "vendor": "Wellness Programs", "category": "Recreation & Wellness", "direction": "C", "flat_code": "", "line_item": "Fitness Trainers", "source_ref": "C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	342	{"date": "2026-04-01", "head": "income", "amount": "16000.0", "vendor": "Community Events", "category": "Events", "direction": "C", "flat_code": "", "line_item": "Flee Market", "source_ref": "C|Events|Community Events|Flee Market|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	343	{"date": "2026-07-01", "head": "income", "amount": "1000.0", "vendor": "Parking Services", "category": "Parking Revenue", "direction": "C", "flat_code": "", "line_item": "Guest Parking Rent", "source_ref": "C|Parking Revenue|Parking Services|Guest Parking Rent|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	344	{"date": "2026-04-01", "head": "income", "amount": "151725.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	345	{"date": "2026-05-01", "head": "income", "amount": "95225.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	346	{"date": "2026-06-01", "head": "income", "amount": "68400.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	347	{"date": "2026-07-01", "head": "income", "amount": "108175.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	348	{"date": "2026-04-01", "head": "income", "amount": "9900.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	349	{"date": "2026-06-01", "head": "income", "amount": "5500.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	350	{"date": "2026-07-01", "head": "income", "amount": "3300.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	351	{"date": "2026-04-01", "head": "income", "amount": "2833274.0", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	352	{"date": "2026-05-01", "head": "income", "amount": "2838854.05", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	353	{"date": "2026-06-01", "head": "income", "amount": "2707115.06", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	354	{"date": "2026-07-01", "head": "income", "amount": "2748794.41", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	355	{"date": "2026-07-01", "head": "income", "amount": "7500.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move In/Out (Manual)", "source_ref": "C|Move Charges|Resident Services|Move In/Out (Manual)|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	356	{"date": "2026-04-01", "head": "income", "amount": "35000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	357	{"date": "2026-05-01", "head": "income", "amount": "20000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	358	{"date": "2026-06-01", "head": "income", "amount": "30000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	359	{"date": "2026-07-01", "head": "income", "amount": "5000.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	360	{"date": "2026-04-01", "head": "income", "amount": "12000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	361	{"date": "2026-05-01", "head": "income", "amount": "27000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	362	{"date": "2026-06-01", "head": "income", "amount": "21000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	363	{"date": "2026-07-01", "head": "income", "amount": "24000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	364	{"date": "2026-06-01", "head": "income", "amount": "1000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Parking Violation", "source_ref": "C|Penalties|Resident Penalties|Parking Violation|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	365	{"date": "2026-04-01", "head": "income", "amount": "12740.4", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-04"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	366	{"date": "2026-05-01", "head": "income", "amount": "7592.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-05"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	367	{"date": "2026-06-01", "head": "income", "amount": "5328.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-06"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	368	{"date": "2026-07-01", "head": "income", "amount": "8680.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-07"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	369	{"date": "2025-11-01", "head": "income", "amount": "2800.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	370	{"date": "2025-12-01", "head": "income", "amount": "2800.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	371	{"date": "2026-01-01", "head": "income", "amount": "2800.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	372	{"date": "2026-02-01", "head": "income", "amount": "1400.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	373	{"date": "2026-03-01", "head": "income", "amount": "2800.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "AV room", "source_ref": "C|Facility Rental|Amenities|AV room|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	374	{"date": "2025-12-01", "head": "income", "amount": "8345.88", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	375	{"date": "2026-01-01", "head": "income", "amount": "30540.06", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	376	{"date": "2026-02-01", "head": "income", "amount": "3940.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	377	{"date": "2026-03-01", "head": "income", "amount": "9199.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "CGST Output", "source_ref": "C|Tax|Tax Collection|CGST Output|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	378	{"date": "2026-03-01", "head": "income", "amount": "3000.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Common Area Violation", "source_ref": "C|Penalties|Resident Penalties|Common Area Violation|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	379	{"date": "2025-11-01", "head": "income", "amount": "26750.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	380	{"date": "2025-12-01", "head": "income", "amount": "40050.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	381	{"date": "2026-01-01", "head": "income", "amount": "38650.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	382	{"date": "2026-02-01", "head": "income", "amount": "93100.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	383	{"date": "2026-03-01", "head": "income", "amount": "147875.0", "vendor": "Resident Penalties", "category": "Penalties", "direction": "C", "flat_code": "", "line_item": "Late Payment Fine", "source_ref": "C|Penalties|Resident Penalties|Late Payment Fine|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	384	{"date": "2026-01-01", "head": "income", "amount": "15400.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	385	{"date": "2026-02-01", "head": "income", "amount": "11000.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	386	{"date": "2026-03-01", "head": "income", "amount": "4000.0", "vendor": "Advertising Revenue", "category": "Advertisement", "direction": "C", "flat_code": "", "line_item": "Lift Advertisement", "source_ref": "C|Advertisement|Advertising Revenue|Lift Advertisement|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	387	{"date": "2025-10-01", "head": "income", "amount": "18470.0", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2025-10"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	388	{"date": "2025-11-01", "head": "income", "amount": "1552953.0", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2025-11"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	389	{"date": "2025-12-01", "head": "income", "amount": "3059180.0", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	390	{"date": "2026-01-01", "head": "income", "amount": "4795572.82", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	391	{"date": "2026-02-01", "head": "income", "amount": "2721950.8", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	392	{"date": "2026-03-01", "head": "income", "amount": "2747405.0", "vendor": "Apartment Owners", "category": "Maintenance Collection", "direction": "C", "flat_code": "", "line_item": "Maintenance Charge", "source_ref": "C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	393	{"date": "2025-12-01", "head": "income", "amount": "7500.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	394	{"date": "2026-01-01", "head": "income", "amount": "7500.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	395	{"date": "2026-02-01", "head": "income", "amount": "17500.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	396	{"date": "2026-03-01", "head": "income", "amount": "37500.0", "vendor": "Resident Services", "category": "Move Charges", "direction": "C", "flat_code": "", "line_item": "Move in/out Charges", "source_ref": "C|Move Charges|Resident Services|Move in/out Charges|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	397	{"date": "2025-12-01", "head": "income", "amount": "18000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	398	{"date": "2026-01-01", "head": "income", "amount": "33000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	399	{"date": "2026-02-01", "head": "income", "amount": "21000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	400	{"date": "2026-03-01", "head": "income", "amount": "27000.0", "vendor": "Amenities", "category": "Facility Rental", "direction": "C", "flat_code": "", "line_item": "Multipurpose Party Hall/Club House", "source_ref": "C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-03"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	401	{"date": "2025-12-01", "head": "income", "amount": "8345.88", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2025-12"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	402	{"date": "2026-01-01", "head": "income", "amount": "30540.06", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-01"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	403	{"date": "2026-02-01", "head": "income", "amount": "3940.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-02"}	\N	\N
f5476189-c8ca-4a28-add9-eda04017ada6	404	{"date": "2026-03-01", "head": "income", "amount": "9199.0", "vendor": "Tax Collection", "category": "Tax", "direction": "C", "flat_code": "", "line_item": "SGST Output", "source_ref": "C|Tax|Tax Collection|SGST Output|2026-03"}	\N	\N
\.


--
-- Data for Name: line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_items (id, category_id, vendor_id, name, first_seen_month, last_seen_month) FROM stdin;
4f36097f-7c65-4a06-9eea-d26e1202f00b	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	1dc46aca-330f-452c-98de-41d3391a095e	AMC (AC)	2026-03-01	2026-03-01
bd851450-a487-430e-bc45-aa058b81d07c	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	fbd6892d-f6ef-4084-a765-f4f07271f0ba	AMC (DG)	2026-01-01	2026-01-01
7eb65156-f0d3-4f3a-b420-208715ec1155	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Annual Compliance Expense	2026-06-01	2026-06-01
df4768bb-916a-40e4-8765-ae27f5749313	b787f534-196a-4914-8172-9563c09b9971	7caa420d-ff54-46b1-b4f6-f9d8cfa28664	Chartered Accountant	2026-02-01	2026-02-01
b219991f-69a9-4440-a587-34de1fe6dc29	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	One Time Operational Procurement	2026-04-01	2026-07-01
d2d5c61d-d96d-4aa5-960f-4cc654cc9088	b787f534-196a-4914-8172-9563c09b9971	7caa420d-ff54-46b1-b4f6-f9d8cfa28664	Legal Consultant	2026-02-01	2026-02-01
64bd977e-0e00-4283-8a0f-945f02f8f2c3	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Tank Cleaning Charges	2026-04-01	2026-04-01
473b2053-0097-4707-9fdd-1344c89f70a8	cc7452d1-7de7-4c2b-89c0-53fe88a38060	581348a6-a54b-44a9-b7a6-f9f960c00d8d	Airtel Postpaid Connection	2026-04-01	2026-07-01
8aae189d-880d-4fef-bc89-aa10221e0518	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Amazon Purchase	2026-04-01	2026-07-01
c989a253-7290-490e-927f-c3c347e68bcc	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	AMC (AC)	2026-03-01	2026-03-01
a9009d42-8291-46d2-88b4-7bd17c39f8f4	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	AMC (DG)	2026-01-01	2026-01-01
27bda39d-214a-40a8-a26a-dc516619e1a3	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	AMC (Lift)	2026-04-01	2026-06-01
171230d0-e4a0-4f43-a9f1-8722b197b244	1f6f324a-4ef5-46f5-b01b-85a6478be869	775bb244-e65f-4219-9cae-c0d30fe5d7c1	Petty Cash - Cultural Event	2025-10-01	2026-03-01
8fa58568-e00a-4b78-ad4c-b566d9a302f1	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Chartered Accountant	2026-02-01	2026-02-01
26737f2a-61e1-46bf-ac31-1c589f42f110	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	Petty Cash - Office Supplies	2026-01-01	2026-01-01
5c6ed05e-47eb-4cb2-b962-f74ab5027201	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Debris Disposal	2026-04-01	2026-06-01
746445c9-8d7a-4cf5-88aa-bafc75b69743	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	DG Service	2026-06-01	2026-06-01
5988da45-6333-4916-bf3c-076de3ca700f	cc7452d1-7de7-4c2b-89c0-53fe88a38060	9c90a9f6-69b6-40da-b5ba-04312a168b25	Diesel	2026-04-01	2026-07-01
01d7d8ed-fed4-4eae-be07-4a3ef37d6b6b	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Electricians Salary	2026-04-01	2026-06-01
30cdecee-4785-4094-b264-0b29637ffb12	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Facility Manager	2026-04-01	2026-06-01
c303be0d-2661-4034-91f5-0ea9560a4a79	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	Garbage removal	2026-04-01	2026-06-01
cba7eb9c-738a-4a17-b8b9-709f9191e52b	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	Garden Tools	2026-04-01	2026-07-01
2a85cb77-023d-402f-ba7d-d78dc7774259	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	Gardeners Salary	2026-04-01	2026-06-01
db764564-ddda-45b8-bb72-cc697cf7b676	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	Gardening Supervisor Salary	2026-04-01	2026-06-01
4350a57f-6e78-4f89-97a4-f1c56106d47c	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Help Desk Salary	2026-04-01	2026-06-01
6f196139-0995-410d-9ed6-65a9704d8812	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	HK Materials	2026-04-01	2026-07-01
be0829f3-9f19-4d2b-967c-ddfe1902f258	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	House Keeping Janitor Salary	2026-04-01	2026-06-01
bd849117-6f31-4b08-a016-b342a0558304	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	Housekeeping Supervisor Salary	2026-04-01	2026-06-01
652be77c-e654-4344-9e6e-119d7e433aa1	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Legal Consultant	2026-02-01	2026-02-01
8426c353-3707-4666-84da-00cb445ca33b	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Management Fee	2026-04-01	2026-06-01
d5149a9b-8612-4062-ae06-6e79d7a0eaa3	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Pest Control Services	2026-04-01	2026-06-01
7a5c2b6e-41d3-4c66-b90a-08b0ef230d9e	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	Petty Cash - Consumables	2026-04-01	2026-07-01
9b9e8735-4b8b-4402-947a-f91b772c076d	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Petty Cash - Cultural Event	2025-10-01	2026-03-01
250bcce6-6ce6-4c78-aebd-8a22169749a9	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	Petty Cash - Electricals	2026-04-01	2026-07-01
7aed34fa-5183-4fa0-9d58-b64ca8718c0f	cc7452d1-7de7-4c2b-89c0-53fe88a38060	028048ac-8e65-4b70-b03c-751c27bd88f1	Airtel Postpaid Connection	2026-01-01	2026-07-01
9fcfe207-5070-4c4a-a80a-1a542ebbac79	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	Petty Cash - Hardware	2026-04-01	2026-07-01
4acc804d-41e2-4c2d-a1bc-8d651c9c3b8e	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	Petty Cash - Office Supplies	2026-01-01	2026-01-01
25194c13-114b-4adb-b53b-2836584c8417	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	cbbf60d9-8db1-4fbb-962d-acacf8717b8a	Amazon Purchase	2025-12-01	2026-07-01
a21243cd-0470-41d1-b9b6-d241ae2e88bf	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	22afd4a5-60fd-410b-93a3-9a94f3c4de3c	AMC (Lift)	2025-11-01	2026-06-01
63e3c2e3-04de-43f2-8b09-0c77d525658e	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Annual Compliance Expense	2026-06-01	2026-06-01
07620758-37e2-4597-bc73-79d2e63d1bcc	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Plumbers Salary	2026-04-01	2026-06-01
3368cea7-8e3d-476e-bb78-069d5d61f73a	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	Rental Charges Machinery	2026-04-01	2026-06-01
19023f6e-bdf7-429a-b00e-a355951e51ec	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	Repair Work	2026-05-01	2026-06-01
40cb6503-4e1f-4a53-a9a3-9c5380f05794	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Roundoff	2026-04-01	2026-06-01
f58c44fb-d0ba-42be-ad5f-56f2698ec5ef	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	BESCOM A Block	2026-04-01	2026-05-01
ab0958c3-582d-4512-82c2-828a8200dce0	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	BESCOM B Block	2026-04-01	2026-05-01
fa73bf34-8218-4dce-9662-b04c0a2cd4bb	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	Security Guards Salary	2026-04-01	2026-06-01
8c3e8f6f-b800-4190-8e9d-e037f5a31c41	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	BESCOM E Block	2026-04-01	2026-05-01
e994896e-57b9-4a73-ab60-2366af002e45	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	BESCOM G Block	2026-04-01	2026-05-01
0b7e0c5b-20e4-40cb-8d00-2efe8e8e1b17	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	Security Lady Guards Salary	2026-04-01	2026-06-01
99a60898-dfdc-4567-a511-59454edf2e0e	77e00431-dd28-4ac2-8141-8e011f73f332	9c90a9f6-69b6-40da-b5ba-04312a168b25	Debris Disposal	2026-02-01	2026-06-01
64de8c54-401a-495f-8a0a-72df06f57e08	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	fbd6892d-f6ef-4084-a765-f4f07271f0ba	DG Service	2026-01-01	2026-06-01
83e06114-f166-4aca-9dde-d7b2817c2657	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	Security Supervisor Salary	2026-04-01	2026-06-01
a49db09b-5ffe-4f02-bc4f-6696ec2fdd9e	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a24668ec-6f8f-44cd-91d6-ce80712dc801	Diesel	2025-11-01	2026-07-01
e6af2c3c-f36e-4604-8f93-f1cf795b597d	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	STP water collection (Sludge Removal)	2026-04-01	2026-06-01
fd467141-e9d7-4cc4-80ce-a9a43306d9f1	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Electricians Salary	2025-10-01	2026-06-01
94b4e1a8-e9ae-4eb8-b816-e1e058bad79c	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	STP/WTP Operators Salary	2026-04-01	2026-06-01
17e3edf0-ee73-490d-9f8f-0e1caf97f357	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Facility Manager	2025-11-01	2026-06-01
dad76512-ea9f-4c7c-9fc7-1074385c3ef8	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Swimming Pool Services	2026-04-01	2026-06-01
7a47a22e-83eb-4972-8c5c-73ba28c8f053	5253d1ba-f944-4641-b6e8-bb6280e088c1	901ea9fa-0af0-460e-9d86-2dcee8d84c11	Garbage removal	2025-10-01	2026-06-01
ae69e209-3e8d-4b41-acf5-cd0fb301768b	60fdea52-667e-4553-aa66-a429cbe2e89b	779b185d-df34-42c1-afc5-a63fa9aefe39	Garden Tools	2025-10-01	2026-07-01
0154ab9b-a334-4202-b3e3-0cc488d8a173	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Gardeners Salary	2025-10-01	2026-06-01
6399189f-103c-4276-bb0d-5406bb69dccd	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Gardening Supervisor Salary	2025-10-01	2026-06-01
b6210fbe-04f8-46ae-a805-04ba39aac620	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Help Desk Salary	2025-10-01	2026-06-01
15aebff2-4ce7-468d-9943-a56bdc6b41b0	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	HK Materials	2025-10-01	2026-07-01
7d217302-1aaa-406f-b1d1-506b00867c57	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	House Keeping Janitor Salary	2025-10-01	2026-06-01
42f2a7c7-8451-4ed7-a4dc-a742af568ea9	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Housekeeping Supervisor Salary	2025-10-01	2026-06-01
0da66f15-bd25-4665-81ee-7b032efb61e4	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Tools & Stationary	2026-04-01	2026-06-01
ab27e102-8b6f-4ae5-a239-a969acb75f2c	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Management Fee	2025-10-01	2026-06-01
96f762e3-5188-4b38-9054-c0200fc7a873	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Walkie Talkies	2026-04-01	2026-06-01
924f84dd-13be-48d8-8114-48d341344f20	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	One Time Operational Procurement	2026-04-01	2026-07-01
6e1307a9-89f6-4b4c-a6e0-1af4dcc86a7f	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Pest Control Services	2025-10-01	2026-06-01
39394630-c7c3-4a80-924c-45f31a761f88	cc7452d1-7de7-4c2b-89c0-53fe88a38060	c5e4bc3d-022e-4535-b5e6-a00385f6b19a	Water Supply	2026-04-01	2026-06-01
6f97ac9c-4b41-4e5d-901e-3f5657a7decc	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	Water Test Report	2026-04-01	2026-06-01
b8f7aa92-ae3d-4368-bd0a-20158f010f42	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	Petty Cash - Consumables	2025-10-01	2026-07-01
292a92f9-0ad6-42bc-84a7-d6518713415d	9314eb17-eb68-4961-ba6f-8c6579a271f7	9c90a9f6-69b6-40da-b5ba-04312a168b25	Association Fund	2026-04-01	2026-06-01
d2a54861-e809-4686-9e71-edb0c1473f38	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	Petty Cash - Electricals	2025-10-01	2026-07-01
b29d4a92-cc1f-4977-a913-e63c3b75ffd1	f7499fee-7b2d-446a-8d9a-99452fe75cd5	9c90a9f6-69b6-40da-b5ba-04312a168b25	Business Center	2026-05-01	2026-07-01
a02d48cd-d8b9-4968-9faf-efc89faf8649	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	Petty Cash - Hardware	2025-10-01	2026-07-01
609ff602-cd5d-4650-b20a-6431ecf5cf7c	80949065-cad3-436e-a1a1-f8ff65634a27	9c90a9f6-69b6-40da-b5ba-04312a168b25	Community Curriculum Activities	2026-05-01	2026-05-01
faf1fc51-a3b4-4730-8649-fa5faa562001	9314eb17-eb68-4961-ba6f-8c6579a271f7	9c90a9f6-69b6-40da-b5ba-04312a168b25	Fitness Trainers	2026-05-01	2026-07-01
651b5f14-6e1a-46c2-844e-9966cef72c20	80949065-cad3-436e-a1a1-f8ff65634a27	9c90a9f6-69b6-40da-b5ba-04312a168b25	Flee Market	2026-04-01	2026-04-01
8735ca25-6bad-4075-b40f-5cb5addda6c1	9314eb17-eb68-4961-ba6f-8c6579a271f7	9c90a9f6-69b6-40da-b5ba-04312a168b25	Guest Parking Rent	2026-07-01	2026-07-01
569d3bba-4e5b-40e9-a4c4-0decdf6fbf1c	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Plumbers Salary	2025-10-01	2026-06-01
76101a05-62de-4032-ab51-9d8027d50e09	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Rental Charges Machinery	2026-02-01	2026-06-01
ba2fe8ae-63af-421f-a4f1-c7616cd0ce1a	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Repair Work	2026-02-01	2026-06-01
92f7557d-43ba-482f-91db-498c8ec00dfc	386378b4-b93e-48e7-8094-b667d71d83b9	2424e6ed-93ab-42c6-807d-b50119107dd1	Roundoff	2025-10-01	2026-06-01
f8b1dedc-b0b7-46eb-a4de-27ce4366b3e1	2cef7ba9-4bda-479a-93e1-94498cfc3725	9c90a9f6-69b6-40da-b5ba-04312a168b25	Move In/Out (Manual)	2026-07-01	2026-07-01
cec5c851-047c-48d3-bcc9-a8de4f8a6f29	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Security Guards Salary	2025-10-01	2026-06-01
4cabdad4-9c6a-49f0-91ed-00084755209c	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Security Lady Guards Salary	2025-10-01	2026-06-01
54b8a0fc-b04c-4cee-828c-75f07a3cd4d5	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	Parking Violation	2026-06-01	2026-06-01
8ae84eea-f24a-4436-b55a-fbef65d02d12	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Security Supervisor Salary	2025-10-01	2026-06-01
4a096871-f440-49b1-b116-f97db7d1ddfb	f951fe7b-e843-4130-8d21-994a29a24a1f	f0785724-ff84-495b-9936-1df07bad8393	STP water collection (Sludge Removal)	2025-10-01	2026-06-01
6532478b-f681-40fa-b255-a5d2e4eab70f	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	STP/WTP Operators Salary	2025-10-01	2026-06-01
f2bd933b-b093-42ed-9ed2-6e829d10f4e8	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	AV room	2026-04-01	2026-07-01
fb9a69dc-1f08-42be-9309-dffc2998eeaa	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Swimming Pool Services	2025-10-01	2026-06-01
2a41cdd4-c92d-45e8-ac6e-1dff91a1e37a	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Tank Cleaning Charges	2026-04-01	2026-04-01
c84eaccd-a5f8-49b4-af8a-48aadad1cb47	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	CGST Output	2026-04-01	2026-07-01
72eb7aef-a149-4e0a-88ad-0a94a4b5220d	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	Common Area Violation	2026-04-01	2026-06-01
2c5949ed-2e11-425b-b7d1-cf6d1a1961c6	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	Tools & Stationary	2025-10-01	2026-06-01
cf71d692-2f96-4b9b-b9b6-43cbefd94619	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Walkie Talkies	2025-10-01	2026-06-01
6e3d465d-e7c7-4356-b5f0-131a8e5106d4	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a01aa921-5c35-4867-872d-1ed121e91875	Water Supply	2025-10-01	2026-06-01
7aeb545b-5236-4a31-863c-5898aabc979d	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	Late Payment Fine	2026-04-01	2026-07-01
6a564814-c594-4d74-b07b-c7743587827c	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	8eee43cb-7057-4998-891a-3b01354c9b41	Lift Advertisement	2026-04-01	2026-07-01
8ea7ddc8-c4b1-40b4-95b6-0161f9b9214d	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	Water Test Report	2025-11-01	2026-06-01
386d1b4e-16c3-4a0f-98b8-0f329db2c3db	18ef50a3-c7e6-4598-b2cf-5e75c727113d	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	Association Fund	2026-04-01	2026-06-01
eea0fea7-ea4a-4c89-b453-bbcd1a1362cc	746213f5-eb70-4bfd-be95-c719831dddf3	64d03044-5c28-4340-acad-af71754741ff	Maintenance Charge	2026-04-01	2026-07-01
c862e30a-f952-4e65-bc20-e5a5fbb0ed59	2cef7ba9-4bda-479a-93e1-94498cfc3725	9c90a9f6-69b6-40da-b5ba-04312a168b25	Move in/out Charges	2026-04-01	2026-07-01
0b1df94d-199b-4869-8c63-a80aea052737	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	Multipurpose Party Hall/Club House	2026-04-01	2026-07-01
536ab333-d8ed-4596-a950-f6667b37e7d4	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	SGST Output	2026-04-01	2026-07-01
09f02d8d-bcd9-44df-884e-6b28fe3b953c	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	Business Center	2026-05-01	2026-07-01
59883a3b-c53e-4b8a-b97d-0421c8c617ed	80949065-cad3-436e-a1a1-f8ff65634a27	6c6cf6ec-d41b-456a-9777-5943fa201c20	Community Curriculum Activities	2026-05-01	2026-05-01
07840cae-30e8-4b60-987c-2eb483e45a9f	ca57194d-2453-4138-a962-bd15e95b15f5	2a8c8086-0441-4b00-b71d-3b1094319c9b	Fitness Trainers	2026-05-01	2026-07-01
0948b577-08d4-4f21-a32e-2c6668d03ce8	80949065-cad3-436e-a1a1-f8ff65634a27	6c6cf6ec-d41b-456a-9777-5943fa201c20	Flee Market	2026-04-01	2026-04-01
eda93ebb-1353-4934-8db8-adb01c904f64	91bf7cbb-d70a-4a93-9116-8884a92f8968	83a2e6a9-991c-498e-8563-7cf076e45662	Guest Parking Rent	2026-07-01	2026-07-01
f55203c8-f4fd-4b9a-b6a3-075e4458294f	2cef7ba9-4bda-479a-93e1-94498cfc3725	7b5c1342-3a72-4331-a90e-684007adeb9e	Move In/Out (Manual)	2026-07-01	2026-07-01
5b6ac997-ddcb-4e2a-bcbf-328db3416c25	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	Parking Violation	2026-06-01	2026-06-01
40483a2a-b24d-4dff-b6bb-b93cc7764b25	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	AV room	2026-04-01	2026-07-01
88b0d502-b86a-493a-a407-60792ab5b5a5	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	CGST Output	2026-04-01	2026-07-01
2eac0b3b-7c95-4cd6-986e-9bb25da41be4	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	Common Area Violation	2026-04-01	2026-06-01
cf33e309-e6e7-4545-80e6-b7f4427427bb	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	Late Payment Fine	2026-04-01	2026-07-01
18d5abfd-d4b4-4fc4-93a2-085c7bf2dc99	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	1708d96b-116e-46fb-ad8b-e8b1ff7f9534	Lift Advertisement	2026-04-01	2026-07-01
295896d7-f8e7-411f-ac4d-17d785d7bda1	746213f5-eb70-4bfd-be95-c719831dddf3	38cc7598-50ed-424e-90f8-83cbd976e33d	Maintenance Charge	2026-04-01	2026-07-01
36812135-b2dd-4bab-85a0-8124121a594e	2cef7ba9-4bda-479a-93e1-94498cfc3725	7b5c1342-3a72-4331-a90e-684007adeb9e	Move in/out Charges	2026-04-01	2026-07-01
aba3d4f9-35b9-4695-85fd-28cb653e8e06	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	Multipurpose Party Hall/Club House	2026-04-01	2026-07-01
f6122417-b832-4e34-b7e6-ef9cdf3eda83	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	SGST Output	2026-04-01	2026-07-01
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp_codes (email, otp_hash, expires_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periods (id, community_id, month, status) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, community_id, txn_date, period_month, head_id, category_id, vendor_id, line_item_id, flat_id, amount_paise, direction, source, source_ref, notes, created_by, created_at, updated_at) FROM stdin;
f8fc0793-a321-47f5-a0dd-2bda168923d2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	581348a6-a54b-44a9-b7a6-f9f960c00d8d	473b2053-0097-4707-9fdd-1344c89f70a8	\N	121482	D	csv	D|Utilities|Airtel|Airtel Postpaid Connection|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
3a9cee88-4815-48c7-8f9d-6dd4999e7b68	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	581348a6-a54b-44a9-b7a6-f9f960c00d8d	473b2053-0097-4707-9fdd-1344c89f70a8	\N	141482	D	csv	D|Utilities|Airtel|Airtel Postpaid Connection|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
cdaff9d4-c83f-40bf-a602-3bde48996368	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	581348a6-a54b-44a9-b7a6-f9f960c00d8d	473b2053-0097-4707-9fdd-1344c89f70a8	\N	142898	D	csv	D|Utilities|Airtel|Airtel Postpaid Connection|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9a0a763f-d363-4bbe-a1e2-49d94a7926af	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	581348a6-a54b-44a9-b7a6-f9f960c00d8d	473b2053-0097-4707-9fdd-1344c89f70a8	\N	141482	D	csv	D|Utilities|Airtel|Airtel Postpaid Connection|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
cbedaa41-aed3-400c-81db-d97d86759af2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8aae189d-880d-4fef-bc89-aa10221e0518	\N	6104900	D	csv	D|Uncategorized|Individual|Amazon Purchase|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
11fda3d4-c9d1-4dc9-90d1-f126b7de30dc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8aae189d-880d-4fef-bc89-aa10221e0518	\N	759036	D	csv	D|Uncategorized|Individual|Amazon Purchase|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f7fd48ab-ce90-413a-bdf4-6ec00f089253	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8aae189d-880d-4fef-bc89-aa10221e0518	\N	1201834	D	csv	D|Uncategorized|Individual|Amazon Purchase|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ebadbd37-8353-48a2-ad8d-1d42835e97c6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8aae189d-880d-4fef-bc89-aa10221e0518	\N	445504	D	csv	D|Uncategorized|Individual|Amazon Purchase|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
bdf21057-de60-40b8-856c-dbd2759d6533	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	27bda39d-214a-40a8-a26a-dc516619e1a3	\N	3000000	D	csv	D|Maintenance|Individual|AMC (Lift)|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5767712c-a61d-4976-8611-0397930f3ce4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	27bda39d-214a-40a8-a26a-dc516619e1a3	\N	15000000	D	csv	D|Maintenance|Individual|AMC (Lift)|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c11d8e1f-4d98-49ee-9324-863f851f53ae	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	7eb65156-f0d3-4f3a-b420-208715ec1155	\N	5500000	D	csv	D|Uncategorized|Individual|Annual Compliance Expense|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
59766905-3f81-4f8e-991a-a254b8abaa4c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	f58c44fb-d0ba-42be-ad5f-56f2698ec5ef	\N	15499900	D	csv	D|Utilities|BESCOM|BESCOM A Block|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f41ba39a-ae74-49d7-ada3-01367eb9634c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	f58c44fb-d0ba-42be-ad5f-56f2698ec5ef	\N	17590200	D	csv	D|Utilities|BESCOM|BESCOM A Block|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
747dac7b-3fde-499d-9209-d7105ccf2635	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	ab0958c3-582d-4512-82c2-828a8200dce0	\N	4613000	D	csv	D|Utilities|BESCOM|BESCOM B Block|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
07460eac-bac8-43f2-be7d-ca05c8817e5b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	ab0958c3-582d-4512-82c2-828a8200dce0	\N	4301100	D	csv	D|Utilities|BESCOM|BESCOM B Block|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
117f93a5-dd66-4ede-9cd0-af919c545a0e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	8c3e8f6f-b800-4190-8e9d-e037f5a31c41	\N	7969200	D	csv	D|Utilities|BESCOM|BESCOM E Block|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b164c48b-bdc9-4456-b768-bba86607e89e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	8c3e8f6f-b800-4190-8e9d-e037f5a31c41	\N	10243100	D	csv	D|Utilities|BESCOM|BESCOM E Block|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
944eb827-68a5-4466-982d-dd7a9f2667fd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	e994896e-57b9-4a73-ab60-2366af002e45	\N	7896600	D	csv	D|Utilities|BESCOM|BESCOM G Block|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
3c022ab0-94d9-4fdb-b328-001b26a694d3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	e994896e-57b9-4a73-ab60-2366af002e45	\N	10157200	D	csv	D|Utilities|BESCOM|BESCOM G Block|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
599ac8c1-c616-4c1e-8321-be1337a4cce7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	5c6ed05e-47eb-4cb2-b962-f74ab5027201	\N	900000	D	csv	D|Uncategorized|Individual|Debris Disposal|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e6db648c-b450-440a-add3-1203dd94dffe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	5c6ed05e-47eb-4cb2-b962-f74ab5027201	\N	1930000	D	csv	D|Uncategorized|Individual|Debris Disposal|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
3ea1d96e-61d5-4dd4-8c91-be80c92ba667	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	5c6ed05e-47eb-4cb2-b962-f74ab5027201	\N	2040000	D	csv	D|Uncategorized|Individual|Debris Disposal|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0ceeb298-9c23-4e57-a759-6e5d6bc94916	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	746445c9-8d7a-4cf5-88aa-bafc75b69743	\N	1287627	D	csv	D|Maintenance|Individual|DG Service|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d31ed226-897e-4f03-8456-572c7b9cd87c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	9c90a9f6-69b6-40da-b5ba-04312a168b25	5988da45-6333-4916-bf3c-076de3ca700f	\N	9140100	D	csv	D|Utilities|Individual|Diesel|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0578aed8-e6e8-43b3-b900-e761b9469dec	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	9c90a9f6-69b6-40da-b5ba-04312a168b25	5988da45-6333-4916-bf3c-076de3ca700f	\N	5482200	D	csv	D|Utilities|Individual|Diesel|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
57f2f878-88a7-4f4e-a36c-a106584d6761	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	9c90a9f6-69b6-40da-b5ba-04312a168b25	5988da45-6333-4916-bf3c-076de3ca700f	\N	5978400	D	csv	D|Utilities|Individual|Diesel|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
17b02408-e5b0-4ee4-bb10-f9bc05844ad8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	9c90a9f6-69b6-40da-b5ba-04312a168b25	5988da45-6333-4916-bf3c-076de3ca700f	\N	5978400	D	csv	D|Utilities|Individual|Diesel|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d03372bb-e308-4a5d-b79a-d8f46967458b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	01d7d8ed-fed4-4eae-be07-4a3ef37d6b6b	\N	7558830	D	csv	D|Uncategorized|Individual|Electricians Salary|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e9b14559-42ca-4446-afb7-b5071a69f4ed	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	01d7d8ed-fed4-4eae-be07-4a3ef37d6b6b	\N	8290254	D	csv	D|Uncategorized|Individual|Electricians Salary|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
1c0aa618-1b62-42e1-8328-f31a6a558fca	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	01d7d8ed-fed4-4eae-be07-4a3ef37d6b6b	\N	8650661	D	csv	D|Uncategorized|Individual|Electricians Salary|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
197c3976-97a0-4f99-9782-50700a19587f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	30cdecee-4785-4094-b264-0b29637ffb12	\N	5942100	D	csv	D|Uncategorized|Individual|Facility Manager|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
784ac049-27df-4b02-8cdb-ff1e253ce7ce	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	30cdecee-4785-4094-b264-0b29637ffb12	\N	5942111	D	csv	D|Uncategorized|Individual|Facility Manager|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
20326564-01cf-4ec4-a896-e890056d41ea	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	30cdecee-4785-4094-b264-0b29637ffb12	\N	5942100	D	csv	D|Uncategorized|Individual|Facility Manager|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d0dffc1b-3038-4481-90bb-823a3275c94e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	c303be0d-2661-4034-91f5-0ea9560a4a79	\N	1400000	D	csv	D|Housekeeping|Individual|Garbage removal|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
14a02ced-4611-4f22-9ce5-c8926e979f5b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	c303be0d-2661-4034-91f5-0ea9560a4a79	\N	2400000	D	csv	D|Housekeeping|Individual|Garbage removal|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4a237a1e-244f-4de7-83e3-c23200a76088	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	c303be0d-2661-4034-91f5-0ea9560a4a79	\N	2400000	D	csv	D|Housekeeping|Individual|Garbage removal|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
181ec8be-05e2-405f-b0c2-aef5f8027b60	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	cba7eb9c-738a-4a17-b8b9-709f9191e52b	\N	2028000	D	csv	D|Gardening|Individual|Garden Tools|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
6b961a20-66bc-49bf-b971-cd7fa88011fe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	cba7eb9c-738a-4a17-b8b9-709f9191e52b	\N	13000	D	csv	D|Gardening|Individual|Garden Tools|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
262c5964-09d1-432b-9b46-97bbdc10ba69	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	cba7eb9c-738a-4a17-b8b9-709f9191e52b	\N	149100	D	csv	D|Gardening|Individual|Garden Tools|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
51a1a12e-c1f6-4a46-8922-d1431aeebc93	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	2a85cb77-023d-402f-ba7d-d78dc7774259	\N	8342100	D	csv	D|Gardening|Individual|Gardeners Salary|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d1b4ec42-6789-418b-b814-1a0adbd2acd1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	2a85cb77-023d-402f-ba7d-d78dc7774259	\N	8756100	D	csv	D|Gardening|Individual|Gardeners Salary|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
47494795-ed0a-408e-a69f-b131de3a3cac	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	2a85cb77-023d-402f-ba7d-d78dc7774259	\N	8534610	D	csv	D|Gardening|Individual|Gardeners Salary|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e78dbab3-7577-4652-85df-7c338a710e2b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	db764564-ddda-45b8-bb72-cc697cf7b676	\N	2447107	D	csv	D|Gardening|Individual|Gardening Supervisor Salary|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
eee8f324-a36a-4cef-be49-68b686d85f5c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	db764564-ddda-45b8-bb72-cc697cf7b676	\N	2368169	D	csv	D|Gardening|Individual|Gardening Supervisor Salary|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
50d6079c-e0fe-475d-a6a6-4bfdd46144f2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	db764564-ddda-45b8-bb72-cc697cf7b676	\N	2362724	D	csv	D|Gardening|Individual|Gardening Supervisor Salary|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4bb5214f-b0d1-47b7-b545-1e8007ba0b5f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	4350a57f-6e78-4f89-97a4-f1c56106d47c	\N	2294808	D	csv	D|Uncategorized|Individual|Help Desk Salary|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
bdebe9f5-1510-437f-b336-7edbfe5e50d6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	4350a57f-6e78-4f89-97a4-f1c56106d47c	\N	2775960	D	csv	D|Uncategorized|Individual|Help Desk Salary|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e117b972-c915-437b-9c7a-ae317f362460	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	4350a57f-6e78-4f89-97a4-f1c56106d47c	\N	2486042	D	csv	D|Uncategorized|Individual|Help Desk Salary|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
71a7b359-dea3-4117-a2db-d95b74bebc00	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f196139-0995-410d-9ed6-65a9704d8812	\N	4531700	D	csv	D|Housekeeping|Individual|HK Materials|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
1ce4edba-5c6b-43c3-b18c-8d8c5ef2bf86	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f196139-0995-410d-9ed6-65a9704d8812	\N	3485760	D	csv	D|Housekeeping|Individual|HK Materials|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
dd9494cc-5822-4c71-aea7-fa1642579cc1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f196139-0995-410d-9ed6-65a9704d8812	\N	57500	D	csv	D|Housekeeping|Individual|HK Materials|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5c1eb0e6-2dd4-405d-afd6-45aac1da1b45	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	be0829f3-9f19-4d2b-967c-ddfe1902f258	\N	23671704	D	csv	D|Housekeeping|Individual|House Keeping Janitor Salary|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f6e80ada-5571-4089-9a2c-631cb59eef11	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	be0829f3-9f19-4d2b-967c-ddfe1902f258	\N	31381743	D	csv	D|Housekeeping|Individual|House Keeping Janitor Salary|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4b9b7fb8-8d10-474e-92a5-f9a98114cd8c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	be0829f3-9f19-4d2b-967c-ddfe1902f258	\N	32307045	D	csv	D|Housekeeping|Individual|House Keeping Janitor Salary|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
8b9edf61-2a8c-4db9-81de-2574ae09f6d5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	bd849117-6f31-4b08-a016-b342a0558304	\N	2420409	D	csv	D|Housekeeping|Individual|Housekeeping Supervisor Salary|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
1e816900-7135-44a0-8bf6-7f76e228a8c6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	bd849117-6f31-4b08-a016-b342a0558304	\N	1639701	D	csv	D|Housekeeping|Individual|Housekeeping Supervisor Salary|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
1a5cc7cb-ac9b-446a-8ddc-2ed353967968	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	bd849117-6f31-4b08-a016-b342a0558304	\N	2339807	D	csv	D|Housekeeping|Individual|Housekeeping Supervisor Salary|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5adf617e-5a1e-40a8-946e-2d779ff21013	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8426c353-3707-4666-84da-00cb445ca33b	\N	9000000	D	csv	D|Uncategorized|Individual|Management Fee|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
1cf3d7f6-e79d-46d0-a517-45e30652245a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8426c353-3707-4666-84da-00cb445ca33b	\N	9000000	D	csv	D|Uncategorized|Individual|Management Fee|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
fbac6266-4063-4c54-a44f-e6345579ae46	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8426c353-3707-4666-84da-00cb445ca33b	\N	9000000	D	csv	D|Uncategorized|Individual|Management Fee|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5394b931-813b-443a-a779-32c019930fcc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	b219991f-69a9-4440-a587-34de1fe6dc29	\N	200000	D	csv	D|Uncategorized|Individual|One Time Operational Procurement|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
08ad49fc-d6b1-4afc-9a16-8e6a4b08ebc3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	b219991f-69a9-4440-a587-34de1fe6dc29	\N	5269400	D	csv	D|Uncategorized|Individual|One Time Operational Procurement|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d7bfa7f1-db2b-40cf-8a8f-e8ef6fe5c584	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	d5149a9b-8612-4062-ae06-6e79d7a0eaa3	\N	2100000	D	csv	D|Uncategorized|Individual|Pest Control Services|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
3be2573a-6ba6-488a-9932-f9551202a4d7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	d5149a9b-8612-4062-ae06-6e79d7a0eaa3	\N	2100000	D	csv	D|Uncategorized|Individual|Pest Control Services|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a89cb299-50e5-4f0e-94f4-c047392a53c0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	d5149a9b-8612-4062-ae06-6e79d7a0eaa3	\N	2100000	D	csv	D|Uncategorized|Individual|Pest Control Services|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4c57df3a-b30e-4d94-aede-33c7db0e9a43	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	7a5c2b6e-41d3-4c66-b90a-08b0ef230d9e	\N	1568300	D	csv	D|Petty Cash|Individual|Petty Cash - Consumables|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
06d37b41-589a-4cfd-817a-79033f22bcb3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	7a5c2b6e-41d3-4c66-b90a-08b0ef230d9e	\N	2053800	D	csv	D|Petty Cash|Individual|Petty Cash - Consumables|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ebd2d7e0-41f8-4ad5-b8b4-33cbc32ac6cf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	7a5c2b6e-41d3-4c66-b90a-08b0ef230d9e	\N	2960000	D	csv	D|Petty Cash|Individual|Petty Cash - Consumables|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2b2318cd-37f4-4104-8fe9-4f1cfddd4b45	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	7a5c2b6e-41d3-4c66-b90a-08b0ef230d9e	\N	1471200	D	csv	D|Petty Cash|Individual|Petty Cash - Consumables|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c0ffc77b-1cd2-4b16-a03e-b796a2c6c4e8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	250bcce6-6ce6-4c78-aebd-8a22169749a9	\N	29500	D	csv	D|Petty Cash|Individual|Petty Cash - Electricals|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
837ec3d1-9955-4a06-9921-115e2768be3e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	250bcce6-6ce6-4c78-aebd-8a22169749a9	\N	648700	D	csv	D|Petty Cash|Individual|Petty Cash - Electricals|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
db3a81d0-2a75-4e76-9c3c-f0bbe5ccc0a8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	250bcce6-6ce6-4c78-aebd-8a22169749a9	\N	500000	D	csv	D|Petty Cash|Individual|Petty Cash - Electricals|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
70a81de2-547a-461b-bdee-3f5742d3d10f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	250bcce6-6ce6-4c78-aebd-8a22169749a9	\N	44400	D	csv	D|Petty Cash|Individual|Petty Cash - Electricals|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
675ecce1-c199-4a7a-870c-c283ea33c537	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	9fcfe207-5070-4c4a-a80a-1a542ebbac79	\N	75500	D	csv	D|Petty Cash|Individual|Petty Cash - Hardware|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a378c5d9-f1b3-4a5b-8eaa-d28a57ec3169	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	9fcfe207-5070-4c4a-a80a-1a542ebbac79	\N	1891700	D	csv	D|Petty Cash|Individual|Petty Cash - Hardware|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e540086d-d94a-4370-b39e-6a6ab1c4f47e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	9fcfe207-5070-4c4a-a80a-1a542ebbac79	\N	536500	D	csv	D|Petty Cash|Individual|Petty Cash - Hardware|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
172f9e27-eec6-4e01-aba0-d99e75f3240c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	9fcfe207-5070-4c4a-a80a-1a542ebbac79	\N	101500	D	csv	D|Petty Cash|Individual|Petty Cash - Hardware|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
76207aaf-8b1f-4b46-aa09-74ae654afd09	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	07620758-37e2-4597-bc73-79d2e63d1bcc	\N	7558830	D	csv	D|Uncategorized|Individual|Plumbers Salary|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e0fec436-b7e6-4601-9ef1-ac4bf00609b4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	07620758-37e2-4597-bc73-79d2e63d1bcc	\N	8696639	D	csv	D|Uncategorized|Individual|Plumbers Salary|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ccf51629-0c20-41ad-abe5-61166f46d23d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	07620758-37e2-4597-bc73-79d2e63d1bcc	\N	8566674	D	csv	D|Uncategorized|Individual|Plumbers Salary|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
09725996-4a2c-484f-9c40-b841abb0f765	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	3368cea7-8e3d-476e-bb78-069d5d61f73a	\N	65000	D	csv	D|Maintenance|Individual|Rental Charges Machinery|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
50c7bfcd-f401-4a9b-8fc6-1705ba9c3cd5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	3368cea7-8e3d-476e-bb78-069d5d61f73a	\N	665000	D	csv	D|Maintenance|Individual|Rental Charges Machinery|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0b2fee32-2767-4406-9174-67e359d78865	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	3368cea7-8e3d-476e-bb78-069d5d61f73a	\N	65000	D	csv	D|Maintenance|Individual|Rental Charges Machinery|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2ba73b5f-3744-469c-90c7-ea01c27aaee1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	19023f6e-bdf7-429a-b00e-a355951e51ec	\N	1733400	D	csv	D|Maintenance|Individual|Repair Work|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
38bd5f48-a669-4955-a96f-f1e4521d64e7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	19023f6e-bdf7-429a-b00e-a355951e51ec	\N	800000	D	csv	D|Maintenance|Individual|Repair Work|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
3a61e1f4-b124-4a7e-b0ce-1b97c8625487	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	40cb6503-4e1f-4a53-a9a3-9c5380f05794	\N	41	D	csv	D|Uncategorized|Individual|Roundoff|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d4d52dc2-a092-4d25-bf05-399a3ff2dd6c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	40cb6503-4e1f-4a53-a9a3-9c5380f05794	\N	21	D	csv	D|Uncategorized|Individual|Roundoff|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
7035b860-276d-4520-8565-991a64d93a02	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	40cb6503-4e1f-4a53-a9a3-9c5380f05794	\N	10	D	csv	D|Uncategorized|Individual|Roundoff|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
128ab661-f81e-4e87-a166-3201f36dc2e0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	fa73bf34-8218-4dce-9662-b04c0a2cd4bb	\N	36113050	D	csv	D|Security|Individual|Security Guards Salary|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c282cb9e-5a56-490f-99a6-f809f2ed5ad8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	fa73bf34-8218-4dce-9662-b04c0a2cd4bb	\N	37367925	D	csv	D|Security|Individual|Security Guards Salary|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ae15c5d9-cca3-4351-96a9-f6bc64c7591e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	fa73bf34-8218-4dce-9662-b04c0a2cd4bb	\N	37584050	D	csv	D|Security|Individual|Security Guards Salary|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a6c00ce3-fd55-4b55-8793-a273f0b5bf28	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	0b7e0c5b-20e4-40cb-8d00-2efe8e8e1b17	\N	2206500	D	csv	D|Security|Individual|Security Lady Guards Salary|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5e48346b-b769-4eff-b040-f948238eb685	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	0b7e0c5b-20e4-40cb-8d00-2efe8e8e1b17	\N	2206487	D	csv	D|Security|Individual|Security Lady Guards Salary|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
eb238a2c-b2b9-44d8-a67c-9777e5672106	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	0b7e0c5b-20e4-40cb-8d00-2efe8e8e1b17	\N	2132950	D	csv	D|Security|Individual|Security Lady Guards Salary|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a29e4b6d-a876-46a3-96e1-77ef58c95593	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	83e06114-f166-4aca-9dde-d7b2817c2657	\N	5164270	D	csv	D|Security|Individual|Security Supervisor Salary|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
36efcaac-dc6f-466e-94b0-78342e6c2ed2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	83e06114-f166-4aca-9dde-d7b2817c2657	\N	5421184	D	csv	D|Security|Individual|Security Supervisor Salary|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
922666e6-2de9-4fdd-a63e-8a40a9198f80	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	83e06114-f166-4aca-9dde-d7b2817c2657	\N	5251800	D	csv	D|Security|Individual|Security Supervisor Salary|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
098fc51f-5e21-48f3-b04a-e68722911769	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	e6af2c3c-f36e-4604-8f93-f1cf795b597d	\N	8600000	D	csv	D|Uncategorized|Individual|STP water collection (Sludge Removal)|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
6d514379-acc7-4820-a2a4-b916ddf260ad	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	e6af2c3c-f36e-4604-8f93-f1cf795b597d	\N	9400000	D	csv	D|Uncategorized|Individual|STP water collection (Sludge Removal)|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
678c61af-8f7d-40e1-b2d0-e320c94e333d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	e6af2c3c-f36e-4604-8f93-f1cf795b597d	\N	11800000	D	csv	D|Uncategorized|Individual|STP water collection (Sludge Removal)|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0ce249af-a247-426d-afb9-4f4d56695385	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	94b4e1a8-e9ae-4eb8-b816-e1e058bad79c	\N	6771870	D	csv	D|Uncategorized|Individual|STP/WTP Operators Salary|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
54bf0f51-2eed-4a5c-81e0-7da0171d9611	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	94b4e1a8-e9ae-4eb8-b816-e1e058bad79c	\N	7063152	D	csv	D|Uncategorized|Individual|STP/WTP Operators Salary|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
eff4f7b3-dd8a-4a07-8122-b9ded7554401	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	94b4e1a8-e9ae-4eb8-b816-e1e058bad79c	\N	7599543	D	csv	D|Uncategorized|Individual|STP/WTP Operators Salary|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0b737cd9-0b93-429f-b975-eb7165630e8e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	dad76512-ea9f-4c7c-9fc7-1074385c3ef8	\N	1750000	D	csv	D|Uncategorized|Individual|Swimming Pool Services|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
8a03034b-d3ef-4a5d-b53e-f8160ca1cd07	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	dad76512-ea9f-4c7c-9fc7-1074385c3ef8	\N	1750000	D	csv	D|Uncategorized|Individual|Swimming Pool Services|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a968297e-9716-4f0a-8f93-2080f36a3e09	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	dad76512-ea9f-4c7c-9fc7-1074385c3ef8	\N	1750000	D	csv	D|Uncategorized|Individual|Swimming Pool Services|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f2b029de-c424-41ba-8184-e6c0ade07367	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	64bd977e-0e00-4283-8a0f-945f02f8f2c3	\N	6300000	D	csv	D|Uncategorized|Individual|Tank Cleaning Charges|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9ae6577b-47d4-4cd3-b216-cff807063db5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	0da66f15-bd25-4665-81ee-7b032efb61e4	\N	903200	D	csv	D|Uncategorized|Individual|Tools & Stationary|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
204ad7a8-dd80-4558-bf55-72a88f9b27ed	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	0da66f15-bd25-4665-81ee-7b032efb61e4	\N	74000	D	csv	D|Uncategorized|Individual|Tools & Stationary|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2543fd93-f101-4ed4-94e6-9d7131f9f2b3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	0da66f15-bd25-4665-81ee-7b032efb61e4	\N	10500	D	csv	D|Uncategorized|Individual|Tools & Stationary|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
23a87c1d-a31a-48ab-ac60-9e55e25511d0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	96f762e3-5188-4b38-9054-c0200fc7a873	\N	600000	D	csv	D|Uncategorized|Individual|Walkie Talkies|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
18b422cb-d97d-418e-9bd8-613ccd6ba936	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	96f762e3-5188-4b38-9054-c0200fc7a873	\N	600000	D	csv	D|Uncategorized|Individual|Walkie Talkies|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f5d02ed7-7e32-480b-a170-2b79c532ae5e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	c5e4bc3d-022e-4535-b5e6-a00385f6b19a	39394630-c7c3-4a80-924c-45f31a761f88	\N	46581500	D	csv	D|Utilities|Water Supplier|Water Supply|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
44d19101-54f7-407f-88de-5e39664aed78	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	c5e4bc3d-022e-4535-b5e6-a00385f6b19a	39394630-c7c3-4a80-924c-45f31a761f88	\N	47899500	D	csv	D|Utilities|Water Supplier|Water Supply|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
45f21f92-a9a2-484a-b28a-31d3d26ad25b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	c5e4bc3d-022e-4535-b5e6-a00385f6b19a	39394630-c7c3-4a80-924c-45f31a761f88	\N	51577500	D	csv	D|Utilities|Water Supplier|Water Supply|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5933847e-ca59-4ce8-b2f0-56a602ee88bd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f97ac9c-4b41-4e5d-901e-3f5657a7decc	\N	620000	D	csv	D|Uncategorized|Individual|Water Test Report|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
01fbda79-0761-4f82-8c62-f7f95a6efa76	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f97ac9c-4b41-4e5d-901e-3f5657a7decc	\N	370000	D	csv	D|Uncategorized|Individual|Water Test Report|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
da5c2def-8435-42db-be3c-d172bea7fb15	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f97ac9c-4b41-4e5d-901e-3f5657a7decc	\N	370000	D	csv	D|Uncategorized|Individual|Water Test Report|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
21db159a-bfc5-46c6-a322-43422ff1b355	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	581348a6-a54b-44a9-b7a6-f9f960c00d8d	473b2053-0097-4707-9fdd-1344c89f70a8	\N	93024	D	csv	D|Utilities|Airtel|Airtel Postpaid Connection|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2240cab0-8e92-4ee9-add2-b6e5f7f184f4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	581348a6-a54b-44a9-b7a6-f9f960c00d8d	473b2053-0097-4707-9fdd-1344c89f70a8	\N	121482	D	csv	D|Utilities|Airtel|Airtel Postpaid Connection|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
83752105-a7ea-4f2a-831f-6d3386dff5f5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	581348a6-a54b-44a9-b7a6-f9f960c00d8d	473b2053-0097-4707-9fdd-1344c89f70a8	\N	121484	D	csv	D|Utilities|Airtel|Airtel Postpaid Connection|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
449080de-feae-4169-9048-4a02f97af566	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8aae189d-880d-4fef-bc89-aa10221e0518	\N	6551612	D	csv	D|Uncategorized|Individual|Amazon Purchase|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
8396301b-61b1-456d-af79-f603b3b158a7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8aae189d-880d-4fef-bc89-aa10221e0518	\N	2192087	D	csv	D|Uncategorized|Individual|Amazon Purchase|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
77ad28dd-a680-40aa-b4c9-aac1980b95b8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8aae189d-880d-4fef-bc89-aa10221e0518	\N	4568625	D	csv	D|Uncategorized|Individual|Amazon Purchase|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
6e2a063d-5e8d-4640-8aac-387e6473b150	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	c989a253-7290-490e-927f-c3c347e68bcc	\N	16815000	D	csv	D|Maintenance|Individual|AMC (AC)|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
1a591ef2-04d7-436a-910e-7406efa87760	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	a9009d42-8291-46d2-88b4-7bd17c39f8f4	\N	7720000	D	csv	D|Maintenance|Individual|AMC (DG)|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
317b3b53-8828-4e2a-a73a-c1edfcd787b0	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	27bda39d-214a-40a8-a26a-dc516619e1a3	\N	18000000	D	csv	D|Maintenance|Individual|AMC (Lift)|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
55968873-60fe-49a3-94a5-f200b1dc7e42	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	27bda39d-214a-40a8-a26a-dc516619e1a3	\N	12000000	D	csv	D|Maintenance|Individual|AMC (Lift)|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
30120be5-149f-4e33-96af-741b595f99e3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	27bda39d-214a-40a8-a26a-dc516619e1a3	\N	3000000	D	csv	D|Maintenance|Individual|AMC (Lift)|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4c5864d1-4131-4e4a-95df-2cbfced3c719	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	f58c44fb-d0ba-42be-ad5f-56f2698ec5ef	\N	16686700	D	csv	D|Utilities|BESCOM|BESCOM A Block|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2f3f2ca3-c631-4385-a222-1b5d3b4867b7	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	f58c44fb-d0ba-42be-ad5f-56f2698ec5ef	\N	16144700	D	csv	D|Utilities|BESCOM|BESCOM A Block|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
80b3e012-d521-447d-b787-53a01cf18892	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	f58c44fb-d0ba-42be-ad5f-56f2698ec5ef	\N	17786900	D	csv	D|Utilities|BESCOM|BESCOM A Block|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2926ffed-7e29-4599-9bed-15f7efc438f0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	f58c44fb-d0ba-42be-ad5f-56f2698ec5ef	\N	10989800	D	csv	D|Utilities|BESCOM|BESCOM A Block|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c6978fd4-c9f8-4a0d-8dde-3e5d848f069b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	f58c44fb-d0ba-42be-ad5f-56f2698ec5ef	\N	15376100	D	csv	D|Utilities|BESCOM|BESCOM A Block|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e0580db9-46bf-40c7-b376-d2d87fbc6c44	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	f58c44fb-d0ba-42be-ad5f-56f2698ec5ef	\N	18271900	D	csv	D|Utilities|BESCOM|BESCOM A Block|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
134d38a4-9f98-48c8-b58b-5e6cc905a930	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	ab0958c3-582d-4512-82c2-828a8200dce0	\N	14864200	D	csv	D|Utilities|BESCOM|BESCOM B Block|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
53da8317-d17a-48fd-aeb2-a92d7b323138	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	ab0958c3-582d-4512-82c2-828a8200dce0	\N	2165400	D	csv	D|Utilities|BESCOM|BESCOM B Block|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
682079e1-ba90-4fae-8486-b4f165eee3d4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	ab0958c3-582d-4512-82c2-828a8200dce0	\N	3509300	D	csv	D|Utilities|BESCOM|BESCOM B Block|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
3bbadb9e-f00c-4b06-a974-e3ce0d097751	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	ab0958c3-582d-4512-82c2-828a8200dce0	\N	4294800	D	csv	D|Utilities|BESCOM|BESCOM B Block|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9a311a55-7d8c-452e-a163-b0feaa0f9f72	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	8c3e8f6f-b800-4190-8e9d-e037f5a31c41	\N	8001000	D	csv	D|Utilities|BESCOM|BESCOM E Block|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4b544cbe-5a09-4353-8127-b26cfdc46c7d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	8c3e8f6f-b800-4190-8e9d-e037f5a31c41	\N	8655200	D	csv	D|Utilities|BESCOM|BESCOM E Block|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b8030099-1e07-46ed-863a-99c77b4eda20	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	8c3e8f6f-b800-4190-8e9d-e037f5a31c41	\N	9483000	D	csv	D|Utilities|BESCOM|BESCOM E Block|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
db153055-6687-46c7-ad9b-790c88c3532d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	8c3e8f6f-b800-4190-8e9d-e037f5a31c41	\N	5202500	D	csv	D|Utilities|BESCOM|BESCOM E Block|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
de71823c-64aa-42ad-96ad-5e6a583e3e23	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	8c3e8f6f-b800-4190-8e9d-e037f5a31c41	\N	7404000	D	csv	D|Utilities|BESCOM|BESCOM E Block|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ebb2ebe9-16db-479c-84f9-1d46efac49a3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	8c3e8f6f-b800-4190-8e9d-e037f5a31c41	\N	8500700	D	csv	D|Utilities|BESCOM|BESCOM E Block|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9177dfb3-3e4d-48ce-b396-09e4353bb325	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	e994896e-57b9-4a73-ab60-2366af002e45	\N	8406700	D	csv	D|Utilities|BESCOM|BESCOM G Block|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b7b7503c-9fc1-4305-8b61-411be0224ec0	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	e994896e-57b9-4a73-ab60-2366af002e45	\N	9050400	D	csv	D|Utilities|BESCOM|BESCOM G Block|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
aad9e952-fecd-4f07-9857-8f8f8757d453	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	e994896e-57b9-4a73-ab60-2366af002e45	\N	10471600	D	csv	D|Utilities|BESCOM|BESCOM G Block|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a7c249e5-04bd-4338-8b12-ae0daccf38f3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	e994896e-57b9-4a73-ab60-2366af002e45	\N	6045600	D	csv	D|Utilities|BESCOM|BESCOM G Block|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4f613362-f820-469e-a8cd-9735b62eb4dc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	e994896e-57b9-4a73-ab60-2366af002e45	\N	8604800	D	csv	D|Utilities|BESCOM|BESCOM G Block|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
65c54254-7e7f-4e43-92ed-46a9d1ac4392	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	f6a8cf98-582f-41bf-97c1-e643d0a3ab72	e994896e-57b9-4a73-ab60-2366af002e45	\N	9577700	D	csv	D|Utilities|BESCOM|BESCOM G Block|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ca6be4ea-fd78-43d0-8f83-c9e71f6da555	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8fa58568-e00a-4b78-ad4c-b566d9a302f1	\N	10000000	D	csv	D|Uncategorized|Individual|Chartered Accountant|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
6aa89d4c-17d9-46e0-967a-c0aa70fb9e89	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	5c6ed05e-47eb-4cb2-b962-f74ab5027201	\N	3383700	D	csv	D|Uncategorized|Individual|Debris Disposal|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
517cbf9a-4899-4cef-9a0e-4ed3dae63ce3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	5c6ed05e-47eb-4cb2-b962-f74ab5027201	\N	600000	D	csv	D|Uncategorized|Individual|Debris Disposal|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9e0a1c79-8ee1-45cd-8e5c-445016e919b3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	746445c9-8d7a-4cf5-88aa-bafc75b69743	\N	2323475	D	csv	D|Maintenance|Individual|DG Service|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
40e99315-605e-4fdd-accc-a8788366e2e5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	9c90a9f6-69b6-40da-b5ba-04312a168b25	5988da45-6333-4916-bf3c-076de3ca700f	\N	4000000	D	csv	D|Utilities|Individual|Diesel|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
96a8c5dd-64cf-476a-ba01-8a4aaa42c3f0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	9c90a9f6-69b6-40da-b5ba-04312a168b25	5988da45-6333-4916-bf3c-076de3ca700f	\N	3654800	D	csv	D|Utilities|Individual|Diesel|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ffada069-ce13-43c1-9e15-387cd904b107	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	9c90a9f6-69b6-40da-b5ba-04312a168b25	5988da45-6333-4916-bf3c-076de3ca700f	\N	3654800	D	csv	D|Utilities|Individual|Diesel|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d94076e8-e015-4f76-b6d3-ffa6d706e7c2	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	01d7d8ed-fed4-4eae-be07-4a3ef37d6b6b	\N	7558761	D	csv	D|Uncategorized|Individual|Electricians Salary|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9525dec3-9d35-4f26-a6dc-1870435b4dff	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	01d7d8ed-fed4-4eae-be07-4a3ef37d6b6b	\N	7558761	D	csv	D|Uncategorized|Individual|Electricians Salary|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9041ba9e-d5f2-4f71-8192-14a63ec1a7f5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	01d7d8ed-fed4-4eae-be07-4a3ef37d6b6b	\N	7477500	D	csv	D|Uncategorized|Individual|Electricians Salary|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
56248dc5-5278-4a45-a560-04d194872aeb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	01d7d8ed-fed4-4eae-be07-4a3ef37d6b6b	\N	7558761	D	csv	D|Uncategorized|Individual|Electricians Salary|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
3e235be3-ec4a-468e-9fcb-b6f7eefccc36	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	01d7d8ed-fed4-4eae-be07-4a3ef37d6b6b	\N	7558824	D	csv	D|Uncategorized|Individual|Electricians Salary|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
61790a28-7770-49b5-b8a8-0478515f3668	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	01d7d8ed-fed4-4eae-be07-4a3ef37d6b6b	\N	7477484	D	csv	D|Uncategorized|Individual|Electricians Salary|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
75b0a044-e5f7-4b4f-9ea1-b9790e4902c8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	30cdecee-4785-4094-b264-0b29637ffb12	\N	5546000	D	csv	D|Uncategorized|Individual|Facility Manager|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c5d87129-97cb-47b1-8975-7e79d528ca3c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	30cdecee-4785-4094-b264-0b29637ffb12	\N	5942100	D	csv	D|Uncategorized|Individual|Facility Manager|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
fb64997e-fd4a-4629-a39d-6ab914aae768	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	30cdecee-4785-4094-b264-0b29637ffb12	\N	5942111	D	csv	D|Uncategorized|Individual|Facility Manager|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a0f57484-e41f-4736-ae58-b41bf9332223	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	30cdecee-4785-4094-b264-0b29637ffb12	\N	5942111	D	csv	D|Uncategorized|Individual|Facility Manager|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
fc89e232-5b84-4f86-ade4-743a38f052eb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	30cdecee-4785-4094-b264-0b29637ffb12	\N	5942111	D	csv	D|Uncategorized|Individual|Facility Manager|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
35a53628-7fc2-4810-b19f-872fb79827d6	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	c303be0d-2661-4034-91f5-0ea9560a4a79	\N	1400000	D	csv	D|Housekeeping|Individual|Garbage removal|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9ad907c1-bdbd-44c2-adcc-c0bbe4111788	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	c303be0d-2661-4034-91f5-0ea9560a4a79	\N	1400000	D	csv	D|Housekeeping|Individual|Garbage removal|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5d1835bc-17e5-49d5-9d93-2ed797a39a9a	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	c303be0d-2661-4034-91f5-0ea9560a4a79	\N	1400000	D	csv	D|Housekeeping|Individual|Garbage removal|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4730c0b7-6e4b-4b6e-ae31-b356fe18fb27	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	c303be0d-2661-4034-91f5-0ea9560a4a79	\N	1400000	D	csv	D|Housekeeping|Individual|Garbage removal|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
cd33f48b-e371-41d8-ae39-94bcd76609d0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	c303be0d-2661-4034-91f5-0ea9560a4a79	\N	1400000	D	csv	D|Housekeeping|Individual|Garbage removal|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
729f54b4-0aaa-4243-bafe-64361702b70d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	c303be0d-2661-4034-91f5-0ea9560a4a79	\N	1400000	D	csv	D|Housekeeping|Individual|Garbage removal|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ecde8473-796a-4100-95b7-0772679ca771	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	cba7eb9c-738a-4a17-b8b9-709f9191e52b	\N	2276500	D	csv	D|Gardening|Individual|Garden Tools|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
8940d386-4100-4c65-ae16-419c32b56bd0	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	cba7eb9c-738a-4a17-b8b9-709f9191e52b	\N	130000	D	csv	D|Gardening|Individual|Garden Tools|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e75779ef-704e-4dd7-ae32-96b01255d359	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	cba7eb9c-738a-4a17-b8b9-709f9191e52b	\N	701500	D	csv	D|Gardening|Individual|Garden Tools|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b1dd1272-462f-4ccc-9ca4-7f5017490711	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	cba7eb9c-738a-4a17-b8b9-709f9191e52b	\N	888000	D	csv	D|Gardening|Individual|Garden Tools|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
aec4acaa-c5c9-4302-95d0-54f7b53fca61	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	cba7eb9c-738a-4a17-b8b9-709f9191e52b	\N	2336000	D	csv	D|Gardening|Individual|Garden Tools|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b6d9c379-c0a8-4bf5-afd5-e70780000741	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	2a85cb77-023d-402f-ba7d-d78dc7774259	\N	9377100	D	csv	D|Gardening|Individual|Gardeners Salary|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ed0cacc3-3222-4c2f-a9b1-c08b39f9720c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	2a85cb77-023d-402f-ba7d-d78dc7774259	\N	9433000	D	csv	D|Gardening|Individual|Gardeners Salary|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0a363774-55f9-4d2a-8bc7-c11bc4afc375	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	2a85cb77-023d-402f-ba7d-d78dc7774259	\N	9004500	D	csv	D|Gardening|Individual|Gardeners Salary|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9e8c84a9-530c-4cf1-8981-21b496ceb3ab	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	2a85cb77-023d-402f-ba7d-d78dc7774259	\N	9625500	D	csv	D|Gardening|Individual|Gardeners Salary|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
6557c2cd-46d3-427c-8bff-3f9f802ae8d3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	2a85cb77-023d-402f-ba7d-d78dc7774259	\N	8869266	D	csv	D|Gardening|Individual|Gardeners Salary|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
21ae130f-cf9b-4506-89ff-f057f95134d4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	2a85cb77-023d-402f-ba7d-d78dc7774259	\N	8383500	D	csv	D|Gardening|Individual|Gardeners Salary|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
255e4b8e-177a-450a-8401-6a2af4a63992	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	db764564-ddda-45b8-bb72-cc697cf7b676	\N	1959864	D	csv	D|Gardening|Individual|Gardening Supervisor Salary|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
84f613c6-5772-46d1-81c3-e31731fe3beb	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	db764564-ddda-45b8-bb72-cc697cf7b676	\N	2531500	D	csv	D|Gardening|Individual|Gardening Supervisor Salary|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ae716a25-0160-4d4a-82e8-1711642534b7	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	db764564-ddda-45b8-bb72-cc697cf7b676	\N	2531500	D	csv	D|Gardening|Individual|Gardening Supervisor Salary|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
85b08945-26e6-428b-99c0-8582cb8382e7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	db764564-ddda-45b8-bb72-cc697cf7b676	\N	2531491	D	csv	D|Gardening|Individual|Gardening Supervisor Salary|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
92ba055b-e90d-4aac-ad25-942978eac12e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	db764564-ddda-45b8-bb72-cc697cf7b676	\N	2441097	D	csv	D|Gardening|Individual|Gardening Supervisor Salary|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5ceda0ff-2131-4bc6-aa90-12913eed6a1c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	9c90a9f6-69b6-40da-b5ba-04312a168b25	db764564-ddda-45b8-bb72-cc697cf7b676	\N	2449830	D	csv	D|Gardening|Individual|Gardening Supervisor Salary|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9ffff918-02e7-4852-aa08-b100f33e2045	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	4350a57f-6e78-4f89-97a4-f1c56106d47c	\N	2868492	D	csv	D|Uncategorized|Individual|Help Desk Salary|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
19f454f0-8f13-4a47-8008-eb1f428690e7	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	4350a57f-6e78-4f89-97a4-f1c56106d47c	\N	2581600	D	csv	D|Uncategorized|Individual|Help Desk Salary|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
94051580-0551-4af9-9132-5b38fb65bc02	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	4350a57f-6e78-4f89-97a4-f1c56106d47c	\N	2683400	D	csv	D|Uncategorized|Individual|Help Desk Salary|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c5bfac80-5603-4107-a686-31ba28078a11	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	4350a57f-6e78-4f89-97a4-f1c56106d47c	\N	2683428	D	csv	D|Uncategorized|Individual|Help Desk Salary|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b29554a9-eeff-4704-8240-b1af4275763c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	4350a57f-6e78-4f89-97a4-f1c56106d47c	\N	2561150	D	csv	D|Uncategorized|Individual|Help Desk Salary|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
182669d6-bbb9-423d-ac88-15a028c7003c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	4350a57f-6e78-4f89-97a4-f1c56106d47c	\N	2683428	D	csv	D|Uncategorized|Individual|Help Desk Salary|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
7c8a06b6-110e-4205-a61d-7084d5c01335	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f196139-0995-410d-9ed6-65a9704d8812	\N	6854000	D	csv	D|Housekeeping|Individual|HK Materials|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
05355927-3376-47a5-9440-675d481bd516	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f196139-0995-410d-9ed6-65a9704d8812	\N	437000	D	csv	D|Housekeeping|Individual|HK Materials|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0c2c1597-33c5-4a2e-9a83-416bcbb1fc31	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f196139-0995-410d-9ed6-65a9704d8812	\N	805000	D	csv	D|Housekeeping|Individual|HK Materials|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
6a1dd9ea-881e-486e-a10b-5711b25be251	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f196139-0995-410d-9ed6-65a9704d8812	\N	65000	D	csv	D|Housekeeping|Individual|HK Materials|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
14861007-0707-4c78-86b8-ad18b7d44312	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f196139-0995-410d-9ed6-65a9704d8812	\N	545000	D	csv	D|Housekeeping|Individual|HK Materials|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d1fca1a2-0b5b-4401-bf5f-a1e8525c9107	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f196139-0995-410d-9ed6-65a9704d8812	\N	2839000	D	csv	D|Housekeeping|Individual|HK Materials|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e41fcff9-99f0-4cc0-b04f-aa446c8185d3	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	be0829f3-9f19-4d2b-967c-ddfe1902f258	\N	27035700	D	csv	D|Housekeeping|Individual|House Keeping Janitor Salary|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e501c296-459c-4460-a838-c047df2c5ab8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	be0829f3-9f19-4d2b-967c-ddfe1902f258	\N	29287600	D	csv	D|Housekeeping|Individual|House Keeping Janitor Salary|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
32a0095e-5a0f-44a5-ae64-d8b318c6129f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	be0829f3-9f19-4d2b-967c-ddfe1902f258	\N	31498600	D	csv	D|Housekeeping|Individual|House Keeping Janitor Salary|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d1195abe-f6f5-47cd-8df3-86d05b31d7d6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	be0829f3-9f19-4d2b-967c-ddfe1902f258	\N	30972670	D	csv	D|Housekeeping|Individual|House Keeping Janitor Salary|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
82100641-0109-4409-bbc4-24a2883225fd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	be0829f3-9f19-4d2b-967c-ddfe1902f258	\N	30603100	D	csv	D|Housekeeping|Individual|House Keeping Janitor Salary|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4d3a4c9e-5650-4a69-9d9e-68f211ab7bf7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	be0829f3-9f19-4d2b-967c-ddfe1902f258	\N	30212963	D	csv	D|Housekeeping|Individual|House Keeping Janitor Salary|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b7691335-e854-46c3-9098-1e30c9088f91	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	bd849117-6f31-4b08-a016-b342a0558304	\N	2420511	D	csv	D|Housekeeping|Individual|Housekeeping Supervisor Salary|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
44bdfbd1-9a00-4493-a095-9938aa438ea9	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	bd849117-6f31-4b08-a016-b342a0558304	\N	2420511	D	csv	D|Housekeeping|Individual|Housekeeping Supervisor Salary|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
8337ea46-51bd-4673-8760-ddc12aab8ded	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	bd849117-6f31-4b08-a016-b342a0558304	\N	2186300	D	csv	D|Housekeeping|Individual|Housekeeping Supervisor Salary|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
6e1e8204-4a39-44db-b101-2b8386ab9ba7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	bd849117-6f31-4b08-a016-b342a0558304	\N	2420511	D	csv	D|Housekeeping|Individual|Housekeeping Supervisor Salary|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f84c1819-d28e-47a1-931a-e117dd6eabe5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	bd849117-6f31-4b08-a016-b342a0558304	\N	2420488	D	csv	D|Housekeeping|Individual|Housekeeping Supervisor Salary|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d8d44f41-15fc-4b72-a5dc-cf69bdb8a0d5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	9c90a9f6-69b6-40da-b5ba-04312a168b25	bd849117-6f31-4b08-a016-b342a0558304	\N	2342430	D	csv	D|Housekeeping|Individual|Housekeeping Supervisor Salary|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c178d77e-3dae-4152-8896-98b94eac5b28	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	652be77c-e654-4344-9e6e-119d7e433aa1	\N	1500000	D	csv	D|Uncategorized|Individual|Legal Consultant|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
23e717e8-2f12-4fad-8f2b-618e7681235e	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8426c353-3707-4666-84da-00cb445ca33b	\N	9000000	D	csv	D|Uncategorized|Individual|Management Fee|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
1074214b-277d-4de7-8b76-cae61676544d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8426c353-3707-4666-84da-00cb445ca33b	\N	9000000	D	csv	D|Uncategorized|Individual|Management Fee|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
326aede8-3d8d-4572-a56d-4153bf470ed3	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8426c353-3707-4666-84da-00cb445ca33b	\N	9000000	D	csv	D|Uncategorized|Individual|Management Fee|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4b4756e9-3b39-405f-a93a-541a26c62bf0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8426c353-3707-4666-84da-00cb445ca33b	\N	9000000	D	csv	D|Uncategorized|Individual|Management Fee|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
25b9952b-6862-4f3f-bd37-15f26c89a001	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8426c353-3707-4666-84da-00cb445ca33b	\N	9000000	D	csv	D|Uncategorized|Individual|Management Fee|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
48afc335-a5ec-4746-a128-509ee475cbe3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	8426c353-3707-4666-84da-00cb445ca33b	\N	9000000	D	csv	D|Uncategorized|Individual|Management Fee|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2b586fe8-cf3f-4f84-a58d-97ddc552ca50	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	d5149a9b-8612-4062-ae06-6e79d7a0eaa3	\N	2100000	D	csv	D|Uncategorized|Individual|Pest Control Services|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0acdea10-0fc9-49d9-a586-b5913079a49e	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	d5149a9b-8612-4062-ae06-6e79d7a0eaa3	\N	2100000	D	csv	D|Uncategorized|Individual|Pest Control Services|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4eb7013b-1158-4f55-90da-0c1f13f6400d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	d5149a9b-8612-4062-ae06-6e79d7a0eaa3	\N	2100000	D	csv	D|Uncategorized|Individual|Pest Control Services|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
fdc056f6-5e8b-4f89-9f94-e7d6a0f499b5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	d5149a9b-8612-4062-ae06-6e79d7a0eaa3	\N	2100000	D	csv	D|Uncategorized|Individual|Pest Control Services|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
872c7e76-dfe0-4f15-95e6-3d920db05404	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	d5149a9b-8612-4062-ae06-6e79d7a0eaa3	\N	2100000	D	csv	D|Uncategorized|Individual|Pest Control Services|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
8da78741-6916-40d9-958f-a9713a9f5a4d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	d5149a9b-8612-4062-ae06-6e79d7a0eaa3	\N	2100000	D	csv	D|Uncategorized|Individual|Pest Control Services|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f1c16809-d43f-496f-a3c1-6d86c57e3049	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	7a5c2b6e-41d3-4c66-b90a-08b0ef230d9e	\N	649500	D	csv	D|Petty Cash|Individual|Petty Cash - Consumables|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
acae07f4-1329-4fc5-8a3f-79688b74409f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	7a5c2b6e-41d3-4c66-b90a-08b0ef230d9e	\N	667500	D	csv	D|Petty Cash|Individual|Petty Cash - Consumables|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0fcf915d-8a61-44d4-b357-e0bdfd0380f6	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	7a5c2b6e-41d3-4c66-b90a-08b0ef230d9e	\N	1176300	D	csv	D|Petty Cash|Individual|Petty Cash - Consumables|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d2fb1cc5-e41f-406b-9543-b429b6659af1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	7a5c2b6e-41d3-4c66-b90a-08b0ef230d9e	\N	2130950	D	csv	D|Petty Cash|Individual|Petty Cash - Consumables|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e92201a2-0281-4d79-ba88-926e35b77690	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	7a5c2b6e-41d3-4c66-b90a-08b0ef230d9e	\N	775141	D	csv	D|Petty Cash|Individual|Petty Cash - Consumables|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5f438ec3-0040-49e6-b16e-3a5cdcbcf4a5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	7a5c2b6e-41d3-4c66-b90a-08b0ef230d9e	\N	644383	D	csv	D|Petty Cash|Individual|Petty Cash - Consumables|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
7e39171b-dec2-4af0-88aa-4457647cc7ef	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	9b9e8735-4b8b-4402-947a-f91b772c076d	\N	16500	D	csv	D|Uncategorized|Individual|Petty Cash - Cultural Event|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5a299d10-5611-4a53-a9b3-c82ce1674d85	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	9b9e8735-4b8b-4402-947a-f91b772c076d	\N	21000	D	csv	D|Uncategorized|Individual|Petty Cash - Cultural Event|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a222d44d-168d-4fb5-a8bc-5ba13468c4fa	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	9b9e8735-4b8b-4402-947a-f91b772c076d	\N	5108300	D	csv	D|Uncategorized|Individual|Petty Cash - Cultural Event|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e5318dd8-2062-4044-8512-abcd131c7075	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	250bcce6-6ce6-4c78-aebd-8a22169749a9	\N	44500	D	csv	D|Petty Cash|Individual|Petty Cash - Electricals|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
96c94f29-9e58-46c1-8b30-ed1b3ba03d56	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	250bcce6-6ce6-4c78-aebd-8a22169749a9	\N	362500	D	csv	D|Petty Cash|Individual|Petty Cash - Electricals|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
36b87f95-7b36-4ba5-9afd-081e9a5f9c9d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	250bcce6-6ce6-4c78-aebd-8a22169749a9	\N	26000	D	csv	D|Petty Cash|Individual|Petty Cash - Electricals|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
7d5b725d-9c33-4d7a-8def-3461937538b5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	250bcce6-6ce6-4c78-aebd-8a22169749a9	\N	302900	D	csv	D|Petty Cash|Individual|Petty Cash - Electricals|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b323fa58-5d40-48fb-b9fe-f6811b2b2527	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	250bcce6-6ce6-4c78-aebd-8a22169749a9	\N	15000	D	csv	D|Petty Cash|Individual|Petty Cash - Electricals|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a8e0ccaa-22f3-4286-8346-05297c7a4598	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	250bcce6-6ce6-4c78-aebd-8a22169749a9	\N	177500	D	csv	D|Petty Cash|Individual|Petty Cash - Electricals|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
019ea895-7f72-4fec-a73f-9d121725f5bc	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	9fcfe207-5070-4c4a-a80a-1a542ebbac79	\N	399800	D	csv	D|Petty Cash|Individual|Petty Cash - Hardware|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ed334244-4202-4e22-ba62-254fb77d2bdb	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	9fcfe207-5070-4c4a-a80a-1a542ebbac79	\N	36000	D	csv	D|Petty Cash|Individual|Petty Cash - Hardware|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c9509499-5e6b-4e9e-9214-07b3b4ba43f7	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	9fcfe207-5070-4c4a-a80a-1a542ebbac79	\N	99000	D	csv	D|Petty Cash|Individual|Petty Cash - Hardware|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
bc1b7317-8967-4a22-b05a-b8002972027b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	9fcfe207-5070-4c4a-a80a-1a542ebbac79	\N	480500	D	csv	D|Petty Cash|Individual|Petty Cash - Hardware|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2c5d9857-b714-4caa-9af1-da8b16687044	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	9fcfe207-5070-4c4a-a80a-1a542ebbac79	\N	1512500	D	csv	D|Petty Cash|Individual|Petty Cash - Hardware|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
6bd536b3-ff9e-4977-8f70-2338eafbe42d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	9fcfe207-5070-4c4a-a80a-1a542ebbac79	\N	929500	D	csv	D|Petty Cash|Individual|Petty Cash - Hardware|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
bf80c68d-48d0-43f5-9abd-c10c2ccec914	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	9c90a9f6-69b6-40da-b5ba-04312a168b25	4acc804d-41e2-4c2d-a1bc-8d651c9c3b8e	\N	18000	D	csv	D|Petty Cash|Individual|Petty Cash - Office Supplies|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
85c41d54-86bf-4544-84c4-1155ef791c8f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	07620758-37e2-4597-bc73-79d2e63d1bcc	\N	7558761	D	csv	D|Uncategorized|Individual|Plumbers Salary|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
10cfb712-d341-4376-bfb7-1a2e2f841418	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	07620758-37e2-4597-bc73-79d2e63d1bcc	\N	7558761	D	csv	D|Uncategorized|Individual|Plumbers Salary|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2f9c8d1d-c074-4360-b554-f149253e9224	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	07620758-37e2-4597-bc73-79d2e63d1bcc	\N	7558800	D	csv	D|Uncategorized|Individual|Plumbers Salary|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
dbc8dcb2-f666-4dc5-b8f9-8d025322101d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	07620758-37e2-4597-bc73-79d2e63d1bcc	\N	7640038	D	csv	D|Uncategorized|Individual|Plumbers Salary|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e431c339-1038-4921-a2dc-909c7ee9ec99	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	07620758-37e2-4597-bc73-79d2e63d1bcc	\N	7558824	D	csv	D|Uncategorized|Individual|Plumbers Salary|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
71f94d08-c861-4233-b94d-d6b7e780c265	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	07620758-37e2-4597-bc73-79d2e63d1bcc	\N	7558761	D	csv	D|Uncategorized|Individual|Plumbers Salary|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d84479b2-6a93-4bc4-ae98-7b5a6ab5e9b2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	3368cea7-8e3d-476e-bb78-069d5d61f73a	\N	65000	D	csv	D|Maintenance|Individual|Rental Charges Machinery|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
96202264-06a9-4daf-bb4f-a10bf867e4b8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	3368cea7-8e3d-476e-bb78-069d5d61f73a	\N	65000	D	csv	D|Maintenance|Individual|Rental Charges Machinery|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f3ed64c8-4cc9-464d-a33e-2bab56ee2062	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	19023f6e-bdf7-429a-b00e-a355951e51ec	\N	3666600	D	csv	D|Maintenance|Individual|Repair Work|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
8600eaad-91f9-4ec1-b6dd-3fe807642ef5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	9c90a9f6-69b6-40da-b5ba-04312a168b25	19023f6e-bdf7-429a-b00e-a355951e51ec	\N	3505000	D	csv	D|Maintenance|Individual|Repair Work|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4ae6646e-2f98-4192-bf38-fb131d17767d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	40cb6503-4e1f-4a53-a9a3-9c5380f05794	\N	39	D	csv	D|Uncategorized|Individual|Roundoff|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d4f075ac-4362-4f66-934f-82281df77c0c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	40cb6503-4e1f-4a53-a9a3-9c5380f05794	\N	10	D	csv	D|Uncategorized|Individual|Roundoff|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
12145569-9de7-4e1e-9b77-4c24c85bc9b5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	fa73bf34-8218-4dce-9662-b04c0a2cd4bb	\N	37083217	D	csv	D|Security|Individual|Security Guards Salary|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b20f6245-8606-4875-b309-c763feec176c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	fa73bf34-8218-4dce-9662-b04c0a2cd4bb	\N	38319500	D	csv	D|Security|Individual|Security Guards Salary|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f9f92ed7-7049-49e5-b30d-0f8b8171add6	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	fa73bf34-8218-4dce-9662-b04c0a2cd4bb	\N	37510300	D	csv	D|Security|Individual|Security Guards Salary|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4b39c387-1cf4-4938-8904-8bdd5c48d7ce	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	fa73bf34-8218-4dce-9662-b04c0a2cd4bb	\N	34876730	D	csv	D|Security|Individual|Security Guards Salary|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
01636af3-4239-4c88-ad58-179ea8f3da27	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	fa73bf34-8218-4dce-9662-b04c0a2cd4bb	\N	35934624	D	csv	D|Security|Individual|Security Guards Salary|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
975c56e8-d325-4d4c-aa3f-db9af3d2a8e8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	fa73bf34-8218-4dce-9662-b04c0a2cd4bb	\N	36554138	D	csv	D|Security|Individual|Security Guards Salary|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2deffb09-1ba7-4fd0-936c-9d7919a8d22f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	0b7e0c5b-20e4-40cb-8d00-2efe8e8e1b17	\N	1921779	D	csv	D|Security|Individual|Security Lady Guards Salary|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0af7b594-45e5-4252-b3b9-d185c9a179a8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	0b7e0c5b-20e4-40cb-8d00-2efe8e8e1b17	\N	2206500	D	csv	D|Security|Individual|Security Lady Guards Salary|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
caf22562-7ecf-4918-a471-567610dbaf45	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	0b7e0c5b-20e4-40cb-8d00-2efe8e8e1b17	\N	2206500	D	csv	D|Security|Individual|Security Lady Guards Salary|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
49168c93-6cd2-49e0-856e-801c8a8ea0f8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	0b7e0c5b-20e4-40cb-8d00-2efe8e8e1b17	\N	2206487	D	csv	D|Security|Individual|Security Lady Guards Salary|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ffaff37e-2230-461a-9a1c-3382af9de931	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	0b7e0c5b-20e4-40cb-8d00-2efe8e8e1b17	\N	2206512	D	csv	D|Security|Individual|Security Lady Guards Salary|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0c6269dc-d564-4b24-bba0-43b9b9b0b30f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	0b7e0c5b-20e4-40cb-8d00-2efe8e8e1b17	\N	2133510	D	csv	D|Security|Individual|Security Lady Guards Salary|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a1505d6b-d983-4542-9a84-bc6527ccaf59	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	83e06114-f166-4aca-9dde-d7b2817c2657	\N	5251772	D	csv	D|Security|Individual|Security Supervisor Salary|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
fc012170-3371-4d9b-b5ba-7cdb3bc0ea51	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	83e06114-f166-4aca-9dde-d7b2817c2657	\N	3501200	D	csv	D|Security|Individual|Security Supervisor Salary|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
023d66c6-1540-46b9-8d4b-3a3c423eeeca	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	83e06114-f166-4aca-9dde-d7b2817c2657	\N	5167100	D	csv	D|Security|Individual|Security Supervisor Salary|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
1b608337-69da-47fe-9b4a-d38cc282845e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	83e06114-f166-4aca-9dde-d7b2817c2657	\N	5251772	D	csv	D|Security|Individual|Security Supervisor Salary|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e2ba5127-9b57-47cc-9711-de0cfcbff511	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	83e06114-f166-4aca-9dde-d7b2817c2657	\N	5251792	D	csv	D|Security|Individual|Security Supervisor Salary|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
7ab4136a-e0be-404c-b13c-196a75b946a3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	93856faa-0c1a-4632-b8e2-f821d60e0f51	9c90a9f6-69b6-40da-b5ba-04312a168b25	83e06114-f166-4aca-9dde-d7b2817c2657	\N	5082360	D	csv	D|Security|Individual|Security Supervisor Salary|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0acdf0bb-e911-4401-be24-70b530b2e293	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	e6af2c3c-f36e-4604-8f93-f1cf795b597d	\N	24000000	D	csv	D|Uncategorized|Individual|STP water collection (Sludge Removal)|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
43f4adb9-413d-41c6-adeb-6328c607ca73	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	e6af2c3c-f36e-4604-8f93-f1cf795b597d	\N	20800000	D	csv	D|Uncategorized|Individual|STP water collection (Sludge Removal)|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d2d07082-6ef7-4594-b085-69bb079db9b9	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	e6af2c3c-f36e-4604-8f93-f1cf795b597d	\N	17800000	D	csv	D|Uncategorized|Individual|STP water collection (Sludge Removal)|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
40ed4db9-c162-48bd-96b1-61461fcdf140	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	e6af2c3c-f36e-4604-8f93-f1cf795b597d	\N	10243500	D	csv	D|Uncategorized|Individual|STP water collection (Sludge Removal)|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c81c5e43-e9f1-4819-a579-675ad24c61bd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	e6af2c3c-f36e-4604-8f93-f1cf795b597d	\N	9000000	D	csv	D|Uncategorized|Individual|STP water collection (Sludge Removal)|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
51d3156c-5f3a-4837-bb98-2d215c5c3a01	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	e6af2c3c-f36e-4604-8f93-f1cf795b597d	\N	10400000	D	csv	D|Uncategorized|Individual|STP water collection (Sludge Removal)|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f9f15f10-91f4-44b1-94da-71f9f7da003d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	94b4e1a8-e9ae-4eb8-b816-e1e058bad79c	\N	8155392	D	csv	D|Uncategorized|Individual|STP/WTP Operators Salary|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
118545ec-78d9-40cd-a4d8-cbcc6a4a53b7	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	94b4e1a8-e9ae-4eb8-b816-e1e058bad79c	\N	6771800	D	csv	D|Uncategorized|Individual|STP/WTP Operators Salary|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5fd3e5c4-b41f-4066-963d-c8a68b07cfa8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	94b4e1a8-e9ae-4eb8-b816-e1e058bad79c	\N	6771900	D	csv	D|Uncategorized|Individual|STP/WTP Operators Salary|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
97ceec7a-3735-4848-b6ee-f9b47581cb2e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	94b4e1a8-e9ae-4eb8-b816-e1e058bad79c	\N	6699072	D	csv	D|Uncategorized|Individual|STP/WTP Operators Salary|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
af2873cf-373c-4a42-b8ef-9c5f92fbfbea	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	94b4e1a8-e9ae-4eb8-b816-e1e058bad79c	\N	6691294	D	csv	D|Uncategorized|Individual|STP/WTP Operators Salary|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c96a51ed-975d-4dc9-a814-49feade46992	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	94b4e1a8-e9ae-4eb8-b816-e1e058bad79c	\N	6771888	D	csv	D|Uncategorized|Individual|STP/WTP Operators Salary|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f70572a9-8be9-4c4a-9d35-237dc329724b	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	dad76512-ea9f-4c7c-9fc7-1074385c3ef8	\N	1750000	D	csv	D|Uncategorized|Individual|Swimming Pool Services|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f87653ae-fb17-4671-8380-c7512687f157	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	dad76512-ea9f-4c7c-9fc7-1074385c3ef8	\N	1750000	D	csv	D|Uncategorized|Individual|Swimming Pool Services|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
98ee430d-e91a-4062-a3e9-fe55dad96a6c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	dad76512-ea9f-4c7c-9fc7-1074385c3ef8	\N	1750000	D	csv	D|Uncategorized|Individual|Swimming Pool Services|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
80562900-a37f-4b51-8712-66922473c3cd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	dad76512-ea9f-4c7c-9fc7-1074385c3ef8	\N	1750000	D	csv	D|Uncategorized|Individual|Swimming Pool Services|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5a3d1eb0-dffe-41b3-bed8-a026d22d5af1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	dad76512-ea9f-4c7c-9fc7-1074385c3ef8	\N	1750000	D	csv	D|Uncategorized|Individual|Swimming Pool Services|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
61c04869-2ff0-4e20-9433-87456f6fe9a9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	dad76512-ea9f-4c7c-9fc7-1074385c3ef8	\N	1750000	D	csv	D|Uncategorized|Individual|Swimming Pool Services|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
8527bdb9-904a-4d4b-a586-94f382914779	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	0da66f15-bd25-4665-81ee-7b032efb61e4	\N	8010100	D	csv	D|Uncategorized|Individual|Tools & Stationary|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9179e72b-f76b-4f5f-8816-424f5247d4d8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	0da66f15-bd25-4665-81ee-7b032efb61e4	\N	375100	D	csv	D|Uncategorized|Individual|Tools & Stationary|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
56b259ea-2ec2-4bcc-b2d9-b48ad5d0f361	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	0da66f15-bd25-4665-81ee-7b032efb61e4	\N	5000	D	csv	D|Uncategorized|Individual|Tools & Stationary|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
62aa8731-2a0d-4a67-aade-77c2ff3fb020	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	0da66f15-bd25-4665-81ee-7b032efb61e4	\N	3218600	D	csv	D|Uncategorized|Individual|Tools & Stationary|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e37a7195-cbc6-4d0b-826a-345e071c992e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	0da66f15-bd25-4665-81ee-7b032efb61e4	\N	164100	D	csv	D|Uncategorized|Individual|Tools & Stationary|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
60eb1314-ab96-4f84-84bc-c14dc6be6b2d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	0da66f15-bd25-4665-81ee-7b032efb61e4	\N	1080000	D	csv	D|Uncategorized|Individual|Tools & Stationary|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2b3bcfd4-904c-48be-be6e-17288b1cea4f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	96f762e3-5188-4b38-9054-c0200fc7a873	\N	600000	D	csv	D|Uncategorized|Individual|Walkie Talkies|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b00b7923-bb85-4be5-b5b1-03242bb46ef5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	96f762e3-5188-4b38-9054-c0200fc7a873	\N	600000	D	csv	D|Uncategorized|Individual|Walkie Talkies|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
cc57c0bc-d846-4d91-9521-03444b23804f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	96f762e3-5188-4b38-9054-c0200fc7a873	\N	600000	D	csv	D|Uncategorized|Individual|Walkie Talkies|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2a3acfcd-18ff-46bc-92da-2f793aeeff76	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	96f762e3-5188-4b38-9054-c0200fc7a873	\N	600000	D	csv	D|Uncategorized|Individual|Walkie Talkies|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
fa0ddfb3-7f64-4796-baea-e0c9e832a0a9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	96f762e3-5188-4b38-9054-c0200fc7a873	\N	600000	D	csv	D|Uncategorized|Individual|Walkie Talkies|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
28c23140-ec5d-448a-97d0-82e5ee861398	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	96f762e3-5188-4b38-9054-c0200fc7a873	\N	600000	D	csv	D|Uncategorized|Individual|Walkie Talkies|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
307ee6dc-9eed-4dab-9977-db946f49b5a6	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	c5e4bc3d-022e-4535-b5e6-a00385f6b19a	39394630-c7c3-4a80-924c-45f31a761f88	\N	38239000	D	csv	D|Utilities|Water Supplier|Water Supply|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9ec24d2f-271e-404a-8426-1aa5c8dfe8ca	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	c5e4bc3d-022e-4535-b5e6-a00385f6b19a	39394630-c7c3-4a80-924c-45f31a761f88	\N	38225000	D	csv	D|Utilities|Water Supplier|Water Supply|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
992bf20b-aa0a-45b6-8019-190986d3a89f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	c5e4bc3d-022e-4535-b5e6-a00385f6b19a	39394630-c7c3-4a80-924c-45f31a761f88	\N	35836500	D	csv	D|Utilities|Water Supplier|Water Supply|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
20235b99-6076-4709-9ff2-b3c4e1aa9559	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	c5e4bc3d-022e-4535-b5e6-a00385f6b19a	39394630-c7c3-4a80-924c-45f31a761f88	\N	37369500	D	csv	D|Utilities|Water Supplier|Water Supply|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0a7f9fd4-f54e-4bf9-98e4-8cc2f5a14c73	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	c5e4bc3d-022e-4535-b5e6-a00385f6b19a	39394630-c7c3-4a80-924c-45f31a761f88	\N	37748000	D	csv	D|Utilities|Water Supplier|Water Supply|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ca5f62d1-4e65-4935-b14d-594f93027aaf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	c5e4bc3d-022e-4535-b5e6-a00385f6b19a	39394630-c7c3-4a80-924c-45f31a761f88	\N	45186500	D	csv	D|Utilities|Water Supplier|Water Supply|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
10a85b8d-6f9d-49bb-beef-fa70e66a95dc	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f97ac9c-4b41-4e5d-901e-3f5657a7decc	\N	370000	D	csv	D|Uncategorized|Individual|Water Test Report|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
aefe8cbd-45a2-47f3-a7d8-993f319289db	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f97ac9c-4b41-4e5d-901e-3f5657a7decc	\N	370000	D	csv	D|Uncategorized|Individual|Water Test Report|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a9da2a14-e15c-419c-9a3d-fbb4badec8b5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f97ac9c-4b41-4e5d-901e-3f5657a7decc	\N	370000	D	csv	D|Uncategorized|Individual|Water Test Report|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ccadfd7c-8fb8-4c46-b541-8577e1a473a1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f97ac9c-4b41-4e5d-901e-3f5657a7decc	\N	370000	D	csv	D|Uncategorized|Individual|Water Test Report|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f44db8af-bbf0-410c-9abe-d7a9c5edb14c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	17fb8810-848d-4e53-98bb-0477324e69e4	9c90a9f6-69b6-40da-b5ba-04312a168b25	6f97ac9c-4b41-4e5d-901e-3f5657a7decc	\N	370000	D	csv	D|Uncategorized|Individual|Water Test Report|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
00af120c-2f10-422d-97ee-8e0957c47e6d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	9314eb17-eb68-4961-ba6f-8c6579a271f7	9c90a9f6-69b6-40da-b5ba-04312a168b25	292a92f9-0ad6-42bc-84a7-d6518713415d	\N	500000	C	csv	C|Uncategorized|Individual|Association Fund|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
03aeafaf-27d5-432f-bd47-028ddc56bd17	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	9314eb17-eb68-4961-ba6f-8c6579a271f7	9c90a9f6-69b6-40da-b5ba-04312a168b25	292a92f9-0ad6-42bc-84a7-d6518713415d	\N	370000	C	csv	C|Uncategorized|Individual|Association Fund|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
fad79e64-8fc9-496c-ad88-d446fec8a5a3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	9314eb17-eb68-4961-ba6f-8c6579a271f7	9c90a9f6-69b6-40da-b5ba-04312a168b25	292a92f9-0ad6-42bc-84a7-d6518713415d	\N	1950000	C	csv	C|Uncategorized|Individual|Association Fund|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e7d963cf-e265-4e72-bf2c-fe1817591b64	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	f2bd933b-b093-42ed-9ed2-6e829d10f4e8	\N	280000	C	csv	C|Facility Rental|Residents|AV room|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
45e2ce4f-4c79-4710-b9eb-0e124f32ec90	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	f2bd933b-b093-42ed-9ed2-6e829d10f4e8	\N	350000	C	csv	C|Facility Rental|Residents|AV room|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
be60149a-eb65-483c-92ee-0187d29c1d5f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	f2bd933b-b093-42ed-9ed2-6e829d10f4e8	\N	210000	C	csv	C|Facility Rental|Residents|AV room|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
8b8cbc4a-2e4f-4c36-a185-8327d5c0b309	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	f2bd933b-b093-42ed-9ed2-6e829d10f4e8	\N	280000	C	csv	C|Facility Rental|Residents|AV room|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b8e2fb50-5197-4246-9ed8-40f2b7814953	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	9c90a9f6-69b6-40da-b5ba-04312a168b25	b29d4a92-cc1f-4977-a913-e63c3b75ffd1	\N	112000	C	csv	C|Facility Rental|Individual|Business Center|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
8bf5d495-0a43-4d22-9705-40b8eb6545ab	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	9c90a9f6-69b6-40da-b5ba-04312a168b25	b29d4a92-cc1f-4977-a913-e63c3b75ffd1	\N	108000	C	csv	C|Facility Rental|Individual|Business Center|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
5caedc8c-16db-480a-a48f-daec554ad376	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	9c90a9f6-69b6-40da-b5ba-04312a168b25	b29d4a92-cc1f-4977-a913-e63c3b75ffd1	\N	100000	C	csv	C|Facility Rental|Individual|Business Center|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
39b8bd9c-ac1f-4195-ae39-66f9c2cd1564	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	c84eaccd-a5f8-49b4-af8a-48aadad1cb47	\N	1274040	C	csv	C|Tax|Individual|CGST Output|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ace3d152-9b73-45bf-8229-6bdf903591fe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	c84eaccd-a5f8-49b4-af8a-48aadad1cb47	\N	759200	C	csv	C|Tax|Individual|CGST Output|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ee3014f2-cd53-461f-ad08-892ff8d408ec	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	c84eaccd-a5f8-49b4-af8a-48aadad1cb47	\N	532800	C	csv	C|Tax|Individual|CGST Output|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e7f536c7-4423-40de-9616-e4e44657597c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	c84eaccd-a5f8-49b4-af8a-48aadad1cb47	\N	868000	C	csv	C|Tax|Individual|CGST Output|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ccdf36c2-ffea-4813-aaec-8ecc188596b2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	72eb7aef-a149-4e0a-88ad-0a94a4b5220d	\N	100000	C	csv	C|Penalties|Individual|Common Area Violation|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
15d4da76-6e74-47d1-b14e-6e72dd4e22cc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	72eb7aef-a149-4e0a-88ad-0a94a4b5220d	\N	600000	C	csv	C|Penalties|Individual|Common Area Violation|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
84c6e3d6-7f92-470f-b012-9f07133ac0e8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	80949065-cad3-436e-a1a1-f8ff65634a27	9c90a9f6-69b6-40da-b5ba-04312a168b25	609ff602-cd5d-4650-b20a-6431ecf5cf7c	\N	817900	C	csv	C|Events|Individual|Community Curriculum Activities|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
1d79f6fa-fa68-4291-98e0-4753eb77687e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	9314eb17-eb68-4961-ba6f-8c6579a271f7	9c90a9f6-69b6-40da-b5ba-04312a168b25	faf1fc51-a3b4-4730-8649-fa5faa562001	\N	100000	C	csv	C|Uncategorized|Individual|Fitness Trainers|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c2af2564-2d83-4b0e-8e9d-e66930f55c8f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	9314eb17-eb68-4961-ba6f-8c6579a271f7	9c90a9f6-69b6-40da-b5ba-04312a168b25	faf1fc51-a3b4-4730-8649-fa5faa562001	\N	230400	C	csv	C|Uncategorized|Individual|Fitness Trainers|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d7cbecbd-3306-4336-b8ba-84fc1d404637	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	80949065-cad3-436e-a1a1-f8ff65634a27	9c90a9f6-69b6-40da-b5ba-04312a168b25	651b5f14-6e1a-46c2-844e-9966cef72c20	\N	1600000	C	csv	C|Events|Individual|Flee Market|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
eebc86a3-20cb-4ae0-b78f-aa2be01714d4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	9314eb17-eb68-4961-ba6f-8c6579a271f7	9c90a9f6-69b6-40da-b5ba-04312a168b25	8735ca25-6bad-4075-b40f-5cb5addda6c1	\N	100000	C	csv	C|Uncategorized|Individual|Guest Parking Rent|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
82a0e4fa-1cdc-46e4-b184-6c0e6380932b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	7aeb545b-5236-4a31-863c-5898aabc979d	\N	15172500	C	csv	C|Penalties|Individual|Late Payment Fine|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
fe4e0b04-09a0-42b4-98a1-4649775ed3f7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	7aeb545b-5236-4a31-863c-5898aabc979d	\N	9522500	C	csv	C|Penalties|Individual|Late Payment Fine|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
73ae7b43-46de-42a5-8ad2-39076904e86a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	7aeb545b-5236-4a31-863c-5898aabc979d	\N	6840000	C	csv	C|Penalties|Individual|Late Payment Fine|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e682ea69-9d32-4812-9784-cb4f66b01620	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	7aeb545b-5236-4a31-863c-5898aabc979d	\N	10817500	C	csv	C|Penalties|Individual|Late Payment Fine|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
8a435511-b6ec-4a3d-92ee-e08add71bd8a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	8eee43cb-7057-4998-891a-3b01354c9b41	6a564814-c594-4d74-b07b-c7743587827c	\N	990000	C	csv	C|Advertisement|Advertiser|Lift Advertisement|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e712d1e4-b0de-455c-a4eb-eca18072983b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	8eee43cb-7057-4998-891a-3b01354c9b41	6a564814-c594-4d74-b07b-c7743587827c	\N	550000	C	csv	C|Advertisement|Advertiser|Lift Advertisement|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a580925d-0d24-4426-8ac5-802d45538bd6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	8eee43cb-7057-4998-891a-3b01354c9b41	6a564814-c594-4d74-b07b-c7743587827c	\N	330000	C	csv	C|Advertisement|Advertiser|Lift Advertisement|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
96fe90dc-a22a-474d-8511-6691a2f7855c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	64d03044-5c28-4340-acad-af71754741ff	eea0fea7-ea4a-4c89-b453-bbcd1a1362cc	\N	283327400	C	csv	C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
998faeb2-7c53-465f-9b1f-a3a5d33c10ce	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	64d03044-5c28-4340-acad-af71754741ff	eea0fea7-ea4a-4c89-b453-bbcd1a1362cc	\N	283885405	C	csv	C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9aa0be04-d709-4c20-8379-09f57ff9333d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	64d03044-5c28-4340-acad-af71754741ff	eea0fea7-ea4a-4c89-b453-bbcd1a1362cc	\N	270711506	C	csv	C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
38d2a9ad-92b2-493a-801a-531e21bb896d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	64d03044-5c28-4340-acad-af71754741ff	eea0fea7-ea4a-4c89-b453-bbcd1a1362cc	\N	274879441	C	csv	C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
3dc30b38-1d8a-4855-a788-b89d68752d4a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	9c90a9f6-69b6-40da-b5ba-04312a168b25	f8b1dedc-b0b7-46eb-a4de-27ce4366b3e1	\N	750000	C	csv	C|Move Charges|Individual|Move In/Out (Manual)|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
965210e7-08a3-48f8-81c1-0fd19e9f08a8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	9c90a9f6-69b6-40da-b5ba-04312a168b25	c862e30a-f952-4e65-bc20-e5a5fbb0ed59	\N	3500000	C	csv	C|Move Charges|Individual|Move in/out Charges|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
8855aaa8-4821-4195-bd5f-3da44135acfa	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	9c90a9f6-69b6-40da-b5ba-04312a168b25	c862e30a-f952-4e65-bc20-e5a5fbb0ed59	\N	2000000	C	csv	C|Move Charges|Individual|Move in/out Charges|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a6f3d1b6-0161-4a89-8c43-db346d24109f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	9c90a9f6-69b6-40da-b5ba-04312a168b25	c862e30a-f952-4e65-bc20-e5a5fbb0ed59	\N	3000000	C	csv	C|Move Charges|Individual|Move in/out Charges|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
a89d0219-c051-47d3-9826-9d8176c49925	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	9c90a9f6-69b6-40da-b5ba-04312a168b25	c862e30a-f952-4e65-bc20-e5a5fbb0ed59	\N	500000	C	csv	C|Move Charges|Individual|Move in/out Charges|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
951db92b-7b21-4f78-9912-3a8494b4885a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	0b1df94d-199b-4869-8c63-a80aea052737	\N	1200000	C	csv	C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
28022ad7-abc1-4dbc-a582-2c664d384548	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	0b1df94d-199b-4869-8c63-a80aea052737	\N	2700000	C	csv	C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
3217347e-b335-492b-a8ef-24334d2bbc67	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	0b1df94d-199b-4869-8c63-a80aea052737	\N	2100000	C	csv	C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f251e836-07ed-4bd8-ba38-9d3c4e4f4ed6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	0b1df94d-199b-4869-8c63-a80aea052737	\N	2400000	C	csv	C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
3f3fb14e-9c9e-44bd-8d24-2cb9c84d9f4a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	54b8a0fc-b04c-4cee-828c-75f07a3cd4d5	\N	100000	C	csv	C|Penalties|Individual|Parking Violation|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d1286654-30ab-4094-a660-09814eb61848	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	536ab333-d8ed-4596-a950-f6667b37e7d4	\N	1274040	C	csv	C|Tax|Individual|SGST Output|2026-04	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
85056ff0-b6fa-40f8-bd08-84f03e661bfb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	536ab333-d8ed-4596-a950-f6667b37e7d4	\N	759200	C	csv	C|Tax|Individual|SGST Output|2026-05	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
047fd132-0166-4c0c-a728-d73d1f51732f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	536ab333-d8ed-4596-a950-f6667b37e7d4	\N	532800	C	csv	C|Tax|Individual|SGST Output|2026-06	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
687c9cf4-05a7-4183-b923-cdf3bdc95449	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	536ab333-d8ed-4596-a950-f6667b37e7d4	\N	868000	C	csv	C|Tax|Individual|SGST Output|2026-07	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b7438d04-a1f1-45ae-9abd-9f2ebb255e56	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	f2bd933b-b093-42ed-9ed2-6e829d10f4e8	\N	280000	C	csv	C|Facility Rental|Residents|AV room|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
75e0df34-1b43-4c62-a77f-ddac769b9ada	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	f2bd933b-b093-42ed-9ed2-6e829d10f4e8	\N	280000	C	csv	C|Facility Rental|Residents|AV room|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2fd95736-4cdd-4e31-8ee3-2b4af22d0b17	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	f2bd933b-b093-42ed-9ed2-6e829d10f4e8	\N	280000	C	csv	C|Facility Rental|Residents|AV room|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0fa895ec-fab6-49b8-9204-2ce70fc66160	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	f2bd933b-b093-42ed-9ed2-6e829d10f4e8	\N	140000	C	csv	C|Facility Rental|Residents|AV room|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
9b7bb212-5790-4371-8463-6ae792717747	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	f2bd933b-b093-42ed-9ed2-6e829d10f4e8	\N	280000	C	csv	C|Facility Rental|Residents|AV room|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
65182cfc-918d-4a1c-bc64-3cf666dc0459	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	c84eaccd-a5f8-49b4-af8a-48aadad1cb47	\N	834588	C	csv	C|Tax|Individual|CGST Output|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
84739678-a512-4205-ba96-81952a3a056c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	c84eaccd-a5f8-49b4-af8a-48aadad1cb47	\N	3054006	C	csv	C|Tax|Individual|CGST Output|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b363ea65-efb8-489a-bbc9-0c80cf16f268	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	c84eaccd-a5f8-49b4-af8a-48aadad1cb47	\N	394000	C	csv	C|Tax|Individual|CGST Output|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
08babb1e-999f-40d5-971e-687df0038009	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	c84eaccd-a5f8-49b4-af8a-48aadad1cb47	\N	919900	C	csv	C|Tax|Individual|CGST Output|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
aaf264c6-8685-4127-b4c5-9714dd987ef9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	72eb7aef-a149-4e0a-88ad-0a94a4b5220d	\N	300000	C	csv	C|Penalties|Individual|Common Area Violation|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ae36170f-5329-49fa-bed9-acd8516a0124	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	7aeb545b-5236-4a31-863c-5898aabc979d	\N	2675000	C	csv	C|Penalties|Individual|Late Payment Fine|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
70d12838-642b-4c2a-9c9f-2c41032feffb	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	7aeb545b-5236-4a31-863c-5898aabc979d	\N	4005000	C	csv	C|Penalties|Individual|Late Payment Fine|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d40017e7-2041-46d1-95df-e334c1ec5395	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	7aeb545b-5236-4a31-863c-5898aabc979d	\N	3865000	C	csv	C|Penalties|Individual|Late Payment Fine|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ae966cdc-cff0-4c19-9d0f-eb2c4390ab1e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	7aeb545b-5236-4a31-863c-5898aabc979d	\N	9310000	C	csv	C|Penalties|Individual|Late Payment Fine|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c38cd51c-ee0e-4aee-9250-84fb52de0b43	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	9c90a9f6-69b6-40da-b5ba-04312a168b25	7aeb545b-5236-4a31-863c-5898aabc979d	\N	14787500	C	csv	C|Penalties|Individual|Late Payment Fine|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4a93dfae-7bc5-4e56-85d5-405ecf819c56	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	8eee43cb-7057-4998-891a-3b01354c9b41	6a564814-c594-4d74-b07b-c7743587827c	\N	1540000	C	csv	C|Advertisement|Advertiser|Lift Advertisement|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
43d0d839-788d-44ed-bd96-40575b764e0d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	8eee43cb-7057-4998-891a-3b01354c9b41	6a564814-c594-4d74-b07b-c7743587827c	\N	1100000	C	csv	C|Advertisement|Advertiser|Lift Advertisement|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2d4d8df3-d2bc-48a4-8b76-8aa27f0f3dc5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	8eee43cb-7057-4998-891a-3b01354c9b41	6a564814-c594-4d74-b07b-c7743587827c	\N	400000	C	csv	C|Advertisement|Advertiser|Lift Advertisement|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c631d4c0-6446-488e-bbdf-2b7f623671a5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	64d03044-5c28-4340-acad-af71754741ff	eea0fea7-ea4a-4c89-b453-bbcd1a1362cc	\N	1847000	C	csv	C|Maintenance Collection|Flat Owners|Maintenance Charge|2025-10	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
079cfbb6-fc1f-45ec-881c-1d43d5ead030	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	64d03044-5c28-4340-acad-af71754741ff	eea0fea7-ea4a-4c89-b453-bbcd1a1362cc	\N	155295300	C	csv	C|Maintenance Collection|Flat Owners|Maintenance Charge|2025-11	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
d6ce2f9a-f191-447b-b2eb-b96ab9f4255f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	64d03044-5c28-4340-acad-af71754741ff	eea0fea7-ea4a-4c89-b453-bbcd1a1362cc	\N	305918000	C	csv	C|Maintenance Collection|Flat Owners|Maintenance Charge|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
2186e4f2-1a1d-4253-8f17-b8a6f24f03e8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	64d03044-5c28-4340-acad-af71754741ff	eea0fea7-ea4a-4c89-b453-bbcd1a1362cc	\N	479557282	C	csv	C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
ddeb5643-f52d-4506-82be-4954f9434c85	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	64d03044-5c28-4340-acad-af71754741ff	eea0fea7-ea4a-4c89-b453-bbcd1a1362cc	\N	272195080	C	csv	C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
701dd7b0-9de1-47e6-8bd4-50b73a230e66	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	64d03044-5c28-4340-acad-af71754741ff	eea0fea7-ea4a-4c89-b453-bbcd1a1362cc	\N	274740500	C	csv	C|Maintenance Collection|Flat Owners|Maintenance Charge|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
0cf84f0b-ed33-4e8a-b8fa-2b223e0be4d5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	9c90a9f6-69b6-40da-b5ba-04312a168b25	c862e30a-f952-4e65-bc20-e5a5fbb0ed59	\N	750000	C	csv	C|Move Charges|Individual|Move in/out Charges|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
54483eaf-591d-4acc-839e-812e04a9dabe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	9c90a9f6-69b6-40da-b5ba-04312a168b25	c862e30a-f952-4e65-bc20-e5a5fbb0ed59	\N	750000	C	csv	C|Move Charges|Individual|Move in/out Charges|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
c1c885cf-cde2-4951-b762-b932d9d04b04	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	9c90a9f6-69b6-40da-b5ba-04312a168b25	c862e30a-f952-4e65-bc20-e5a5fbb0ed59	\N	1750000	C	csv	C|Move Charges|Individual|Move in/out Charges|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
7b2173d8-2563-439b-80ce-4cfcb684026e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	9c90a9f6-69b6-40da-b5ba-04312a168b25	c862e30a-f952-4e65-bc20-e5a5fbb0ed59	\N	3750000	C	csv	C|Move Charges|Individual|Move in/out Charges|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f7c1d232-bcaf-4090-931f-f0515eb5786f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	0b1df94d-199b-4869-8c63-a80aea052737	\N	1800000	C	csv	C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
e6d3de95-f954-449d-98e1-d2d18ed140bf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	0b1df94d-199b-4869-8c63-a80aea052737	\N	3300000	C	csv	C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
4a822cf5-0794-4403-88c0-03ff8950391f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	0b1df94d-199b-4869-8c63-a80aea052737	\N	2100000	C	csv	C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
bb0ed83a-63ad-4742-b488-c02d91f76b9e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	0b1df94d-199b-4869-8c63-a80aea052737	\N	2700000	C	csv	C|Facility Rental|Residents|Multipurpose Party Hall/Club House|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b1515891-be9f-4973-8ed3-c6a8a48195bf	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	536ab333-d8ed-4596-a950-f6667b37e7d4	\N	834588	C	csv	C|Tax|Individual|SGST Output|2025-12	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f96e65a2-8575-4931-9196-3c29bf6dada7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	536ab333-d8ed-4596-a950-f6667b37e7d4	\N	3054006	C	csv	C|Tax|Individual|SGST Output|2026-01	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
b6e831d9-3146-4170-a8f5-e83a3e784a7e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	536ab333-d8ed-4596-a950-f6667b37e7d4	\N	394000	C	csv	C|Tax|Individual|SGST Output|2026-02	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
f55533bc-bb66-4b55-950f-c15d81fd22e4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	9c90a9f6-69b6-40da-b5ba-04312a168b25	536ab333-d8ed-4596-a950-f6667b37e7d4	\N	919900	C	csv	C|Tax|Individual|SGST Output|2026-03	\N	\N	2026-08-03 18:50:45.125015+00	2026-08-03 18:50:45.125015+00
1bb99415-592b-4293-8690-8dd2d4c0fc6b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	028048ac-8e65-4b70-b03c-751c27bd88f1	7aed34fa-5183-4fa0-9d58-b64ca8718c0f	\N	93024	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
1516ef03-e89e-4f67-82b5-4da4a570b3fc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	028048ac-8e65-4b70-b03c-751c27bd88f1	7aed34fa-5183-4fa0-9d58-b64ca8718c0f	\N	121482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
8663d4a2-1da0-445f-823c-aba01eda021e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	028048ac-8e65-4b70-b03c-751c27bd88f1	7aed34fa-5183-4fa0-9d58-b64ca8718c0f	\N	121484	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
438edf0e-ac62-4b45-bb73-cd94ddf62ef1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	cbbf60d9-8db1-4fbb-962d-acacf8717b8a	25194c13-114b-4adb-b53b-2836584c8417	\N	6551612	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
41217d1d-3c14-4aa6-9c61-61215d54ee25	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	cbbf60d9-8db1-4fbb-962d-acacf8717b8a	25194c13-114b-4adb-b53b-2836584c8417	\N	2192087	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
10a5dcd9-167e-4fb5-a436-49fb7ee046af	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	cbbf60d9-8db1-4fbb-962d-acacf8717b8a	25194c13-114b-4adb-b53b-2836584c8417	\N	4568625	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a1711d80-e0ba-452b-8558-5b4da8d44bb9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	1dc46aca-330f-452c-98de-41d3391a095e	4f36097f-7c65-4a06-9eea-d26e1202f00b	\N	16815000	D	csv	D|Maintenance|KNND ASSOCIATES PVT LTD|AMC (AC)|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
82858d3b-676a-4c3b-8cd6-db1716b893ab	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	fbd6892d-f6ef-4084-a765-f4f07271f0ba	bd851450-a487-430e-bc45-aa058b81d07c	\N	7720000	D	csv	D|Maintenance|KIRLOSKAR OIL ENGINES LTD|AMC (DG)|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
e34291ec-9482-416c-a40c-3a84f82f72d9	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	22afd4a5-60fd-410b-93a3-9a94f3c4de3c	a21243cd-0470-41d1-b9b6-d241ae2e88bf	\N	18000000	D	csv	D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ba99c814-fdd3-489f-be29-c216cd6a7b14	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	22afd4a5-60fd-410b-93a3-9a94f3c4de3c	a21243cd-0470-41d1-b9b6-d241ae2e88bf	\N	12000000	D	csv	D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c246f655-a7de-4342-8425-cf1c2ce62184	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	22afd4a5-60fd-410b-93a3-9a94f3c4de3c	a21243cd-0470-41d1-b9b6-d241ae2e88bf	\N	3000000	D	csv	D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a09bed48-74d3-4dcd-bd8a-8ed09956bb86	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	b787f534-196a-4914-8172-9563c09b9971	7caa420d-ff54-46b1-b4f6-f9d8cfa28664	df4768bb-916a-40e4-8765-ae27f5749313	\N	10000000	D	csv	D|Professional Services|Professional Consultant|Chartered Accountant|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
bf26bae0-2791-465c-850f-9cf36b300c1f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	77e00431-dd28-4ac2-8141-8e011f73f332	9c90a9f6-69b6-40da-b5ba-04312a168b25	99a60898-dfdc-4567-a511-59454edf2e0e	\N	3383700	D	csv	D|Cleaning|Individual|Debris Disposal|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
9f6d3ace-4420-4080-b0ce-1aa71d5670c4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	77e00431-dd28-4ac2-8141-8e011f73f332	9c90a9f6-69b6-40da-b5ba-04312a168b25	99a60898-dfdc-4567-a511-59454edf2e0e	\N	600000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
28ba603f-415c-4a03-9ed8-890b37e19dc8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	fbd6892d-f6ef-4084-a765-f4f07271f0ba	64de8c54-401a-495f-8a0a-72df06f57e08	\N	2323475	D	csv	D|Maintenance|KIRLOSKAR OIL ENGINES LTD|DG Service|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
e6979481-46a7-4578-b107-4835507a4632	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a24668ec-6f8f-44cd-91d6-ce80712dc801	a49db09b-5ffe-4f02-bc4f-6696ec2fdd9e	\N	4000000	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2bd0c8fc-a5b1-456d-9057-ec597639f501	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a24668ec-6f8f-44cd-91d6-ce80712dc801	a49db09b-5ffe-4f02-bc4f-6696ec2fdd9e	\N	3654800	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
84a52738-f37b-4f1d-9654-99d0f9e72452	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a24668ec-6f8f-44cd-91d6-ce80712dc801	a49db09b-5ffe-4f02-bc4f-6696ec2fdd9e	\N	3654800	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c6abe7c5-513e-4f11-a6ad-6b97cd71c91f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fd467141-e9d7-4cc4-80ce-a9a43306d9f1	\N	7558761	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3d2725cd-78c8-4dd4-800d-eed290f2d8d2	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fd467141-e9d7-4cc4-80ce-a9a43306d9f1	\N	7558761	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
28214bfb-7c61-4465-80bf-d9aaddb03293	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fd467141-e9d7-4cc4-80ce-a9a43306d9f1	\N	7477500	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
83ef47c5-81fa-432e-9fce-5647fbbc81ed	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fd467141-e9d7-4cc4-80ce-a9a43306d9f1	\N	7558761	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c633e2d9-1d18-4a05-9dea-195969de2a6a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fd467141-e9d7-4cc4-80ce-a9a43306d9f1	\N	7558824	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ee7efa31-6170-408b-ad37-9e510b3876a4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fd467141-e9d7-4cc4-80ce-a9a43306d9f1	\N	7477484	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3dd152f4-c43e-4d8d-86b9-29e71dd04635	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	17e3edf0-ee73-490d-9f8f-0e1caf97f357	\N	5546000	D	csv	D|Facility Management|EXOZEN|Facility Manager|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ae040251-f6d0-48c5-8cf6-ad6b3af11e19	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	17e3edf0-ee73-490d-9f8f-0e1caf97f357	\N	5942100	D	csv	D|Facility Management|EXOZEN|Facility Manager|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3c42890e-98c8-4f19-8e1c-e227ce74eff5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	17e3edf0-ee73-490d-9f8f-0e1caf97f357	\N	5942111	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ed3ec15a-40a1-42d5-87f3-114356fc5e57	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	17e3edf0-ee73-490d-9f8f-0e1caf97f357	\N	5942111	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
5e43e733-f14d-486e-a458-de41680cc99a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	17e3edf0-ee73-490d-9f8f-0e1caf97f357	\N	5942111	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
1a135c35-fb5e-4a9a-8c37-9ddf951eece4	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	901ea9fa-0af0-460e-9d86-2dcee8d84c11	7a47a22e-83eb-4972-8c5c-73ba28c8f053	\N	1400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
50deaabc-462d-4d3e-976f-ab4c8dc14f37	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	901ea9fa-0af0-460e-9d86-2dcee8d84c11	7a47a22e-83eb-4972-8c5c-73ba28c8f053	\N	1400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
01d66f99-d293-4b02-883e-18de86d4b82e	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	901ea9fa-0af0-460e-9d86-2dcee8d84c11	7a47a22e-83eb-4972-8c5c-73ba28c8f053	\N	1400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3b9a62c8-3906-4721-b4fc-fb1ae601e442	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	901ea9fa-0af0-460e-9d86-2dcee8d84c11	7a47a22e-83eb-4972-8c5c-73ba28c8f053	\N	1400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ccedd75c-239c-4574-bc1b-c74b2a73f93c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	901ea9fa-0af0-460e-9d86-2dcee8d84c11	7a47a22e-83eb-4972-8c5c-73ba28c8f053	\N	1400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6bd8b0d4-c48f-4290-89e1-4e9c2703814b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	901ea9fa-0af0-460e-9d86-2dcee8d84c11	7a47a22e-83eb-4972-8c5c-73ba28c8f053	\N	1400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
11c538c1-4828-4660-8430-718576025aac	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	779b185d-df34-42c1-afc5-a63fa9aefe39	ae69e209-3e8d-4b41-acf5-cd0fb301768b	\N	2276500	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
76330961-03cd-4ed9-96f7-a5b8d5f8084f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	779b185d-df34-42c1-afc5-a63fa9aefe39	ae69e209-3e8d-4b41-acf5-cd0fb301768b	\N	130000	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
7c6ee6f1-5094-4365-81a4-bb96edb85111	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	779b185d-df34-42c1-afc5-a63fa9aefe39	ae69e209-3e8d-4b41-acf5-cd0fb301768b	\N	701500	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
e26e25e1-56fc-48ba-80d7-f9c89300f30e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	779b185d-df34-42c1-afc5-a63fa9aefe39	ae69e209-3e8d-4b41-acf5-cd0fb301768b	\N	888000	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c0f6a860-3c89-46a9-a04a-b0f40f0c0976	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	779b185d-df34-42c1-afc5-a63fa9aefe39	ae69e209-3e8d-4b41-acf5-cd0fb301768b	\N	2336000	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
70414532-8b39-4a69-9cf7-769fa45c4fd5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	0154ab9b-a334-4202-b3e3-0cc488d8a173	\N	9377100	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c5782e13-0c2e-4ea0-b0b1-14583ccf2bc9	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	0154ab9b-a334-4202-b3e3-0cc488d8a173	\N	9433000	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
8a0dc9d2-c4a2-4090-997a-4aeac3bd8047	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	0154ab9b-a334-4202-b3e3-0cc488d8a173	\N	9004500	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
17639883-c89e-41e6-88d3-a1b0249e1869	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	0154ab9b-a334-4202-b3e3-0cc488d8a173	\N	9625500	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
eba0e63a-5a92-4a10-a42f-062fb4c2c97a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	0154ab9b-a334-4202-b3e3-0cc488d8a173	\N	8869266	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d9bbfe50-87c4-4ae3-a68e-8febe0ce566a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	0154ab9b-a334-4202-b3e3-0cc488d8a173	\N	8383500	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f721eb4f-8b3f-4fa1-a00f-f6fe8c633792	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6399189f-103c-4276-bb0d-5406bb69dccd	\N	1959864	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d51421a1-58c3-4775-9830-ff130e22bb0e	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6399189f-103c-4276-bb0d-5406bb69dccd	\N	2531500	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c63d9580-7c60-4da1-9ebb-6288847d81fa	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6399189f-103c-4276-bb0d-5406bb69dccd	\N	2531500	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
5ac2115e-7f53-4917-9e05-442b00dd8796	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6399189f-103c-4276-bb0d-5406bb69dccd	\N	2531491	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2111ce13-745f-409d-8df0-07ba5aefe3fd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6399189f-103c-4276-bb0d-5406bb69dccd	\N	2441097	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d91e6d76-6b0d-43a2-b105-5b3fd2c7746b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6399189f-103c-4276-bb0d-5406bb69dccd	\N	2449830	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ccc2fcfc-b22d-4a5c-a45d-b4a40f27bee8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	b6210fbe-04f8-46ae-a805-04ba39aac620	\N	2868492	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
0be9e2be-9713-4a17-916d-5d4d449274df	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	b6210fbe-04f8-46ae-a805-04ba39aac620	\N	2581600	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
5f0decea-0fdd-47d2-aaad-87d2e6459ea5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	b6210fbe-04f8-46ae-a805-04ba39aac620	\N	2683400	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
667cd956-2699-400e-9388-670ccdec1d32	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	b6210fbe-04f8-46ae-a805-04ba39aac620	\N	2683428	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d388962f-8e5e-4abf-94ce-284cfcfa1afe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	b6210fbe-04f8-46ae-a805-04ba39aac620	\N	2561150	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
e61c4f4c-79b4-4701-ad89-cf1ec2ae2b80	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	b6210fbe-04f8-46ae-a805-04ba39aac620	\N	2683428	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
471f2afd-4fbb-4aa6-8145-d761eed6b760	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	15aebff2-4ce7-468d-9943-a56bdc6b41b0	\N	6854000	D	csv	D|Facility Management|EXOZEN|HK Materials|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
bb706262-5895-4dbd-9769-6687beea5503	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	15aebff2-4ce7-468d-9943-a56bdc6b41b0	\N	437000	D	csv	D|Facility Management|EXOZEN|HK Materials|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3854fd7d-16ee-4d07-b575-6807dd4e5cb1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	15aebff2-4ce7-468d-9943-a56bdc6b41b0	\N	805000	D	csv	D|Facility Management|EXOZEN|HK Materials|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
51bfef00-264c-41a3-8cc3-db6220531bc5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	15aebff2-4ce7-468d-9943-a56bdc6b41b0	\N	65000	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d3c9593b-e0a7-44b3-a187-ff320a29efee	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	15aebff2-4ce7-468d-9943-a56bdc6b41b0	\N	545000	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c713ef03-f6b1-4680-8e7e-c81b36ed349b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	15aebff2-4ce7-468d-9943-a56bdc6b41b0	\N	2839000	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ce39b344-9db1-4b66-9a98-050dbbbd1462	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	7d217302-1aaa-406f-b1d1-506b00867c57	\N	27035700	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a81d83f8-c933-4907-80a5-255576da8e15	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	7d217302-1aaa-406f-b1d1-506b00867c57	\N	29287600	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a719ce6c-42d6-4182-b7ed-a4a46ed5f137	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	7d217302-1aaa-406f-b1d1-506b00867c57	\N	31498600	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
bfd3454e-c54c-4dfc-8bf5-2d0ea800afcd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	7d217302-1aaa-406f-b1d1-506b00867c57	\N	30972670	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b9f7a2d7-bbe4-4a40-87d3-226afd353d2a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	7d217302-1aaa-406f-b1d1-506b00867c57	\N	30603100	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
717dc998-f4f2-4e30-9104-0d2753418275	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	7d217302-1aaa-406f-b1d1-506b00867c57	\N	30212963	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ffab18f3-df21-4f90-878e-956479afabea	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	42f2a7c7-8451-4ed7-a4dc-a742af568ea9	\N	2420511	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
1989d278-7bbc-467b-86ec-31d4b407078d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	42f2a7c7-8451-4ed7-a4dc-a742af568ea9	\N	2420511	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
107c143d-aaa3-46c1-9140-eba0802d5643	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	42f2a7c7-8451-4ed7-a4dc-a742af568ea9	\N	2186300	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
84facd7e-8582-4e0f-a38a-2a3df0a960f8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	42f2a7c7-8451-4ed7-a4dc-a742af568ea9	\N	2420511	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ec7fa2ec-2ed4-4bb6-b013-839db73b4849	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	42f2a7c7-8451-4ed7-a4dc-a742af568ea9	\N	2420488	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3bf9e158-e6ac-40b1-b8c3-46e95c77d65d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	42f2a7c7-8451-4ed7-a4dc-a742af568ea9	\N	2342430	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f4f99e3f-578d-487a-be93-c56cde7da59a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	b787f534-196a-4914-8172-9563c09b9971	7caa420d-ff54-46b1-b4f6-f9d8cfa28664	d2d5c61d-d96d-4aa5-960f-4cc654cc9088	\N	1500000	D	csv	D|Professional Services|Professional Consultant|Legal Consultant|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d84c63b8-7622-4a79-b3f9-c53ae50051c1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ab27e102-8b6f-4ae5-a239-a969acb75f2c	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
42ba86f5-ba13-4139-917f-12463f0b4b45	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ab27e102-8b6f-4ae5-a239-a969acb75f2c	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
0de73e61-7477-4888-bfcc-6df20ac8270d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ab27e102-8b6f-4ae5-a239-a969acb75f2c	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
8943cafc-54f4-46e1-add3-24f2625e2813	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ab27e102-8b6f-4ae5-a239-a969acb75f2c	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
da0c582c-1b9a-4286-ac65-4fc77ca2c401	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ab27e102-8b6f-4ae5-a239-a969acb75f2c	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
31e30726-e911-4ee9-8c71-8d6160989a17	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ab27e102-8b6f-4ae5-a239-a969acb75f2c	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c38af7dd-0568-4991-97fe-5f03f52ba03d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6e1307a9-89f6-4b4c-a6e0-1af4dcc86a7f	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
240bfc22-d1e0-443c-a0a3-240526633a33	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6e1307a9-89f6-4b4c-a6e0-1af4dcc86a7f	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
cf157f2a-4e59-414c-8dfe-155b670d9df1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6e1307a9-89f6-4b4c-a6e0-1af4dcc86a7f	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b13d6316-5e5a-4fed-8eb2-86a6a867e359	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6e1307a9-89f6-4b4c-a6e0-1af4dcc86a7f	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
22d02724-d04c-4b82-b5a9-33f629fef46c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6e1307a9-89f6-4b4c-a6e0-1af4dcc86a7f	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d279fa18-8626-4049-8fb3-2b27f2e2711b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6e1307a9-89f6-4b4c-a6e0-1af4dcc86a7f	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
cce76e56-96fb-4ab7-a68c-4335173193ce	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	b8f7aa92-ae3d-4368-bd0a-20158f010f42	\N	649500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2185b1e2-cdcc-4abe-ba67-08d365d928c3	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	b8f7aa92-ae3d-4368-bd0a-20158f010f42	\N	667500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f13bb2c2-0802-4326-bd6f-cd38f310c637	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	b8f7aa92-ae3d-4368-bd0a-20158f010f42	\N	1176300	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d8e4d3dc-956d-43f7-8e7f-07a860c64a05	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	b8f7aa92-ae3d-4368-bd0a-20158f010f42	\N	2130950	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3a4ac57d-e772-45e7-807b-8e4d5e888a73	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	b8f7aa92-ae3d-4368-bd0a-20158f010f42	\N	775141	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
1ace9941-f623-4f12-8115-378756d95723	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	b8f7aa92-ae3d-4368-bd0a-20158f010f42	\N	644383	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a505f30d-000d-43d2-a0e9-02f4c3cd67d5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1f6f324a-4ef5-46f5-b01b-85a6478be869	775bb244-e65f-4219-9cae-c0d30fe5d7c1	171230d0-e4a0-4f43-a9f1-8722b197b244	\N	16500	D	csv	D|Events|Petty Cash|Petty Cash - Cultural Event|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d994d6cc-0166-4ed0-ae30-b2e37fea083d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1f6f324a-4ef5-46f5-b01b-85a6478be869	775bb244-e65f-4219-9cae-c0d30fe5d7c1	171230d0-e4a0-4f43-a9f1-8722b197b244	\N	21000	D	csv	D|Events|Petty Cash|Petty Cash - Cultural Event|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
48aabf29-fb58-4f54-92f5-b1d315cce20a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1f6f324a-4ef5-46f5-b01b-85a6478be869	775bb244-e65f-4219-9cae-c0d30fe5d7c1	171230d0-e4a0-4f43-a9f1-8722b197b244	\N	5108300	D	csv	D|Events|Petty Cash|Petty Cash - Cultural Event|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2a182c0b-8901-4708-a027-a8f2baca85eb	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	d2a54861-e809-4686-9e71-edb0c1473f38	\N	44500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
7ab34885-7ca5-47f7-bade-79662968bec3	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	d2a54861-e809-4686-9e71-edb0c1473f38	\N	362500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
bbef0643-041a-4649-95e8-4272ca3f0e19	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	d2a54861-e809-4686-9e71-edb0c1473f38	\N	26000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
13f957b5-12f7-4239-b4d2-246ccacff6b8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	d2a54861-e809-4686-9e71-edb0c1473f38	\N	302900	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
50a9163f-9b93-4d31-a080-16aea5af5f5e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	d2a54861-e809-4686-9e71-edb0c1473f38	\N	15000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2b452051-dff4-4c15-b0de-3a1b14b3fa0c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	d2a54861-e809-4686-9e71-edb0c1473f38	\N	177500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
36f4de5e-6308-4bae-a851-4a96dba47501	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	a02d48cd-d8b9-4968-9faf-efc89faf8649	\N	399800	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
492f3ae6-a056-4840-8074-635b056f5713	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	a02d48cd-d8b9-4968-9faf-efc89faf8649	\N	36000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ad8d0c47-65d1-4b57-9d3e-9cafe67511ad	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	a02d48cd-d8b9-4968-9faf-efc89faf8649	\N	99000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
459c4f66-3382-44c6-95b5-385b5424970a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	a02d48cd-d8b9-4968-9faf-efc89faf8649	\N	480500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
58b08c00-a908-4f39-8880-5a61983d9473	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	a02d48cd-d8b9-4968-9faf-efc89faf8649	\N	1512500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
9f834fc0-6b4f-407d-8530-b49c2dc362a8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	a02d48cd-d8b9-4968-9faf-efc89faf8649	\N	929500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
4032cef0-2f5d-44a0-9d3a-e14ef36c7f19	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	26737f2a-61e1-46bf-ac31-1c589f42f110	\N	18000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Office Supplies|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2904e8c8-9441-4801-9839-eb2755e77ff6	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	569d3bba-4e5b-40e9-a4c4-0decdf6fbf1c	\N	7558761	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
fc50c500-a079-4891-acb3-5fba5921ce68	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	569d3bba-4e5b-40e9-a4c4-0decdf6fbf1c	\N	7558761	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
14ca9b96-c932-4477-b730-2738a4d91666	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	569d3bba-4e5b-40e9-a4c4-0decdf6fbf1c	\N	7558800	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
7819a7ed-18f9-41c3-b509-bb2d9a765e97	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	569d3bba-4e5b-40e9-a4c4-0decdf6fbf1c	\N	7640038	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ed52afd8-cd24-400f-bbd7-bc88229c2bb0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	569d3bba-4e5b-40e9-a4c4-0decdf6fbf1c	\N	7558824	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
cb73f344-7657-4b0a-a9a3-fc94be6b6be8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	569d3bba-4e5b-40e9-a4c4-0decdf6fbf1c	\N	7558761	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
5c517be5-97f8-4151-b8aa-251dec2e32b0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	76101a05-62de-4032-ab51-9d8027d50e09	\N	65000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a18f4ba2-61ee-4f3d-842c-a97719e196cd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	76101a05-62de-4032-ab51-9d8027d50e09	\N	65000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
0e97d9ce-bd20-4094-9ee0-e47e338509ee	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ba2fe8ae-63af-421f-a4f1-c7616cd0ce1a	\N	3666600	D	csv	D|Facility Management|EXOZEN|Repair Work|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b6186c07-012e-4d18-b360-11250018228e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ba2fe8ae-63af-421f-a4f1-c7616cd0ce1a	\N	3505000	D	csv	D|Facility Management|EXOZEN|Repair Work|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
264bcae9-758b-4026-a1e3-2139912fa56d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	386378b4-b93e-48e7-8094-b667d71d83b9	2424e6ed-93ab-42c6-807d-b50119107dd1	92f7557d-43ba-482f-91db-498c8ec00dfc	\N	39	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f9c4737a-f08f-4715-85a1-4df9f3de7b29	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	386378b4-b93e-48e7-8094-b667d71d83b9	2424e6ed-93ab-42c6-807d-b50119107dd1	92f7557d-43ba-482f-91db-498c8ec00dfc	\N	10	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
65d8ba3e-e40e-4485-946a-eae1776206c8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cec5c851-047c-48d3-bcc9-a8de4f8a6f29	\N	37083217	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d3c37ae1-1bd1-4e6e-90c7-fcf68a5d0bfd	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cec5c851-047c-48d3-bcc9-a8de4f8a6f29	\N	38319500	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
904d12f4-74d7-415f-9041-43c103f855d2	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cec5c851-047c-48d3-bcc9-a8de4f8a6f29	\N	37510300	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c411f4fc-79fd-4be5-a587-464ca36f5053	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cec5c851-047c-48d3-bcc9-a8de4f8a6f29	\N	34876730	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c2cac034-73e7-4879-81c0-2624772e7d75	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cec5c851-047c-48d3-bcc9-a8de4f8a6f29	\N	35934624	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f13bcbd3-1802-47d0-ba15-c6419b26418a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cec5c851-047c-48d3-bcc9-a8de4f8a6f29	\N	36554138	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a1f921fe-ee2a-4913-8eb4-2530ca00a72f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	4cabdad4-9c6a-49f0-91ed-00084755209c	\N	1921779	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
861c0303-aec6-4c5c-92f2-e7c83453e925	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	4cabdad4-9c6a-49f0-91ed-00084755209c	\N	2206500	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d78ef8d9-836f-4ae9-8419-03cce0b57623	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	4cabdad4-9c6a-49f0-91ed-00084755209c	\N	2206500	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6015a62c-1848-4340-866b-69af622be1dd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	4cabdad4-9c6a-49f0-91ed-00084755209c	\N	2206487	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ad79d98a-8d38-4ab3-bb0e-fa8888bfcb43	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	4cabdad4-9c6a-49f0-91ed-00084755209c	\N	2206512	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6391030a-d0da-4f9d-ae73-f715d198ea5b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	4cabdad4-9c6a-49f0-91ed-00084755209c	\N	2133510	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
44bb3438-6657-4905-bdd7-921c55393646	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ae84eea-f24a-4436-b55a-fbef65d02d12	\N	5251772	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a1d8a65e-806d-4036-aaa0-e8a15fe0c892	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ae84eea-f24a-4436-b55a-fbef65d02d12	\N	3501200	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
7363f576-6a43-4e51-a9bb-70356db0bae2	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ae84eea-f24a-4436-b55a-fbef65d02d12	\N	5167100	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
1bf691dc-701f-4867-ad1d-9f3ba03dc6bb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ae84eea-f24a-4436-b55a-fbef65d02d12	\N	5251772	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
640a0c4e-5527-4f8a-8827-d9e1faa9662e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ae84eea-f24a-4436-b55a-fbef65d02d12	\N	5251792	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
32dd19a6-0e36-45e5-a245-71fc8e0a5058	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ae84eea-f24a-4436-b55a-fbef65d02d12	\N	5082360	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
fd9afaac-6962-449b-834d-f2a055d7b73f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f951fe7b-e843-4130-8d21-994a29a24a1f	f0785724-ff84-495b-9936-1df07bad8393	4a096871-f440-49b1-b116-f97db7d1ddfb	\N	24000000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
789b2a52-7f2d-4f4b-a066-03d900e40796	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f951fe7b-e843-4130-8d21-994a29a24a1f	f0785724-ff84-495b-9936-1df07bad8393	4a096871-f440-49b1-b116-f97db7d1ddfb	\N	20800000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3d44e5d6-8d0f-4b30-8698-ecc1f5ec2c21	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f951fe7b-e843-4130-8d21-994a29a24a1f	f0785724-ff84-495b-9936-1df07bad8393	4a096871-f440-49b1-b116-f97db7d1ddfb	\N	17800000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
8a360868-1dfc-46bd-873f-3d1e17fe86f8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f951fe7b-e843-4130-8d21-994a29a24a1f	f0785724-ff84-495b-9936-1df07bad8393	4a096871-f440-49b1-b116-f97db7d1ddfb	\N	10243500	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6271bcde-8091-4f06-9306-8d53bbfbd83d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f951fe7b-e843-4130-8d21-994a29a24a1f	f0785724-ff84-495b-9936-1df07bad8393	4a096871-f440-49b1-b116-f97db7d1ddfb	\N	9000000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b2b34255-986f-4d4b-b17e-b3f9cb0b386e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f951fe7b-e843-4130-8d21-994a29a24a1f	f0785724-ff84-495b-9936-1df07bad8393	4a096871-f440-49b1-b116-f97db7d1ddfb	\N	10400000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
1471c388-8a3e-470d-bcfe-52dcaaab87b2	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6532478b-f681-40fa-b255-a5d2e4eab70f	\N	8155392	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
64ddd180-2703-4d33-84e0-811aadeb72e1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6532478b-f681-40fa-b255-a5d2e4eab70f	\N	6771800	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
89bdff23-43a9-488f-af7e-38add929c6f3	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6532478b-f681-40fa-b255-a5d2e4eab70f	\N	6771900	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
acae8d3b-62d5-48bc-8ecf-179748492ddb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6532478b-f681-40fa-b255-a5d2e4eab70f	\N	6699072	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
98e2336c-1e7f-4b42-92ca-0663324af249	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6532478b-f681-40fa-b255-a5d2e4eab70f	\N	6691294	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6d3641c6-a316-482a-815b-b059738709da	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6532478b-f681-40fa-b255-a5d2e4eab70f	\N	6771888	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6bf8f141-f6aa-47d8-8561-680628cbe445	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fb9a69dc-1f08-42be-9309-dffc2998eeaa	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b9728813-7f4f-47fe-88cc-f35d9fc1ca04	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fb9a69dc-1f08-42be-9309-dffc2998eeaa	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c2eb58ba-19a4-44f4-b87f-95e021ffa1b1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fb9a69dc-1f08-42be-9309-dffc2998eeaa	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
0fa2948a-86a3-4a8c-bed9-4de555f6a3ed	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fb9a69dc-1f08-42be-9309-dffc2998eeaa	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c103360a-2b5f-4215-aad2-a72fa0be80f2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fb9a69dc-1f08-42be-9309-dffc2998eeaa	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d4dd8457-5dbd-408c-8a7d-6444fb37cd7f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fb9a69dc-1f08-42be-9309-dffc2998eeaa	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
94949977-f817-4068-a040-9ad987317612	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	2c5949ed-2e11-425b-b7d1-cf6d1a1961c6	\N	8010100	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
32a9164a-51da-4f5c-90ea-a204af1777ff	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	2c5949ed-2e11-425b-b7d1-cf6d1a1961c6	\N	375100	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
bf4c9d22-03a1-44ed-96a4-e28169364d61	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	2c5949ed-2e11-425b-b7d1-cf6d1a1961c6	\N	5000	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b69e646e-a6ed-4017-a049-a08866a22849	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	2c5949ed-2e11-425b-b7d1-cf6d1a1961c6	\N	3218600	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
80bce7ac-6499-4c67-9e24-9220b080ec88	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	2c5949ed-2e11-425b-b7d1-cf6d1a1961c6	\N	164100	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
10223c50-3ebf-4ac2-8a7e-fc1f9d96acac	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	2c5949ed-2e11-425b-b7d1-cf6d1a1961c6	\N	1080000	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d8f9facb-d483-47c0-96ee-ae3dc01d978a	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cf71d692-2f96-4b9b-b9b6-43cbefd94619	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b815a813-924a-4c13-bdb7-46fa5facfe6e	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cf71d692-2f96-4b9b-b9b6-43cbefd94619	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
26b5696b-d3ed-402d-b756-6be1e85b6af9	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cf71d692-2f96-4b9b-b9b6-43cbefd94619	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2eb1c851-bf8f-4f82-808d-225e05c42673	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cf71d692-2f96-4b9b-b9b6-43cbefd94619	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
606c30af-3eef-4eaf-b328-36aa6ef6d404	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cf71d692-2f96-4b9b-b9b6-43cbefd94619	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b02abc58-eb36-4f20-b861-bfffa7ffa7cd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cf71d692-2f96-4b9b-b9b6-43cbefd94619	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f33325b3-43a0-4bd3-8c08-b2e4ef78fb4e	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a01aa921-5c35-4867-872d-1ed121e91875	6e3d465d-e7c7-4356-b5f0-131a8e5106d4	\N	38239000	D	csv	D|Utilities|BSN Water Supply|Water Supply|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2a5c6718-24ff-4cb2-88c2-359d60a95adb	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a01aa921-5c35-4867-872d-1ed121e91875	6e3d465d-e7c7-4356-b5f0-131a8e5106d4	\N	38225000	D	csv	D|Utilities|BSN Water Supply|Water Supply|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
931b4b42-ecb4-476a-ab83-f7253e68a6c4	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a01aa921-5c35-4867-872d-1ed121e91875	6e3d465d-e7c7-4356-b5f0-131a8e5106d4	\N	35836500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6174e17d-f740-47d4-8252-35e22344f33b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a01aa921-5c35-4867-872d-1ed121e91875	6e3d465d-e7c7-4356-b5f0-131a8e5106d4	\N	37369500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a73eff23-75d2-42fd-bea2-463aec1069bf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a01aa921-5c35-4867-872d-1ed121e91875	6e3d465d-e7c7-4356-b5f0-131a8e5106d4	\N	37748000	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
41475a0b-cb83-472a-bb42-9092925e06ae	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a01aa921-5c35-4867-872d-1ed121e91875	6e3d465d-e7c7-4356-b5f0-131a8e5106d4	\N	45186500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a7e66f85-5656-4b25-b99a-9442f4df4821	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ea7ddc8-c4b1-40b4-95b6-0161f9b9214d	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
53bcf717-3064-4008-9d17-b0313ba505c7	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ea7ddc8-c4b1-40b4-95b6-0161f9b9214d	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
960c98b9-4d4b-49a7-8c6c-21d410380b37	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ea7ddc8-c4b1-40b4-95b6-0161f9b9214d	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
e1ca2390-77f2-44c8-b8b6-1e96e11744d5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ea7ddc8-c4b1-40b4-95b6-0161f9b9214d	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
8890d33c-624c-43b9-8bd2-3cf982ec2191	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ea7ddc8-c4b1-40b4-95b6-0161f9b9214d	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
bd8fd147-086a-40bb-ac73-d6a88d6e7600	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	028048ac-8e65-4b70-b03c-751c27bd88f1	7aed34fa-5183-4fa0-9d58-b64ca8718c0f	\N	121482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a1b3e649-6828-44bc-80a2-06243fe85aac	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	028048ac-8e65-4b70-b03c-751c27bd88f1	7aed34fa-5183-4fa0-9d58-b64ca8718c0f	\N	141482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b376ff51-3088-4730-9738-e704e4dc0317	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	028048ac-8e65-4b70-b03c-751c27bd88f1	7aed34fa-5183-4fa0-9d58-b64ca8718c0f	\N	142898	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ea7f862a-141d-4280-b0d5-71e4cb1a2644	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	028048ac-8e65-4b70-b03c-751c27bd88f1	7aed34fa-5183-4fa0-9d58-b64ca8718c0f	\N	141482	D	csv	D|Utilities|Airtel Postpaid|Airtel Postpaid Connection|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
fd1ba985-9cad-4477-99b5-00573f9d89cf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	cbbf60d9-8db1-4fbb-962d-acacf8717b8a	25194c13-114b-4adb-b53b-2836584c8417	\N	6104900	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6e335092-4dc9-45fd-aecb-86564da0d424	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	cbbf60d9-8db1-4fbb-962d-acacf8717b8a	25194c13-114b-4adb-b53b-2836584c8417	\N	759036	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6b0e79d2-923f-40c9-bd79-f2edfc7a681b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	cbbf60d9-8db1-4fbb-962d-acacf8717b8a	25194c13-114b-4adb-b53b-2836584c8417	\N	1201834	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ccd82bdd-8982-498f-96a1-b279f2b46c85	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	cbbf60d9-8db1-4fbb-962d-acacf8717b8a	25194c13-114b-4adb-b53b-2836584c8417	\N	445504	D	csv	D|Office Supplies|Amazon CG Boulevard RWA|Amazon Purchase|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
25cd4df5-59bd-4996-a75c-f147216f7ad1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	22afd4a5-60fd-410b-93a3-9a94f3c4de3c	a21243cd-0470-41d1-b9b6-d241ae2e88bf	\N	3000000	D	csv	D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
dc3e31f0-3761-4b6a-afe0-f38b1d6e7186	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	22afd4a5-60fd-410b-93a3-9a94f3c4de3c	a21243cd-0470-41d1-b9b6-d241ae2e88bf	\N	15000000	D	csv	D|Maintenance|JOHNSON LIFTS Pvt Ltd|AMC (Lift)|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
41a95ca6-467b-4dbb-9a1d-477aae728f79	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	63e3c2e3-04de-43f2-8b09-0c77d525658e	\N	5500000	D	csv	D|Facility Management|EXOZEN|Annual Compliance Expense|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
8e093d1a-789a-45d5-92a8-b8b3cfd5fcec	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	77e00431-dd28-4ac2-8141-8e011f73f332	9c90a9f6-69b6-40da-b5ba-04312a168b25	99a60898-dfdc-4567-a511-59454edf2e0e	\N	900000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6c12a080-fca0-4b16-8c80-cd4b35eea940	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	77e00431-dd28-4ac2-8141-8e011f73f332	9c90a9f6-69b6-40da-b5ba-04312a168b25	99a60898-dfdc-4567-a511-59454edf2e0e	\N	1930000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
caa823b4-2fa7-4a60-96a9-7360f8a320a8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	77e00431-dd28-4ac2-8141-8e011f73f332	9c90a9f6-69b6-40da-b5ba-04312a168b25	99a60898-dfdc-4567-a511-59454edf2e0e	\N	2040000	D	csv	D|Cleaning|Individual|Debris Disposal|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
46d58acd-e0e2-451d-97b8-656bfca23b87	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f9f65ae9-1306-46e5-b7ed-a9f0fdf7e327	fbd6892d-f6ef-4084-a765-f4f07271f0ba	64de8c54-401a-495f-8a0a-72df06f57e08	\N	1287627	D	csv	D|Maintenance|KIRLOSKAR OIL ENGINES LTD|DG Service|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
5c5db8c6-fc22-4f9b-9208-7a24e374101a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a24668ec-6f8f-44cd-91d6-ce80712dc801	a49db09b-5ffe-4f02-bc4f-6696ec2fdd9e	\N	9140100	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
8f0c0147-e6e1-434f-baae-bdb92352e2d9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a24668ec-6f8f-44cd-91d6-ce80712dc801	a49db09b-5ffe-4f02-bc4f-6696ec2fdd9e	\N	5482200	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
89c82cde-7c44-41ac-8833-ec99bdc90e40	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a24668ec-6f8f-44cd-91d6-ce80712dc801	a49db09b-5ffe-4f02-bc4f-6696ec2fdd9e	\N	5978400	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d7be8c63-58f3-4d9c-bce8-26948b7149aa	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a24668ec-6f8f-44cd-91d6-ce80712dc801	a49db09b-5ffe-4f02-bc4f-6696ec2fdd9e	\N	5978400	D	csv	D|Utilities|Sai Krupa Petroleum|Diesel|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
bc578c2c-6624-444e-902a-1a4a1e59699f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fd467141-e9d7-4cc4-80ce-a9a43306d9f1	\N	7558830	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c81c21cc-0efe-4bb6-b9e1-31e9a6d44e21	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fd467141-e9d7-4cc4-80ce-a9a43306d9f1	\N	8290254	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
eb78644d-78f1-47be-baad-fe935b602cdb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fd467141-e9d7-4cc4-80ce-a9a43306d9f1	\N	8650661	D	csv	D|Facility Management|EXOZEN|Electricians Salary|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
383a5c54-43e3-41e6-b91e-ecf37878fbf0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	17e3edf0-ee73-490d-9f8f-0e1caf97f357	\N	5942100	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
55930c47-95d2-4182-8232-8df89def191c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	17e3edf0-ee73-490d-9f8f-0e1caf97f357	\N	5942111	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d251354b-ba23-4691-b5bc-c78c8102c1a9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	17e3edf0-ee73-490d-9f8f-0e1caf97f357	\N	5942100	D	csv	D|Facility Management|EXOZEN|Facility Manager|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6a527482-20d5-4a21-9ded-dd372d80ee35	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	901ea9fa-0af0-460e-9d86-2dcee8d84c11	7a47a22e-83eb-4972-8c5c-73ba28c8f053	\N	1400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a05695e4-1391-4021-a59b-9a2e8d375b4d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	901ea9fa-0af0-460e-9d86-2dcee8d84c11	7a47a22e-83eb-4972-8c5c-73ba28c8f053	\N	2400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
4bf298b6-0401-442e-b855-dba939e446a1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5253d1ba-f944-4641-b6e8-bb6280e088c1	901ea9fa-0af0-460e-9d86-2dcee8d84c11	7a47a22e-83eb-4972-8c5c-73ba28c8f053	\N	2400000	D	csv	D|Housekeeping|Sewa Waste Management|Garbage removal|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
be07d252-158e-4834-b634-1f8797777ffb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	779b185d-df34-42c1-afc5-a63fa9aefe39	ae69e209-3e8d-4b41-acf5-cd0fb301768b	\N	2028000	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2d4eca5b-e7a4-459a-b8da-9b07fe63fe55	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	779b185d-df34-42c1-afc5-a63fa9aefe39	ae69e209-3e8d-4b41-acf5-cd0fb301768b	\N	13000	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f1b7d60f-f671-42b3-803b-dedc5c66870e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	60fdea52-667e-4553-aa66-a429cbe2e89b	779b185d-df34-42c1-afc5-a63fa9aefe39	ae69e209-3e8d-4b41-acf5-cd0fb301768b	\N	149100	D	csv	D|Gardening|Kavitha Enterprises|Garden Tools|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
0c1580d1-798e-400d-8961-0300e2562b2c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	0154ab9b-a334-4202-b3e3-0cc488d8a173	\N	8342100	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
7133d538-1e76-41b0-99c6-b862f3b67aae	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	0154ab9b-a334-4202-b3e3-0cc488d8a173	\N	8756100	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f92c61ef-9db5-4276-a7fb-110854e8d09e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	0154ab9b-a334-4202-b3e3-0cc488d8a173	\N	8534610	D	csv	D|Facility Management|EXOZEN|Gardeners Salary|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
dcc7b558-ec0f-41cb-8bcd-b4c7017ea36f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6399189f-103c-4276-bb0d-5406bb69dccd	\N	2447107	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b5793572-7390-42a4-bc0f-811eada2ecd1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6399189f-103c-4276-bb0d-5406bb69dccd	\N	2368169	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
840dea5a-1993-47eb-9a48-6581420a2531	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6399189f-103c-4276-bb0d-5406bb69dccd	\N	2362724	D	csv	D|Facility Management|EXOZEN|Gardening Supervisor Salary|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
cd57680e-3e24-4758-b9d1-9290eb7c597d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	b6210fbe-04f8-46ae-a805-04ba39aac620	\N	2294808	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
db813bd6-75bd-4bf8-8407-ac5ecbfc99f3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	b6210fbe-04f8-46ae-a805-04ba39aac620	\N	2775960	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6cc1c51c-7d61-4519-9d1b-195e62c809c7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	b6210fbe-04f8-46ae-a805-04ba39aac620	\N	2486042	D	csv	D|Facility Management|EXOZEN|Help Desk Salary|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
039a24a9-128f-4f62-bde9-d0dd479eedee	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	15aebff2-4ce7-468d-9943-a56bdc6b41b0	\N	4531700	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
94d31a23-f55a-4048-948c-9c3035f4a77e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	15aebff2-4ce7-468d-9943-a56bdc6b41b0	\N	3485760	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
4e6fca31-24e0-43a4-b899-15b6e224c583	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	15aebff2-4ce7-468d-9943-a56bdc6b41b0	\N	57500	D	csv	D|Facility Management|EXOZEN|HK Materials|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
028bdb07-2a49-4a05-a559-0b1250b8215e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	7d217302-1aaa-406f-b1d1-506b00867c57	\N	23671704	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
364fb2bb-1ea6-4a0f-bb20-7b22a5e0ed62	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	7d217302-1aaa-406f-b1d1-506b00867c57	\N	31381743	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2d84d8bc-f5ce-44b2-a84b-b79031cf00c4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	7d217302-1aaa-406f-b1d1-506b00867c57	\N	32307045	D	csv	D|Facility Management|EXOZEN|House Keeping Janitor Salary|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ed38f235-77ca-4957-a3e1-527e202f1f73	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	42f2a7c7-8451-4ed7-a4dc-a742af568ea9	\N	2420409	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
e36e743b-bfc1-44cd-b967-fba32d8300d5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	42f2a7c7-8451-4ed7-a4dc-a742af568ea9	\N	1639701	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
724faee7-7a74-4789-8ad7-d652129fff80	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	42f2a7c7-8451-4ed7-a4dc-a742af568ea9	\N	2339807	D	csv	D|Facility Management|EXOZEN|Housekeeping Supervisor Salary|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
09c49675-aec3-4d51-8792-8d907291a0c8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ab27e102-8b6f-4ae5-a239-a969acb75f2c	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
0c558737-f256-4cf4-aebe-ef3c23d4b230	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ab27e102-8b6f-4ae5-a239-a969acb75f2c	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c0b0151c-0b3b-46fd-89d0-e0e84db0bef7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ab27e102-8b6f-4ae5-a239-a969acb75f2c	\N	9000000	D	csv	D|Facility Management|EXOZEN|Management Fee|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
390f858e-c0d6-4213-bd8e-7878ef699013	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	924f84dd-13be-48d8-8114-48d341344f20	\N	200000	D	csv	D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f723e049-eac1-4d52-b96a-e84e963aec91	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	924f84dd-13be-48d8-8114-48d341344f20	\N	5269400	D	csv	D|Office Supplies|Petty Cash|One Time Operational Procurement|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c27b82ce-91ee-4d1b-8a77-cf85685f8a7f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6e1307a9-89f6-4b4c-a6e0-1af4dcc86a7f	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
197423bb-f498-408f-bb61-c6b8a6add826	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6e1307a9-89f6-4b4c-a6e0-1af4dcc86a7f	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
52df3587-c4f3-442f-a1aa-b026f181efc8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6e1307a9-89f6-4b4c-a6e0-1af4dcc86a7f	\N	2100000	D	csv	D|Facility Management|EXOZEN|Pest Control Services|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
0bc4fb08-640d-4abf-84da-206a2bbc345b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	b8f7aa92-ae3d-4368-bd0a-20158f010f42	\N	1568300	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f8ae3c8a-9cb3-4b79-8af5-d52dad4cef8a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	b8f7aa92-ae3d-4368-bd0a-20158f010f42	\N	2053800	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
75f37b43-2d36-4db3-96f2-8878919e721a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	b8f7aa92-ae3d-4368-bd0a-20158f010f42	\N	2960000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
df56b3e3-2205-4e3a-b5ba-df3b9b93b5a8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	b8f7aa92-ae3d-4368-bd0a-20158f010f42	\N	1471200	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Consumables|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
05966abb-8cc7-4658-80dc-8cadd453617d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	d2a54861-e809-4686-9e71-edb0c1473f38	\N	29500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
59b85973-118c-4e44-9b22-9ca8b93775a5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	d2a54861-e809-4686-9e71-edb0c1473f38	\N	648700	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
8045e65b-e9e6-4281-9284-fbebc0610037	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	d2a54861-e809-4686-9e71-edb0c1473f38	\N	500000	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
c29fe228-159a-434d-adcb-963489cd9635	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	d2a54861-e809-4686-9e71-edb0c1473f38	\N	44400	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Electricals|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ae14a390-f997-48b9-b895-84cd50fbd217	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	a02d48cd-d8b9-4968-9faf-efc89faf8649	\N	75500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6e43bb4d-aaf4-44d7-b0b0-67675831eb1b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	a02d48cd-d8b9-4968-9faf-efc89faf8649	\N	1891700	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f1e6e2a0-8e4e-4957-b7b5-a6a3aa8f8056	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	a02d48cd-d8b9-4968-9faf-efc89faf8649	\N	536500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3edc6689-502e-432e-a5d8-eb3e5f0de753	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	1e20c166-0399-4b6e-aa16-3ce316ae5979	775bb244-e65f-4219-9cae-c0d30fe5d7c1	a02d48cd-d8b9-4968-9faf-efc89faf8649	\N	101500	D	csv	D|Petty Cash|Petty Cash|Petty Cash - Hardware|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f3175918-45dd-4643-a481-3990283ce4ad	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	569d3bba-4e5b-40e9-a4c4-0decdf6fbf1c	\N	7558830	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ceacc7d6-120f-4ee0-a40b-1f856201f7d5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	569d3bba-4e5b-40e9-a4c4-0decdf6fbf1c	\N	8696639	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6dcab515-9241-4939-a188-959a292a3f69	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	569d3bba-4e5b-40e9-a4c4-0decdf6fbf1c	\N	8566674	D	csv	D|Facility Management|EXOZEN|Plumbers Salary|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
68733931-64f1-4469-8027-f6adc0c9b103	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	76101a05-62de-4032-ab51-9d8027d50e09	\N	65000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
05a87004-a975-41ea-aa84-464f7d15ac40	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	76101a05-62de-4032-ab51-9d8027d50e09	\N	665000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
1fd0fa8d-e924-48e5-b3c5-d7d7e8ec8e73	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	76101a05-62de-4032-ab51-9d8027d50e09	\N	65000	D	csv	D|Facility Management|EXOZEN|Rental Charges Machinery|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
dfcfc291-5e36-49cc-9f44-3c5b9e56e588	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ba2fe8ae-63af-421f-a4f1-c7616cd0ce1a	\N	1733400	D	csv	D|Facility Management|EXOZEN|Repair Work|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
84637e21-a8f0-4f51-8ede-533e5ba46627	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	ba2fe8ae-63af-421f-a4f1-c7616cd0ce1a	\N	800000	D	csv	D|Facility Management|EXOZEN|Repair Work|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ecc09a31-9845-4bfe-8376-06076756584f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	386378b4-b93e-48e7-8094-b667d71d83b9	2424e6ed-93ab-42c6-807d-b50119107dd1	92f7557d-43ba-482f-91db-498c8ec00dfc	\N	41	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
cf4b40ab-165c-40e3-b00e-6b20185a575b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	386378b4-b93e-48e7-8094-b667d71d83b9	2424e6ed-93ab-42c6-807d-b50119107dd1	92f7557d-43ba-482f-91db-498c8ec00dfc	\N	21	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
22579416-e2e6-499b-931a-f058e732f0b0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	386378b4-b93e-48e7-8094-b667d71d83b9	2424e6ed-93ab-42c6-807d-b50119107dd1	92f7557d-43ba-482f-91db-498c8ec00dfc	\N	10	D	csv	D|Accounting Adjustments|System Adjustment|Roundoff|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ce82dfd7-1032-485e-bed8-cc2c20d47680	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cec5c851-047c-48d3-bcc9-a8de4f8a6f29	\N	36113050	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
4ad1b1e6-d50a-4613-b194-6404a0d456f8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cec5c851-047c-48d3-bcc9-a8de4f8a6f29	\N	37367925	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a584b846-98dc-4ee4-becb-80d16023cd5f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cec5c851-047c-48d3-bcc9-a8de4f8a6f29	\N	37584050	D	csv	D|Facility Management|EXOZEN|Security Guards Salary|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
33359e93-04c1-4b3f-8ddd-b21896179e74	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	4cabdad4-9c6a-49f0-91ed-00084755209c	\N	2206500	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b809b445-7ccc-48c3-9122-251865c550e4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	4cabdad4-9c6a-49f0-91ed-00084755209c	\N	2206487	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
abae1636-d91c-4143-ad92-5f296bbbf06d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	4cabdad4-9c6a-49f0-91ed-00084755209c	\N	2132950	D	csv	D|Facility Management|EXOZEN|Security Lady Guards Salary|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
e5b8be02-b6f7-40f4-ac07-c68548bba5ae	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ae84eea-f24a-4436-b55a-fbef65d02d12	\N	5164270	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
7a6e4bcc-d9f8-458f-ae96-4011512f06bf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ae84eea-f24a-4436-b55a-fbef65d02d12	\N	5421184	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b77de1be-8403-45ac-85a0-07750090375e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ae84eea-f24a-4436-b55a-fbef65d02d12	\N	5251800	D	csv	D|Facility Management|EXOZEN|Security Supervisor Salary|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a28275ed-2190-4364-bcb2-ba3b08fc8e17	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f951fe7b-e843-4130-8d21-994a29a24a1f	f0785724-ff84-495b-9936-1df07bad8393	4a096871-f440-49b1-b116-f97db7d1ddfb	\N	8600000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
cc8e5d7b-433e-42f0-815e-bb6b77951a0f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f951fe7b-e843-4130-8d21-994a29a24a1f	f0785724-ff84-495b-9936-1df07bad8393	4a096871-f440-49b1-b116-f97db7d1ddfb	\N	9400000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
956a24bd-10d4-467f-913d-5aeb6a5686c9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	f951fe7b-e843-4130-8d21-994a29a24a1f	f0785724-ff84-495b-9936-1df07bad8393	4a096871-f440-49b1-b116-f97db7d1ddfb	\N	11800000	D	csv	D|Water Treatment|Sapthagiri Cleaner|STP water collection (Sludge Removal)|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
fedd5888-d102-41d2-87af-45f87b3de958	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6532478b-f681-40fa-b255-a5d2e4eab70f	\N	6771870	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
8e756c26-e6c8-428c-8cd3-55824910537b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6532478b-f681-40fa-b255-a5d2e4eab70f	\N	7063152	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3e53f157-8324-40d0-9d6b-5bb4c188cde7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	6532478b-f681-40fa-b255-a5d2e4eab70f	\N	7599543	D	csv	D|Facility Management|EXOZEN|STP/WTP Operators Salary|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
33fe595f-9673-4893-bfa5-3fcd8c3cf25b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fb9a69dc-1f08-42be-9309-dffc2998eeaa	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
0e64ab1f-b971-4e76-96f7-cb809af4ab0a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fb9a69dc-1f08-42be-9309-dffc2998eeaa	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
786f123f-32e2-452c-b30c-8b1146e633c4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	fb9a69dc-1f08-42be-9309-dffc2998eeaa	\N	1750000	D	csv	D|Facility Management|EXOZEN|Swimming Pool Services|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
9f1fa9b7-de97-4dd2-abb6-701ebb9a09b4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	2a41cdd4-c92d-45e8-ac6e-1dff91a1e37a	\N	6300000	D	csv	D|Facility Management|EXOZEN|Tank Cleaning Charges|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ae0dd1bf-99f6-4f58-abf9-90e76919d44c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	2c5949ed-2e11-425b-b7d1-cf6d1a1961c6	\N	903200	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d2cd950c-08ed-41ce-a440-b34116e5fb4f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	2c5949ed-2e11-425b-b7d1-cf6d1a1961c6	\N	74000	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
36566df3-6ba6-4b26-b253-5a70d3eb0a39	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	d898a0ee-ea3e-4a39-bae0-59f5fcd66978	775bb244-e65f-4219-9cae-c0d30fe5d7c1	2c5949ed-2e11-425b-b7d1-cf6d1a1961c6	\N	10500	D	csv	D|Office Supplies|Petty Cash|Tools & Stationary|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2db26b36-f74f-4848-ab34-18a8c552f5f0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cf71d692-2f96-4b9b-b9b6-43cbefd94619	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
cdfb2e11-0fc7-4bbe-9688-fb6eb3226dec	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	cf71d692-2f96-4b9b-b9b6-43cbefd94619	\N	600000	D	csv	D|Facility Management|EXOZEN|Walkie Talkies|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f7b20f98-1cca-4899-af03-34c04c28f156	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a01aa921-5c35-4867-872d-1ed121e91875	6e3d465d-e7c7-4356-b5f0-131a8e5106d4	\N	46581500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b9385710-775f-4163-88a2-0a589cad50a8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a01aa921-5c35-4867-872d-1ed121e91875	6e3d465d-e7c7-4356-b5f0-131a8e5106d4	\N	47899500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f0836d7c-3622-4ed9-9647-6c1e4024ee20	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	cc7452d1-7de7-4c2b-89c0-53fe88a38060	a01aa921-5c35-4867-872d-1ed121e91875	6e3d465d-e7c7-4356-b5f0-131a8e5106d4	\N	51577500	D	csv	D|Utilities|BSN Water Supply|Water Supply|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d394c0f1-1324-4427-a4e5-a78df21dda0d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ea7ddc8-c4b1-40b4-95b6-0161f9b9214d	\N	620000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
deb9a920-752d-486e-8db9-d7dcbb328057	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ea7ddc8-c4b1-40b4-95b6-0161f9b9214d	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
dc5428b2-d996-4342-b6d2-67531fc9781c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	2af7724b-5dfe-40e6-88e2-88db1981ecb2	5826db79-e049-42ec-b928-0a7447b894b4	d210622b-72cf-4da8-91ff-8ba0b3d19a56	8ea7ddc8-c4b1-40b4-95b6-0161f9b9214d	\N	370000	D	csv	D|Facility Management|EXOZEN|Water Test Report|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
04086827-ab67-43b9-a278-f9e012847ed1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	18ef50a3-c7e6-4598-b2cf-5e75c727113d	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	386d1b4e-16c3-4a0f-98b8-0f329db2c3db	\N	500000	C	csv	C|Community Contributions|Residents|Association Fund|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
852c71df-e01d-4e0a-8db4-b43b89804bc2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	18ef50a3-c7e6-4598-b2cf-5e75c727113d	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	386d1b4e-16c3-4a0f-98b8-0f329db2c3db	\N	370000	C	csv	C|Community Contributions|Residents|Association Fund|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b2962154-6553-4456-9d01-8af785d53d1e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	18ef50a3-c7e6-4598-b2cf-5e75c727113d	c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	386d1b4e-16c3-4a0f-98b8-0f329db2c3db	\N	1950000	C	csv	C|Community Contributions|Residents|Association Fund|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
5b55fbd1-1674-4efa-9b62-c1ccad26230b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	40483a2a-b24d-4dff-b6bb-b93cc7764b25	\N	280000	C	csv	C|Facility Rental|Amenities|AV room|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
9027d3f4-e072-482f-96fb-e1e9faeac33e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	40483a2a-b24d-4dff-b6bb-b93cc7764b25	\N	350000	C	csv	C|Facility Rental|Amenities|AV room|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6905a3f8-637e-4b72-86c9-7c3c6a540b37	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	40483a2a-b24d-4dff-b6bb-b93cc7764b25	\N	210000	C	csv	C|Facility Rental|Amenities|AV room|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
36cdc594-2722-48e5-a5b9-dc83b1615ed3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	40483a2a-b24d-4dff-b6bb-b93cc7764b25	\N	280000	C	csv	C|Facility Rental|Amenities|AV room|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ea615a19-56d6-4679-962e-00fbad207616	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	09f02d8d-bcd9-44df-884e-6b28fe3b953c	\N	112000	C	csv	C|Facility Rental|Amenities|Business Center|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
af736a41-543b-478c-8c27-945a119844c6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	09f02d8d-bcd9-44df-884e-6b28fe3b953c	\N	108000	C	csv	C|Facility Rental|Amenities|Business Center|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
7646e4e8-8627-4177-afcb-2d7f4f6132e7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	09f02d8d-bcd9-44df-884e-6b28fe3b953c	\N	100000	C	csv	C|Facility Rental|Amenities|Business Center|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
09033497-b89f-4d39-954a-077fe51cd33b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	88b0d502-b86a-493a-a407-60792ab5b5a5	\N	1274040	C	csv	C|Tax|Tax Collection|CGST Output|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
74511050-d487-4a16-a517-8ea644d81bf0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	88b0d502-b86a-493a-a407-60792ab5b5a5	\N	759200	C	csv	C|Tax|Tax Collection|CGST Output|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
1881799a-f7d3-48ac-9fce-b4172e185afb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	88b0d502-b86a-493a-a407-60792ab5b5a5	\N	532800	C	csv	C|Tax|Tax Collection|CGST Output|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
7696063e-ccd0-485e-8f21-c7449c21babc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	88b0d502-b86a-493a-a407-60792ab5b5a5	\N	868000	C	csv	C|Tax|Tax Collection|CGST Output|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b6402967-9765-4e54-85dc-215c8e7bd499	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	2eac0b3b-7c95-4cd6-986e-9bb25da41be4	\N	100000	C	csv	C|Penalties|Resident Penalties|Common Area Violation|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
fab413d3-aed5-4205-b69a-3d6f085ed4b2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	2eac0b3b-7c95-4cd6-986e-9bb25da41be4	\N	600000	C	csv	C|Penalties|Resident Penalties|Common Area Violation|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
74c54d24-ff29-43b8-be94-6b2ac32195a4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	80949065-cad3-436e-a1a1-f8ff65634a27	6c6cf6ec-d41b-456a-9777-5943fa201c20	59883a3b-c53e-4b8a-b97d-0421c8c617ed	\N	817900	C	csv	C|Events|Community Events|Community Curriculum Activities|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d61dfd44-3b08-4f82-bda3-4665b3f83f27	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ca57194d-2453-4138-a962-bd15e95b15f5	2a8c8086-0441-4b00-b71d-3b1094319c9b	07840cae-30e8-4b60-987c-2eb483e45a9f	\N	100000	C	csv	C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3c926711-25b0-4c33-be9a-6e6e9a3da43e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ca57194d-2453-4138-a962-bd15e95b15f5	2a8c8086-0441-4b00-b71d-3b1094319c9b	07840cae-30e8-4b60-987c-2eb483e45a9f	\N	230400	C	csv	C|Recreation & Wellness|Wellness Programs|Fitness Trainers|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f076e1e6-2c9c-4c48-a661-8462a42a32b9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	80949065-cad3-436e-a1a1-f8ff65634a27	6c6cf6ec-d41b-456a-9777-5943fa201c20	0948b577-08d4-4f21-a32e-2c6668d03ce8	\N	1600000	C	csv	C|Events|Community Events|Flee Market|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
8d9f6a20-17d1-41c7-97d3-84511b28b4a9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	91bf7cbb-d70a-4a93-9116-8884a92f8968	83a2e6a9-991c-498e-8563-7cf076e45662	eda93ebb-1353-4934-8db8-adb01c904f64	\N	100000	C	csv	C|Parking Revenue|Parking Services|Guest Parking Rent|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
479f1cb4-22a5-4126-8a49-49cfb39a6c2e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	cf33e309-e6e7-4545-80e6-b7f4427427bb	\N	15172500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
67e9e2e4-d8c1-4702-9c8e-4b594b7d2530	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	cf33e309-e6e7-4545-80e6-b7f4427427bb	\N	9522500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
ff3d5f14-40e8-418b-bbdb-2846df26dffe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	cf33e309-e6e7-4545-80e6-b7f4427427bb	\N	6840000	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
812015b3-e353-455b-b1f6-8fd06b52517d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	cf33e309-e6e7-4545-80e6-b7f4427427bb	\N	10817500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
8e24a34e-a2fc-4b76-ad27-5ffc3901f4a7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	1708d96b-116e-46fb-ad8b-e8b1ff7f9534	18d5abfd-d4b4-4fc4-93a2-085c7bf2dc99	\N	990000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
83cd7509-cbe7-4040-9b41-5c18b125b7c7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	1708d96b-116e-46fb-ad8b-e8b1ff7f9534	18d5abfd-d4b4-4fc4-93a2-085c7bf2dc99	\N	550000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3b149133-163a-488f-b8cd-dc94ad779fda	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	1708d96b-116e-46fb-ad8b-e8b1ff7f9534	18d5abfd-d4b4-4fc4-93a2-085c7bf2dc99	\N	330000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
bb5b097b-16df-4b27-b628-40186f66c35e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	38cc7598-50ed-424e-90f8-83cbd976e33d	295896d7-f8e7-411f-ac4d-17d785d7bda1	\N	283327400	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b9a10ac2-18d6-4c64-8a9b-0e3dba140050	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	38cc7598-50ed-424e-90f8-83cbd976e33d	295896d7-f8e7-411f-ac4d-17d785d7bda1	\N	283885405	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
f8791c61-9c24-433e-80d5-36814d60fdb1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	38cc7598-50ed-424e-90f8-83cbd976e33d	295896d7-f8e7-411f-ac4d-17d785d7bda1	\N	270711506	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
693bd51f-e33b-40d3-9a69-46ed35b08305	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	38cc7598-50ed-424e-90f8-83cbd976e33d	295896d7-f8e7-411f-ac4d-17d785d7bda1	\N	274879441	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6c9fe5cb-1d7d-4fa9-bef3-78dd0c704623	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	7b5c1342-3a72-4331-a90e-684007adeb9e	f55203c8-f4fd-4b9a-b6a3-075e4458294f	\N	750000	C	csv	C|Move Charges|Resident Services|Move In/Out (Manual)|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
4a8d2c2a-ae89-4a52-9c31-453d8bc10c86	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	7b5c1342-3a72-4331-a90e-684007adeb9e	36812135-b2dd-4bab-85a0-8124121a594e	\N	3500000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6198eeab-98fe-4666-9905-78d229107c50	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	7b5c1342-3a72-4331-a90e-684007adeb9e	36812135-b2dd-4bab-85a0-8124121a594e	\N	2000000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
fb42aec3-68a3-4703-b11b-029dadf64b52	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	7b5c1342-3a72-4331-a90e-684007adeb9e	36812135-b2dd-4bab-85a0-8124121a594e	\N	3000000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
384f6c77-0c29-4ec8-927b-2a8b4bfbf042	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	7b5c1342-3a72-4331-a90e-684007adeb9e	36812135-b2dd-4bab-85a0-8124121a594e	\N	500000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6bcc1d56-fdc5-4ee8-9991-0afccbeb6ada	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	aba3d4f9-35b9-4695-85fd-28cb653e8e06	\N	1200000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d8eb72ae-f256-4002-ab93-86ef49c98b66	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	aba3d4f9-35b9-4695-85fd-28cb653e8e06	\N	2700000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6f805e41-bb4c-4940-88f5-c436d1577823	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	aba3d4f9-35b9-4695-85fd-28cb653e8e06	\N	2100000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
48a6aba7-e200-41b4-ac2d-6853d42b6844	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	aba3d4f9-35b9-4695-85fd-28cb653e8e06	\N	2400000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3a72434f-9d8b-48ce-b619-8746bccbe852	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	5b6ac997-ddcb-4e2a-bcbf-328db3416c25	\N	100000	C	csv	C|Penalties|Resident Penalties|Parking Violation|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2e5df10b-1ce9-40c6-9bc9-e8e8248eab8f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	2026-04-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	f6122417-b832-4e34-b7e6-ef9cdf3eda83	\N	1274040	C	csv	C|Tax|Tax Collection|SGST Output|2026-04	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
402cccaa-2d7a-4f34-9cb3-f92e3b4ecc46	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	2026-05-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	f6122417-b832-4e34-b7e6-ef9cdf3eda83	\N	759200	C	csv	C|Tax|Tax Collection|SGST Output|2026-05	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
0faa301e-1361-4bda-a229-bbebef9728ef	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	2026-06-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	f6122417-b832-4e34-b7e6-ef9cdf3eda83	\N	532800	C	csv	C|Tax|Tax Collection|SGST Output|2026-06	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a4ba1c40-b0e4-4f20-9b06-a359655eb129	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	2026-07-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	f6122417-b832-4e34-b7e6-ef9cdf3eda83	\N	868000	C	csv	C|Tax|Tax Collection|SGST Output|2026-07	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
4623364c-8830-4441-9212-d27482338c9c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	40483a2a-b24d-4dff-b6bb-b93cc7764b25	\N	280000	C	csv	C|Facility Rental|Amenities|AV room|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
1816875c-5caf-490c-9ab0-316dfb828e30	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	40483a2a-b24d-4dff-b6bb-b93cc7764b25	\N	280000	C	csv	C|Facility Rental|Amenities|AV room|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
5673c5df-803e-4784-8869-d713692f1f58	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	40483a2a-b24d-4dff-b6bb-b93cc7764b25	\N	280000	C	csv	C|Facility Rental|Amenities|AV room|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
54699e98-b716-4ad4-a287-f0f7d6e2898d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	40483a2a-b24d-4dff-b6bb-b93cc7764b25	\N	140000	C	csv	C|Facility Rental|Amenities|AV room|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
bc657ae7-46dd-4161-bb03-7986b28d485f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	40483a2a-b24d-4dff-b6bb-b93cc7764b25	\N	280000	C	csv	C|Facility Rental|Amenities|AV room|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
4222bb46-de76-4a4d-a9ac-511f2ddc3bdd	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	88b0d502-b86a-493a-a407-60792ab5b5a5	\N	834588	C	csv	C|Tax|Tax Collection|CGST Output|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a43e40e0-847f-4b42-b577-c9d90ff494c8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	88b0d502-b86a-493a-a407-60792ab5b5a5	\N	3054006	C	csv	C|Tax|Tax Collection|CGST Output|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
0f0b33dd-3d47-4e9a-900c-5e72882259b3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	88b0d502-b86a-493a-a407-60792ab5b5a5	\N	394000	C	csv	C|Tax|Tax Collection|CGST Output|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
8cdffdc3-7386-418d-b5a8-f9cb576488a8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	88b0d502-b86a-493a-a407-60792ab5b5a5	\N	919900	C	csv	C|Tax|Tax Collection|CGST Output|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
af5a58a8-fc10-4623-9b20-007a37b15b4e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	2eac0b3b-7c95-4cd6-986e-9bb25da41be4	\N	300000	C	csv	C|Penalties|Resident Penalties|Common Area Violation|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
9fae838f-3021-4a7d-8c19-627a89c84695	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	cf33e309-e6e7-4545-80e6-b7f4427427bb	\N	2675000	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
b6b30bd1-3897-43e0-bc1b-e20749f52e4d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	cf33e309-e6e7-4545-80e6-b7f4427427bb	\N	4005000	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
5cd8479b-b37d-413d-b85e-30f01006befe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	cf33e309-e6e7-4545-80e6-b7f4427427bb	\N	3865000	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
7b4f141c-5c64-4a44-be3e-d6a4be6573c3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	cf33e309-e6e7-4545-80e6-b7f4427427bb	\N	9310000	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
db4fe32e-5119-4146-946a-12d6cf89b57a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	90cb34c1-56bd-4609-afd3-bbf1d6b021de	7613c1e2-7fc0-4728-b9e3-efed077d73af	cf33e309-e6e7-4545-80e6-b7f4427427bb	\N	14787500	C	csv	C|Penalties|Resident Penalties|Late Payment Fine|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
317e433c-812d-4912-bec8-4d97ffc7c321	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	1708d96b-116e-46fb-ad8b-e8b1ff7f9534	18d5abfd-d4b4-4fc4-93a2-085c7bf2dc99	\N	1540000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
e28f6413-005f-4c47-9a5f-3d85b468215a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	1708d96b-116e-46fb-ad8b-e8b1ff7f9534	18d5abfd-d4b4-4fc4-93a2-085c7bf2dc99	\N	1100000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
a08d2082-6de1-4704-adc0-252c0a1a0de5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	db3e0a08-c6a1-4d7a-bad0-a36f9ee53059	1708d96b-116e-46fb-ad8b-e8b1ff7f9534	18d5abfd-d4b4-4fc4-93a2-085c7bf2dc99	\N	400000	C	csv	C|Advertisement|Advertising Revenue|Lift Advertisement|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
fcc5b74a-6e08-438e-b69c-38b7ec705a38	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	2025-10-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	38cc7598-50ed-424e-90f8-83cbd976e33d	295896d7-f8e7-411f-ac4d-17d785d7bda1	\N	1847000	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2025-10	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
836f9594-9aaf-4a5e-9e48-4d4edb618a4f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	2025-11-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	38cc7598-50ed-424e-90f8-83cbd976e33d	295896d7-f8e7-411f-ac4d-17d785d7bda1	\N	155295300	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2025-11	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
1ba31286-7a0f-4125-8e69-c72b033c028e	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	38cc7598-50ed-424e-90f8-83cbd976e33d	295896d7-f8e7-411f-ac4d-17d785d7bda1	\N	305918000	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
88678e1b-6a40-4818-a6c8-d9b866089c8e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	38cc7598-50ed-424e-90f8-83cbd976e33d	295896d7-f8e7-411f-ac4d-17d785d7bda1	\N	479557282	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
6afa0f87-bca2-4b20-95fe-603c49d1de10	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	38cc7598-50ed-424e-90f8-83cbd976e33d	295896d7-f8e7-411f-ac4d-17d785d7bda1	\N	272195080	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
4f5316e1-9eeb-41d1-ab5e-dcab9f467a43	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	746213f5-eb70-4bfd-be95-c719831dddf3	38cc7598-50ed-424e-90f8-83cbd976e33d	295896d7-f8e7-411f-ac4d-17d785d7bda1	\N	274740500	C	csv	C|Maintenance Collection|Apartment Owners|Maintenance Charge|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
4501e4f6-08c0-41a0-8b26-4626dddc1e3c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	7b5c1342-3a72-4331-a90e-684007adeb9e	36812135-b2dd-4bab-85a0-8124121a594e	\N	750000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
d61d98da-f08a-427a-bb85-9d9e7a3e39ac	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	7b5c1342-3a72-4331-a90e-684007adeb9e	36812135-b2dd-4bab-85a0-8124121a594e	\N	750000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
acc9ce50-bac8-4e91-9be3-abcec27252ce	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	7b5c1342-3a72-4331-a90e-684007adeb9e	36812135-b2dd-4bab-85a0-8124121a594e	\N	1750000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
52222d71-38cc-4714-87f3-12a35bc601ec	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	2cef7ba9-4bda-479a-93e1-94498cfc3725	7b5c1342-3a72-4331-a90e-684007adeb9e	36812135-b2dd-4bab-85a0-8124121a594e	\N	3750000	C	csv	C|Move Charges|Resident Services|Move in/out Charges|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
3f5b0fef-2ddc-4279-a7da-9f2f761920d3	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	aba3d4f9-35b9-4695-85fd-28cb653e8e06	\N	1800000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2872e270-4245-4dc6-9fd4-b022a7b7e348	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	aba3d4f9-35b9-4695-85fd-28cb653e8e06	\N	3300000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
aed1022f-1b88-48bd-a6f9-812cb91abae2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	aba3d4f9-35b9-4695-85fd-28cb653e8e06	\N	2100000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
cac40e7c-04b7-4414-923c-9c227d6a6180	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	f7499fee-7b2d-446a-8d9a-99452fe75cd5	8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	aba3d4f9-35b9-4695-85fd-28cb653e8e06	\N	2700000	C	csv	C|Facility Rental|Amenities|Multipurpose Party Hall/Club House|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
83687a8e-2507-4265-93ff-be65319ffdcb	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	2025-12-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	f6122417-b832-4e34-b7e6-ef9cdf3eda83	\N	834588	C	csv	C|Tax|Tax Collection|SGST Output|2025-12	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
e179ca27-cf5a-49e1-b797-baa887038f57	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	2026-01-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	f6122417-b832-4e34-b7e6-ef9cdf3eda83	\N	3054006	C	csv	C|Tax|Tax Collection|SGST Output|2026-01	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
2f87f6c9-8f6d-4abf-b7c8-8e7dfda0a28a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	2026-02-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	f6122417-b832-4e34-b7e6-ef9cdf3eda83	\N	394000	C	csv	C|Tax|Tax Collection|SGST Output|2026-02	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
956ff07a-8829-4a3a-985e-e26c476e44ac	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	2026-03-01	08829c33-ddf3-437f-b05b-83a5b106e7bf	ba7f14db-b217-41ed-bd79-0e71b404070a	8d6f01b4-3830-48bc-978c-20998ebe2839	f6122417-b832-4e34-b7e6-ef9cdf3eda83	\N	919900	C	csv	C|Tax|Tax Collection|SGST Output|2026-03	\N	\N	2026-08-10 17:24:15.863954+00	2026-08-10 17:24:15.863954+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	superadmin
0f0c6024-6c4d-47b3-9012-4f714d448a40	admin
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, community_id, email, name, password_hash, last_login_at, created_at) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	caa11b01-c3a5-4067-a90c-b73b35075def	admin@example.com	Super Admin	$argon2id$v=19$m=65536,t=3,p=4$ClriAYS29VF6qG8A2z9g0g$BucBee+CO4fDjZqATbn+syQnpotISh+CAp8wqgHJmY8	2026-08-10 17:23:56.721497+00	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, community_id, name, kind) FROM stdin;
1dc46aca-330f-452c-98de-41d3391a095e	caa11b01-c3a5-4067-a90c-b73b35075def	KNND ASSOCIATES PVT LTD	company
7caa420d-ff54-46b1-b4f6-f9d8cfa28664	caa11b01-c3a5-4067-a90c-b73b35075def	Professional Consultant	company
581348a6-a54b-44a9-b7a6-f9f960c00d8d	caa11b01-c3a5-4067-a90c-b73b35075def	Airtel	company
028048ac-8e65-4b70-b03c-751c27bd88f1	caa11b01-c3a5-4067-a90c-b73b35075def	Airtel Postpaid	company
cbbf60d9-8db1-4fbb-962d-acacf8717b8a	caa11b01-c3a5-4067-a90c-b73b35075def	Amazon CG Boulevard RWA	company
22afd4a5-60fd-410b-93a3-9a94f3c4de3c	caa11b01-c3a5-4067-a90c-b73b35075def	JOHNSON LIFTS Pvt Ltd	company
f6a8cf98-582f-41bf-97c1-e643d0a3ab72	caa11b01-c3a5-4067-a90c-b73b35075def	BESCOM	company
fbd6892d-f6ef-4084-a765-f4f07271f0ba	caa11b01-c3a5-4067-a90c-b73b35075def	KIRLOSKAR OIL ENGINES LTD	company
a24668ec-6f8f-44cd-91d6-ce80712dc801	caa11b01-c3a5-4067-a90c-b73b35075def	Sai Krupa Petroleum	company
901ea9fa-0af0-460e-9d86-2dcee8d84c11	caa11b01-c3a5-4067-a90c-b73b35075def	Sewa Waste Management	company
779b185d-df34-42c1-afc5-a63fa9aefe39	caa11b01-c3a5-4067-a90c-b73b35075def	Kavitha Enterprises	company
2424e6ed-93ab-42c6-807d-b50119107dd1	caa11b01-c3a5-4067-a90c-b73b35075def	System Adjustment	company
f0785724-ff84-495b-9936-1df07bad8393	caa11b01-c3a5-4067-a90c-b73b35075def	Sapthagiri Cleaner	company
c5e4bc3d-022e-4535-b5e6-a00385f6b19a	caa11b01-c3a5-4067-a90c-b73b35075def	Water Supplier	company
9c90a9f6-69b6-40da-b5ba-04312a168b25	caa11b01-c3a5-4067-a90c-b73b35075def	Individual	company
775bb244-e65f-4219-9cae-c0d30fe5d7c1	caa11b01-c3a5-4067-a90c-b73b35075def	Petty Cash	company
a01aa921-5c35-4867-872d-1ed121e91875	caa11b01-c3a5-4067-a90c-b73b35075def	BSN Water Supply	company
d210622b-72cf-4da8-91ff-8ba0b3d19a56	caa11b01-c3a5-4067-a90c-b73b35075def	EXOZEN	company
c44ed2e5-34a5-4cd3-b5d2-4e1e61016ac5	caa11b01-c3a5-4067-a90c-b73b35075def	Residents	company
2a8c8086-0441-4b00-b71d-3b1094319c9b	caa11b01-c3a5-4067-a90c-b73b35075def	Wellness Programs	company
6c6cf6ec-d41b-456a-9777-5943fa201c20	caa11b01-c3a5-4067-a90c-b73b35075def	Community Events	company
83a2e6a9-991c-498e-8563-7cf076e45662	caa11b01-c3a5-4067-a90c-b73b35075def	Parking Services	company
8eee43cb-7057-4998-891a-3b01354c9b41	caa11b01-c3a5-4067-a90c-b73b35075def	Advertiser	company
64d03044-5c28-4340-acad-af71754741ff	caa11b01-c3a5-4067-a90c-b73b35075def	Flat Owners	company
7613c1e2-7fc0-4728-b9e3-efed077d73af	caa11b01-c3a5-4067-a90c-b73b35075def	Resident Penalties	company
1708d96b-116e-46fb-ad8b-e8b1ff7f9534	caa11b01-c3a5-4067-a90c-b73b35075def	Advertising Revenue	company
38cc7598-50ed-424e-90f8-83cbd976e33d	caa11b01-c3a5-4067-a90c-b73b35075def	Apartment Owners	company
7b5c1342-3a72-4331-a90e-684007adeb9e	caa11b01-c3a5-4067-a90c-b73b35075def	Resident Services	company
8a9cbc9f-3f48-45db-82fd-3baa14ac7b71	caa11b01-c3a5-4067-a90c-b73b35075def	Amenities	company
8d6f01b4-3830-48bc-978c-20998ebe2839	caa11b01-c3a5-4067-a90c-b73b35075def	Tax Collection	company
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 3, true);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (name);


--
-- Name: allowed_emails allowed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_pkey PRIMARY KEY (email);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: balances balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_pkey PRIMARY KEY (community_id, month);


--
-- Name: categories categories_head_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_name_key UNIQUE (head_id, name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: collections_dues collections_dues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_pkey PRIMARY KEY (flat_id, period_month);


--
-- Name: communities communities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communities
    ADD CONSTRAINT communities_pkey PRIMARY KEY (id);


--
-- Name: dashboard_settings dashboard_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_pkey PRIMARY KEY (community_id, dashboard_key);


--
-- Name: flats flats_community_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_code_key UNIQUE (community_id, code);


--
-- Name: flats flats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_pkey PRIMARY KEY (id);


--
-- Name: heads heads_community_id_kind_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_kind_name_key UNIQUE (community_id, kind, name);


--
-- Name: heads heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_rules import_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_pkey PRIMARY KEY (id);


--
-- Name: import_staging import_staging_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_pkey PRIMARY KEY (batch_id, row_no);


--
-- Name: line_items line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_pkey PRIMARY KEY (id);


--
-- Name: otp_codes magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (email, otp_hash);


--
-- Name: periods periods_community_id_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_month_key UNIQUE (community_id, month);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_source_source_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_source_source_ref_key UNIQUE (source, source_ref);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_community_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_name_key UNIQUE (community_id, name);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_at ON public.audit_log USING btree (at DESC);


--
-- Name: idx_audit_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_entity ON public.audit_log USING btree (entity, entity_id);


--
-- Name: idx_txn_category_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_category_month ON public.transactions USING btree (category_id, period_month);


--
-- Name: idx_txn_community_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_community_month ON public.transactions USING btree (community_id, period_month);


--
-- Name: idx_txn_flat_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_flat_month ON public.transactions USING btree (flat_id, period_month);


--
-- Name: idx_txn_head_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_head_month ON public.transactions USING btree (head_id, period_month);


--
-- Name: idx_txn_vendor_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_vendor_month ON public.transactions USING btree (vendor_id, period_month);


--
-- Name: line_items_cat_vendor_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX line_items_cat_vendor_name_uq ON public.line_items USING btree (category_id, COALESCE(vendor_id, '00000000-0000-0000-0000-000000000000'::uuid), name);


--
-- Name: mv_cat_monthly_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_cat_monthly_idx ON public.mv_category_monthly USING btree (community_id, month);


--
-- Name: mv_monthly_totals_pk; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mv_monthly_totals_pk ON public.mv_monthly_totals USING btree (community_id, month);


--
-- Name: mv_vendor_ranking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_vendor_ranking_idx ON public.mv_vendor_ranking USING btree (community_id, total_expense_paise DESC);


--
-- Name: allowed_emails allowed_emails_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: allowed_emails allowed_emails_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE SET NULL;


--
-- Name: balances balances_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: categories categories_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id) ON DELETE CASCADE;


--
-- Name: collections_dues collections_dues_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE CASCADE;


--
-- Name: dashboard_settings dashboard_settings_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: flats flats_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: heads heads_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: import_rules import_rules_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_staging import_staging_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE SET NULL;


--
-- Name: periods periods_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: transactions transactions_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id);


--
-- Name: transactions transactions_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id);


--
-- Name: transactions transactions_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_line_item_id_fkey FOREIGN KEY (line_item_id) REFERENCES public.line_items(id);


--
-- Name: transactions transactions_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: vendors vendors_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_category_monthly;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_monthly_totals;


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_vendor_ranking;


--
-- PostgreSQL database dump complete
--

\unrestrict AWC4Dv2nkMZJCKv8gfGvjU5JcZkQrX2Pif82jsNTbGGmEPeFPfachuPV9Y8mP2z

