--
-- PostgreSQL database dump
--

\restrict Y9oCcYRweuX3saQ79NiCxpKi6mEz6chrwXcafVRuQYMCg4GXF7Gg67t3rBPAB4T

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_line_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_batch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_actor_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_community_id_fkey;
DROP INDEX IF EXISTS public.mv_vendor_ranking_idx;
DROP INDEX IF EXISTS public.mv_monthly_totals_pk;
DROP INDEX IF EXISTS public.mv_cat_monthly_idx;
DROP INDEX IF EXISTS public.line_items_cat_vendor_name_uq;
DROP INDEX IF EXISTS public.idx_txn_vendor_month;
DROP INDEX IF EXISTS public.idx_txn_head_month;
DROP INDEX IF EXISTS public.idx_txn_flat_month;
DROP INDEX IF EXISTS public.idx_txn_community_month;
DROP INDEX IF EXISTS public.idx_txn_category_month;
DROP INDEX IF EXISTS public.idx_audit_entity;
DROP INDEX IF EXISTS public.idx_audit_at;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_pkey;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_name_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_source_source_ref_key;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_month_key;
ALTER TABLE IF EXISTS ONLY public.otp_codes DROP CONSTRAINT IF EXISTS magic_links_pkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_pkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_pkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_kind_name_key;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_pkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_code_key;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.communities DROP CONSTRAINT IF EXISTS communities_pkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_name_key;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_pkey;
ALTER TABLE IF EXISTS ONLY public._migrations DROP CONSTRAINT IF EXISTS _migrations_pkey;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.periods;
DROP TABLE IF EXISTS public.otp_codes;
DROP MATERIALIZED VIEW IF EXISTS public.mv_vendor_ranking;
DROP TABLE IF EXISTS public.vendors;
DROP MATERIALIZED VIEW IF EXISTS public.mv_monthly_totals;
DROP MATERIALIZED VIEW IF EXISTS public.mv_category_monthly;
DROP TABLE IF EXISTS public.transactions;
DROP TABLE IF EXISTS public.line_items;
DROP TABLE IF EXISTS public.import_staging;
DROP TABLE IF EXISTS public.import_rules;
DROP TABLE IF EXISTS public.import_batches;
DROP TABLE IF EXISTS public.heads;
DROP TABLE IF EXISTS public.flats;
DROP TABLE IF EXISTS public.dashboard_settings;
DROP TABLE IF EXISTS public.communities;
DROP TABLE IF EXISTS public.collections_dues;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.balances;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP TABLE IF EXISTS public.allowed_emails;
DROP TABLE IF EXISTS public._migrations;
DROP TYPE IF EXISTS public.vendor_kind;
DROP TYPE IF EXISTS public.head_kind;
DROP TYPE IF EXISTS public.app_role;
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'resident',
    'admin',
    'superadmin'
);


--
-- Name: head_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.head_kind AS ENUM (
    'income',
    'expense'
);


--
-- Name: vendor_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vendor_kind AS ENUM (
    'company',
    'individual'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    name text NOT NULL,
    run_at timestamp with time zone DEFAULT now()
);


--
-- Name: allowed_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allowed_emails (
    email text NOT NULL,
    community_id uuid NOT NULL,
    role public.app_role NOT NULL,
    flat_id uuid,
    name text,
    invited_by text,
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    community_id uuid,
    actor_user_id uuid,
    actor_email text,
    entity text NOT NULL,
    entity_id text,
    action text NOT NULL,
    before jsonb,
    after jsonb,
    at timestamp with time zone DEFAULT now() NOT NULL,
    ip text,
    user_agent text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balances (
    community_id uuid NOT NULL,
    month date NOT NULL,
    opening_paise bigint DEFAULT 0 NOT NULL,
    closing_paise bigint DEFAULT 0 NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    head_id uuid NOT NULL,
    name text NOT NULL
);


--
-- Name: collections_dues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections_dues (
    flat_id uuid NOT NULL,
    period_month date NOT NULL,
    dues_paise bigint DEFAULT 0 NOT NULL,
    paid_paise bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'due'::text NOT NULL
);


--
-- Name: communities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    fy_start_month smallint DEFAULT 4 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dashboard_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_settings (
    community_id uuid NOT NULL,
    dashboard_key text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    hidden_widgets text[] DEFAULT '{}'::text[] NOT NULL
);


--
-- Name: flats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    code text NOT NULL,
    owner_email text
);


--
-- Name: heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind public.head_kind NOT NULL,
    name text NOT NULL
);


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    filename text NOT NULL,
    kind text NOT NULL,
    uploaded_by uuid,
    status text DEFAULT 'staged'::text NOT NULL,
    error text,
    row_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind text NOT NULL,
    match jsonb NOT NULL,
    set_fields jsonb NOT NULL,
    priority integer DEFAULT 100 NOT NULL
);


--
-- Name: import_staging; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_staging (
    batch_id uuid NOT NULL,
    row_no integer NOT NULL,
    raw_json jsonb NOT NULL,
    mapped_json jsonb,
    error text
);


--
-- Name: line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    name text NOT NULL,
    first_seen_month date,
    last_seen_month date
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    txn_date date NOT NULL,
    period_month date NOT NULL,
    head_id uuid NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    line_item_id uuid,
    flat_id uuid,
    amount_paise bigint NOT NULL,
    direction character(1) NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    source_ref text,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT transactions_amount_paise_check CHECK ((amount_paise >= 0)),
    CONSTRAINT transactions_direction_check CHECK ((direction = ANY (ARRAY['C'::bpchar, 'D'::bpchar])))
);


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_category_monthly AS
 SELECT t.community_id,
    t.category_id,
    c.name AS category_name,
    h.kind AS head_kind,
    t.period_month AS month,
    (sum(t.amount_paise))::bigint AS amount_paise
   FROM ((public.transactions t
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON ((h.id = t.head_id)))
  GROUP BY t.community_id, t.category_id, c.name, h.kind, t.period_month
  WITH NO DATA;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_monthly_totals AS
 WITH spine AS (
         SELECT c.id AS community_id,
            (date_trunc('month'::text, gs.gs))::date AS month
           FROM (public.communities c
             CROSS JOIN generate_series((( SELECT COALESCE(min(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, (( SELECT COALESCE(max(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, '1 mon'::interval) gs(gs))
        )
 SELECT s.community_id,
    s.month,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric))::bigint AS collection_paise,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric))::bigint AS expense_paise,
    ((COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric) - COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric)))::bigint AS net_paise
   FROM (spine s
     LEFT JOIN public.transactions t ON (((t.community_id = s.community_id) AND (t.period_month = s.month))))
  GROUP BY s.community_id, s.month
  WITH NO DATA;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    name text NOT NULL,
    kind public.vendor_kind DEFAULT 'company'::public.vendor_kind NOT NULL
);


--
-- Name: TABLE vendors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vendors IS 'Vendor dimension. Read-only from admin UI; populated via CSV import + on-the-fly during transaction ingest.';


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_vendor_ranking AS
 SELECT t.community_id,
    v.id AS vendor_id,
    v.name AS vendor_name,
    v.kind AS vendor_kind,
    COALESCE(string_agg(DISTINCT c.name, ', '::text), ''::text) AS categories,
    (sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)))::bigint AS total_expense_paise,
    count(DISTINCT t.period_month) AS months_active
   FROM (((public.transactions t
     JOIN public.vendors v ON ((v.id = t.vendor_id)))
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON (((h.id = t.head_id) AND (h.kind = 'expense'::public.head_kind))))
  GROUP BY t.community_id, v.id, v.name, v.kind
  WITH NO DATA;


--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_codes (
    email text NOT NULL,
    otp_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone
);


--
-- Name: periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    month date NOT NULL,
    status text DEFAULT 'open'::text NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role public.app_role NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    email text NOT NULL,
    name text,
    password_hash text,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._migrations (name, run_at) FROM stdin;
0001_init.sql	2026-07-13 11:13:56.401452+00
0002_indexes.sql	2026-07-13 11:13:56.401452+00
0003_mviews.sql	2026-07-13 11:13:56.401452+00
0004_otp_rename.sql	2026-07-13 11:20:04.500279+00
\.


--
-- Data for Name: allowed_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allowed_emails (email, community_id, role, flat_id, name, invited_by, invited_at, revoked_at) FROM stdin;
treasurer@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	admin	\N	Treasurer	system	2026-07-13 11:20:04.55456+00	\N
resident@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	resident	\N	Demo Resident	system	2026-07-13 11:20:04.55456+00	\N
admin@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	superadmin	\N	Super Admin	system	2026-07-13 11:20:04.55456+00	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, community_id, actor_user_id, actor_email, entity, entity_id, action, before, after, at, ip, user_agent) FROM stdin;
1	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	import_batch	4bd2887a-2c60-4a90-ae00-a937d2afc257	import	\N	{"kind": "transactions", "rows": 152, "failed": 0, "filename": "transactions.csv", "inserted": 152}	2026-07-13 14:24:38.511364+00	192.168.16.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
2	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	auth	\N	login	\N	\N	2026-07-25 08:24:06.262813+00	172.18.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
\.


--
-- Data for Name: balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.balances (community_id, month, opening_paise, closing_paise) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, head_id, name) FROM stdin;
455a23f5-cd05-4d4e-bfd8-c3d365856bdd	2b304b23-6390-4b36-8b80-1401a611e227	Utilities
25942ad2-bd57-4975-a30c-b6b7803e7b3f	2b304b23-6390-4b36-8b80-1401a611e227	Maintenance
5adeed80-8ff1-46c6-963b-3f26b1feba42	2b304b23-6390-4b36-8b80-1401a611e227	Security
94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	2b304b23-6390-4b36-8b80-1401a611e227	Housekeeping
950a91fe-dd86-4350-a419-06258dc38dbc	2b304b23-6390-4b36-8b80-1401a611e227	Petty Cash
0e8cf05b-a0bd-4751-aa40-30728926c822	d40b3d73-99c5-4e0a-958c-1d4700b351bb	Maintenance Collections
100e858a-f0ad-4449-8b44-4049067c09b8	d40b3d73-99c5-4e0a-958c-1d4700b351bb	Other Income
\.


--
-- Data for Name: collections_dues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections_dues (flat_id, period_month, dues_paise, paid_paise, status) FROM stdin;
\.


--
-- Data for Name: communities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communities (id, name, currency, fy_start_month, created_at) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	Green Meadows	INR	4	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: dashboard_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_settings (community_id, dashboard_key, enabled, hidden_widgets) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	resident.overview	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.drilldown	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.cashflow	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.income	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.balance	t	{}
\.


--
-- Data for Name: flats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flats (id, community_id, code, owner_email) FROM stdin;
f88d6359-58a8-42b1-8476-24ce41b63802	caa11b01-c3a5-4067-a90c-b73b35075def	A-001	\N
5696d5bf-57f9-44ad-b92d-781cabc4a550	caa11b01-c3a5-4067-a90c-b73b35075def	A-002	\N
5c447f5e-a684-4075-8224-072f1fb12c93	caa11b01-c3a5-4067-a90c-b73b35075def	A-003	\N
6ddf10b7-40ed-44a1-9080-e50c60a08e32	caa11b01-c3a5-4067-a90c-b73b35075def	A-004	\N
5bfe95a5-bc38-4d00-811e-b5a6106e71c7	caa11b01-c3a5-4067-a90c-b73b35075def	A-005	\N
6e67ec18-d2aa-4cd4-8a51-b9a2b33429a2	caa11b01-c3a5-4067-a90c-b73b35075def	A-006	\N
05fbfe69-9195-45aa-bb9a-ef1de36f6fd9	caa11b01-c3a5-4067-a90c-b73b35075def	A-007	\N
7dca9ae9-39f7-4b2c-85b6-f9c820a65f0c	caa11b01-c3a5-4067-a90c-b73b35075def	A-008	\N
24f24d23-6946-4d06-b2d4-7ebe31278f9e	caa11b01-c3a5-4067-a90c-b73b35075def	A-009	\N
39278459-ad85-4e5e-937a-0a36b195c960	caa11b01-c3a5-4067-a90c-b73b35075def	A-010	\N
716bbe4c-f53d-4558-a4b5-caeb642f2c23	caa11b01-c3a5-4067-a90c-b73b35075def	A-011	\N
6dac5232-f75f-44d2-8533-4119c856f0ac	caa11b01-c3a5-4067-a90c-b73b35075def	A-012	\N
ea815ea6-a6d6-4547-bb06-ebfc9497a6f2	caa11b01-c3a5-4067-a90c-b73b35075def	A-013	\N
b441021b-6b42-4350-bd7a-385d23b17015	caa11b01-c3a5-4067-a90c-b73b35075def	A-014	\N
74194275-0229-47a7-9a12-691c228cbf03	caa11b01-c3a5-4067-a90c-b73b35075def	A-015	\N
f9df5252-7643-42fd-9a63-2e839347a52f	caa11b01-c3a5-4067-a90c-b73b35075def	A-016	\N
321b8a10-e82d-4cf6-a6b2-fde3fa7b05b1	caa11b01-c3a5-4067-a90c-b73b35075def	A-017	\N
9c1ddcb5-9b93-4e47-80ac-cbfc3b7f326e	caa11b01-c3a5-4067-a90c-b73b35075def	A-018	\N
f0106df5-f061-40fd-97c8-f6408f268ff9	caa11b01-c3a5-4067-a90c-b73b35075def	A-019	\N
deeb22d9-7a6b-4417-985b-c76049abae2e	caa11b01-c3a5-4067-a90c-b73b35075def	A-020	\N
c2e7bc3c-62db-4d01-aad3-9513cbf2ecbf	caa11b01-c3a5-4067-a90c-b73b35075def	A-021	\N
8c7ed2ff-3fea-4279-a889-c4e44b78ef6e	caa11b01-c3a5-4067-a90c-b73b35075def	A-022	\N
fb52fe46-dded-4f23-975d-3f36184896e9	caa11b01-c3a5-4067-a90c-b73b35075def	A-023	\N
5fc3f4ab-169c-47bc-819a-315c1a244aac	caa11b01-c3a5-4067-a90c-b73b35075def	A-024	\N
\.


--
-- Data for Name: heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heads (id, community_id, kind, name) FROM stdin;
2b304b23-6390-4b36-8b80-1401a611e227	caa11b01-c3a5-4067-a90c-b73b35075def	expense	Expense
d40b3d73-99c5-4e0a-958c-1d4700b351bb	caa11b01-c3a5-4067-a90c-b73b35075def	income	Income
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, community_id, filename, kind, uploaded_by, status, error, row_count, created_at) FROM stdin;
4bd2887a-2c60-4a90-ae00-a937d2afc257	caa11b01-c3a5-4067-a90c-b73b35075def	transactions.csv	transactions	0f0c6024-6c4d-47b3-9012-4f714d448a40	committed	\N	152	2026-07-13 14:24:38.504271+00
\.


--
-- Data for Name: import_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_rules (id, community_id, kind, match, set_fields, priority) FROM stdin;
\.


--
-- Data for Name: import_staging; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_staging (batch_id, row_no, raw_json, mapped_json, error) FROM stdin;
4bd2887a-2c60-4a90-ae00-a937d2afc257	1	{"date": "2025-08-15", "head": "expense", "amount": "48000", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	2	{"date": "2025-09-15", "head": "expense", "amount": "51366", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	3	{"date": "2025-10-15", "head": "expense", "amount": "51637", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	4	{"date": "2025-11-15", "head": "expense", "amount": "48564", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	5	{"date": "2025-12-15", "head": "expense", "amount": "44973", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	6	{"date": "2026-01-15", "head": "expense", "amount": "44164", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	7	{"date": "2026-02-15", "head": "expense", "amount": "46882", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	8	{"date": "2026-03-15", "head": "expense", "amount": "50628", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	9	{"date": "2026-04-15", "head": "expense", "amount": "51957", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	10	{"date": "2026-05-15", "head": "expense", "amount": "49648", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	11	{"date": "2026-06-15", "head": "expense", "amount": "45824", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	12	{"date": "2026-07-15", "head": "expense", "amount": "44000", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	13	{"date": "2025-08-15", "head": "expense", "amount": "12000", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	14	{"date": "2025-09-15", "head": "expense", "amount": "14945", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	15	{"date": "2025-11-15", "head": "expense", "amount": "12494", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	16	{"date": "2025-12-15", "head": "expense", "amount": "9351", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	17	{"date": "2026-01-15", "head": "expense", "amount": "8644", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	18	{"date": "2026-02-15", "head": "expense", "amount": "11022", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	19	{"date": "2026-03-15", "head": "expense", "amount": "14299", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	20	{"date": "2026-05-15", "head": "expense", "amount": "13442", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	21	{"date": "2026-06-15", "head": "expense", "amount": "10096", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	22	{"date": "2026-07-15", "head": "expense", "amount": "8500", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	23	{"date": "2025-08-15", "head": "expense", "amount": "32000", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	24	{"date": "2025-09-15", "head": "expense", "amount": "33683", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	25	{"date": "2025-10-15", "head": "expense", "amount": "33819", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	26	{"date": "2025-11-15", "head": "expense", "amount": "32282", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	27	{"date": "2025-12-15", "head": "expense", "amount": "30486", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	28	{"date": "2026-01-15", "head": "expense", "amount": "30082", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	29	{"date": "2026-02-15", "head": "expense", "amount": "31441", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	30	{"date": "2026-03-15", "head": "expense", "amount": "33314", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	31	{"date": "2026-04-15", "head": "expense", "amount": "33979", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	32	{"date": "2026-05-15", "head": "expense", "amount": "32824", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	33	{"date": "2026-06-15", "head": "expense", "amount": "30912", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	34	{"date": "2026-07-15", "head": "expense", "amount": "30000", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	35	{"date": "2025-08-15", "head": "expense", "amount": "65000", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	36	{"date": "2025-09-15", "head": "expense", "amount": "67524", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	37	{"date": "2025-10-15", "head": "expense", "amount": "67728", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	38	{"date": "2025-11-15", "head": "expense", "amount": "65423", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	39	{"date": "2025-12-15", "head": "expense", "amount": "62730", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	40	{"date": "2026-01-15", "head": "expense", "amount": "62123", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	41	{"date": "2026-02-15", "head": "expense", "amount": "64162", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	42	{"date": "2026-03-15", "head": "expense", "amount": "66971", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	43	{"date": "2026-04-15", "head": "expense", "amount": "67968", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	44	{"date": "2026-05-15", "head": "expense", "amount": "66236", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	45	{"date": "2026-06-15", "head": "expense", "amount": "63368", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	46	{"date": "2026-07-15", "head": "expense", "amount": "62000", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	47	{"date": "2025-08-15", "head": "expense", "amount": "18000", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	48	{"date": "2025-10-15", "head": "expense", "amount": "23456", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	49	{"date": "2025-11-15", "head": "expense", "amount": "18847", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	50	{"date": "2026-01-15", "head": "expense", "amount": "12246", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	51	{"date": "2026-02-15", "head": "expense", "amount": "16324", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	52	{"date": "2026-04-15", "head": "expense", "amount": "23936", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	53	{"date": "2026-05-15", "head": "expense", "amount": "20473", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	54	{"date": "2026-06-15", "head": "expense", "amount": "14736", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	55	{"date": "2026-07-15", "head": "expense", "amount": "12000", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	56	{"date": "2025-10-15", "head": "expense", "amount": "9455", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "STP salt purchase", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	57	{"date": "2026-01-15", "head": "expense", "amount": "8521", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "STP salt purchase", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	58	{"date": "2026-04-15", "head": "expense", "amount": "9495", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "STP salt purchase", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	59	{"date": "2026-07-15", "head": "expense", "amount": "8500", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "STP salt purchase", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	60	{"date": "2025-09-15", "head": "expense", "amount": "7445", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	61	{"date": "2025-11-15", "head": "expense", "amount": "4994", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	62	{"date": "2025-12-15", "head": "expense", "amount": "1851", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	63	{"date": "2026-03-15", "head": "expense", "amount": "6799", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	64	{"date": "2026-05-15", "head": "expense", "amount": "5942", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	65	{"date": "2026-06-15", "head": "expense", "amount": "2596", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	66	{"date": "2025-08-15", "head": "expense", "amount": "120000", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	67	{"date": "2025-09-15", "head": "expense", "amount": "121683", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	68	{"date": "2025-10-15", "head": "expense", "amount": "121819", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	69	{"date": "2025-11-15", "head": "expense", "amount": "120282", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	70	{"date": "2025-12-15", "head": "expense", "amount": "118486", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	71	{"date": "2026-01-15", "head": "expense", "amount": "118082", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	72	{"date": "2026-02-15", "head": "expense", "amount": "119441", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	73	{"date": "2026-03-15", "head": "expense", "amount": "121314", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	74	{"date": "2026-04-15", "head": "expense", "amount": "121979", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	75	{"date": "2026-05-15", "head": "expense", "amount": "120824", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	76	{"date": "2026-06-15", "head": "expense", "amount": "118912", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	77	{"date": "2026-07-15", "head": "expense", "amount": "118000", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	78	{"date": "2025-08-15", "head": "expense", "amount": "58000", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	79	{"date": "2025-09-15", "head": "expense", "amount": "59262", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	80	{"date": "2025-10-15", "head": "expense", "amount": "59364", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	81	{"date": "2025-11-15", "head": "expense", "amount": "58212", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	82	{"date": "2025-12-15", "head": "expense", "amount": "56865", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	83	{"date": "2026-01-15", "head": "expense", "amount": "56562", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	84	{"date": "2026-02-15", "head": "expense", "amount": "57581", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	85	{"date": "2026-03-15", "head": "expense", "amount": "58985", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	86	{"date": "2026-04-15", "head": "expense", "amount": "59484", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	87	{"date": "2026-05-15", "head": "expense", "amount": "58618", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	88	{"date": "2026-06-15", "head": "expense", "amount": "57184", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	89	{"date": "2026-07-15", "head": "expense", "amount": "56500", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	90	{"date": "2025-08-15", "head": "expense", "amount": "7500", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	91	{"date": "2025-09-15", "head": "expense", "amount": "8762", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	92	{"date": "2025-10-15", "head": "expense", "amount": "8864", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	93	{"date": "2025-11-15", "head": "expense", "amount": "7712", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	94	{"date": "2025-12-15", "head": "expense", "amount": "6365", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	95	{"date": "2026-01-15", "head": "expense", "amount": "6062", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	96	{"date": "2026-02-15", "head": "expense", "amount": "7081", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	97	{"date": "2026-03-15", "head": "expense", "amount": "8485", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	98	{"date": "2026-04-15", "head": "expense", "amount": "8984", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	99	{"date": "2026-05-15", "head": "expense", "amount": "8118", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	100	{"date": "2026-06-15", "head": "expense", "amount": "6684", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	101	{"date": "2026-07-15", "head": "expense", "amount": "6000", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	102	{"date": "2025-08-15", "head": "expense", "amount": "6000", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	103	{"date": "2025-09-15", "head": "expense", "amount": "10628", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	104	{"date": "2025-10-15", "head": "expense", "amount": "11001", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	105	{"date": "2025-11-15", "head": "expense", "amount": "6776", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	106	{"date": "2025-12-15", "head": "expense", "amount": "1838", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	107	{"date": "2026-01-15", "head": "expense", "amount": "726", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	108	{"date": "2026-02-15", "head": "expense", "amount": "4463", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	109	{"date": "2026-03-15", "head": "expense", "amount": "9613", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	110	{"date": "2026-04-15", "head": "expense", "amount": "11441", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	111	{"date": "2026-05-15", "head": "expense", "amount": "8267", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	112	{"date": "2026-06-15", "head": "expense", "amount": "3008", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	113	{"date": "2026-07-15", "head": "expense", "amount": "500", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	114	{"date": "2025-08-15", "head": "income", "amount": "340000", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	115	{"date": "2025-09-15", "head": "income", "amount": "352622", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	116	{"date": "2025-10-15", "head": "income", "amount": "353639", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	117	{"date": "2025-11-15", "head": "income", "amount": "342117", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	118	{"date": "2025-12-15", "head": "income", "amount": "328648", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	119	{"date": "2026-01-15", "head": "income", "amount": "325616", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	120	{"date": "2026-02-15", "head": "income", "amount": "335809", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	121	{"date": "2026-03-15", "head": "income", "amount": "349855", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	122	{"date": "2026-04-15", "head": "income", "amount": "354840", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	123	{"date": "2026-05-15", "head": "income", "amount": "346182", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	124	{"date": "2026-06-15", "head": "income", "amount": "331840", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	125	{"date": "2026-07-15", "head": "income", "amount": "325000", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	126	{"date": "2025-08-15", "head": "income", "amount": "18000", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	127	{"date": "2025-10-15", "head": "income", "amount": "25274", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	128	{"date": "2025-11-15", "head": "income", "amount": "19129", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	129	{"date": "2025-12-15", "head": "income", "amount": "11946", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	130	{"date": "2026-02-15", "head": "income", "amount": "15765", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	131	{"date": "2026-03-15", "head": "income", "amount": "23256", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	132	{"date": "2026-04-15", "head": "income", "amount": "25915", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	133	{"date": "2026-06-15", "head": "income", "amount": "13648", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	134	{"date": "2026-07-15", "head": "income", "amount": "10000", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	135	{"date": "2025-09-15", "head": "income", "amount": "9787", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	136	{"date": "2025-11-15", "head": "income", "amount": "6635", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	137	{"date": "2026-01-15", "head": "income", "amount": "1685", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	138	{"date": "2026-03-15", "head": "income", "amount": "8956", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	139	{"date": "2026-05-15", "head": "income", "amount": "7855", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	140	{"date": "2026-07-15", "head": "income", "amount": "1500", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	141	{"date": "2025-08-15", "head": "income", "amount": "12000", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	142	{"date": "2025-09-15", "head": "income", "amount": "12421", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	143	{"date": "2025-10-15", "head": "income", "amount": "12455", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	144	{"date": "2025-11-15", "head": "income", "amount": "12071", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	145	{"date": "2025-12-15", "head": "income", "amount": "11622", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	146	{"date": "2026-01-15", "head": "income", "amount": "11521", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	147	{"date": "2026-02-15", "head": "income", "amount": "11860", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	148	{"date": "2026-03-15", "head": "income", "amount": "12328", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	149	{"date": "2026-04-15", "head": "income", "amount": "12495", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	150	{"date": "2026-05-15", "head": "income", "amount": "12206", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	151	{"date": "2026-06-15", "head": "income", "amount": "11728", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
4bd2887a-2c60-4a90-ae00-a937d2afc257	152	{"date": "2026-07-15", "head": "income", "amount": "11500", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
\.


--
-- Data for Name: line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_items (id, category_id, vendor_id, name, first_seen_month, last_seen_month) FROM stdin;
16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	Common area electricity	2025-08-01	2026-07-01
fbf45e48-7261-477b-9cba-bd441d429a21	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	Backup usage	2025-08-01	2026-07-01
ec27a0e3-c3da-440b-9557-194b52d1fb1c	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	Water charges	2025-08-01	2026-07-01
5a8f63e3-267b-4885-8618-8ce186889ce6	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	Labour charges	2025-08-01	2026-07-01
29401a2e-0c96-403c-88e4-57983f3742e4	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	Spare parts	2025-08-01	2026-07-01
9dd98399-f785-4e87-bfda-8275dd9fd92d	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	STP salt purchase	2025-10-01	2026-07-01
e25734a9-b53c-4db5-a907-17f7a1c6f796	25942ad2-bd57-4975-a30c-b6b7803e7b3f	b53804ac-e36e-404f-b6f8-c5da53265a2e	Plumbing repair	2025-09-01	2026-06-01
c543e21d-0dee-4f0b-91c4-0e909098bbc2	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	Guard salaries	2025-08-01	2026-07-01
a9a81406-0d42-485f-9c94-2582ca96d6e9	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	Staff wages	2025-08-01	2026-07-01
4624ca4b-e2bf-461c-976d-ab4718550873	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	Cleaning supplies	2025-08-01	2026-07-01
22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	Ad-hoc expenses	2025-08-01	2026-07-01
26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	Flat maintenance dues	2025-08-01	2026-07-01
0bf19380-9c34-4d4b-be1d-20e5a6922dac	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	Hall rental	2025-08-01	2026-07-01
96c67d4f-edb4-48b7-b8e2-0d3bb3864f8f	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	Event usage charges	2025-09-01	2026-07-01
b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	Billboard fee	2025-08-01	2026-07-01
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp_codes (email, otp_hash, expires_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periods (id, community_id, month, status) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, community_id, txn_date, period_month, head_id, category_id, vendor_id, line_item_id, flat_id, amount_paise, direction, source, source_ref, notes, created_by, created_at, updated_at) FROM stdin;
bb4d1b9e-2151-4703-b441-2578821c2420	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	\N	4800000	D	csv	2025-08-15|Utilities|Bescom|Common area electricity|4800000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
8162a6a7-c9ee-438b-bc7a-8af31e92c4c0	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	\N	5136600	D	csv	2025-09-15|Utilities|Bescom|Common area electricity|5136600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
dfc19edd-4a71-40db-8284-99feb5f0f072	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	\N	5163700	D	csv	2025-10-15|Utilities|Bescom|Common area electricity|5163700	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
171684d5-bb9e-4c77-8605-e70348e7ecca	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	\N	4856400	D	csv	2025-11-15|Utilities|Bescom|Common area electricity|4856400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
81298ab6-31ac-4a7b-bfb8-f0d102d76687	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	\N	4497300	D	csv	2025-12-15|Utilities|Bescom|Common area electricity|4497300	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
c98c8bb1-2749-48f8-9c5e-f9d6626bfbdc	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	\N	4416400	D	csv	2026-01-15|Utilities|Bescom|Common area electricity|4416400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
3b71a299-b259-4102-bddc-d42f3bb27785	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	\N	4688200	D	csv	2026-02-15|Utilities|Bescom|Common area electricity|4688200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
7d69a9d6-7e2d-4104-a0d5-b57f9f43c744	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	\N	5062800	D	csv	2026-03-15|Utilities|Bescom|Common area electricity|5062800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
ca6a2705-611e-444a-af7c-2a69c18a8043	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	\N	5195700	D	csv	2026-04-15|Utilities|Bescom|Common area electricity|5195700	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
ada098e3-55c9-4c57-a7c2-f0ab9bc84a33	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	\N	4964800	D	csv	2026-05-15|Utilities|Bescom|Common area electricity|4964800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
b6fbc683-bdce-4f22-8e1b-23bce240a39b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	\N	4582400	D	csv	2026-06-15|Utilities|Bescom|Common area electricity|4582400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
09fa1946-de69-4015-bad0-065850e9cd4e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	16e5eeb5-47a0-4df9-b0dc-b2dc4d5a70b1	\N	4400000	D	csv	2026-07-15|Utilities|Bescom|Common area electricity|4400000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
3a1d28be-ed26-4595-af13-9cadbc3b0143	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	fbf45e48-7261-477b-9cba-bd441d429a21	\N	1200000	D	csv	2025-08-15|Utilities|Bescom|Backup usage|1200000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
7f2151d1-7548-404f-8f95-f988fe279ee5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	fbf45e48-7261-477b-9cba-bd441d429a21	\N	1494500	D	csv	2025-09-15|Utilities|Bescom|Backup usage|1494500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
c5814d10-c7c4-4cb3-bc10-ca52521bc0ce	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	fbf45e48-7261-477b-9cba-bd441d429a21	\N	1249400	D	csv	2025-11-15|Utilities|Bescom|Backup usage|1249400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
e0216d5c-a17b-4bbd-9011-32c78a53514c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	fbf45e48-7261-477b-9cba-bd441d429a21	\N	935100	D	csv	2025-12-15|Utilities|Bescom|Backup usage|935100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
f30f4a64-1082-4877-99fe-a46b1e3d9060	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	fbf45e48-7261-477b-9cba-bd441d429a21	\N	864400	D	csv	2026-01-15|Utilities|Bescom|Backup usage|864400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
910cabda-61ee-404b-b30c-3d205c78f596	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	fbf45e48-7261-477b-9cba-bd441d429a21	\N	1102200	D	csv	2026-02-15|Utilities|Bescom|Backup usage|1102200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
44d3c02e-79b5-46a9-bdfd-145bf7a0a463	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	fbf45e48-7261-477b-9cba-bd441d429a21	\N	1429900	D	csv	2026-03-15|Utilities|Bescom|Backup usage|1429900	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
e2d75bae-7224-44bb-9e0e-7468ba57d702	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	fbf45e48-7261-477b-9cba-bd441d429a21	\N	1344200	D	csv	2026-05-15|Utilities|Bescom|Backup usage|1344200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
d02c304f-61d1-469c-ad46-18a710417605	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	fbf45e48-7261-477b-9cba-bd441d429a21	\N	1009600	D	csv	2026-06-15|Utilities|Bescom|Backup usage|1009600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
0b9fe207-174b-474a-aa2d-3907526aa05d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	fbf45e48-7261-477b-9cba-bd441d429a21	\N	850000	D	csv	2026-07-15|Utilities|Bescom|Backup usage|850000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
d50c3cde-cbf1-4ce9-8be8-efe52a043419	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	ec27a0e3-c3da-440b-9557-194b52d1fb1c	\N	3200000	D	csv	2025-08-15|Utilities|BWSSB|Water charges|3200000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
5ccce4ec-7200-497b-a382-f181f2e2f1fc	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	ec27a0e3-c3da-440b-9557-194b52d1fb1c	\N	3368300	D	csv	2025-09-15|Utilities|BWSSB|Water charges|3368300	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
536765f6-cf9b-445c-8319-525e78d3e2f2	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	ec27a0e3-c3da-440b-9557-194b52d1fb1c	\N	3381900	D	csv	2025-10-15|Utilities|BWSSB|Water charges|3381900	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
a9fda424-3b29-4713-9ee6-f27f44282a21	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	ec27a0e3-c3da-440b-9557-194b52d1fb1c	\N	3228200	D	csv	2025-11-15|Utilities|BWSSB|Water charges|3228200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
3a6ac0a1-e097-4405-8220-4fee9574388a	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	ec27a0e3-c3da-440b-9557-194b52d1fb1c	\N	3048600	D	csv	2025-12-15|Utilities|BWSSB|Water charges|3048600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
1ceb398b-c5c2-4647-b175-2eabf0be7035	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	ec27a0e3-c3da-440b-9557-194b52d1fb1c	\N	3008200	D	csv	2026-01-15|Utilities|BWSSB|Water charges|3008200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
48fbb060-9b09-49ff-8688-a53de51eb3ac	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	ec27a0e3-c3da-440b-9557-194b52d1fb1c	\N	3144100	D	csv	2026-02-15|Utilities|BWSSB|Water charges|3144100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
6e765b72-60b7-462b-b042-458db405c51d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	ec27a0e3-c3da-440b-9557-194b52d1fb1c	\N	3331400	D	csv	2026-03-15|Utilities|BWSSB|Water charges|3331400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
1ae327f1-5f40-4a0b-8f5d-bc82976b921b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	ec27a0e3-c3da-440b-9557-194b52d1fb1c	\N	3397900	D	csv	2026-04-15|Utilities|BWSSB|Water charges|3397900	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
2e355b76-74e0-43c7-85aa-39d1f9c6eab4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	ec27a0e3-c3da-440b-9557-194b52d1fb1c	\N	3282400	D	csv	2026-05-15|Utilities|BWSSB|Water charges|3282400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
d4b0fd55-2c11-40ec-8ee4-10ca47bc5cdf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	ec27a0e3-c3da-440b-9557-194b52d1fb1c	\N	3091200	D	csv	2026-06-15|Utilities|BWSSB|Water charges|3091200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
be7ef584-0abd-4c91-9704-a4a31885963b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	2b304b23-6390-4b36-8b80-1401a611e227	455a23f5-cd05-4d4e-bfd8-c3d365856bdd	8f64549f-f474-4bc3-a187-bfc822ff6ebe	ec27a0e3-c3da-440b-9557-194b52d1fb1c	\N	3000000	D	csv	2026-07-15|Utilities|BWSSB|Water charges|3000000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
02f72f4d-60b8-4569-817c-b3e8f88b6c1b	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	5a8f63e3-267b-4885-8618-8ce186889ce6	\N	6500000	D	csv	2025-08-15|Maintenance|ABC Enterprise|Labour charges|6500000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
d78752f0-3c7a-4729-9d3d-64f421fd8ff5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	5a8f63e3-267b-4885-8618-8ce186889ce6	\N	6752400	D	csv	2025-09-15|Maintenance|ABC Enterprise|Labour charges|6752400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
47ea0a27-03d7-46d9-9dc0-aae16988cdbe	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	5a8f63e3-267b-4885-8618-8ce186889ce6	\N	6772800	D	csv	2025-10-15|Maintenance|ABC Enterprise|Labour charges|6772800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
2d51dd1b-0f21-4e0b-b16a-1f990d8a04c7	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	5a8f63e3-267b-4885-8618-8ce186889ce6	\N	6542300	D	csv	2025-11-15|Maintenance|ABC Enterprise|Labour charges|6542300	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
c0dc9e91-70f0-4388-9725-4e702f23a604	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	5a8f63e3-267b-4885-8618-8ce186889ce6	\N	6273000	D	csv	2025-12-15|Maintenance|ABC Enterprise|Labour charges|6273000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
e55774c3-cd4b-44c6-ab2c-7cebd0674363	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	5a8f63e3-267b-4885-8618-8ce186889ce6	\N	6212300	D	csv	2026-01-15|Maintenance|ABC Enterprise|Labour charges|6212300	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
fb048dfc-3cd8-49ec-b660-bd6bee50dfc8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	5a8f63e3-267b-4885-8618-8ce186889ce6	\N	6416200	D	csv	2026-02-15|Maintenance|ABC Enterprise|Labour charges|6416200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
a356f656-f343-4a0f-99d8-e5cf59e98aad	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	5a8f63e3-267b-4885-8618-8ce186889ce6	\N	6697100	D	csv	2026-03-15|Maintenance|ABC Enterprise|Labour charges|6697100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
ba53fe6c-b904-4364-8003-5244052cb0e9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	5a8f63e3-267b-4885-8618-8ce186889ce6	\N	6796800	D	csv	2026-04-15|Maintenance|ABC Enterprise|Labour charges|6796800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
af6614f1-2045-400f-bc48-f057b25c9703	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	5a8f63e3-267b-4885-8618-8ce186889ce6	\N	6623600	D	csv	2026-05-15|Maintenance|ABC Enterprise|Labour charges|6623600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
45c556ab-de5d-4d64-9abd-521abf5d6dbb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	5a8f63e3-267b-4885-8618-8ce186889ce6	\N	6336800	D	csv	2026-06-15|Maintenance|ABC Enterprise|Labour charges|6336800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
3a78a5ae-feec-4460-843a-c760e07314b4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	5a8f63e3-267b-4885-8618-8ce186889ce6	\N	6200000	D	csv	2026-07-15|Maintenance|ABC Enterprise|Labour charges|6200000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
c7dcd5bb-cabd-48e8-b428-02e20a070bdf	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	29401a2e-0c96-403c-88e4-57983f3742e4	\N	1800000	D	csv	2025-08-15|Maintenance|ABC Enterprise|Spare parts|1800000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
ca790c1b-2533-4c1b-bab7-e7afdd1094ad	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	29401a2e-0c96-403c-88e4-57983f3742e4	\N	2345600	D	csv	2025-10-15|Maintenance|ABC Enterprise|Spare parts|2345600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
346d7094-5620-4d3d-be06-e732f301869b	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	29401a2e-0c96-403c-88e4-57983f3742e4	\N	1884700	D	csv	2025-11-15|Maintenance|ABC Enterprise|Spare parts|1884700	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
ad53340c-a95f-49a0-9ca1-09f2242f00b8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	29401a2e-0c96-403c-88e4-57983f3742e4	\N	1224600	D	csv	2026-01-15|Maintenance|ABC Enterprise|Spare parts|1224600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
11017dbb-a4f7-43ca-8713-637dcce67d28	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	29401a2e-0c96-403c-88e4-57983f3742e4	\N	1632400	D	csv	2026-02-15|Maintenance|ABC Enterprise|Spare parts|1632400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
193f7fd8-d9c5-43b4-8bbf-3d52b1a4bb08	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	29401a2e-0c96-403c-88e4-57983f3742e4	\N	2393600	D	csv	2026-04-15|Maintenance|ABC Enterprise|Spare parts|2393600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
a6d84d3a-ecb6-48b8-984c-d5ae6693af31	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	29401a2e-0c96-403c-88e4-57983f3742e4	\N	2047300	D	csv	2026-05-15|Maintenance|ABC Enterprise|Spare parts|2047300	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
d02a00a2-b170-454a-98b4-3583103d01a5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	29401a2e-0c96-403c-88e4-57983f3742e4	\N	1473600	D	csv	2026-06-15|Maintenance|ABC Enterprise|Spare parts|1473600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
bd45ec7d-d513-4e46-bf55-fcaf11184a70	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	29401a2e-0c96-403c-88e4-57983f3742e4	\N	1200000	D	csv	2026-07-15|Maintenance|ABC Enterprise|Spare parts|1200000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
3a02e95e-fad9-4028-8a86-697d1ca9ca62	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	9dd98399-f785-4e87-bfda-8275dd9fd92d	\N	945500	D	csv	2025-10-15|Maintenance|ABC Enterprise|STP salt purchase|945500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
4347d794-01fb-451d-8807-110eadf2f660	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	9dd98399-f785-4e87-bfda-8275dd9fd92d	\N	852100	D	csv	2026-01-15|Maintenance|ABC Enterprise|STP salt purchase|852100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
076ae1ea-1679-4ad8-a9c8-8fe4a8439546	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	9dd98399-f785-4e87-bfda-8275dd9fd92d	\N	949500	D	csv	2026-04-15|Maintenance|ABC Enterprise|STP salt purchase|949500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
bd3b0f64-a1e0-490d-8742-b85e48d001db	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	3e24f366-7fae-4c15-a653-4e63d879a9c0	9dd98399-f785-4e87-bfda-8275dd9fd92d	\N	850000	D	csv	2026-07-15|Maintenance|ABC Enterprise|STP salt purchase|850000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
59df5a97-f053-4c68-bc17-5899e659ca9f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	b53804ac-e36e-404f-b6f8-c5da53265a2e	e25734a9-b53c-4db5-a907-17f7a1c6f796	\N	744500	D	csv	2025-09-15|Maintenance|John (Plumber)|Plumbing repair|744500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
fa4a76ad-b354-49a5-9995-a4a592d2d581	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	b53804ac-e36e-404f-b6f8-c5da53265a2e	e25734a9-b53c-4db5-a907-17f7a1c6f796	\N	499400	D	csv	2025-11-15|Maintenance|John (Plumber)|Plumbing repair|499400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
780f8a99-f968-4587-9b7c-d584d02cfe21	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	b53804ac-e36e-404f-b6f8-c5da53265a2e	e25734a9-b53c-4db5-a907-17f7a1c6f796	\N	185100	D	csv	2025-12-15|Maintenance|John (Plumber)|Plumbing repair|185100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
7f9cdd44-1544-48a7-b9b2-96709fdd675c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	b53804ac-e36e-404f-b6f8-c5da53265a2e	e25734a9-b53c-4db5-a907-17f7a1c6f796	\N	679900	D	csv	2026-03-15|Maintenance|John (Plumber)|Plumbing repair|679900	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
76dd8499-b1a0-4938-b254-99fc9600d28f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	b53804ac-e36e-404f-b6f8-c5da53265a2e	e25734a9-b53c-4db5-a907-17f7a1c6f796	\N	594200	D	csv	2026-05-15|Maintenance|John (Plumber)|Plumbing repair|594200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
c0d7fa2b-02e6-4d9f-bc6f-808e4779d7ab	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	2b304b23-6390-4b36-8b80-1401a611e227	25942ad2-bd57-4975-a30c-b6b7803e7b3f	b53804ac-e36e-404f-b6f8-c5da53265a2e	e25734a9-b53c-4db5-a907-17f7a1c6f796	\N	259600	D	csv	2026-06-15|Maintenance|John (Plumber)|Plumbing repair|259600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
ac41bc32-39e3-4b4c-b141-6aa72b92a678	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	2b304b23-6390-4b36-8b80-1401a611e227	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	c543e21d-0dee-4f0b-91c4-0e909098bbc2	\N	12000000	D	csv	2025-08-15|Security|SafeGuard Services|Guard salaries|12000000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
7b55fe17-05d6-4678-bee5-5b0e5252025c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	2b304b23-6390-4b36-8b80-1401a611e227	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	c543e21d-0dee-4f0b-91c4-0e909098bbc2	\N	12168300	D	csv	2025-09-15|Security|SafeGuard Services|Guard salaries|12168300	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
f5a9aec1-0b5a-41c2-a7d6-bd3b0ee0a415	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	2b304b23-6390-4b36-8b80-1401a611e227	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	c543e21d-0dee-4f0b-91c4-0e909098bbc2	\N	12181900	D	csv	2025-10-15|Security|SafeGuard Services|Guard salaries|12181900	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
abeb4e22-fa0f-4f85-9a48-0962d9eaa743	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	2b304b23-6390-4b36-8b80-1401a611e227	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	c543e21d-0dee-4f0b-91c4-0e909098bbc2	\N	12028200	D	csv	2025-11-15|Security|SafeGuard Services|Guard salaries|12028200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
2d8d9984-86f9-4bd5-8f9a-0a208831101c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	2b304b23-6390-4b36-8b80-1401a611e227	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	c543e21d-0dee-4f0b-91c4-0e909098bbc2	\N	11848600	D	csv	2025-12-15|Security|SafeGuard Services|Guard salaries|11848600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
a37cf2f8-7de0-4ac2-832e-fd6679dabcd3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	2b304b23-6390-4b36-8b80-1401a611e227	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	c543e21d-0dee-4f0b-91c4-0e909098bbc2	\N	11808200	D	csv	2026-01-15|Security|SafeGuard Services|Guard salaries|11808200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
5453a9b8-4cf4-40d5-b64b-043ea6aac9f6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	2b304b23-6390-4b36-8b80-1401a611e227	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	c543e21d-0dee-4f0b-91c4-0e909098bbc2	\N	11944100	D	csv	2026-02-15|Security|SafeGuard Services|Guard salaries|11944100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
7e2b106c-22e6-42db-ad7b-49d06057f96f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	2b304b23-6390-4b36-8b80-1401a611e227	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	c543e21d-0dee-4f0b-91c4-0e909098bbc2	\N	12131400	D	csv	2026-03-15|Security|SafeGuard Services|Guard salaries|12131400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
b2b2ef0c-49b4-4527-9e1e-ceb980465919	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	2b304b23-6390-4b36-8b80-1401a611e227	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	c543e21d-0dee-4f0b-91c4-0e909098bbc2	\N	12197900	D	csv	2026-04-15|Security|SafeGuard Services|Guard salaries|12197900	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
5f6bec01-e1b1-41b0-9763-ceecd8d36130	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	2b304b23-6390-4b36-8b80-1401a611e227	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	c543e21d-0dee-4f0b-91c4-0e909098bbc2	\N	12082400	D	csv	2026-05-15|Security|SafeGuard Services|Guard salaries|12082400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
3b098caf-ff7a-4733-a52f-92d00e988f98	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	2b304b23-6390-4b36-8b80-1401a611e227	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	c543e21d-0dee-4f0b-91c4-0e909098bbc2	\N	11891200	D	csv	2026-06-15|Security|SafeGuard Services|Guard salaries|11891200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
e05962a5-f599-4a47-9f32-5d486246af17	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	2b304b23-6390-4b36-8b80-1401a611e227	5adeed80-8ff1-46c6-963b-3f26b1feba42	3fb98051-7eb3-419d-8359-03b99488ad11	c543e21d-0dee-4f0b-91c4-0e909098bbc2	\N	11800000	D	csv	2026-07-15|Security|SafeGuard Services|Guard salaries|11800000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
286b603f-15bc-43f0-96c3-3fff63801f94	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	a9a81406-0d42-485f-9c94-2582ca96d6e9	\N	5800000	D	csv	2025-08-15|Housekeeping|CleanCo|Staff wages|5800000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
79a996b0-4689-4c5f-9174-d463f0ea90b0	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	a9a81406-0d42-485f-9c94-2582ca96d6e9	\N	5926200	D	csv	2025-09-15|Housekeeping|CleanCo|Staff wages|5926200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
25a4cb4d-0582-4e9c-8f4d-22169738acf0	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	a9a81406-0d42-485f-9c94-2582ca96d6e9	\N	5936400	D	csv	2025-10-15|Housekeeping|CleanCo|Staff wages|5936400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
33bc1d1f-bd5f-4da7-9c5e-c24f730cc1e1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	a9a81406-0d42-485f-9c94-2582ca96d6e9	\N	5821200	D	csv	2025-11-15|Housekeeping|CleanCo|Staff wages|5821200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
7334bb77-432c-48b9-8848-c1cbe3e73275	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	a9a81406-0d42-485f-9c94-2582ca96d6e9	\N	5686500	D	csv	2025-12-15|Housekeeping|CleanCo|Staff wages|5686500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
1226d23a-307f-4e22-8097-63819eac76da	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	a9a81406-0d42-485f-9c94-2582ca96d6e9	\N	5656200	D	csv	2026-01-15|Housekeeping|CleanCo|Staff wages|5656200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
6a377a1a-e3d7-43e4-9cfe-fe1207e28e10	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	a9a81406-0d42-485f-9c94-2582ca96d6e9	\N	5758100	D	csv	2026-02-15|Housekeeping|CleanCo|Staff wages|5758100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
f550c842-4aef-4178-8fe6-f8930024017f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	a9a81406-0d42-485f-9c94-2582ca96d6e9	\N	5898500	D	csv	2026-03-15|Housekeeping|CleanCo|Staff wages|5898500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
f83fd2f3-2618-4149-bd54-e90b277b7402	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	a9a81406-0d42-485f-9c94-2582ca96d6e9	\N	5948400	D	csv	2026-04-15|Housekeeping|CleanCo|Staff wages|5948400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
783093d5-e7a2-483a-9818-c17cdf5545df	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	a9a81406-0d42-485f-9c94-2582ca96d6e9	\N	5861800	D	csv	2026-05-15|Housekeeping|CleanCo|Staff wages|5861800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
e2e5fe84-2a44-47fa-bcf9-0babae5d3e20	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	a9a81406-0d42-485f-9c94-2582ca96d6e9	\N	5718400	D	csv	2026-06-15|Housekeeping|CleanCo|Staff wages|5718400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
3211a343-5c30-46cb-90eb-03c3cf4de891	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	a9a81406-0d42-485f-9c94-2582ca96d6e9	\N	5650000	D	csv	2026-07-15|Housekeeping|CleanCo|Staff wages|5650000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
4e855f0f-546d-4e54-94bb-70c132db5fdc	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	4624ca4b-e2bf-461c-976d-ab4718550873	\N	750000	D	csv	2025-08-15|Housekeeping|CleanCo|Cleaning supplies|750000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
914d0347-eeed-4f7a-b48e-4fde9864225f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	4624ca4b-e2bf-461c-976d-ab4718550873	\N	876200	D	csv	2025-09-15|Housekeeping|CleanCo|Cleaning supplies|876200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
b1b8c809-a9c1-4aa6-9818-a7ef3c74da0c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	4624ca4b-e2bf-461c-976d-ab4718550873	\N	886400	D	csv	2025-10-15|Housekeeping|CleanCo|Cleaning supplies|886400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
36feac4b-11cc-4f2c-b05e-1c1c56121203	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	4624ca4b-e2bf-461c-976d-ab4718550873	\N	771200	D	csv	2025-11-15|Housekeeping|CleanCo|Cleaning supplies|771200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
1aadb41c-64c5-436b-a3c1-5d2900ca7972	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	4624ca4b-e2bf-461c-976d-ab4718550873	\N	636500	D	csv	2025-12-15|Housekeeping|CleanCo|Cleaning supplies|636500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
256a4217-793b-4239-bfa4-ecc1b233381b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	4624ca4b-e2bf-461c-976d-ab4718550873	\N	606200	D	csv	2026-01-15|Housekeeping|CleanCo|Cleaning supplies|606200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
4a460f70-f3d5-4171-b545-35e43ea738a3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	4624ca4b-e2bf-461c-976d-ab4718550873	\N	708100	D	csv	2026-02-15|Housekeeping|CleanCo|Cleaning supplies|708100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
b5b2c1a3-2863-438b-b9b4-e9f93a7ec0c2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	4624ca4b-e2bf-461c-976d-ab4718550873	\N	848500	D	csv	2026-03-15|Housekeeping|CleanCo|Cleaning supplies|848500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
44250ca1-e570-4b57-b48e-9680f4603985	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	4624ca4b-e2bf-461c-976d-ab4718550873	\N	898400	D	csv	2026-04-15|Housekeeping|CleanCo|Cleaning supplies|898400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
e36d103d-f26b-4788-9af9-5f0378795419	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	4624ca4b-e2bf-461c-976d-ab4718550873	\N	811800	D	csv	2026-05-15|Housekeeping|CleanCo|Cleaning supplies|811800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
6ffccabe-2fae-48ed-89a2-60981c3494fa	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	4624ca4b-e2bf-461c-976d-ab4718550873	\N	668400	D	csv	2026-06-15|Housekeeping|CleanCo|Cleaning supplies|668400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
eba7024d-7c37-4f88-857f-2f46b22b4522	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	2b304b23-6390-4b36-8b80-1401a611e227	94cea1f7-cb86-4d6d-9a1d-d9fd4dcaaf83	ca2816b6-cb52-4070-a5a4-8819919e6730	4624ca4b-e2bf-461c-976d-ab4718550873	\N	600000	D	csv	2026-07-15|Housekeeping|CleanCo|Cleaning supplies|600000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
57540e21-0ceb-4e57-90a0-a908fe1a5849	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	2b304b23-6390-4b36-8b80-1401a611e227	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	\N	600000	D	csv	2025-08-15|Petty Cash|Office petty cash|Ad-hoc expenses|600000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
d3ee14ee-ff40-4a9b-8257-a6b3db299e70	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	2b304b23-6390-4b36-8b80-1401a611e227	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	\N	1062800	D	csv	2025-09-15|Petty Cash|Office petty cash|Ad-hoc expenses|1062800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
bb7f7474-e50c-4f3a-8a09-e83bbe8e4327	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	2b304b23-6390-4b36-8b80-1401a611e227	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	\N	1100100	D	csv	2025-10-15|Petty Cash|Office petty cash|Ad-hoc expenses|1100100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
02c49717-f859-40f1-9129-6a76e463810c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	2b304b23-6390-4b36-8b80-1401a611e227	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	\N	677600	D	csv	2025-11-15|Petty Cash|Office petty cash|Ad-hoc expenses|677600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
1bf06a72-b26c-4707-ae51-ffce0b69fb68	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	2b304b23-6390-4b36-8b80-1401a611e227	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	\N	183800	D	csv	2025-12-15|Petty Cash|Office petty cash|Ad-hoc expenses|183800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
78a29602-17e3-482c-a62b-7750b43506d9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	2b304b23-6390-4b36-8b80-1401a611e227	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	\N	72600	D	csv	2026-01-15|Petty Cash|Office petty cash|Ad-hoc expenses|72600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
79dfd1c7-3123-4852-87f3-a6234ba69e60	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	2b304b23-6390-4b36-8b80-1401a611e227	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	\N	446300	D	csv	2026-02-15|Petty Cash|Office petty cash|Ad-hoc expenses|446300	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
6b9791bc-3dfc-48af-b5d6-c090c9716745	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	2b304b23-6390-4b36-8b80-1401a611e227	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	\N	961300	D	csv	2026-03-15|Petty Cash|Office petty cash|Ad-hoc expenses|961300	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
2616ef95-6166-4b04-ae7b-31ec4d8ba4df	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	2b304b23-6390-4b36-8b80-1401a611e227	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	\N	1144100	D	csv	2026-04-15|Petty Cash|Office petty cash|Ad-hoc expenses|1144100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
f03716c6-69f2-4b80-8f02-b912539ee15f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	2b304b23-6390-4b36-8b80-1401a611e227	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	\N	826700	D	csv	2026-05-15|Petty Cash|Office petty cash|Ad-hoc expenses|826700	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
cd049954-2c65-441c-93d1-8d6b575824c6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	2b304b23-6390-4b36-8b80-1401a611e227	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	\N	300800	D	csv	2026-06-15|Petty Cash|Office petty cash|Ad-hoc expenses|300800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
cb01525d-e5ad-4782-9906-9d8c31df658a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	2b304b23-6390-4b36-8b80-1401a611e227	950a91fe-dd86-4350-a419-06258dc38dbc	07377987-75ef-4bc2-890f-dbe1d0216bb8	22fca8fa-d65b-4bfb-9a28-8cc2e0f736d3	\N	50000	D	csv	2026-07-15|Petty Cash|Office petty cash|Ad-hoc expenses|50000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
39ccd8fd-bab3-4a7c-a0da-b8cc3984f7d6	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	\N	34000000	C	csv	2025-08-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|34000000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
81c6ad31-d766-4f2b-99c9-6a2b800fcff4	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	\N	35262200	C	csv	2025-09-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|35262200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
051785f8-0d5b-433c-ba4e-44ab7c6a64bd	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	\N	35363900	C	csv	2025-10-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|35363900	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
8ad919db-ea58-4134-90d8-164b86025754	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	\N	34211700	C	csv	2025-11-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|34211700	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
e8b594dd-ebf6-4733-8fdb-825d26760087	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	\N	32864800	C	csv	2025-12-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|32864800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
dd9b3e51-41c9-4d17-9075-52e2ebe693c2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	\N	32561600	C	csv	2026-01-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|32561600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
a4e24deb-51fb-4773-b5f8-ab89244bf74f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	\N	33580900	C	csv	2026-02-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|33580900	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
54552f06-3634-4d2d-b812-3a13b8531274	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	\N	34985500	C	csv	2026-03-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|34985500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
6964e0ab-e50b-476f-bff9-cac906201135	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	\N	35484000	C	csv	2026-04-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|35484000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
b95555ca-0f8c-43c8-9f05-e7784021da85	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	\N	34618200	C	csv	2026-05-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|34618200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
6a7a57be-3119-44cd-afc0-5376f47f488a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	\N	33184000	C	csv	2026-06-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|33184000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
a8920177-dbeb-47d5-9afa-7dc76a8f1a9f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	0e8cf05b-a0bd-4751-aa40-30728926c822	47bf53ff-56d4-4ec6-a3c6-278681b634d0	26aadc1a-f2b0-401b-a4d1-e76bbe56c09c	\N	32500000	C	csv	2026-07-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|32500000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
23059f99-0929-4b80-ac86-f9895022eedb	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	0bf19380-9c34-4d4b-be1d-20e5a6922dac	\N	1800000	C	csv	2025-08-15|Other Income|Community Hall|Hall rental|1800000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
ebbb8a49-38d5-4d27-bd72-747c112e3aec	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	0bf19380-9c34-4d4b-be1d-20e5a6922dac	\N	2527400	C	csv	2025-10-15|Other Income|Community Hall|Hall rental|2527400	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
eabf130f-5d64-4d6d-8935-f75eee25e4bf	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	0bf19380-9c34-4d4b-be1d-20e5a6922dac	\N	1912900	C	csv	2025-11-15|Other Income|Community Hall|Hall rental|1912900	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
0579ed79-4842-43e6-9178-82249f61a814	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	0bf19380-9c34-4d4b-be1d-20e5a6922dac	\N	1194600	C	csv	2025-12-15|Other Income|Community Hall|Hall rental|1194600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
ab0245bf-1261-4689-a64c-e50fe24b305a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	0bf19380-9c34-4d4b-be1d-20e5a6922dac	\N	1576500	C	csv	2026-02-15|Other Income|Community Hall|Hall rental|1576500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
3d47199c-e011-436e-92df-4834a8b19d37	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	0bf19380-9c34-4d4b-be1d-20e5a6922dac	\N	2325600	C	csv	2026-03-15|Other Income|Community Hall|Hall rental|2325600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
309c16f7-4af5-4485-9db5-f06c25c6c10e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	0bf19380-9c34-4d4b-be1d-20e5a6922dac	\N	2591500	C	csv	2026-04-15|Other Income|Community Hall|Hall rental|2591500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
9ed14aa7-b293-473f-a67e-884d2ce051a0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	0bf19380-9c34-4d4b-be1d-20e5a6922dac	\N	1364800	C	csv	2026-06-15|Other Income|Community Hall|Hall rental|1364800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
2998fe42-4520-4588-964f-b01ed1930a2a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	0bf19380-9c34-4d4b-be1d-20e5a6922dac	\N	1000000	C	csv	2026-07-15|Other Income|Community Hall|Hall rental|1000000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
77c7c10d-4e23-4bf9-8f2b-82e4b2a3ac9a	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	96c67d4f-edb4-48b7-b8e2-0d3bb3864f8f	\N	978700	C	csv	2025-09-15|Other Income|Community Hall|Event usage charges|978700	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
61f2c572-3aca-4ada-b4dc-a045898999d1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	96c67d4f-edb4-48b7-b8e2-0d3bb3864f8f	\N	663500	C	csv	2025-11-15|Other Income|Community Hall|Event usage charges|663500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
5fa1349c-0fcb-4f3b-9bb7-db4125ad8795	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	96c67d4f-edb4-48b7-b8e2-0d3bb3864f8f	\N	168500	C	csv	2026-01-15|Other Income|Community Hall|Event usage charges|168500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
6f06b342-a60e-48ee-a289-4c562d06ad53	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	96c67d4f-edb4-48b7-b8e2-0d3bb3864f8f	\N	895600	C	csv	2026-03-15|Other Income|Community Hall|Event usage charges|895600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
1b1cb228-c711-4b2e-8860-484ebaaca02e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	96c67d4f-edb4-48b7-b8e2-0d3bb3864f8f	\N	785500	C	csv	2026-05-15|Other Income|Community Hall|Event usage charges|785500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
73745340-d9b0-45fe-a6b1-f8e380604de6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	45b86bc4-a76d-4455-93c6-50cb8e867fc5	96c67d4f-edb4-48b7-b8e2-0d3bb3864f8f	\N	150000	C	csv	2026-07-15|Other Income|Community Hall|Event usage charges|150000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
eb4384cc-8884-493d-975e-ce2808f9d0a0	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	\N	1200000	C	csv	2025-08-15|Other Income|Signage Rental|Billboard fee|1200000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
e95ac847-402a-468e-a312-a780ebaa7f85	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	\N	1242100	C	csv	2025-09-15|Other Income|Signage Rental|Billboard fee|1242100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
8763c872-b48e-42dc-8b31-eb0cc8db5311	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	\N	1245500	C	csv	2025-10-15|Other Income|Signage Rental|Billboard fee|1245500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
6d0a6dbc-b70a-4ad3-b23d-988f7aeae771	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	\N	1207100	C	csv	2025-11-15|Other Income|Signage Rental|Billboard fee|1207100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
fb37a7bf-5dd3-4ae6-b141-395abc3fd65c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	\N	1162200	C	csv	2025-12-15|Other Income|Signage Rental|Billboard fee|1162200	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
1593a338-3736-4685-a805-37f6e5bc1676	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	\N	1152100	C	csv	2026-01-15|Other Income|Signage Rental|Billboard fee|1152100	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
560b2507-b5d4-40f3-925c-078340e881e3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	\N	1186000	C	csv	2026-02-15|Other Income|Signage Rental|Billboard fee|1186000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
95845e8d-4367-4867-a1d5-24fcbf90f278	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	\N	1232800	C	csv	2026-03-15|Other Income|Signage Rental|Billboard fee|1232800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
e17f81ec-c7fb-40e7-888a-20c97edc1cdd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	\N	1249500	C	csv	2026-04-15|Other Income|Signage Rental|Billboard fee|1249500	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
ba4d1e2b-1c3a-4d54-82e0-7c286e1fdc3c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	\N	1220600	C	csv	2026-05-15|Other Income|Signage Rental|Billboard fee|1220600	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
4842d4c7-a3b0-4721-9dc6-07072ba2e4a0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	\N	1172800	C	csv	2026-06-15|Other Income|Signage Rental|Billboard fee|1172800	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
49a6d85e-7a35-467b-b961-acf989e44c7c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	d40b3d73-99c5-4e0a-958c-1d4700b351bb	100e858a-f0ad-4449-8b44-4049067c09b8	a9bf1d7d-145a-4ce2-902e-936b5430f536	b8e2ba3a-910d-4fcb-9ff5-b0618bf8bc4a	\N	1150000	C	csv	2026-07-15|Other Income|Signage Rental|Billboard fee|1150000	\N	\N	2026-07-13 14:24:38.511364+00	2026-07-13 14:24:38.511364+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	superadmin
0f0c6024-6c4d-47b3-9012-4f714d448a40	admin
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, community_id, email, name, password_hash, last_login_at, created_at) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	caa11b01-c3a5-4067-a90c-b73b35075def	admin@example.com	Super Admin	$argon2id$v=19$m=65536,t=3,p=4$tz7RMjj1QyFsjXCWDZLqgQ$tVCinqN39Lp3ZgjwEPKQF9GfJwlAxuxFjK/Bus6oVyE	2026-07-25 08:24:06.240508+00	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, community_id, name, kind) FROM stdin;
fd61e98b-a8cb-4e5e-a25d-dcf6ddb7822d	caa11b01-c3a5-4067-a90c-b73b35075def	Bescom	company
8f64549f-f474-4bc3-a187-bfc822ff6ebe	caa11b01-c3a5-4067-a90c-b73b35075def	BWSSB	company
3e24f366-7fae-4c15-a653-4e63d879a9c0	caa11b01-c3a5-4067-a90c-b73b35075def	ABC Enterprise	company
b53804ac-e36e-404f-b6f8-c5da53265a2e	caa11b01-c3a5-4067-a90c-b73b35075def	John (Plumber)	individual
3fb98051-7eb3-419d-8359-03b99488ad11	caa11b01-c3a5-4067-a90c-b73b35075def	SafeGuard Services	company
ca2816b6-cb52-4070-a5a4-8819919e6730	caa11b01-c3a5-4067-a90c-b73b35075def	CleanCo	company
07377987-75ef-4bc2-890f-dbe1d0216bb8	caa11b01-c3a5-4067-a90c-b73b35075def	Office petty cash	individual
47bf53ff-56d4-4ec6-a3c6-278681b634d0	caa11b01-c3a5-4067-a90c-b73b35075def	Monthly maintenance	company
45b86bc4-a76d-4455-93c6-50cb8e867fc5	caa11b01-c3a5-4067-a90c-b73b35075def	Community Hall	company
a9bf1d7d-145a-4ce2-902e-936b5430f536	caa11b01-c3a5-4067-a90c-b73b35075def	Signage Rental	individual
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 2, true);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (name);


--
-- Name: allowed_emails allowed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_pkey PRIMARY KEY (email);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: balances balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_pkey PRIMARY KEY (community_id, month);


--
-- Name: categories categories_head_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_name_key UNIQUE (head_id, name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: collections_dues collections_dues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_pkey PRIMARY KEY (flat_id, period_month);


--
-- Name: communities communities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communities
    ADD CONSTRAINT communities_pkey PRIMARY KEY (id);


--
-- Name: dashboard_settings dashboard_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_pkey PRIMARY KEY (community_id, dashboard_key);


--
-- Name: flats flats_community_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_code_key UNIQUE (community_id, code);


--
-- Name: flats flats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_pkey PRIMARY KEY (id);


--
-- Name: heads heads_community_id_kind_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_kind_name_key UNIQUE (community_id, kind, name);


--
-- Name: heads heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_rules import_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_pkey PRIMARY KEY (id);


--
-- Name: import_staging import_staging_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_pkey PRIMARY KEY (batch_id, row_no);


--
-- Name: line_items line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_pkey PRIMARY KEY (id);


--
-- Name: otp_codes magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (email, otp_hash);


--
-- Name: periods periods_community_id_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_month_key UNIQUE (community_id, month);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_source_source_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_source_source_ref_key UNIQUE (source, source_ref);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_community_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_name_key UNIQUE (community_id, name);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_at ON public.audit_log USING btree (at DESC);


--
-- Name: idx_audit_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_entity ON public.audit_log USING btree (entity, entity_id);


--
-- Name: idx_txn_category_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_category_month ON public.transactions USING btree (category_id, period_month);


--
-- Name: idx_txn_community_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_community_month ON public.transactions USING btree (community_id, period_month);


--
-- Name: idx_txn_flat_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_flat_month ON public.transactions USING btree (flat_id, period_month);


--
-- Name: idx_txn_head_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_head_month ON public.transactions USING btree (head_id, period_month);


--
-- Name: idx_txn_vendor_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_vendor_month ON public.transactions USING btree (vendor_id, period_month);


--
-- Name: line_items_cat_vendor_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX line_items_cat_vendor_name_uq ON public.line_items USING btree (category_id, COALESCE(vendor_id, '00000000-0000-0000-0000-000000000000'::uuid), name);


--
-- Name: mv_cat_monthly_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_cat_monthly_idx ON public.mv_category_monthly USING btree (community_id, month);


--
-- Name: mv_monthly_totals_pk; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mv_monthly_totals_pk ON public.mv_monthly_totals USING btree (community_id, month);


--
-- Name: mv_vendor_ranking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_vendor_ranking_idx ON public.mv_vendor_ranking USING btree (community_id, total_expense_paise DESC);


--
-- Name: allowed_emails allowed_emails_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: allowed_emails allowed_emails_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE SET NULL;


--
-- Name: balances balances_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: categories categories_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id) ON DELETE CASCADE;


--
-- Name: collections_dues collections_dues_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE CASCADE;


--
-- Name: dashboard_settings dashboard_settings_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: flats flats_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: heads heads_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: import_rules import_rules_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_staging import_staging_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE SET NULL;


--
-- Name: periods periods_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: transactions transactions_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id);


--
-- Name: transactions transactions_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id);


--
-- Name: transactions transactions_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_line_item_id_fkey FOREIGN KEY (line_item_id) REFERENCES public.line_items(id);


--
-- Name: transactions transactions_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: vendors vendors_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_category_monthly;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_monthly_totals;


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_vendor_ranking;


--
-- PostgreSQL database dump complete
--

\unrestrict Y9oCcYRweuX3saQ79NiCxpKi6mEz6chrwXcafVRuQYMCg4GXF7Gg67t3rBPAB4T

