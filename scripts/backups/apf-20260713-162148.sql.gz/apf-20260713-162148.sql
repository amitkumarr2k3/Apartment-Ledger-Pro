--
-- PostgreSQL database dump
--

\restrict QeSzyT7AMUetfb5MYmgQIHFIBzwXjrsJl5dVsoiDzglG7thXRUU8arjtc2RRdk9

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_line_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_batch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_actor_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_community_id_fkey;
DROP INDEX IF EXISTS public.mv_vendor_ranking_idx;
DROP INDEX IF EXISTS public.mv_monthly_totals_pk;
DROP INDEX IF EXISTS public.mv_cat_monthly_idx;
DROP INDEX IF EXISTS public.line_items_cat_vendor_name_uq;
DROP INDEX IF EXISTS public.idx_txn_vendor_month;
DROP INDEX IF EXISTS public.idx_txn_head_month;
DROP INDEX IF EXISTS public.idx_txn_flat_month;
DROP INDEX IF EXISTS public.idx_txn_community_month;
DROP INDEX IF EXISTS public.idx_txn_category_month;
DROP INDEX IF EXISTS public.idx_audit_entity;
DROP INDEX IF EXISTS public.idx_audit_at;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_pkey;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_name_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_source_source_ref_key;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_month_key;
ALTER TABLE IF EXISTS ONLY public.otp_codes DROP CONSTRAINT IF EXISTS magic_links_pkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_pkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_pkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_kind_name_key;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_pkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_code_key;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.communities DROP CONSTRAINT IF EXISTS communities_pkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_name_key;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_pkey;
ALTER TABLE IF EXISTS ONLY public._migrations DROP CONSTRAINT IF EXISTS _migrations_pkey;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.periods;
DROP TABLE IF EXISTS public.otp_codes;
DROP MATERIALIZED VIEW IF EXISTS public.mv_vendor_ranking;
DROP TABLE IF EXISTS public.vendors;
DROP MATERIALIZED VIEW IF EXISTS public.mv_monthly_totals;
DROP MATERIALIZED VIEW IF EXISTS public.mv_category_monthly;
DROP TABLE IF EXISTS public.transactions;
DROP TABLE IF EXISTS public.line_items;
DROP TABLE IF EXISTS public.import_staging;
DROP TABLE IF EXISTS public.import_rules;
DROP TABLE IF EXISTS public.import_batches;
DROP TABLE IF EXISTS public.heads;
DROP TABLE IF EXISTS public.flats;
DROP TABLE IF EXISTS public.dashboard_settings;
DROP TABLE IF EXISTS public.communities;
DROP TABLE IF EXISTS public.collections_dues;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.balances;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP TABLE IF EXISTS public.allowed_emails;
DROP TABLE IF EXISTS public._migrations;
DROP TYPE IF EXISTS public.vendor_kind;
DROP TYPE IF EXISTS public.head_kind;
DROP TYPE IF EXISTS public.app_role;
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'resident',
    'admin',
    'superadmin'
);


--
-- Name: head_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.head_kind AS ENUM (
    'income',
    'expense'
);


--
-- Name: vendor_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vendor_kind AS ENUM (
    'company',
    'individual'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    name text NOT NULL,
    run_at timestamp with time zone DEFAULT now()
);


--
-- Name: allowed_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allowed_emails (
    email text NOT NULL,
    community_id uuid NOT NULL,
    role public.app_role NOT NULL,
    flat_id uuid,
    name text,
    invited_by text,
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    community_id uuid,
    actor_user_id uuid,
    actor_email text,
    entity text NOT NULL,
    entity_id text,
    action text NOT NULL,
    before jsonb,
    after jsonb,
    at timestamp with time zone DEFAULT now() NOT NULL,
    ip text,
    user_agent text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balances (
    community_id uuid NOT NULL,
    month date NOT NULL,
    opening_paise bigint DEFAULT 0 NOT NULL,
    closing_paise bigint DEFAULT 0 NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    head_id uuid NOT NULL,
    name text NOT NULL
);


--
-- Name: collections_dues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections_dues (
    flat_id uuid NOT NULL,
    period_month date NOT NULL,
    dues_paise bigint DEFAULT 0 NOT NULL,
    paid_paise bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'due'::text NOT NULL
);


--
-- Name: communities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    fy_start_month smallint DEFAULT 4 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dashboard_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_settings (
    community_id uuid NOT NULL,
    dashboard_key text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    hidden_widgets text[] DEFAULT '{}'::text[] NOT NULL
);


--
-- Name: flats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    code text NOT NULL,
    owner_email text
);


--
-- Name: heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind public.head_kind NOT NULL,
    name text NOT NULL
);


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    filename text NOT NULL,
    kind text NOT NULL,
    uploaded_by uuid,
    status text DEFAULT 'staged'::text NOT NULL,
    error text,
    row_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind text NOT NULL,
    match jsonb NOT NULL,
    set_fields jsonb NOT NULL,
    priority integer DEFAULT 100 NOT NULL
);


--
-- Name: import_staging; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_staging (
    batch_id uuid NOT NULL,
    row_no integer NOT NULL,
    raw_json jsonb NOT NULL,
    mapped_json jsonb,
    error text
);


--
-- Name: line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    name text NOT NULL,
    first_seen_month date,
    last_seen_month date
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    txn_date date NOT NULL,
    period_month date NOT NULL,
    head_id uuid NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    line_item_id uuid,
    flat_id uuid,
    amount_paise bigint NOT NULL,
    direction character(1) NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    source_ref text,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT transactions_amount_paise_check CHECK ((amount_paise >= 0)),
    CONSTRAINT transactions_direction_check CHECK ((direction = ANY (ARRAY['C'::bpchar, 'D'::bpchar])))
);


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_category_monthly AS
 SELECT t.community_id,
    t.category_id,
    c.name AS category_name,
    h.kind AS head_kind,
    t.period_month AS month,
    (sum(t.amount_paise))::bigint AS amount_paise
   FROM ((public.transactions t
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON ((h.id = t.head_id)))
  GROUP BY t.community_id, t.category_id, c.name, h.kind, t.period_month
  WITH NO DATA;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_monthly_totals AS
 WITH spine AS (
         SELECT c.id AS community_id,
            (date_trunc('month'::text, gs.gs))::date AS month
           FROM (public.communities c
             CROSS JOIN generate_series((( SELECT COALESCE(min(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, (( SELECT COALESCE(max(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, '1 mon'::interval) gs(gs))
        )
 SELECT s.community_id,
    s.month,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric))::bigint AS collection_paise,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric))::bigint AS expense_paise,
    ((COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric) - COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric)))::bigint AS net_paise
   FROM (spine s
     LEFT JOIN public.transactions t ON (((t.community_id = s.community_id) AND (t.period_month = s.month))))
  GROUP BY s.community_id, s.month
  WITH NO DATA;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    name text NOT NULL,
    kind public.vendor_kind DEFAULT 'company'::public.vendor_kind NOT NULL
);


--
-- Name: TABLE vendors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vendors IS 'Vendor dimension. Read-only from admin UI; populated via CSV import + on-the-fly during transaction ingest.';


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_vendor_ranking AS
 SELECT t.community_id,
    v.id AS vendor_id,
    v.name AS vendor_name,
    v.kind AS vendor_kind,
    COALESCE(string_agg(DISTINCT c.name, ', '::text), ''::text) AS categories,
    (sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)))::bigint AS total_expense_paise,
    count(DISTINCT t.period_month) AS months_active
   FROM (((public.transactions t
     JOIN public.vendors v ON ((v.id = t.vendor_id)))
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON (((h.id = t.head_id) AND (h.kind = 'expense'::public.head_kind))))
  GROUP BY t.community_id, v.id, v.name, v.kind
  WITH NO DATA;


--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_codes (
    email text NOT NULL,
    otp_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone
);


--
-- Name: periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    month date NOT NULL,
    status text DEFAULT 'open'::text NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role public.app_role NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    email text NOT NULL,
    name text,
    password_hash text,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._migrations (name, run_at) FROM stdin;
0001_init.sql	2026-07-13 09:33:54.325042+00
0002_indexes.sql	2026-07-13 09:33:54.347299+00
0003_mviews.sql	2026-07-13 09:33:54.380291+00
0004_otp_rename.sql	2026-07-13 09:33:54.38385+00
\.


--
-- Data for Name: allowed_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allowed_emails (email, community_id, role, flat_id, name, invited_by, invited_at, revoked_at) FROM stdin;
treasurer@example.com	3dea846d-5182-4c78-8fcd-fabb1a80ee61	admin	\N	Treasurer	system	2026-07-13 09:33:54.398256+00	\N
resident@example.com	3dea846d-5182-4c78-8fcd-fabb1a80ee61	resident	\N	Demo Resident	system	2026-07-13 09:33:54.398256+00	\N
admin@example.com	3dea846d-5182-4c78-8fcd-fabb1a80ee61	superadmin	\N	Super Admin	system	2026-07-13 09:33:54.398256+00	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, community_id, actor_user_id, actor_email, entity, entity_id, action, before, after, at, ip, user_agent) FROM stdin;
1	3dea846d-5182-4c78-8fcd-fabb1a80ee61	345358dc-316f-433a-92f6-a37b149e08a2	admin@example.com	auth	\N	login	\N	\N	2026-07-13 09:52:06.165342+00	172.26.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
2	3dea846d-5182-4c78-8fcd-fabb1a80ee61	345358dc-316f-433a-92f6-a37b149e08a2	admin@example.com	auth	\N	login	\N	\N	2026-07-13 10:47:53.786955+00	172.26.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
3	3dea846d-5182-4c78-8fcd-fabb1a80ee61	345358dc-316f-433a-92f6-a37b149e08a2	admin@example.com	auth	\N	login	\N	\N	2026-07-13 10:51:11.381451+00	172.26.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
\.


--
-- Data for Name: balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.balances (community_id, month, opening_paise, closing_paise) FROM stdin;
3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-01	85000000	85350000
3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-01	85350000	85303200
3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-01	85303200	85725700
3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-01	85725700	86162300
3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-01	86162300	88089400
3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-01	88089400	87250400
3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-01	87250400	87754100
3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-01	87754100	90152800
3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-01	90152800	90555500
3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-01	90555500	88740600
3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-01	88740600	89130200
3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-01	89130200	89330200
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, head_id, name) FROM stdin;
e0ae57ca-6a78-4459-ada0-38b354beb849	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	Utilities
531e64d6-3d5e-410a-927a-ab20f191e052	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	Maintenance
21a451dc-3dad-4b2e-80d6-ecf6a2529537	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	Security
0529a542-968d-4c4e-8bd3-176f94feff0e	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	Housekeeping
c6e72096-3add-4b2b-ab4e-e078a03102a2	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	Petty Cash
4f561960-40d3-4400-be9c-39063480a0fc	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	Maintenance Collections
0912efbb-45d6-4f91-a943-5b67304415c3	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	Other Income
\.


--
-- Data for Name: collections_dues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections_dues (flat_id, period_month, dues_paise, paid_paise, status) FROM stdin;
\.


--
-- Data for Name: communities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communities (id, name, currency, fy_start_month, created_at) FROM stdin;
3dea846d-5182-4c78-8fcd-fabb1a80ee61	Green Meadows	INR	4	2026-07-13 09:33:54.398256+00
\.


--
-- Data for Name: dashboard_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_settings (community_id, dashboard_key, enabled, hidden_widgets) FROM stdin;
3dea846d-5182-4c78-8fcd-fabb1a80ee61	resident.overview	t	{}
3dea846d-5182-4c78-8fcd-fabb1a80ee61	resident.drilldown	t	{}
3dea846d-5182-4c78-8fcd-fabb1a80ee61	resident.cashflow	t	{}
3dea846d-5182-4c78-8fcd-fabb1a80ee61	resident.income	t	{}
3dea846d-5182-4c78-8fcd-fabb1a80ee61	resident.balance	t	{}
\.


--
-- Data for Name: flats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flats (id, community_id, code, owner_email) FROM stdin;
8bf30656-67e0-4547-aa5e-5248a44c0c96	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-001	\N
46f12b55-76bc-4c0b-92c2-26d55cd9499d	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-002	\N
4736f5e3-24df-4780-a9e3-5877d7aec278	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-003	\N
377b73aa-a543-4fde-a1b9-c0fd6f6acd66	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-004	\N
2635b334-48bd-48d9-b1b5-a387ff8d3e74	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-005	\N
550e1c25-6e5b-42a2-9cce-5925163e09eb	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-006	\N
4bb06039-b1fc-4fd7-afae-bae317def27d	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-007	\N
f0cc5bda-b148-4b0c-93ff-2a8bad71f7d4	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-008	\N
e5afe313-9e21-4220-98a7-145e29c0c881	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-009	\N
375e042a-76b9-4bc7-8736-958e1ff401e2	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-010	\N
f370b4b9-b9d8-4590-aa31-0aaebae9a914	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-011	\N
ee982986-36de-4b66-98f5-b647527c442c	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-012	\N
aa7e15b9-9f06-4afc-8f67-57730eb5c204	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-013	\N
ec0b66a7-4ce9-47bc-b06d-b72fda9b302c	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-014	\N
09ba70f1-721d-49fd-997a-4141ded786cf	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-015	\N
93851498-8af1-46f7-92d4-2a0905e3e76e	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-016	\N
3ad3da76-8e54-4a09-968f-eff585d16f95	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-017	\N
3922f748-a47a-4257-ad46-39f60f75cf78	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-018	\N
f166ee64-5bf0-46be-b843-007a00ea9dd1	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-019	\N
f24472ef-1fd1-4e99-8257-11ff71c69802	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-020	\N
52663f11-4f77-4629-91ae-c9fe032703d4	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-021	\N
cbc7d540-e340-4db6-a594-29a2f451e085	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-022	\N
aba8dc48-993c-4dd6-ba87-938cdae214d5	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-023	\N
5dca130b-055f-4411-bae7-32fdeb546dc8	3dea846d-5182-4c78-8fcd-fabb1a80ee61	A-024	\N
\.


--
-- Data for Name: heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heads (id, community_id, kind, name) FROM stdin;
2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	3dea846d-5182-4c78-8fcd-fabb1a80ee61	expense	Operating Expenses
40b58237-30d3-40a3-ab0a-1a6fe75f62bb	3dea846d-5182-4c78-8fcd-fabb1a80ee61	income	Operating Income
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, community_id, filename, kind, uploaded_by, status, error, row_count, created_at) FROM stdin;
\.


--
-- Data for Name: import_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_rules (id, community_id, kind, match, set_fields, priority) FROM stdin;
\.


--
-- Data for Name: import_staging; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_staging (batch_id, row_no, raw_json, mapped_json, error) FROM stdin;
\.


--
-- Data for Name: line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_items (id, category_id, vendor_id, name, first_seen_month, last_seen_month) FROM stdin;
e4dda2c4-0578-4129-87f4-deeb60864605	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	Common area electricity	2025-08-01	2026-07-01
c882feef-ed93-465a-adc4-acd29a1f3d19	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	Backup usage	2025-08-01	2026-07-01
429d0ec9-40e1-47ab-b1ec-52f933fe2f52	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	Water charges	2025-08-01	2026-07-01
43d73c5a-bde0-4158-802b-7ad1764a6cb3	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	Labour charges	2025-08-01	2026-07-01
0dc9bd64-f98e-4802-b8fd-175e8f3a3e75	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	Spare parts	2025-08-01	2026-07-01
17df501e-2f4c-400c-b697-c6d3d6d58beb	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	STP salt purchase	2025-10-01	2026-07-01
15cd27a9-83bb-4b32-967f-50d9e6d0962f	531e64d6-3d5e-410a-927a-ab20f191e052	03fe3f5f-cd32-480e-99b8-832b6914d30a	Plumbing repair	2025-09-01	2026-06-01
69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	Guard salaries	2025-08-01	2026-07-01
e3dc12ec-ac0c-4a57-ba82-b1496d556527	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	Staff wages	2025-08-01	2026-07-01
4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	Cleaning supplies	2025-08-01	2026-07-01
c2f94f2b-021d-455a-9bfb-11d86621cf17	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	Ad-hoc expenses	2025-08-01	2026-07-01
b4bdb55c-d959-493b-aca4-2d6acfec80bd	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	Flat maintenance dues	2025-08-01	2026-07-01
98d1b9a4-609a-41db-9d38-5002e9ce3fb4	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	Hall rental	2025-08-01	2026-07-01
b70f8f10-f79c-43b0-b6f4-fad005b61be3	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	Event usage charges	2025-09-01	2026-07-01
9fcd6632-4b80-48f9-8ecc-e14ab03b118f	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	Billboard fee	2025-08-01	2026-07-01
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp_codes (email, otp_hash, expires_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periods (id, community_id, month, status) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, community_id, txn_date, period_month, head_id, category_id, vendor_id, line_item_id, flat_id, amount_paise, direction, source, source_ref, notes, created_by, created_at, updated_at) FROM stdin;
da081f54-283f-460c-ba02-d5d9c710ed97	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-15	2025-08-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	e4dda2c4-0578-4129-87f4-deeb60864605	\N	4800000	D	seed	seed|Utilities|Bescom|Common area electricity|2025-08-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
34a02736-5532-455d-9369-2fb367c3b89a	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-15	2025-09-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	e4dda2c4-0578-4129-87f4-deeb60864605	\N	5136600	D	seed	seed|Utilities|Bescom|Common area electricity|2025-09-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
aac8be9e-4592-4690-b1df-44a38a01f850	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-15	2025-10-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	e4dda2c4-0578-4129-87f4-deeb60864605	\N	5163700	D	seed	seed|Utilities|Bescom|Common area electricity|2025-10-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
ccace56d-e93f-4afa-8160-51344ff6006e	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	e4dda2c4-0578-4129-87f4-deeb60864605	\N	4856400	D	seed	seed|Utilities|Bescom|Common area electricity|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
bfb3cd1e-167b-43a4-9831-f25f7b7902ce	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-15	2025-12-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	e4dda2c4-0578-4129-87f4-deeb60864605	\N	4497300	D	seed	seed|Utilities|Bescom|Common area electricity|2025-12-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
34e6e313-e981-4faf-8fa3-b989db7be49c	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	e4dda2c4-0578-4129-87f4-deeb60864605	\N	4416400	D	seed	seed|Utilities|Bescom|Common area electricity|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
f5d35f69-5128-4c14-a971-74d542a348de	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-15	2026-02-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	e4dda2c4-0578-4129-87f4-deeb60864605	\N	4688200	D	seed	seed|Utilities|Bescom|Common area electricity|2026-02-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
2adbd8ff-4d72-4647-8f55-771d06d5d1e2	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	e4dda2c4-0578-4129-87f4-deeb60864605	\N	5062800	D	seed	seed|Utilities|Bescom|Common area electricity|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
79166813-3da4-4ecd-b5d9-a05374c5c2f9	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-15	2026-04-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	e4dda2c4-0578-4129-87f4-deeb60864605	\N	5195700	D	seed	seed|Utilities|Bescom|Common area electricity|2026-04-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
0cd5298b-cffc-4cd7-a5a1-7f8173ba2eb2	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	e4dda2c4-0578-4129-87f4-deeb60864605	\N	4964800	D	seed	seed|Utilities|Bescom|Common area electricity|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
384e3d11-b1d2-4469-8501-9254607b6454	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	e4dda2c4-0578-4129-87f4-deeb60864605	\N	4582400	D	seed	seed|Utilities|Bescom|Common area electricity|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
33d7f54d-d082-4d2c-a2e0-a1942628ae75	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	e4dda2c4-0578-4129-87f4-deeb60864605	\N	4400000	D	seed	seed|Utilities|Bescom|Common area electricity|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
93e47eb9-5f48-4bee-ba7d-a8befb0cd8f3	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-15	2025-08-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	c882feef-ed93-465a-adc4-acd29a1f3d19	\N	1200000	D	seed	seed|Utilities|Bescom|Backup usage|2025-08-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
6138f18a-2a90-4a87-88fa-d88141426664	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-15	2025-09-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	c882feef-ed93-465a-adc4-acd29a1f3d19	\N	1494500	D	seed	seed|Utilities|Bescom|Backup usage|2025-09-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
07f9e064-c69b-479e-b5e9-fe19a9d09d6c	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	c882feef-ed93-465a-adc4-acd29a1f3d19	\N	1249400	D	seed	seed|Utilities|Bescom|Backup usage|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
7307a134-20cd-4af2-8c30-4fe54fb1309d	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-15	2025-12-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	c882feef-ed93-465a-adc4-acd29a1f3d19	\N	935100	D	seed	seed|Utilities|Bescom|Backup usage|2025-12-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
07a17320-7f5b-46e4-a41e-c8028479ecf2	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	c882feef-ed93-465a-adc4-acd29a1f3d19	\N	864400	D	seed	seed|Utilities|Bescom|Backup usage|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
c508e9e3-6327-45df-9d5d-894841116743	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-15	2026-02-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	c882feef-ed93-465a-adc4-acd29a1f3d19	\N	1102200	D	seed	seed|Utilities|Bescom|Backup usage|2026-02-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
7463455f-b66e-4b34-afa9-d8e38104d767	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	c882feef-ed93-465a-adc4-acd29a1f3d19	\N	1429900	D	seed	seed|Utilities|Bescom|Backup usage|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
e55019c9-0cbf-43d6-a5a7-0894a2e5a969	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	c882feef-ed93-465a-adc4-acd29a1f3d19	\N	1344200	D	seed	seed|Utilities|Bescom|Backup usage|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
519ff89b-568b-4469-a31e-4c6382487295	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	c882feef-ed93-465a-adc4-acd29a1f3d19	\N	1009600	D	seed	seed|Utilities|Bescom|Backup usage|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
e7b66505-a870-4e60-b34b-d2df5ad83dae	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	5a319407-b5d1-4fd2-a4be-84e79d2c663f	c882feef-ed93-465a-adc4-acd29a1f3d19	\N	850000	D	seed	seed|Utilities|Bescom|Backup usage|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
6e91c6e5-f3c5-42f9-b4c2-b61b052b9364	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-15	2025-08-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	429d0ec9-40e1-47ab-b1ec-52f933fe2f52	\N	3200000	D	seed	seed|Utilities|BWSSB|Water charges|2025-08-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
85c752d2-aa4f-4e12-847e-429aab750864	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-15	2025-09-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	429d0ec9-40e1-47ab-b1ec-52f933fe2f52	\N	3368300	D	seed	seed|Utilities|BWSSB|Water charges|2025-09-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
241a6474-223a-4a70-a3f5-f7e822e340e4	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-15	2025-10-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	429d0ec9-40e1-47ab-b1ec-52f933fe2f52	\N	3381900	D	seed	seed|Utilities|BWSSB|Water charges|2025-10-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
4cd2f06b-6d49-4eb4-b5b6-a4d779d9fb60	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	429d0ec9-40e1-47ab-b1ec-52f933fe2f52	\N	3228200	D	seed	seed|Utilities|BWSSB|Water charges|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
1a7d69c8-e7fd-4df3-954e-2c1a71ec2483	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-15	2025-12-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	429d0ec9-40e1-47ab-b1ec-52f933fe2f52	\N	3048600	D	seed	seed|Utilities|BWSSB|Water charges|2025-12-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
faff2cf9-52e4-45a7-8f83-7e355e6f17f4	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	429d0ec9-40e1-47ab-b1ec-52f933fe2f52	\N	3008200	D	seed	seed|Utilities|BWSSB|Water charges|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
86733517-804b-4694-af5d-badcbdadeaa6	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-15	2026-02-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	429d0ec9-40e1-47ab-b1ec-52f933fe2f52	\N	3144100	D	seed	seed|Utilities|BWSSB|Water charges|2026-02-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
bc2d955f-0ff5-426f-9ab8-f40db1498793	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	429d0ec9-40e1-47ab-b1ec-52f933fe2f52	\N	3331400	D	seed	seed|Utilities|BWSSB|Water charges|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
229bf078-9271-44a5-9075-c5d643d6b2f0	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-15	2026-04-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	429d0ec9-40e1-47ab-b1ec-52f933fe2f52	\N	3397900	D	seed	seed|Utilities|BWSSB|Water charges|2026-04-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
c3ebf6dd-a09c-4978-af5c-2a3f03a3bb31	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	429d0ec9-40e1-47ab-b1ec-52f933fe2f52	\N	3282400	D	seed	seed|Utilities|BWSSB|Water charges|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
9207d386-f820-463f-938e-1fc5712e80fe	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	429d0ec9-40e1-47ab-b1ec-52f933fe2f52	\N	3091200	D	seed	seed|Utilities|BWSSB|Water charges|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
d0bf5004-0bfd-488b-b2d9-b60abcbc31c6	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	e0ae57ca-6a78-4459-ada0-38b354beb849	7f9d7b1d-1450-4f96-af9f-9ca783e33a30	429d0ec9-40e1-47ab-b1ec-52f933fe2f52	\N	3000000	D	seed	seed|Utilities|BWSSB|Water charges|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
b2b5e735-76b0-4764-95a8-e25b64b10cd9	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-15	2025-08-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	43d73c5a-bde0-4158-802b-7ad1764a6cb3	\N	6500000	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2025-08-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
ca248fdf-3adb-47b5-89b7-92fbe49a6e1b	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-15	2025-09-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	43d73c5a-bde0-4158-802b-7ad1764a6cb3	\N	6752400	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2025-09-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
fc2fd51a-d77f-4513-acbe-0b70c1e20990	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-15	2025-10-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	43d73c5a-bde0-4158-802b-7ad1764a6cb3	\N	6772800	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2025-10-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
8ed88cc8-e396-45cd-a5d3-0995f47bb4ff	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	43d73c5a-bde0-4158-802b-7ad1764a6cb3	\N	6542300	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
3a575c21-114d-4514-96c1-1db9115a67f1	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-15	2025-12-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	43d73c5a-bde0-4158-802b-7ad1764a6cb3	\N	6273000	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2025-12-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
bf8351c2-c462-4062-bf24-d72a814cd61a	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	43d73c5a-bde0-4158-802b-7ad1764a6cb3	\N	6212300	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
25cb2f4b-ffee-45df-a2cb-7abbbbb16802	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-15	2026-02-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	43d73c5a-bde0-4158-802b-7ad1764a6cb3	\N	6416200	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-02-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
a80dff0d-fdee-4ec4-9d55-69d3223265c8	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	43d73c5a-bde0-4158-802b-7ad1764a6cb3	\N	6697100	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
41538353-fda6-433c-9fc0-0acd180763a3	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-15	2026-04-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	43d73c5a-bde0-4158-802b-7ad1764a6cb3	\N	6796800	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-04-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
acb9d727-f800-44cd-b137-617ad816e2ce	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	43d73c5a-bde0-4158-802b-7ad1764a6cb3	\N	6623600	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
7b677ff4-f3dc-43fe-bcc8-57eed6d4607f	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	43d73c5a-bde0-4158-802b-7ad1764a6cb3	\N	6336800	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
8d8520c0-30ac-41f6-8d43-76576b6c6a95	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	43d73c5a-bde0-4158-802b-7ad1764a6cb3	\N	6200000	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
38849cb2-3027-414a-a2d8-06a963dca32e	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-15	2025-08-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	0dc9bd64-f98e-4802-b8fd-175e8f3a3e75	\N	1800000	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2025-08-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
85d3989f-e005-48fd-afe9-3ce08cd6d886	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-15	2025-10-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	0dc9bd64-f98e-4802-b8fd-175e8f3a3e75	\N	2345600	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2025-10-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
1d38324a-ab38-4213-98bb-b82f992a0226	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	0dc9bd64-f98e-4802-b8fd-175e8f3a3e75	\N	1884700	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
61841e41-3f4d-4883-8989-ded4eaa87f9f	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	0dc9bd64-f98e-4802-b8fd-175e8f3a3e75	\N	1224600	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
1f9f50af-aa2e-4fdb-83fc-67a10caa7bd2	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-15	2026-02-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	0dc9bd64-f98e-4802-b8fd-175e8f3a3e75	\N	1632400	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2026-02-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
151aee16-2647-4b26-8c2f-752cfbd6234e	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-15	2026-04-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	0dc9bd64-f98e-4802-b8fd-175e8f3a3e75	\N	2393600	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2026-04-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
1f08daca-008e-40fd-9236-00a7dc091ba4	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	0dc9bd64-f98e-4802-b8fd-175e8f3a3e75	\N	2047300	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
2889da41-72a7-492b-bafa-6b51f083d2d1	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	0dc9bd64-f98e-4802-b8fd-175e8f3a3e75	\N	1473600	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
fda4d80e-11e0-41c3-a377-cd4dd45444e8	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	0dc9bd64-f98e-4802-b8fd-175e8f3a3e75	\N	1200000	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
462d3af2-426b-4a4b-9e00-6e4d106b5f1c	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-15	2025-10-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	17df501e-2f4c-400c-b697-c6d3d6d58beb	\N	945500	D	seed	seed|Maintenance|ABC Enterprise|STP salt purchase|2025-10-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
16815edc-b98e-4889-b6a5-2b71f19646b2	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	17df501e-2f4c-400c-b697-c6d3d6d58beb	\N	852100	D	seed	seed|Maintenance|ABC Enterprise|STP salt purchase|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
e2bae9e7-1b8c-4f0c-b3d4-597286cf2825	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-15	2026-04-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	17df501e-2f4c-400c-b697-c6d3d6d58beb	\N	949500	D	seed	seed|Maintenance|ABC Enterprise|STP salt purchase|2026-04-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
da3582c5-161a-4710-a3b8-dfe2c2f1a424	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	f8942478-0d68-4b7e-9e26-c36c9da15ba8	17df501e-2f4c-400c-b697-c6d3d6d58beb	\N	850000	D	seed	seed|Maintenance|ABC Enterprise|STP salt purchase|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
876d6d32-2397-489d-bb76-9578e1fa6f9f	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-15	2025-09-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	03fe3f5f-cd32-480e-99b8-832b6914d30a	15cd27a9-83bb-4b32-967f-50d9e6d0962f	\N	744500	D	seed	seed|Maintenance|John (Plumber)|Plumbing repair|2025-09-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
404f6649-d478-47a8-a34a-a13634dd77ed	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	03fe3f5f-cd32-480e-99b8-832b6914d30a	15cd27a9-83bb-4b32-967f-50d9e6d0962f	\N	499400	D	seed	seed|Maintenance|John (Plumber)|Plumbing repair|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
940bec72-6696-4a3a-9c9a-984ff261cb1d	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-15	2025-12-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	03fe3f5f-cd32-480e-99b8-832b6914d30a	15cd27a9-83bb-4b32-967f-50d9e6d0962f	\N	185100	D	seed	seed|Maintenance|John (Plumber)|Plumbing repair|2025-12-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
95f76b5a-dce2-4f08-a2cc-d004f3ccbb41	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	03fe3f5f-cd32-480e-99b8-832b6914d30a	15cd27a9-83bb-4b32-967f-50d9e6d0962f	\N	679900	D	seed	seed|Maintenance|John (Plumber)|Plumbing repair|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
9c6d60e1-4782-4f35-ba15-8c305fb5593a	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	03fe3f5f-cd32-480e-99b8-832b6914d30a	15cd27a9-83bb-4b32-967f-50d9e6d0962f	\N	594200	D	seed	seed|Maintenance|John (Plumber)|Plumbing repair|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
a417b807-b5c5-4803-b0e2-8512f7e2aa0b	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	531e64d6-3d5e-410a-927a-ab20f191e052	03fe3f5f-cd32-480e-99b8-832b6914d30a	15cd27a9-83bb-4b32-967f-50d9e6d0962f	\N	259600	D	seed	seed|Maintenance|John (Plumber)|Plumbing repair|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
8b10040a-a2d4-4724-bf27-ff4c7ccbdc63	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-15	2025-08-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	\N	12000000	D	seed	seed|Security|SafeGuard Services|Guard salaries|2025-08-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
882ff4d3-b4e7-4771-870d-7c52645bcb0b	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-15	2025-09-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	\N	12168300	D	seed	seed|Security|SafeGuard Services|Guard salaries|2025-09-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
2b372a78-81ec-4f66-a9fd-4e5a40abc1c2	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-15	2025-10-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	\N	12181900	D	seed	seed|Security|SafeGuard Services|Guard salaries|2025-10-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
cc220447-f2f8-4577-9459-31b5e9b7d63c	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	\N	12028200	D	seed	seed|Security|SafeGuard Services|Guard salaries|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
4a204789-6337-4cea-b8e0-21f1d1a7a28c	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-15	2025-12-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	\N	11848600	D	seed	seed|Security|SafeGuard Services|Guard salaries|2025-12-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
7252aaa7-ab48-4557-ae41-d68cd287f17c	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	\N	11808200	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
65d846e2-f6f3-4953-ba8f-3901d3e0e123	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-15	2026-02-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	\N	11944100	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-02-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
c991a542-528c-4664-9dc8-62f64617d39c	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	\N	12131400	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
7c469571-2090-4dae-ad90-7147645b8e31	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-15	2026-04-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	\N	12197900	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-04-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
50cce7ca-e238-467d-9a4a-bea351e4ba0e	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	\N	12082400	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
5c00378a-7ec1-411e-870d-2b55edd73ff3	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	\N	11891200	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
d59dbccd-f77d-43ae-a748-afbea123f6ea	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	21a451dc-3dad-4b2e-80d6-ecf6a2529537	12aba4c7-55f1-43c3-b78f-76dd049ab9e0	69c45cf6-2d7b-40d1-a5a1-6bb6cfa158dd	\N	11800000	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
310cdbd2-02e6-445d-a59e-ff239bd42128	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-15	2025-08-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	e3dc12ec-ac0c-4a57-ba82-b1496d556527	\N	5800000	D	seed	seed|Housekeeping|CleanCo|Staff wages|2025-08-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
963656fc-bb7f-40e8-80c0-201a0aa8e8b2	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-15	2025-09-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	e3dc12ec-ac0c-4a57-ba82-b1496d556527	\N	5926200	D	seed	seed|Housekeeping|CleanCo|Staff wages|2025-09-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
0a80cc0c-0a8e-4849-a92a-42efbfb53328	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-15	2025-10-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	e3dc12ec-ac0c-4a57-ba82-b1496d556527	\N	5936400	D	seed	seed|Housekeeping|CleanCo|Staff wages|2025-10-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
9b978b74-03b5-47a5-8aca-f29eb1492ab5	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	e3dc12ec-ac0c-4a57-ba82-b1496d556527	\N	5821200	D	seed	seed|Housekeeping|CleanCo|Staff wages|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
121c7e82-e417-4d33-9eed-65ba31c5ad80	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-15	2025-12-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	e3dc12ec-ac0c-4a57-ba82-b1496d556527	\N	5686500	D	seed	seed|Housekeeping|CleanCo|Staff wages|2025-12-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
a268ac95-5f15-499f-bf92-06bd1031d382	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	e3dc12ec-ac0c-4a57-ba82-b1496d556527	\N	5656200	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
cc37a7dc-e577-43e7-80e8-535c79ba3914	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-15	2026-02-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	e3dc12ec-ac0c-4a57-ba82-b1496d556527	\N	5758100	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-02-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
d5e9eec8-0690-44d8-85a1-656038734301	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	e3dc12ec-ac0c-4a57-ba82-b1496d556527	\N	5898500	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
19644f37-7255-4f89-9932-142ca60903ef	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-15	2026-04-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	e3dc12ec-ac0c-4a57-ba82-b1496d556527	\N	5948400	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-04-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
e5b8058d-6940-45f6-832a-b3710426c69f	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	e3dc12ec-ac0c-4a57-ba82-b1496d556527	\N	5861800	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
577b60ec-49ec-47fc-93d5-e7b4420d7565	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	e3dc12ec-ac0c-4a57-ba82-b1496d556527	\N	5718400	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
e6c17d72-86e4-452e-84b4-e152df7c9202	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	e3dc12ec-ac0c-4a57-ba82-b1496d556527	\N	5650000	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
c8efff72-96a5-47b2-975d-7648e6b5f0e3	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-15	2025-08-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	\N	750000	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2025-08-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
9ac459c4-8b46-4092-84c6-f3f002eac70a	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-15	2025-09-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	\N	876200	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2025-09-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
ce7a9be7-7f84-42b2-aa1d-15ccc113e22b	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-15	2025-10-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	\N	886400	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2025-10-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
9dae3c97-dc9f-42fa-8612-796446ec0d3a	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	\N	771200	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
fc2672da-3a14-4ced-ba64-4d47dd923f42	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-15	2025-12-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	\N	636500	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2025-12-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
a8bf548f-917c-4c14-9625-b8df882d3312	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	\N	606200	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
3cff8688-dc23-4acb-a0a7-3f704122945f	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-15	2026-02-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	\N	708100	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-02-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
a7b39229-6e5c-4ddf-ad7b-71e46c5e1c8f	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	\N	848500	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
2426f0ac-6aaf-4201-a915-c07826b280eb	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-15	2026-04-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	\N	898400	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-04-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
42a94661-e739-4011-bab6-bc24b3b2572f	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	\N	811800	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
df88cf31-8195-4a51-ab19-c24bfb72fe2e	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	\N	668400	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
7388edbc-3569-44af-b6e4-dc54d6e52966	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	0529a542-968d-4c4e-8bd3-176f94feff0e	4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	4e3f79c6-7cfa-40eb-9f3f-9991f311efa5	\N	600000	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
e260488d-3e69-44e4-8066-71ab86528cd2	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-15	2025-08-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	c2f94f2b-021d-455a-9bfb-11d86621cf17	\N	600000	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2025-08-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
ff1db6f9-dc3e-4c68-af57-b982a77f795e	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-15	2025-09-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	c2f94f2b-021d-455a-9bfb-11d86621cf17	\N	1062800	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2025-09-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
9eb5afe7-3c89-4726-80de-7d60f42488bd	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-15	2025-10-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	c2f94f2b-021d-455a-9bfb-11d86621cf17	\N	1100100	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2025-10-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
278a2aef-8fe0-42b6-8ac6-c9575203ab61	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	c2f94f2b-021d-455a-9bfb-11d86621cf17	\N	677600	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
e5792e9b-0e34-468c-aa25-349b77f54e17	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-15	2025-12-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	c2f94f2b-021d-455a-9bfb-11d86621cf17	\N	183800	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2025-12-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
c402baa2-7dc8-4aca-ad95-2074047255f7	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	c2f94f2b-021d-455a-9bfb-11d86621cf17	\N	72600	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
bd05c12c-444a-4230-8a55-0cab4c128330	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-15	2026-02-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	c2f94f2b-021d-455a-9bfb-11d86621cf17	\N	446300	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-02-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
332695d2-c8c8-4fc4-9516-1ede3912e517	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	c2f94f2b-021d-455a-9bfb-11d86621cf17	\N	961300	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
6043da35-ec20-4eb1-96a0-a67f8f360e5d	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-15	2026-04-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	c2f94f2b-021d-455a-9bfb-11d86621cf17	\N	1144100	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-04-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
05fae5c9-1636-4965-9cc0-7bab38229b50	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	c2f94f2b-021d-455a-9bfb-11d86621cf17	\N	826700	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
7019a70b-28bd-4fba-8dc1-1295f3cf4a8b	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	c2f94f2b-021d-455a-9bfb-11d86621cf17	\N	300800	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
b5b70842-a67b-445f-933d-cf961567d2fb	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	2ce9ad8b-7cc9-4b5c-97e7-de0b8d92faf6	c6e72096-3add-4b2b-ab4e-e078a03102a2	f37a7657-355d-41f2-9745-bc7319c9ea76	c2f94f2b-021d-455a-9bfb-11d86621cf17	\N	50000	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
64211f58-cc34-4c14-9bd4-99339e5aa9d4	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-15	2025-08-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	b4bdb55c-d959-493b-aca4-2d6acfec80bd	\N	34000000	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2025-08-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
5ef55327-34c9-4e91-8b3c-8a24a4593cbc	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-15	2025-09-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	b4bdb55c-d959-493b-aca4-2d6acfec80bd	\N	35262200	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2025-09-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
0354686c-aff0-4771-94cd-156658a5533a	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-15	2025-10-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	b4bdb55c-d959-493b-aca4-2d6acfec80bd	\N	35363900	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2025-10-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
5683d7e9-1f10-4879-b271-f424bd1e4b7a	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	b4bdb55c-d959-493b-aca4-2d6acfec80bd	\N	34211700	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
b0b35522-4a49-4473-9e0a-12f1efb0554d	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-15	2025-12-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	b4bdb55c-d959-493b-aca4-2d6acfec80bd	\N	32864800	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2025-12-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
a4c7d840-a34c-454e-99bc-e3a7e12c5606	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	b4bdb55c-d959-493b-aca4-2d6acfec80bd	\N	32561600	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
71f8e4fe-7075-4919-bacd-3654f7a8a7f7	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-15	2026-02-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	b4bdb55c-d959-493b-aca4-2d6acfec80bd	\N	33580900	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-02-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
d6fec2d7-eb4c-465a-a747-5cd1b14a1aa1	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	b4bdb55c-d959-493b-aca4-2d6acfec80bd	\N	34985500	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
594fa828-8baf-4d78-88e0-58efda367edd	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-15	2026-04-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	b4bdb55c-d959-493b-aca4-2d6acfec80bd	\N	35484000	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-04-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
14829a2b-97e6-4c14-925e-df79b186c7c2	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	b4bdb55c-d959-493b-aca4-2d6acfec80bd	\N	34618200	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
98b84d1c-24b3-48f2-b3a7-4ea02b1edacd	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	b4bdb55c-d959-493b-aca4-2d6acfec80bd	\N	33184000	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
81fbe10d-813a-43f5-8bc8-5319a46fb443	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	4f561960-40d3-4400-be9c-39063480a0fc	6bfbdf2d-2fb9-4998-8753-26ca545aee66	b4bdb55c-d959-493b-aca4-2d6acfec80bd	\N	32500000	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
e451e32b-052e-400f-8f8d-fc6b6a2e01ac	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-15	2025-08-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	98d1b9a4-609a-41db-9d38-5002e9ce3fb4	\N	1800000	C	seed	seed|Other Income|Community Hall|Hall rental|2025-08-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
b0b5856f-88c5-491e-8a92-80e0773577e7	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-15	2025-10-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	98d1b9a4-609a-41db-9d38-5002e9ce3fb4	\N	2527400	C	seed	seed|Other Income|Community Hall|Hall rental|2025-10-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
02c5c7ed-8a17-4e03-a4e2-5799c8047e73	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	98d1b9a4-609a-41db-9d38-5002e9ce3fb4	\N	1912900	C	seed	seed|Other Income|Community Hall|Hall rental|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
93c4785d-4579-40a3-9aab-cee3eb67b9ec	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-15	2025-12-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	98d1b9a4-609a-41db-9d38-5002e9ce3fb4	\N	1194600	C	seed	seed|Other Income|Community Hall|Hall rental|2025-12-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
446a84a9-456d-4590-8b1c-4884c5703279	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-15	2026-02-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	98d1b9a4-609a-41db-9d38-5002e9ce3fb4	\N	1576500	C	seed	seed|Other Income|Community Hall|Hall rental|2026-02-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
07c5ff5b-f2eb-4629-a1a2-9925022ce07d	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	98d1b9a4-609a-41db-9d38-5002e9ce3fb4	\N	2325600	C	seed	seed|Other Income|Community Hall|Hall rental|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
7ecb70d1-e94d-42b1-81c9-9bd58d22a311	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-15	2026-04-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	98d1b9a4-609a-41db-9d38-5002e9ce3fb4	\N	2591500	C	seed	seed|Other Income|Community Hall|Hall rental|2026-04-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
e6db5af8-cc31-48e4-b7a5-efc526f2b65a	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	98d1b9a4-609a-41db-9d38-5002e9ce3fb4	\N	1364800	C	seed	seed|Other Income|Community Hall|Hall rental|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
d157cd6d-f5ed-4e94-ad11-2b028ace1f67	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	98d1b9a4-609a-41db-9d38-5002e9ce3fb4	\N	1000000	C	seed	seed|Other Income|Community Hall|Hall rental|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
e80069a3-4e10-420f-b454-df01081c0f7e	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-15	2025-09-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	b70f8f10-f79c-43b0-b6f4-fad005b61be3	\N	978700	C	seed	seed|Other Income|Community Hall|Event usage charges|2025-09-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
21bbe0be-d276-4e0e-8313-eee51e832350	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	b70f8f10-f79c-43b0-b6f4-fad005b61be3	\N	663500	C	seed	seed|Other Income|Community Hall|Event usage charges|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
e64689a0-96a0-4174-81ad-509b17d099e8	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	b70f8f10-f79c-43b0-b6f4-fad005b61be3	\N	168500	C	seed	seed|Other Income|Community Hall|Event usage charges|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
1677275f-3d87-4e6d-99e2-73b4093a2970	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	b70f8f10-f79c-43b0-b6f4-fad005b61be3	\N	895600	C	seed	seed|Other Income|Community Hall|Event usage charges|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
e221a177-363b-46ca-98f4-388b85f1f04c	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	b70f8f10-f79c-43b0-b6f4-fad005b61be3	\N	785500	C	seed	seed|Other Income|Community Hall|Event usage charges|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
408bb0aa-e310-4e13-adbc-3f9300ff3d74	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	b504be52-40f8-486b-a8dc-7c370caf7797	b70f8f10-f79c-43b0-b6f4-fad005b61be3	\N	150000	C	seed	seed|Other Income|Community Hall|Event usage charges|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
62da0b52-d60a-4ea0-ba51-d54fd1b620b4	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-08-15	2025-08-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	9fcd6632-4b80-48f9-8ecc-e14ab03b118f	\N	1200000	C	seed	seed|Other Income|Signage Rental|Billboard fee|2025-08-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
3f6823d9-eb7f-4cef-a3db-83544d51fe18	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-09-15	2025-09-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	9fcd6632-4b80-48f9-8ecc-e14ab03b118f	\N	1242100	C	seed	seed|Other Income|Signage Rental|Billboard fee|2025-09-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
235043e9-81b1-47d9-be2b-a5edff5d7392	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-10-15	2025-10-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	9fcd6632-4b80-48f9-8ecc-e14ab03b118f	\N	1245500	C	seed	seed|Other Income|Signage Rental|Billboard fee|2025-10-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
b4f6bda5-6150-4969-82b6-0a4cf03b0abd	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-11-15	2025-11-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	9fcd6632-4b80-48f9-8ecc-e14ab03b118f	\N	1207100	C	seed	seed|Other Income|Signage Rental|Billboard fee|2025-11-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
c9ad1e12-7f4e-46dd-9d39-4fcd222caac4	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2025-12-15	2025-12-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	9fcd6632-4b80-48f9-8ecc-e14ab03b118f	\N	1162200	C	seed	seed|Other Income|Signage Rental|Billboard fee|2025-12-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
da73269f-51a4-4e8f-9bd5-05d90e922b5b	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-01-15	2026-01-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	9fcd6632-4b80-48f9-8ecc-e14ab03b118f	\N	1152100	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-01-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
091368c2-c967-4d14-8f91-66a1ceee789a	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-02-15	2026-02-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	9fcd6632-4b80-48f9-8ecc-e14ab03b118f	\N	1186000	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-02-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
7baa31f7-aeab-4a59-a526-4166a88ffade	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-03-15	2026-03-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	9fcd6632-4b80-48f9-8ecc-e14ab03b118f	\N	1232800	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-03-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
2abcff09-d91f-43dc-8064-6cb6825188ac	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-04-15	2026-04-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	9fcd6632-4b80-48f9-8ecc-e14ab03b118f	\N	1249500	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-04-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
51310916-bc7e-42fa-9126-93fb6629f6da	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-05-15	2026-05-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	9fcd6632-4b80-48f9-8ecc-e14ab03b118f	\N	1220600	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-05-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
8d1d0ac5-26c4-4796-afae-26b63f245614	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-06-15	2026-06-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	9fcd6632-4b80-48f9-8ecc-e14ab03b118f	\N	1172800	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-06-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
5e18fb39-592c-45bb-a4fd-c646e8c098ef	3dea846d-5182-4c78-8fcd-fabb1a80ee61	2026-07-15	2026-07-01	40b58237-30d3-40a3-ab0a-1a6fe75f62bb	0912efbb-45d6-4f91-a943-5b67304415c3	c8445c54-844f-426a-a290-4b7b1857452f	9fcd6632-4b80-48f9-8ecc-e14ab03b118f	\N	1150000	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-07-01	\N	\N	2026-07-13 09:33:54.398256+00	2026-07-13 09:33:54.398256+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role) FROM stdin;
345358dc-316f-433a-92f6-a37b149e08a2	superadmin
345358dc-316f-433a-92f6-a37b149e08a2	admin
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, community_id, email, name, password_hash, last_login_at, created_at) FROM stdin;
345358dc-316f-433a-92f6-a37b149e08a2	3dea846d-5182-4c78-8fcd-fabb1a80ee61	admin@example.com	Super Admin	$argon2id$v=19$m=65536,t=3,p=4$R8xLA8HOJ13iEQKCawjNSQ$Q+J/jly/HF05U3Nm0RybN6oJYKkGkbQhZ8c9SfKlQL0	2026-07-13 10:51:11.364935+00	2026-07-13 09:51:53.709368+00
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, community_id, name, kind) FROM stdin;
5a319407-b5d1-4fd2-a4be-84e79d2c663f	3dea846d-5182-4c78-8fcd-fabb1a80ee61	Bescom	company
7f9d7b1d-1450-4f96-af9f-9ca783e33a30	3dea846d-5182-4c78-8fcd-fabb1a80ee61	BWSSB	company
f8942478-0d68-4b7e-9e26-c36c9da15ba8	3dea846d-5182-4c78-8fcd-fabb1a80ee61	ABC Enterprise	company
03fe3f5f-cd32-480e-99b8-832b6914d30a	3dea846d-5182-4c78-8fcd-fabb1a80ee61	John (Plumber)	individual
12aba4c7-55f1-43c3-b78f-76dd049ab9e0	3dea846d-5182-4c78-8fcd-fabb1a80ee61	SafeGuard Services	company
4da4cd3d-316b-4d1a-b9d8-8c53ce0aa555	3dea846d-5182-4c78-8fcd-fabb1a80ee61	CleanCo	company
f37a7657-355d-41f2-9745-bc7319c9ea76	3dea846d-5182-4c78-8fcd-fabb1a80ee61	Office petty cash	individual
6bfbdf2d-2fb9-4998-8753-26ca545aee66	3dea846d-5182-4c78-8fcd-fabb1a80ee61	Monthly maintenance	company
b504be52-40f8-486b-a8dc-7c370caf7797	3dea846d-5182-4c78-8fcd-fabb1a80ee61	Community Hall	company
c8445c54-844f-426a-a290-4b7b1857452f	3dea846d-5182-4c78-8fcd-fabb1a80ee61	Signage Rental	individual
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 3, true);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (name);


--
-- Name: allowed_emails allowed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_pkey PRIMARY KEY (email);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: balances balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_pkey PRIMARY KEY (community_id, month);


--
-- Name: categories categories_head_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_name_key UNIQUE (head_id, name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: collections_dues collections_dues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_pkey PRIMARY KEY (flat_id, period_month);


--
-- Name: communities communities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communities
    ADD CONSTRAINT communities_pkey PRIMARY KEY (id);


--
-- Name: dashboard_settings dashboard_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_pkey PRIMARY KEY (community_id, dashboard_key);


--
-- Name: flats flats_community_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_code_key UNIQUE (community_id, code);


--
-- Name: flats flats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_pkey PRIMARY KEY (id);


--
-- Name: heads heads_community_id_kind_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_kind_name_key UNIQUE (community_id, kind, name);


--
-- Name: heads heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_rules import_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_pkey PRIMARY KEY (id);


--
-- Name: import_staging import_staging_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_pkey PRIMARY KEY (batch_id, row_no);


--
-- Name: line_items line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_pkey PRIMARY KEY (id);


--
-- Name: otp_codes magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (email, otp_hash);


--
-- Name: periods periods_community_id_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_month_key UNIQUE (community_id, month);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_source_source_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_source_source_ref_key UNIQUE (source, source_ref);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_community_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_name_key UNIQUE (community_id, name);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_at ON public.audit_log USING btree (at DESC);


--
-- Name: idx_audit_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_entity ON public.audit_log USING btree (entity, entity_id);


--
-- Name: idx_txn_category_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_category_month ON public.transactions USING btree (category_id, period_month);


--
-- Name: idx_txn_community_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_community_month ON public.transactions USING btree (community_id, period_month);


--
-- Name: idx_txn_flat_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_flat_month ON public.transactions USING btree (flat_id, period_month);


--
-- Name: idx_txn_head_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_head_month ON public.transactions USING btree (head_id, period_month);


--
-- Name: idx_txn_vendor_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_vendor_month ON public.transactions USING btree (vendor_id, period_month);


--
-- Name: line_items_cat_vendor_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX line_items_cat_vendor_name_uq ON public.line_items USING btree (category_id, COALESCE(vendor_id, '00000000-0000-0000-0000-000000000000'::uuid), name);


--
-- Name: mv_cat_monthly_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_cat_monthly_idx ON public.mv_category_monthly USING btree (community_id, month);


--
-- Name: mv_monthly_totals_pk; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mv_monthly_totals_pk ON public.mv_monthly_totals USING btree (community_id, month);


--
-- Name: mv_vendor_ranking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_vendor_ranking_idx ON public.mv_vendor_ranking USING btree (community_id, total_expense_paise DESC);


--
-- Name: allowed_emails allowed_emails_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: allowed_emails allowed_emails_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE SET NULL;


--
-- Name: balances balances_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: categories categories_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id) ON DELETE CASCADE;


--
-- Name: collections_dues collections_dues_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE CASCADE;


--
-- Name: dashboard_settings dashboard_settings_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: flats flats_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: heads heads_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: import_rules import_rules_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_staging import_staging_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE SET NULL;


--
-- Name: periods periods_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: transactions transactions_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id);


--
-- Name: transactions transactions_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id);


--
-- Name: transactions transactions_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_line_item_id_fkey FOREIGN KEY (line_item_id) REFERENCES public.line_items(id);


--
-- Name: transactions transactions_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: vendors vendors_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_category_monthly;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_monthly_totals;


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_vendor_ranking;


--
-- PostgreSQL database dump complete
--

\unrestrict QeSzyT7AMUetfb5MYmgQIHFIBzwXjrsJl5dVsoiDzglG7thXRUU8arjtc2RRdk9

