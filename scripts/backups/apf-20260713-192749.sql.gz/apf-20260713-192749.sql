--
-- PostgreSQL database dump
--

\restrict MPQb4IpwYw1JMgYn4Q3YYqqmA5YFzRHvi6rdoUAkufUA69Fu5fT8Lv1S5R1oTry

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_line_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_batch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_actor_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_community_id_fkey;
DROP INDEX IF EXISTS public.mv_vendor_ranking_idx;
DROP INDEX IF EXISTS public.mv_monthly_totals_pk;
DROP INDEX IF EXISTS public.mv_cat_monthly_idx;
DROP INDEX IF EXISTS public.line_items_cat_vendor_name_uq;
DROP INDEX IF EXISTS public.idx_txn_vendor_month;
DROP INDEX IF EXISTS public.idx_txn_head_month;
DROP INDEX IF EXISTS public.idx_txn_flat_month;
DROP INDEX IF EXISTS public.idx_txn_community_month;
DROP INDEX IF EXISTS public.idx_txn_category_month;
DROP INDEX IF EXISTS public.idx_audit_entity;
DROP INDEX IF EXISTS public.idx_audit_at;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_pkey;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_name_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_source_source_ref_key;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_month_key;
ALTER TABLE IF EXISTS ONLY public.otp_codes DROP CONSTRAINT IF EXISTS magic_links_pkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_pkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_pkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_kind_name_key;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_pkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_code_key;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.communities DROP CONSTRAINT IF EXISTS communities_pkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_name_key;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_pkey;
ALTER TABLE IF EXISTS ONLY public._migrations DROP CONSTRAINT IF EXISTS _migrations_pkey;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.periods;
DROP TABLE IF EXISTS public.otp_codes;
DROP MATERIALIZED VIEW IF EXISTS public.mv_vendor_ranking;
DROP TABLE IF EXISTS public.vendors;
DROP MATERIALIZED VIEW IF EXISTS public.mv_monthly_totals;
DROP MATERIALIZED VIEW IF EXISTS public.mv_category_monthly;
DROP TABLE IF EXISTS public.transactions;
DROP TABLE IF EXISTS public.line_items;
DROP TABLE IF EXISTS public.import_staging;
DROP TABLE IF EXISTS public.import_rules;
DROP TABLE IF EXISTS public.import_batches;
DROP TABLE IF EXISTS public.heads;
DROP TABLE IF EXISTS public.flats;
DROP TABLE IF EXISTS public.dashboard_settings;
DROP TABLE IF EXISTS public.communities;
DROP TABLE IF EXISTS public.collections_dues;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.balances;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP TABLE IF EXISTS public.allowed_emails;
DROP TABLE IF EXISTS public._migrations;
DROP TYPE IF EXISTS public.vendor_kind;
DROP TYPE IF EXISTS public.head_kind;
DROP TYPE IF EXISTS public.app_role;
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'resident',
    'admin',
    'superadmin'
);


--
-- Name: head_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.head_kind AS ENUM (
    'income',
    'expense'
);


--
-- Name: vendor_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vendor_kind AS ENUM (
    'company',
    'individual'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    name text NOT NULL,
    run_at timestamp with time zone DEFAULT now()
);


--
-- Name: allowed_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allowed_emails (
    email text NOT NULL,
    community_id uuid NOT NULL,
    role public.app_role NOT NULL,
    flat_id uuid,
    name text,
    invited_by text,
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    community_id uuid,
    actor_user_id uuid,
    actor_email text,
    entity text NOT NULL,
    entity_id text,
    action text NOT NULL,
    before jsonb,
    after jsonb,
    at timestamp with time zone DEFAULT now() NOT NULL,
    ip text,
    user_agent text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balances (
    community_id uuid NOT NULL,
    month date NOT NULL,
    opening_paise bigint DEFAULT 0 NOT NULL,
    closing_paise bigint DEFAULT 0 NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    head_id uuid NOT NULL,
    name text NOT NULL
);


--
-- Name: collections_dues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections_dues (
    flat_id uuid NOT NULL,
    period_month date NOT NULL,
    dues_paise bigint DEFAULT 0 NOT NULL,
    paid_paise bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'due'::text NOT NULL
);


--
-- Name: communities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    fy_start_month smallint DEFAULT 4 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dashboard_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_settings (
    community_id uuid NOT NULL,
    dashboard_key text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    hidden_widgets text[] DEFAULT '{}'::text[] NOT NULL
);


--
-- Name: flats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    code text NOT NULL,
    owner_email text
);


--
-- Name: heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind public.head_kind NOT NULL,
    name text NOT NULL
);


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    filename text NOT NULL,
    kind text NOT NULL,
    uploaded_by uuid,
    status text DEFAULT 'staged'::text NOT NULL,
    error text,
    row_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind text NOT NULL,
    match jsonb NOT NULL,
    set_fields jsonb NOT NULL,
    priority integer DEFAULT 100 NOT NULL
);


--
-- Name: import_staging; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_staging (
    batch_id uuid NOT NULL,
    row_no integer NOT NULL,
    raw_json jsonb NOT NULL,
    mapped_json jsonb,
    error text
);


--
-- Name: line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    name text NOT NULL,
    first_seen_month date,
    last_seen_month date
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    txn_date date NOT NULL,
    period_month date NOT NULL,
    head_id uuid NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    line_item_id uuid,
    flat_id uuid,
    amount_paise bigint NOT NULL,
    direction character(1) NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    source_ref text,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT transactions_amount_paise_check CHECK ((amount_paise >= 0)),
    CONSTRAINT transactions_direction_check CHECK ((direction = ANY (ARRAY['C'::bpchar, 'D'::bpchar])))
);


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_category_monthly AS
 SELECT t.community_id,
    t.category_id,
    c.name AS category_name,
    h.kind AS head_kind,
    t.period_month AS month,
    (sum(t.amount_paise))::bigint AS amount_paise
   FROM ((public.transactions t
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON ((h.id = t.head_id)))
  GROUP BY t.community_id, t.category_id, c.name, h.kind, t.period_month
  WITH NO DATA;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_monthly_totals AS
 WITH spine AS (
         SELECT c.id AS community_id,
            (date_trunc('month'::text, gs.gs))::date AS month
           FROM (public.communities c
             CROSS JOIN generate_series((( SELECT COALESCE(min(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, (( SELECT COALESCE(max(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, '1 mon'::interval) gs(gs))
        )
 SELECT s.community_id,
    s.month,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric))::bigint AS collection_paise,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric))::bigint AS expense_paise,
    ((COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric) - COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric)))::bigint AS net_paise
   FROM (spine s
     LEFT JOIN public.transactions t ON (((t.community_id = s.community_id) AND (t.period_month = s.month))))
  GROUP BY s.community_id, s.month
  WITH NO DATA;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    name text NOT NULL,
    kind public.vendor_kind DEFAULT 'company'::public.vendor_kind NOT NULL
);


--
-- Name: TABLE vendors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vendors IS 'Vendor dimension. Read-only from admin UI; populated via CSV import + on-the-fly during transaction ingest.';


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_vendor_ranking AS
 SELECT t.community_id,
    v.id AS vendor_id,
    v.name AS vendor_name,
    v.kind AS vendor_kind,
    COALESCE(string_agg(DISTINCT c.name, ', '::text), ''::text) AS categories,
    (sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)))::bigint AS total_expense_paise,
    count(DISTINCT t.period_month) AS months_active
   FROM (((public.transactions t
     JOIN public.vendors v ON ((v.id = t.vendor_id)))
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON (((h.id = t.head_id) AND (h.kind = 'expense'::public.head_kind))))
  GROUP BY t.community_id, v.id, v.name, v.kind
  WITH NO DATA;


--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_codes (
    email text NOT NULL,
    otp_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone
);


--
-- Name: periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    month date NOT NULL,
    status text DEFAULT 'open'::text NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role public.app_role NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    email text NOT NULL,
    name text,
    password_hash text,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._migrations (name, run_at) FROM stdin;
0001_init.sql	2026-07-13 11:13:56.401452+00
0002_indexes.sql	2026-07-13 11:13:56.401452+00
0003_mviews.sql	2026-07-13 11:13:56.401452+00
0004_otp_rename.sql	2026-07-13 11:20:04.500279+00
\.


--
-- Data for Name: allowed_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allowed_emails (email, community_id, role, flat_id, name, invited_by, invited_at, revoked_at) FROM stdin;
treasurer@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	admin	\N	Treasurer	system	2026-07-13 11:20:04.55456+00	\N
resident@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	resident	\N	Demo Resident	system	2026-07-13 11:20:04.55456+00	\N
admin@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	superadmin	\N	Super Admin	system	2026-07-13 11:20:04.55456+00	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, community_id, actor_user_id, actor_email, entity, entity_id, action, before, after, at, ip, user_agent) FROM stdin;
1	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	auth	\N	login	\N	\N	2026-07-13 13:36:56.361948+00	172.31.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
2	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	auth	\N	login	\N	\N	2026-07-13 13:45:07.527171+00	172.31.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
3	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	import_batch	93794c13-76d1-4640-8b88-212cfa27dfda	import	\N	{"kind": "vendors", "rows": 10, "failed": 10, "filename": "vendors.csv", "inserted": 0}	2026-07-13 13:45:24.374363+00	172.31.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
4	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	import_batch	384c2bb9-1afa-4d02-8058-b65901eed16b	import	\N	{"kind": "vendors", "rows": 10, "failed": 10, "filename": "vendors.csv", "inserted": 0}	2026-07-13 13:46:05.444837+00	172.31.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
5	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	import_batch	357eb336-d2b7-4673-be90-4b545b4f00cc	import	\N	{"kind": "vendors", "rows": 10, "failed": 0, "filename": "vendors.csv", "inserted": 10}	2026-07-13 13:51:53.099087+00	172.31.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
6	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	import_batch	96bba21d-31dc-4280-af5c-307230fa9cf7	import	\N	{"kind": "transactions", "rows": 152, "failed": 0, "filename": "transactions.csv", "inserted": 152}	2026-07-13 13:52:18.235327+00	172.31.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
\.


--
-- Data for Name: balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.balances (community_id, month, opening_paise, closing_paise) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, head_id, name) FROM stdin;
1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	82e64189-a014-4a10-8c88-7fb239056c07	Utilities
4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	82e64189-a014-4a10-8c88-7fb239056c07	Maintenance
ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	82e64189-a014-4a10-8c88-7fb239056c07	Security
6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	82e64189-a014-4a10-8c88-7fb239056c07	Housekeeping
56a0442b-369d-4293-909a-cb39f4c8af1d	82e64189-a014-4a10-8c88-7fb239056c07	Petty Cash
68b902c9-bbc3-46e3-9c63-ce3a766f67a6	3c9b72a3-e708-4855-9e3a-d14019b2d825	Maintenance Collections
1ac7ef9c-60f2-431d-9db4-54680f60568a	3c9b72a3-e708-4855-9e3a-d14019b2d825	Other Income
\.


--
-- Data for Name: collections_dues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections_dues (flat_id, period_month, dues_paise, paid_paise, status) FROM stdin;
\.


--
-- Data for Name: communities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communities (id, name, currency, fy_start_month, created_at) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	Green Meadows	INR	4	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: dashboard_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_settings (community_id, dashboard_key, enabled, hidden_widgets) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	resident.overview	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.drilldown	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.cashflow	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.income	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.balance	t	{}
\.


--
-- Data for Name: flats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flats (id, community_id, code, owner_email) FROM stdin;
f88d6359-58a8-42b1-8476-24ce41b63802	caa11b01-c3a5-4067-a90c-b73b35075def	A-001	\N
5696d5bf-57f9-44ad-b92d-781cabc4a550	caa11b01-c3a5-4067-a90c-b73b35075def	A-002	\N
5c447f5e-a684-4075-8224-072f1fb12c93	caa11b01-c3a5-4067-a90c-b73b35075def	A-003	\N
6ddf10b7-40ed-44a1-9080-e50c60a08e32	caa11b01-c3a5-4067-a90c-b73b35075def	A-004	\N
5bfe95a5-bc38-4d00-811e-b5a6106e71c7	caa11b01-c3a5-4067-a90c-b73b35075def	A-005	\N
6e67ec18-d2aa-4cd4-8a51-b9a2b33429a2	caa11b01-c3a5-4067-a90c-b73b35075def	A-006	\N
05fbfe69-9195-45aa-bb9a-ef1de36f6fd9	caa11b01-c3a5-4067-a90c-b73b35075def	A-007	\N
7dca9ae9-39f7-4b2c-85b6-f9c820a65f0c	caa11b01-c3a5-4067-a90c-b73b35075def	A-008	\N
24f24d23-6946-4d06-b2d4-7ebe31278f9e	caa11b01-c3a5-4067-a90c-b73b35075def	A-009	\N
39278459-ad85-4e5e-937a-0a36b195c960	caa11b01-c3a5-4067-a90c-b73b35075def	A-010	\N
716bbe4c-f53d-4558-a4b5-caeb642f2c23	caa11b01-c3a5-4067-a90c-b73b35075def	A-011	\N
6dac5232-f75f-44d2-8533-4119c856f0ac	caa11b01-c3a5-4067-a90c-b73b35075def	A-012	\N
ea815ea6-a6d6-4547-bb06-ebfc9497a6f2	caa11b01-c3a5-4067-a90c-b73b35075def	A-013	\N
b441021b-6b42-4350-bd7a-385d23b17015	caa11b01-c3a5-4067-a90c-b73b35075def	A-014	\N
74194275-0229-47a7-9a12-691c228cbf03	caa11b01-c3a5-4067-a90c-b73b35075def	A-015	\N
f9df5252-7643-42fd-9a63-2e839347a52f	caa11b01-c3a5-4067-a90c-b73b35075def	A-016	\N
321b8a10-e82d-4cf6-a6b2-fde3fa7b05b1	caa11b01-c3a5-4067-a90c-b73b35075def	A-017	\N
9c1ddcb5-9b93-4e47-80ac-cbfc3b7f326e	caa11b01-c3a5-4067-a90c-b73b35075def	A-018	\N
f0106df5-f061-40fd-97c8-f6408f268ff9	caa11b01-c3a5-4067-a90c-b73b35075def	A-019	\N
deeb22d9-7a6b-4417-985b-c76049abae2e	caa11b01-c3a5-4067-a90c-b73b35075def	A-020	\N
c2e7bc3c-62db-4d01-aad3-9513cbf2ecbf	caa11b01-c3a5-4067-a90c-b73b35075def	A-021	\N
8c7ed2ff-3fea-4279-a889-c4e44b78ef6e	caa11b01-c3a5-4067-a90c-b73b35075def	A-022	\N
fb52fe46-dded-4f23-975d-3f36184896e9	caa11b01-c3a5-4067-a90c-b73b35075def	A-023	\N
5fc3f4ab-169c-47bc-819a-315c1a244aac	caa11b01-c3a5-4067-a90c-b73b35075def	A-024	\N
\.


--
-- Data for Name: heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heads (id, community_id, kind, name) FROM stdin;
82e64189-a014-4a10-8c88-7fb239056c07	caa11b01-c3a5-4067-a90c-b73b35075def	expense	Expense
3c9b72a3-e708-4855-9e3a-d14019b2d825	caa11b01-c3a5-4067-a90c-b73b35075def	income	Income
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, community_id, filename, kind, uploaded_by, status, error, row_count, created_at) FROM stdin;
806777cb-6636-493b-9cd0-24e340aa46bf	caa11b01-c3a5-4067-a90c-b73b35075def	vendors.csv	vendors	0f0c6024-6c4d-47b3-9012-4f714d448a40	staged	\N	10	2026-07-13 13:37:55.141154+00
df2abfcc-4160-4fb6-acc4-766e580d629e	caa11b01-c3a5-4067-a90c-b73b35075def	transactions.csv	transactions	0f0c6024-6c4d-47b3-9012-4f714d448a40	staged	\N	152	2026-07-13 13:40:26.875654+00
93794c13-76d1-4640-8b88-212cfa27dfda	caa11b01-c3a5-4067-a90c-b73b35075def	vendors.csv	vendors	0f0c6024-6c4d-47b3-9012-4f714d448a40	failed	\N	10	2026-07-13 13:45:24.298708+00
384c2bb9-1afa-4d02-8058-b65901eed16b	caa11b01-c3a5-4067-a90c-b73b35075def	vendors.csv	vendors	0f0c6024-6c4d-47b3-9012-4f714d448a40	failed	\N	10	2026-07-13 13:46:05.441701+00
357eb336-d2b7-4673-be90-4b545b4f00cc	caa11b01-c3a5-4067-a90c-b73b35075def	vendors.csv	vendors	0f0c6024-6c4d-47b3-9012-4f714d448a40	committed	\N	10	2026-07-13 13:51:53.095408+00
96bba21d-31dc-4280-af5c-307230fa9cf7	caa11b01-c3a5-4067-a90c-b73b35075def	transactions.csv	transactions	0f0c6024-6c4d-47b3-9012-4f714d448a40	committed	\N	152	2026-07-13 13:52:18.229499+00
\.


--
-- Data for Name: import_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_rules (id, community_id, kind, match, set_fields, priority) FROM stdin;
\.


--
-- Data for Name: import_staging; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_staging (batch_id, row_no, raw_json, mapped_json, error) FROM stdin;
93794c13-76d1-4640-8b88-212cfa27dfda	1	{"kind": "company", "name": "Bescom"}	\N	column "kind" is of type vendor_kind but expression is of type text
93794c13-76d1-4640-8b88-212cfa27dfda	2	{"kind": "company", "name": "BWSSB"}	\N	column "kind" is of type vendor_kind but expression is of type text
93794c13-76d1-4640-8b88-212cfa27dfda	3	{"kind": "company", "name": "ABC Enterprise"}	\N	column "kind" is of type vendor_kind but expression is of type text
93794c13-76d1-4640-8b88-212cfa27dfda	4	{"kind": "individual", "name": "John (Plumber)"}	\N	column "kind" is of type vendor_kind but expression is of type text
93794c13-76d1-4640-8b88-212cfa27dfda	5	{"kind": "company", "name": "SafeGuard Services"}	\N	column "kind" is of type vendor_kind but expression is of type text
93794c13-76d1-4640-8b88-212cfa27dfda	6	{"kind": "company", "name": "CleanCo"}	\N	column "kind" is of type vendor_kind but expression is of type text
93794c13-76d1-4640-8b88-212cfa27dfda	7	{"kind": "individual", "name": "Office petty cash"}	\N	column "kind" is of type vendor_kind but expression is of type text
93794c13-76d1-4640-8b88-212cfa27dfda	8	{"kind": "company", "name": "Monthly maintenance"}	\N	column "kind" is of type vendor_kind but expression is of type text
93794c13-76d1-4640-8b88-212cfa27dfda	9	{"kind": "company", "name": "Community Hall"}	\N	column "kind" is of type vendor_kind but expression is of type text
93794c13-76d1-4640-8b88-212cfa27dfda	10	{"kind": "individual", "name": "Signage Rental"}	\N	column "kind" is of type vendor_kind but expression is of type text
384c2bb9-1afa-4d02-8058-b65901eed16b	1	{"kind": "company", "name": "Bescom"}	\N	column "kind" is of type vendor_kind but expression is of type text
384c2bb9-1afa-4d02-8058-b65901eed16b	2	{"kind": "company", "name": "BWSSB"}	\N	column "kind" is of type vendor_kind but expression is of type text
384c2bb9-1afa-4d02-8058-b65901eed16b	3	{"kind": "company", "name": "ABC Enterprise"}	\N	column "kind" is of type vendor_kind but expression is of type text
384c2bb9-1afa-4d02-8058-b65901eed16b	4	{"kind": "individual", "name": "John (Plumber)"}	\N	column "kind" is of type vendor_kind but expression is of type text
384c2bb9-1afa-4d02-8058-b65901eed16b	5	{"kind": "company", "name": "SafeGuard Services"}	\N	column "kind" is of type vendor_kind but expression is of type text
384c2bb9-1afa-4d02-8058-b65901eed16b	6	{"kind": "company", "name": "CleanCo"}	\N	column "kind" is of type vendor_kind but expression is of type text
384c2bb9-1afa-4d02-8058-b65901eed16b	7	{"kind": "individual", "name": "Office petty cash"}	\N	column "kind" is of type vendor_kind but expression is of type text
384c2bb9-1afa-4d02-8058-b65901eed16b	8	{"kind": "company", "name": "Monthly maintenance"}	\N	column "kind" is of type vendor_kind but expression is of type text
384c2bb9-1afa-4d02-8058-b65901eed16b	9	{"kind": "company", "name": "Community Hall"}	\N	column "kind" is of type vendor_kind but expression is of type text
384c2bb9-1afa-4d02-8058-b65901eed16b	10	{"kind": "individual", "name": "Signage Rental"}	\N	column "kind" is of type vendor_kind but expression is of type text
357eb336-d2b7-4673-be90-4b545b4f00cc	1	{"kind": "company", "name": "Bescom"}	\N	\N
357eb336-d2b7-4673-be90-4b545b4f00cc	2	{"kind": "company", "name": "BWSSB"}	\N	\N
357eb336-d2b7-4673-be90-4b545b4f00cc	3	{"kind": "company", "name": "ABC Enterprise"}	\N	\N
357eb336-d2b7-4673-be90-4b545b4f00cc	4	{"kind": "individual", "name": "John (Plumber)"}	\N	\N
357eb336-d2b7-4673-be90-4b545b4f00cc	5	{"kind": "company", "name": "SafeGuard Services"}	\N	\N
357eb336-d2b7-4673-be90-4b545b4f00cc	6	{"kind": "company", "name": "CleanCo"}	\N	\N
357eb336-d2b7-4673-be90-4b545b4f00cc	7	{"kind": "individual", "name": "Office petty cash"}	\N	\N
357eb336-d2b7-4673-be90-4b545b4f00cc	8	{"kind": "company", "name": "Monthly maintenance"}	\N	\N
357eb336-d2b7-4673-be90-4b545b4f00cc	9	{"kind": "company", "name": "Community Hall"}	\N	\N
357eb336-d2b7-4673-be90-4b545b4f00cc	10	{"kind": "individual", "name": "Signage Rental"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	1	{"date": "2025-08-15", "head": "expense", "amount": "48000", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	2	{"date": "2025-09-15", "head": "expense", "amount": "51366", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	3	{"date": "2025-10-15", "head": "expense", "amount": "51637", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	4	{"date": "2025-11-15", "head": "expense", "amount": "48564", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	5	{"date": "2025-12-15", "head": "expense", "amount": "44973", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	6	{"date": "2026-01-15", "head": "expense", "amount": "44164", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	7	{"date": "2026-02-15", "head": "expense", "amount": "46882", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	8	{"date": "2026-03-15", "head": "expense", "amount": "50628", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	9	{"date": "2026-04-15", "head": "expense", "amount": "51957", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	10	{"date": "2026-05-15", "head": "expense", "amount": "49648", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	11	{"date": "2026-06-15", "head": "expense", "amount": "45824", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	12	{"date": "2026-07-15", "head": "expense", "amount": "44000", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	13	{"date": "2025-08-15", "head": "expense", "amount": "12000", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	14	{"date": "2025-09-15", "head": "expense", "amount": "14945", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	15	{"date": "2025-11-15", "head": "expense", "amount": "12494", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	16	{"date": "2025-12-15", "head": "expense", "amount": "9351", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	17	{"date": "2026-01-15", "head": "expense", "amount": "8644", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	18	{"date": "2026-02-15", "head": "expense", "amount": "11022", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	19	{"date": "2026-03-15", "head": "expense", "amount": "14299", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	20	{"date": "2026-05-15", "head": "expense", "amount": "13442", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	21	{"date": "2026-06-15", "head": "expense", "amount": "10096", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	22	{"date": "2026-07-15", "head": "expense", "amount": "8500", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	23	{"date": "2025-08-15", "head": "expense", "amount": "32000", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	24	{"date": "2025-09-15", "head": "expense", "amount": "33683", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	25	{"date": "2025-10-15", "head": "expense", "amount": "33819", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	26	{"date": "2025-11-15", "head": "expense", "amount": "32282", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	27	{"date": "2025-12-15", "head": "expense", "amount": "30486", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	28	{"date": "2026-01-15", "head": "expense", "amount": "30082", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	29	{"date": "2026-02-15", "head": "expense", "amount": "31441", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	30	{"date": "2026-03-15", "head": "expense", "amount": "33314", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	31	{"date": "2026-04-15", "head": "expense", "amount": "33979", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	32	{"date": "2026-05-15", "head": "expense", "amount": "32824", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	33	{"date": "2026-06-15", "head": "expense", "amount": "30912", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	34	{"date": "2026-07-15", "head": "expense", "amount": "30000", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	35	{"date": "2025-08-15", "head": "expense", "amount": "65000", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	36	{"date": "2025-09-15", "head": "expense", "amount": "67524", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	37	{"date": "2025-10-15", "head": "expense", "amount": "67728", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	38	{"date": "2025-11-15", "head": "expense", "amount": "65423", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	39	{"date": "2025-12-15", "head": "expense", "amount": "62730", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	40	{"date": "2026-01-15", "head": "expense", "amount": "62123", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	41	{"date": "2026-02-15", "head": "expense", "amount": "64162", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	42	{"date": "2026-03-15", "head": "expense", "amount": "66971", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	43	{"date": "2026-04-15", "head": "expense", "amount": "67968", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	44	{"date": "2026-05-15", "head": "expense", "amount": "66236", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	45	{"date": "2026-06-15", "head": "expense", "amount": "63368", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	46	{"date": "2026-07-15", "head": "expense", "amount": "62000", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	47	{"date": "2025-08-15", "head": "expense", "amount": "18000", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	48	{"date": "2025-10-15", "head": "expense", "amount": "23456", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	49	{"date": "2025-11-15", "head": "expense", "amount": "18847", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	50	{"date": "2026-01-15", "head": "expense", "amount": "12246", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	51	{"date": "2026-02-15", "head": "expense", "amount": "16324", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	52	{"date": "2026-04-15", "head": "expense", "amount": "23936", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	53	{"date": "2026-05-15", "head": "expense", "amount": "20473", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	54	{"date": "2026-06-15", "head": "expense", "amount": "14736", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	55	{"date": "2026-07-15", "head": "expense", "amount": "12000", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	56	{"date": "2025-10-15", "head": "expense", "amount": "9455", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "STP salt purchase", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	57	{"date": "2026-01-15", "head": "expense", "amount": "8521", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "STP salt purchase", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	58	{"date": "2026-04-15", "head": "expense", "amount": "9495", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "STP salt purchase", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	59	{"date": "2026-07-15", "head": "expense", "amount": "8500", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "STP salt purchase", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	60	{"date": "2025-09-15", "head": "expense", "amount": "7445", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	61	{"date": "2025-11-15", "head": "expense", "amount": "4994", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	62	{"date": "2025-12-15", "head": "expense", "amount": "1851", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	63	{"date": "2026-03-15", "head": "expense", "amount": "6799", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	64	{"date": "2026-05-15", "head": "expense", "amount": "5942", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	65	{"date": "2026-06-15", "head": "expense", "amount": "2596", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	66	{"date": "2025-08-15", "head": "expense", "amount": "120000", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	67	{"date": "2025-09-15", "head": "expense", "amount": "121683", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	68	{"date": "2025-10-15", "head": "expense", "amount": "121819", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	69	{"date": "2025-11-15", "head": "expense", "amount": "120282", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	70	{"date": "2025-12-15", "head": "expense", "amount": "118486", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	71	{"date": "2026-01-15", "head": "expense", "amount": "118082", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	72	{"date": "2026-02-15", "head": "expense", "amount": "119441", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	73	{"date": "2026-03-15", "head": "expense", "amount": "121314", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	74	{"date": "2026-04-15", "head": "expense", "amount": "121979", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	75	{"date": "2026-05-15", "head": "expense", "amount": "120824", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	76	{"date": "2026-06-15", "head": "expense", "amount": "118912", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	77	{"date": "2026-07-15", "head": "expense", "amount": "118000", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	78	{"date": "2025-08-15", "head": "expense", "amount": "58000", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	79	{"date": "2025-09-15", "head": "expense", "amount": "59262", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	80	{"date": "2025-10-15", "head": "expense", "amount": "59364", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	81	{"date": "2025-11-15", "head": "expense", "amount": "58212", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	82	{"date": "2025-12-15", "head": "expense", "amount": "56865", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	83	{"date": "2026-01-15", "head": "expense", "amount": "56562", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	84	{"date": "2026-02-15", "head": "expense", "amount": "57581", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	85	{"date": "2026-03-15", "head": "expense", "amount": "58985", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	86	{"date": "2026-04-15", "head": "expense", "amount": "59484", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	87	{"date": "2026-05-15", "head": "expense", "amount": "58618", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	88	{"date": "2026-06-15", "head": "expense", "amount": "57184", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	89	{"date": "2026-07-15", "head": "expense", "amount": "56500", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	90	{"date": "2025-08-15", "head": "expense", "amount": "7500", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	91	{"date": "2025-09-15", "head": "expense", "amount": "8762", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	92	{"date": "2025-10-15", "head": "expense", "amount": "8864", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	93	{"date": "2025-11-15", "head": "expense", "amount": "7712", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	94	{"date": "2025-12-15", "head": "expense", "amount": "6365", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	95	{"date": "2026-01-15", "head": "expense", "amount": "6062", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	96	{"date": "2026-02-15", "head": "expense", "amount": "7081", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	97	{"date": "2026-03-15", "head": "expense", "amount": "8485", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	98	{"date": "2026-04-15", "head": "expense", "amount": "8984", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	99	{"date": "2026-05-15", "head": "expense", "amount": "8118", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	100	{"date": "2026-06-15", "head": "expense", "amount": "6684", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	101	{"date": "2026-07-15", "head": "expense", "amount": "6000", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	102	{"date": "2025-08-15", "head": "expense", "amount": "6000", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	103	{"date": "2025-09-15", "head": "expense", "amount": "10628", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	104	{"date": "2025-10-15", "head": "expense", "amount": "11001", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	105	{"date": "2025-11-15", "head": "expense", "amount": "6776", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	106	{"date": "2025-12-15", "head": "expense", "amount": "1838", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	107	{"date": "2026-01-15", "head": "expense", "amount": "726", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	108	{"date": "2026-02-15", "head": "expense", "amount": "4463", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	109	{"date": "2026-03-15", "head": "expense", "amount": "9613", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	110	{"date": "2026-04-15", "head": "expense", "amount": "11441", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	111	{"date": "2026-05-15", "head": "expense", "amount": "8267", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	112	{"date": "2026-06-15", "head": "expense", "amount": "3008", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	113	{"date": "2026-07-15", "head": "expense", "amount": "500", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	114	{"date": "2025-08-15", "head": "income", "amount": "340000", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	115	{"date": "2025-09-15", "head": "income", "amount": "352622", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	116	{"date": "2025-10-15", "head": "income", "amount": "353639", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	117	{"date": "2025-11-15", "head": "income", "amount": "342117", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	118	{"date": "2025-12-15", "head": "income", "amount": "328648", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	119	{"date": "2026-01-15", "head": "income", "amount": "325616", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	120	{"date": "2026-02-15", "head": "income", "amount": "335809", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	121	{"date": "2026-03-15", "head": "income", "amount": "349855", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	122	{"date": "2026-04-15", "head": "income", "amount": "354840", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	123	{"date": "2026-05-15", "head": "income", "amount": "346182", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	124	{"date": "2026-06-15", "head": "income", "amount": "331840", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	125	{"date": "2026-07-15", "head": "income", "amount": "325000", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	126	{"date": "2025-08-15", "head": "income", "amount": "18000", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	127	{"date": "2025-10-15", "head": "income", "amount": "25274", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	128	{"date": "2025-11-15", "head": "income", "amount": "19129", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	129	{"date": "2025-12-15", "head": "income", "amount": "11946", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	130	{"date": "2026-02-15", "head": "income", "amount": "15765", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	131	{"date": "2026-03-15", "head": "income", "amount": "23256", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	132	{"date": "2026-04-15", "head": "income", "amount": "25915", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	133	{"date": "2026-06-15", "head": "income", "amount": "13648", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	134	{"date": "2026-07-15", "head": "income", "amount": "10000", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	135	{"date": "2025-09-15", "head": "income", "amount": "9787", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	136	{"date": "2025-11-15", "head": "income", "amount": "6635", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	137	{"date": "2026-01-15", "head": "income", "amount": "1685", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	138	{"date": "2026-03-15", "head": "income", "amount": "8956", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	139	{"date": "2026-05-15", "head": "income", "amount": "7855", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	140	{"date": "2026-07-15", "head": "income", "amount": "1500", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	141	{"date": "2025-08-15", "head": "income", "amount": "12000", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	142	{"date": "2025-09-15", "head": "income", "amount": "12421", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	143	{"date": "2025-10-15", "head": "income", "amount": "12455", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	144	{"date": "2025-11-15", "head": "income", "amount": "12071", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	145	{"date": "2025-12-15", "head": "income", "amount": "11622", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	146	{"date": "2026-01-15", "head": "income", "amount": "11521", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	147	{"date": "2026-02-15", "head": "income", "amount": "11860", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	148	{"date": "2026-03-15", "head": "income", "amount": "12328", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	149	{"date": "2026-04-15", "head": "income", "amount": "12495", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	150	{"date": "2026-05-15", "head": "income", "amount": "12206", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	151	{"date": "2026-06-15", "head": "income", "amount": "11728", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
96bba21d-31dc-4280-af5c-307230fa9cf7	152	{"date": "2026-07-15", "head": "income", "amount": "11500", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
\.


--
-- Data for Name: line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_items (id, category_id, vendor_id, name, first_seen_month, last_seen_month) FROM stdin;
e87088da-8f5f-4e02-97a1-d08b8b411e90	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	Common area electricity	2025-08-01	2026-07-01
ac9aaacd-576d-4e7c-ab15-8435f733bc1b	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	Backup usage	2025-08-01	2026-07-01
7ef7e63b-a661-43c2-8e60-69f0b1094818	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	Water charges	2025-08-01	2026-07-01
35a9f024-b779-4885-8d44-4f0c6c1f0ff8	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	Labour charges	2025-08-01	2026-07-01
63105838-9605-4ab2-bc25-24abbcd9ff28	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	Spare parts	2025-08-01	2026-07-01
739be97c-87e1-4133-bd90-8a9e4d175e18	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	STP salt purchase	2025-10-01	2026-07-01
65502b0b-1c05-49c1-8eb6-e68e0d963977	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	41321aa1-9577-4777-83b3-bac1b57bc85f	Plumbing repair	2025-09-01	2026-06-01
3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	Guard salaries	2025-08-01	2026-07-01
a845b714-6226-4f8a-a8dc-178f29a68f58	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	Staff wages	2025-08-01	2026-07-01
0d614d28-d81e-4fd0-8808-8347b9a96a82	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	Cleaning supplies	2025-08-01	2026-07-01
1aa17d97-20af-4baa-a3a2-ce743ca8748b	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	Ad-hoc expenses	2025-08-01	2026-07-01
5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	Flat maintenance dues	2025-08-01	2026-07-01
03153939-e10b-4570-928e-2ed56971eac9	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	Hall rental	2025-08-01	2026-07-01
f4b5617e-aba2-4b86-868a-5ef578c51a06	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	Event usage charges	2025-09-01	2026-07-01
4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	Billboard fee	2025-08-01	2026-07-01
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp_codes (email, otp_hash, expires_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periods (id, community_id, month, status) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, community_id, txn_date, period_month, head_id, category_id, vendor_id, line_item_id, flat_id, amount_paise, direction, source, source_ref, notes, created_by, created_at, updated_at) FROM stdin;
f3d9c766-5d7f-465e-b780-9d4a95d60f24	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	e87088da-8f5f-4e02-97a1-d08b8b411e90	\N	4800000	D	csv	2025-08-15|Utilities|Bescom|Common area electricity|4800000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
fd0ac9b5-08f5-425b-86fd-d07a6ab78b11	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	e87088da-8f5f-4e02-97a1-d08b8b411e90	\N	5136600	D	csv	2025-09-15|Utilities|Bescom|Common area electricity|5136600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
819108cf-6399-45a3-8c75-ee6df35ae939	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	e87088da-8f5f-4e02-97a1-d08b8b411e90	\N	5163700	D	csv	2025-10-15|Utilities|Bescom|Common area electricity|5163700	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
9edfc789-a298-45e0-b3fd-724a69f1b740	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	e87088da-8f5f-4e02-97a1-d08b8b411e90	\N	4856400	D	csv	2025-11-15|Utilities|Bescom|Common area electricity|4856400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
ef44497c-b02c-4605-9ce4-47eba45a09dd	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	e87088da-8f5f-4e02-97a1-d08b8b411e90	\N	4497300	D	csv	2025-12-15|Utilities|Bescom|Common area electricity|4497300	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
0d8bdc91-6a5c-46d4-81ff-238fb82c7f4d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	e87088da-8f5f-4e02-97a1-d08b8b411e90	\N	4416400	D	csv	2026-01-15|Utilities|Bescom|Common area electricity|4416400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
5a2aa1d7-b29f-4887-8db8-01deacb79c0d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	e87088da-8f5f-4e02-97a1-d08b8b411e90	\N	4688200	D	csv	2026-02-15|Utilities|Bescom|Common area electricity|4688200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
97ccf4f7-7924-4782-9f7d-d97b9184032b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	e87088da-8f5f-4e02-97a1-d08b8b411e90	\N	5062800	D	csv	2026-03-15|Utilities|Bescom|Common area electricity|5062800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
64d8f086-5a05-4b23-bf06-e2a1792cbf70	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	e87088da-8f5f-4e02-97a1-d08b8b411e90	\N	5195700	D	csv	2026-04-15|Utilities|Bescom|Common area electricity|5195700	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
2cd437e5-1918-4f47-8aac-31a1093d06c2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	e87088da-8f5f-4e02-97a1-d08b8b411e90	\N	4964800	D	csv	2026-05-15|Utilities|Bescom|Common area electricity|4964800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
bfd3110f-40f2-45f6-b302-67d6f802ec0d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	e87088da-8f5f-4e02-97a1-d08b8b411e90	\N	4582400	D	csv	2026-06-15|Utilities|Bescom|Common area electricity|4582400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
72c68b62-78a4-430a-b457-4366cc242c5d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	e87088da-8f5f-4e02-97a1-d08b8b411e90	\N	4400000	D	csv	2026-07-15|Utilities|Bescom|Common area electricity|4400000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
bbcbb2b8-5828-4f00-91ab-d8530b846050	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	ac9aaacd-576d-4e7c-ab15-8435f733bc1b	\N	1200000	D	csv	2025-08-15|Utilities|Bescom|Backup usage|1200000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
582cb426-339e-46f4-a197-fbfd43d4efc6	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	ac9aaacd-576d-4e7c-ab15-8435f733bc1b	\N	1494500	D	csv	2025-09-15|Utilities|Bescom|Backup usage|1494500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
4165ba65-52c0-4a65-830b-019798ef777c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	ac9aaacd-576d-4e7c-ab15-8435f733bc1b	\N	1249400	D	csv	2025-11-15|Utilities|Bescom|Backup usage|1249400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
a6527a4c-9911-4f18-8ce3-3f8db46b7480	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	ac9aaacd-576d-4e7c-ab15-8435f733bc1b	\N	935100	D	csv	2025-12-15|Utilities|Bescom|Backup usage|935100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
e06fea7a-5e80-4634-aa7f-1742422f67e0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	ac9aaacd-576d-4e7c-ab15-8435f733bc1b	\N	864400	D	csv	2026-01-15|Utilities|Bescom|Backup usage|864400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
2b7ced47-d93f-41b3-9070-44e1a99cbc1a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	ac9aaacd-576d-4e7c-ab15-8435f733bc1b	\N	1102200	D	csv	2026-02-15|Utilities|Bescom|Backup usage|1102200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
ab49be64-217e-4c86-9a0a-c7f1babd598b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	ac9aaacd-576d-4e7c-ab15-8435f733bc1b	\N	1429900	D	csv	2026-03-15|Utilities|Bescom|Backup usage|1429900	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
e029b1cd-c626-4054-9085-5720c15a4c6b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	ac9aaacd-576d-4e7c-ab15-8435f733bc1b	\N	1344200	D	csv	2026-05-15|Utilities|Bescom|Backup usage|1344200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
179dd991-c100-4fa2-aee1-fea9d8b2063e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	ac9aaacd-576d-4e7c-ab15-8435f733bc1b	\N	1009600	D	csv	2026-06-15|Utilities|Bescom|Backup usage|1009600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
5ad86df5-427a-466c-bd78-c00dc53f0307	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	f5660094-91f0-4bee-a5df-2e1e0232713a	ac9aaacd-576d-4e7c-ab15-8435f733bc1b	\N	850000	D	csv	2026-07-15|Utilities|Bescom|Backup usage|850000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
6cc5f400-9104-4ab4-9c00-a50efc128231	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	7ef7e63b-a661-43c2-8e60-69f0b1094818	\N	3200000	D	csv	2025-08-15|Utilities|BWSSB|Water charges|3200000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
8c57153f-48ad-4600-9870-81b33210fb29	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	7ef7e63b-a661-43c2-8e60-69f0b1094818	\N	3368300	D	csv	2025-09-15|Utilities|BWSSB|Water charges|3368300	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
fef99358-65dc-4730-90bf-67ee522706dd	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	7ef7e63b-a661-43c2-8e60-69f0b1094818	\N	3381900	D	csv	2025-10-15|Utilities|BWSSB|Water charges|3381900	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
83e4a297-da54-4507-8c43-f60a73e76acd	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	7ef7e63b-a661-43c2-8e60-69f0b1094818	\N	3228200	D	csv	2025-11-15|Utilities|BWSSB|Water charges|3228200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
1d74cd19-a60c-4499-b932-81a5fac884b1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	7ef7e63b-a661-43c2-8e60-69f0b1094818	\N	3048600	D	csv	2025-12-15|Utilities|BWSSB|Water charges|3048600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
cdc8e238-019c-4315-b65f-b51313e4288f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	7ef7e63b-a661-43c2-8e60-69f0b1094818	\N	3008200	D	csv	2026-01-15|Utilities|BWSSB|Water charges|3008200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
b3f296b8-67b9-462b-8300-67fbde7e45db	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	7ef7e63b-a661-43c2-8e60-69f0b1094818	\N	3144100	D	csv	2026-02-15|Utilities|BWSSB|Water charges|3144100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
03fa4dc5-9149-4ed7-b868-6133912ca915	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	7ef7e63b-a661-43c2-8e60-69f0b1094818	\N	3331400	D	csv	2026-03-15|Utilities|BWSSB|Water charges|3331400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
b9ac8af2-b218-4daf-99ae-653a681c0b2a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	7ef7e63b-a661-43c2-8e60-69f0b1094818	\N	3397900	D	csv	2026-04-15|Utilities|BWSSB|Water charges|3397900	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
8cea86fa-3a52-48ef-9643-d5da0132fcc6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	7ef7e63b-a661-43c2-8e60-69f0b1094818	\N	3282400	D	csv	2026-05-15|Utilities|BWSSB|Water charges|3282400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
fd8a3483-36f9-4b7a-b28a-218462a65b04	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	7ef7e63b-a661-43c2-8e60-69f0b1094818	\N	3091200	D	csv	2026-06-15|Utilities|BWSSB|Water charges|3091200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
b06680c2-962a-464f-a962-9414fbe5fdf8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	82e64189-a014-4a10-8c88-7fb239056c07	1baebeba-1ce7-4e5c-89f2-fc2ffa2f5c47	84cd4899-27e5-49ce-9640-f7aa7b497865	7ef7e63b-a661-43c2-8e60-69f0b1094818	\N	3000000	D	csv	2026-07-15|Utilities|BWSSB|Water charges|3000000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
136352d7-845f-4e21-8c6a-f57cf990d0ad	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	35a9f024-b779-4885-8d44-4f0c6c1f0ff8	\N	6500000	D	csv	2025-08-15|Maintenance|ABC Enterprise|Labour charges|6500000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
9e4c4c07-b390-4d53-ae4d-ac2ce1d8d7c1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	35a9f024-b779-4885-8d44-4f0c6c1f0ff8	\N	6752400	D	csv	2025-09-15|Maintenance|ABC Enterprise|Labour charges|6752400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
3b998ab6-27af-4e16-be9a-30961129dc44	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	35a9f024-b779-4885-8d44-4f0c6c1f0ff8	\N	6772800	D	csv	2025-10-15|Maintenance|ABC Enterprise|Labour charges|6772800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
c278e1db-802a-4e74-9efb-080f2c1533eb	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	35a9f024-b779-4885-8d44-4f0c6c1f0ff8	\N	6542300	D	csv	2025-11-15|Maintenance|ABC Enterprise|Labour charges|6542300	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
903839c0-ffaa-41e1-b7ca-df747030a79c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	35a9f024-b779-4885-8d44-4f0c6c1f0ff8	\N	6273000	D	csv	2025-12-15|Maintenance|ABC Enterprise|Labour charges|6273000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
a5b13bf2-da4b-4b53-8e9a-9bb5d87ab078	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	35a9f024-b779-4885-8d44-4f0c6c1f0ff8	\N	6212300	D	csv	2026-01-15|Maintenance|ABC Enterprise|Labour charges|6212300	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
7d830129-2480-436c-9bed-5a864e4ca0f5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	35a9f024-b779-4885-8d44-4f0c6c1f0ff8	\N	6416200	D	csv	2026-02-15|Maintenance|ABC Enterprise|Labour charges|6416200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
7c1e8f32-b7f7-413f-b4c1-4866ccae9235	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	35a9f024-b779-4885-8d44-4f0c6c1f0ff8	\N	6697100	D	csv	2026-03-15|Maintenance|ABC Enterprise|Labour charges|6697100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
5328c937-e960-4d11-9377-e32c4c871a1a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	35a9f024-b779-4885-8d44-4f0c6c1f0ff8	\N	6796800	D	csv	2026-04-15|Maintenance|ABC Enterprise|Labour charges|6796800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
9016ba94-a25c-46fc-9c8b-67551e78f656	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	35a9f024-b779-4885-8d44-4f0c6c1f0ff8	\N	6623600	D	csv	2026-05-15|Maintenance|ABC Enterprise|Labour charges|6623600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
69ad0e30-c886-4d90-8f25-751caac07f44	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	35a9f024-b779-4885-8d44-4f0c6c1f0ff8	\N	6336800	D	csv	2026-06-15|Maintenance|ABC Enterprise|Labour charges|6336800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
b33c6bb7-fc59-43e3-a76f-cdcf26ee0a2b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	35a9f024-b779-4885-8d44-4f0c6c1f0ff8	\N	6200000	D	csv	2026-07-15|Maintenance|ABC Enterprise|Labour charges|6200000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
eb859f09-b209-4448-8739-41db7d4b9f06	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	63105838-9605-4ab2-bc25-24abbcd9ff28	\N	1800000	D	csv	2025-08-15|Maintenance|ABC Enterprise|Spare parts|1800000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
4f9c9ce6-f2e4-4036-8c66-57de138ecae0	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	63105838-9605-4ab2-bc25-24abbcd9ff28	\N	2345600	D	csv	2025-10-15|Maintenance|ABC Enterprise|Spare parts|2345600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
b05305bb-646d-44d6-acde-12036f6cced7	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	63105838-9605-4ab2-bc25-24abbcd9ff28	\N	1884700	D	csv	2025-11-15|Maintenance|ABC Enterprise|Spare parts|1884700	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
86a73991-1fa9-4e5f-9819-b6b2c23438ae	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	63105838-9605-4ab2-bc25-24abbcd9ff28	\N	1224600	D	csv	2026-01-15|Maintenance|ABC Enterprise|Spare parts|1224600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
73feded2-810d-4947-b5af-4098ab53bf7b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	63105838-9605-4ab2-bc25-24abbcd9ff28	\N	1632400	D	csv	2026-02-15|Maintenance|ABC Enterprise|Spare parts|1632400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
fdbc598c-39c2-4da7-849a-baf91d19e5d9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	63105838-9605-4ab2-bc25-24abbcd9ff28	\N	2393600	D	csv	2026-04-15|Maintenance|ABC Enterprise|Spare parts|2393600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
7f37e3aa-4799-49c6-b937-65e887c6316a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	63105838-9605-4ab2-bc25-24abbcd9ff28	\N	2047300	D	csv	2026-05-15|Maintenance|ABC Enterprise|Spare parts|2047300	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
1c207850-a15a-4ae4-881c-8de7fd6bf7eb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	63105838-9605-4ab2-bc25-24abbcd9ff28	\N	1473600	D	csv	2026-06-15|Maintenance|ABC Enterprise|Spare parts|1473600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
40396838-a686-405f-bdc7-80de967280de	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	63105838-9605-4ab2-bc25-24abbcd9ff28	\N	1200000	D	csv	2026-07-15|Maintenance|ABC Enterprise|Spare parts|1200000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
d9bf0381-d680-4ab5-9745-2f28f886a523	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	739be97c-87e1-4133-bd90-8a9e4d175e18	\N	945500	D	csv	2025-10-15|Maintenance|ABC Enterprise|STP salt purchase|945500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
7ba76243-79c4-40e9-9fe6-929c5f21586e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	739be97c-87e1-4133-bd90-8a9e4d175e18	\N	852100	D	csv	2026-01-15|Maintenance|ABC Enterprise|STP salt purchase|852100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
383eefa5-526a-405e-9f67-7eae1db05548	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	739be97c-87e1-4133-bd90-8a9e4d175e18	\N	949500	D	csv	2026-04-15|Maintenance|ABC Enterprise|STP salt purchase|949500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
205937d6-9615-4d67-be09-38e70b13b7ea	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	5cf9910f-8049-414f-9fd8-d7048e29cb3b	739be97c-87e1-4133-bd90-8a9e4d175e18	\N	850000	D	csv	2026-07-15|Maintenance|ABC Enterprise|STP salt purchase|850000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
c0984ad5-9fbc-45c9-96a6-2e93cce18f76	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	41321aa1-9577-4777-83b3-bac1b57bc85f	65502b0b-1c05-49c1-8eb6-e68e0d963977	\N	744500	D	csv	2025-09-15|Maintenance|John (Plumber)|Plumbing repair|744500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
e8ed8718-71db-4950-aed0-49d327321ba8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	41321aa1-9577-4777-83b3-bac1b57bc85f	65502b0b-1c05-49c1-8eb6-e68e0d963977	\N	499400	D	csv	2025-11-15|Maintenance|John (Plumber)|Plumbing repair|499400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
2a24a365-8c18-45c3-9399-3d6c9fa8bf68	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	41321aa1-9577-4777-83b3-bac1b57bc85f	65502b0b-1c05-49c1-8eb6-e68e0d963977	\N	185100	D	csv	2025-12-15|Maintenance|John (Plumber)|Plumbing repair|185100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
a121b376-5b49-463c-9967-feafbb5ce071	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	41321aa1-9577-4777-83b3-bac1b57bc85f	65502b0b-1c05-49c1-8eb6-e68e0d963977	\N	679900	D	csv	2026-03-15|Maintenance|John (Plumber)|Plumbing repair|679900	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
f3a6cc88-b544-4612-b0f4-27ffa15e1732	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	41321aa1-9577-4777-83b3-bac1b57bc85f	65502b0b-1c05-49c1-8eb6-e68e0d963977	\N	594200	D	csv	2026-05-15|Maintenance|John (Plumber)|Plumbing repair|594200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
3d99a147-362b-4e66-9898-9d8bce8b1304	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	82e64189-a014-4a10-8c88-7fb239056c07	4b1fbe99-dd8c-4ec0-8fe4-4677e6f5b2c6	41321aa1-9577-4777-83b3-bac1b57bc85f	65502b0b-1c05-49c1-8eb6-e68e0d963977	\N	259600	D	csv	2026-06-15|Maintenance|John (Plumber)|Plumbing repair|259600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
1ee91f6f-17fa-4720-a653-d8058a4fa378	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	82e64189-a014-4a10-8c88-7fb239056c07	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	\N	12000000	D	csv	2025-08-15|Security|SafeGuard Services|Guard salaries|12000000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
ad32f269-8edf-471a-b3c9-8b7cd268da44	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	82e64189-a014-4a10-8c88-7fb239056c07	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	\N	12168300	D	csv	2025-09-15|Security|SafeGuard Services|Guard salaries|12168300	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
9a69d322-fc58-461d-816f-95799463f0b4	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	82e64189-a014-4a10-8c88-7fb239056c07	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	\N	12181900	D	csv	2025-10-15|Security|SafeGuard Services|Guard salaries|12181900	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
8429d632-f02e-43f9-b93d-21c84bd30905	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	82e64189-a014-4a10-8c88-7fb239056c07	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	\N	12028200	D	csv	2025-11-15|Security|SafeGuard Services|Guard salaries|12028200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
97d458b2-064b-41e2-b383-aeca993edd82	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	82e64189-a014-4a10-8c88-7fb239056c07	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	\N	11848600	D	csv	2025-12-15|Security|SafeGuard Services|Guard salaries|11848600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
b7e3c190-08fd-438e-b88a-bf4f85d0faf6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	82e64189-a014-4a10-8c88-7fb239056c07	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	\N	11808200	D	csv	2026-01-15|Security|SafeGuard Services|Guard salaries|11808200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
98602125-36d4-48b5-b5b8-902fe60dfbc2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	82e64189-a014-4a10-8c88-7fb239056c07	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	\N	11944100	D	csv	2026-02-15|Security|SafeGuard Services|Guard salaries|11944100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
019aae00-4106-4752-b4ae-8239e505ffbb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	82e64189-a014-4a10-8c88-7fb239056c07	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	\N	12131400	D	csv	2026-03-15|Security|SafeGuard Services|Guard salaries|12131400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
58f9e80d-5225-4e27-bcff-52c237f0f7d5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	82e64189-a014-4a10-8c88-7fb239056c07	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	\N	12197900	D	csv	2026-04-15|Security|SafeGuard Services|Guard salaries|12197900	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
c37b390f-2d84-4bbf-a508-3adf7dda8f74	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	82e64189-a014-4a10-8c88-7fb239056c07	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	\N	12082400	D	csv	2026-05-15|Security|SafeGuard Services|Guard salaries|12082400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
351b0f73-a09c-4105-9ecf-5d399549c3c3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	82e64189-a014-4a10-8c88-7fb239056c07	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	\N	11891200	D	csv	2026-06-15|Security|SafeGuard Services|Guard salaries|11891200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
26af409d-5252-452d-aa48-5b58b48b329b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	82e64189-a014-4a10-8c88-7fb239056c07	ff2e28c0-2a59-4a89-a61a-f4d4d6494af5	d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	3d3f739c-8c7b-4663-bfa3-4b0e6d4051d5	\N	11800000	D	csv	2026-07-15|Security|SafeGuard Services|Guard salaries|11800000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
878ab3e2-3aed-4d31-9346-d975eba776f2	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	a845b714-6226-4f8a-a8dc-178f29a68f58	\N	5800000	D	csv	2025-08-15|Housekeeping|CleanCo|Staff wages|5800000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
aa182b56-79f8-43e6-9287-18637fcb362a	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	a845b714-6226-4f8a-a8dc-178f29a68f58	\N	5926200	D	csv	2025-09-15|Housekeeping|CleanCo|Staff wages|5926200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
2f5d3f08-6081-486e-9342-475c2f8a43e9	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	a845b714-6226-4f8a-a8dc-178f29a68f58	\N	5936400	D	csv	2025-10-15|Housekeeping|CleanCo|Staff wages|5936400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
c4f32707-1220-4f50-a259-8948c40501c8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	a845b714-6226-4f8a-a8dc-178f29a68f58	\N	5821200	D	csv	2025-11-15|Housekeeping|CleanCo|Staff wages|5821200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
f1008e3a-c729-4a48-a4b7-f955e7145bfa	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	a845b714-6226-4f8a-a8dc-178f29a68f58	\N	5686500	D	csv	2025-12-15|Housekeeping|CleanCo|Staff wages|5686500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
6d284f70-70ae-4c09-8445-ba9ab9ed8472	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	a845b714-6226-4f8a-a8dc-178f29a68f58	\N	5656200	D	csv	2026-01-15|Housekeeping|CleanCo|Staff wages|5656200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
b57efaff-fd9f-40f2-9fac-356705bf5a07	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	a845b714-6226-4f8a-a8dc-178f29a68f58	\N	5758100	D	csv	2026-02-15|Housekeeping|CleanCo|Staff wages|5758100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
d2a6fcae-4194-4488-9bf8-bb2d60a8b180	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	a845b714-6226-4f8a-a8dc-178f29a68f58	\N	5898500	D	csv	2026-03-15|Housekeeping|CleanCo|Staff wages|5898500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
c70de549-9a68-41c1-a54b-79da5ecbbc10	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	a845b714-6226-4f8a-a8dc-178f29a68f58	\N	5948400	D	csv	2026-04-15|Housekeeping|CleanCo|Staff wages|5948400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
54b2aadc-da44-448a-8c76-2a6494abcf12	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	a845b714-6226-4f8a-a8dc-178f29a68f58	\N	5861800	D	csv	2026-05-15|Housekeeping|CleanCo|Staff wages|5861800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
96ca3698-ce03-4346-99b7-5a250e55c680	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	a845b714-6226-4f8a-a8dc-178f29a68f58	\N	5718400	D	csv	2026-06-15|Housekeeping|CleanCo|Staff wages|5718400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
4be380ea-1ed2-4883-966d-89da2880e4cf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	a845b714-6226-4f8a-a8dc-178f29a68f58	\N	5650000	D	csv	2026-07-15|Housekeeping|CleanCo|Staff wages|5650000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
136f7d13-47d7-4892-ba31-e2c696fdcd2e	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	0d614d28-d81e-4fd0-8808-8347b9a96a82	\N	750000	D	csv	2025-08-15|Housekeeping|CleanCo|Cleaning supplies|750000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
1404bab2-bdbb-4c68-8015-c45ef12b9c7e	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	0d614d28-d81e-4fd0-8808-8347b9a96a82	\N	876200	D	csv	2025-09-15|Housekeeping|CleanCo|Cleaning supplies|876200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
25826d9b-1986-42ac-8f6b-99637792b2e7	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	0d614d28-d81e-4fd0-8808-8347b9a96a82	\N	886400	D	csv	2025-10-15|Housekeeping|CleanCo|Cleaning supplies|886400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
857d2677-d9e2-4a65-adcc-0f8d396596dd	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	0d614d28-d81e-4fd0-8808-8347b9a96a82	\N	771200	D	csv	2025-11-15|Housekeeping|CleanCo|Cleaning supplies|771200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
f635cea2-e061-4bc0-9dce-a4a08d0c3fb1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	0d614d28-d81e-4fd0-8808-8347b9a96a82	\N	636500	D	csv	2025-12-15|Housekeeping|CleanCo|Cleaning supplies|636500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
97a00d0c-893e-412f-ac75-2bac58cac70c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	0d614d28-d81e-4fd0-8808-8347b9a96a82	\N	606200	D	csv	2026-01-15|Housekeeping|CleanCo|Cleaning supplies|606200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
7c2364c8-3fc5-4d0c-934b-929d71026e1f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	0d614d28-d81e-4fd0-8808-8347b9a96a82	\N	708100	D	csv	2026-02-15|Housekeeping|CleanCo|Cleaning supplies|708100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
b3a9ddb5-a9fc-43cd-b6ff-b7ba08ac8c44	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	0d614d28-d81e-4fd0-8808-8347b9a96a82	\N	848500	D	csv	2026-03-15|Housekeeping|CleanCo|Cleaning supplies|848500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
8fd0af6d-7a10-4a55-b123-983803c13975	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	0d614d28-d81e-4fd0-8808-8347b9a96a82	\N	898400	D	csv	2026-04-15|Housekeeping|CleanCo|Cleaning supplies|898400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
0e115eef-b6b2-4e9c-b8b0-fdfd2f4717cf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	0d614d28-d81e-4fd0-8808-8347b9a96a82	\N	811800	D	csv	2026-05-15|Housekeeping|CleanCo|Cleaning supplies|811800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
aab356bc-d994-4f3f-b934-9ba3691c4ccb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	0d614d28-d81e-4fd0-8808-8347b9a96a82	\N	668400	D	csv	2026-06-15|Housekeeping|CleanCo|Cleaning supplies|668400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
db81c12f-fb8d-4b50-a703-034922185379	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	82e64189-a014-4a10-8c88-7fb239056c07	6c8f2409-cbf7-4e2f-b24b-3fd6269bfb28	e9a23daf-024e-4651-b1d6-72bfc022091a	0d614d28-d81e-4fd0-8808-8347b9a96a82	\N	600000	D	csv	2026-07-15|Housekeeping|CleanCo|Cleaning supplies|600000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
18200999-b4db-4d7c-a8ac-ce81bcfebcfc	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	82e64189-a014-4a10-8c88-7fb239056c07	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	1aa17d97-20af-4baa-a3a2-ce743ca8748b	\N	600000	D	csv	2025-08-15|Petty Cash|Office petty cash|Ad-hoc expenses|600000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
f633ef63-db37-47e0-bf84-e7b332b96430	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	82e64189-a014-4a10-8c88-7fb239056c07	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	1aa17d97-20af-4baa-a3a2-ce743ca8748b	\N	1062800	D	csv	2025-09-15|Petty Cash|Office petty cash|Ad-hoc expenses|1062800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
5c81e97c-d753-41e7-89a6-4292c68ea929	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	82e64189-a014-4a10-8c88-7fb239056c07	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	1aa17d97-20af-4baa-a3a2-ce743ca8748b	\N	1100100	D	csv	2025-10-15|Petty Cash|Office petty cash|Ad-hoc expenses|1100100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
08e54249-0da5-4574-a99f-421ec9b48af1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	82e64189-a014-4a10-8c88-7fb239056c07	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	1aa17d97-20af-4baa-a3a2-ce743ca8748b	\N	677600	D	csv	2025-11-15|Petty Cash|Office petty cash|Ad-hoc expenses|677600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
3fde95a9-34e9-489b-9fe0-e92cc9bb8f41	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	82e64189-a014-4a10-8c88-7fb239056c07	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	1aa17d97-20af-4baa-a3a2-ce743ca8748b	\N	183800	D	csv	2025-12-15|Petty Cash|Office petty cash|Ad-hoc expenses|183800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
111ad42d-8019-43b9-bb7d-7cac9a1e5b3a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	82e64189-a014-4a10-8c88-7fb239056c07	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	1aa17d97-20af-4baa-a3a2-ce743ca8748b	\N	72600	D	csv	2026-01-15|Petty Cash|Office petty cash|Ad-hoc expenses|72600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
7a835e55-8bf2-481c-b7cd-b2f6a462b233	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	82e64189-a014-4a10-8c88-7fb239056c07	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	1aa17d97-20af-4baa-a3a2-ce743ca8748b	\N	446300	D	csv	2026-02-15|Petty Cash|Office petty cash|Ad-hoc expenses|446300	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
abd1245a-3948-4026-8b39-c940ab53984d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	82e64189-a014-4a10-8c88-7fb239056c07	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	1aa17d97-20af-4baa-a3a2-ce743ca8748b	\N	961300	D	csv	2026-03-15|Petty Cash|Office petty cash|Ad-hoc expenses|961300	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
7e861ca4-8e94-4bc3-91fe-eb72fbb1ac70	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	82e64189-a014-4a10-8c88-7fb239056c07	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	1aa17d97-20af-4baa-a3a2-ce743ca8748b	\N	1144100	D	csv	2026-04-15|Petty Cash|Office petty cash|Ad-hoc expenses|1144100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
fa9ab7fc-1942-4d44-b40b-33f6b6082a1a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	82e64189-a014-4a10-8c88-7fb239056c07	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	1aa17d97-20af-4baa-a3a2-ce743ca8748b	\N	826700	D	csv	2026-05-15|Petty Cash|Office petty cash|Ad-hoc expenses|826700	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
8c6fa3c0-6952-43ec-a1fd-bc4e05bc3b52	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	82e64189-a014-4a10-8c88-7fb239056c07	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	1aa17d97-20af-4baa-a3a2-ce743ca8748b	\N	300800	D	csv	2026-06-15|Petty Cash|Office petty cash|Ad-hoc expenses|300800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
1553ae38-3697-4380-ade1-bf40e2e170f9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	82e64189-a014-4a10-8c88-7fb239056c07	56a0442b-369d-4293-909a-cb39f4c8af1d	af4366dc-211d-44de-adbd-8f335438ef3c	1aa17d97-20af-4baa-a3a2-ce743ca8748b	\N	50000	D	csv	2026-07-15|Petty Cash|Office petty cash|Ad-hoc expenses|50000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
396f6b9e-483d-423b-95c4-c5af2d8bdc0f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	\N	34000000	C	csv	2025-08-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|34000000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
57b0129b-57f3-45ce-b616-9a38a7b5a104	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	\N	35262200	C	csv	2025-09-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|35262200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
d6a04f0b-b778-4fab-a930-8714b236b5e8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	\N	35363900	C	csv	2025-10-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|35363900	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
cd1180e5-630a-4fc0-8f77-275b634dabf6	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	\N	34211700	C	csv	2025-11-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|34211700	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
809c7902-c11d-4f09-bfa8-4ff2f6a6619a	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	\N	32864800	C	csv	2025-12-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|32864800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
f29d4baf-2382-4ff3-953b-e7ed9424896a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	\N	32561600	C	csv	2026-01-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|32561600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
acddd56f-9b03-4240-bef2-16cc403bed79	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	\N	33580900	C	csv	2026-02-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|33580900	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
0d0cdcc0-4900-457e-80bd-79c534cb8be5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	\N	34985500	C	csv	2026-03-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|34985500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
825b3218-fb77-47f3-bd72-704b5a870830	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	\N	35484000	C	csv	2026-04-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|35484000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
f23196d7-aea0-4597-8962-fe9b9c285f96	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	\N	34618200	C	csv	2026-05-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|34618200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
b076fc10-dba9-4bc7-869d-1b0898f1a9fe	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	\N	33184000	C	csv	2026-06-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|33184000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
48e6de58-5319-43c1-bf56-3d4900d7697c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	68b902c9-bbc3-46e3-9c63-ce3a766f67a6	34f13af0-1c5f-4527-833d-f937b8eb6655	5ea3042d-7a35-45a6-9f7d-2ffafbf62bcc	\N	32500000	C	csv	2026-07-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|32500000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
9ccb0428-c420-41bc-b4d6-bda0cfeaf81d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	03153939-e10b-4570-928e-2ed56971eac9	\N	1800000	C	csv	2025-08-15|Other Income|Community Hall|Hall rental|1800000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
d2aec19a-70a3-40a5-89f4-e9177822c686	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	03153939-e10b-4570-928e-2ed56971eac9	\N	2527400	C	csv	2025-10-15|Other Income|Community Hall|Hall rental|2527400	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
7cf90604-7f7c-4c97-8c98-3d0443b52b3b	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	03153939-e10b-4570-928e-2ed56971eac9	\N	1912900	C	csv	2025-11-15|Other Income|Community Hall|Hall rental|1912900	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
6714157e-70ee-4b43-b785-760d4b29b8a1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	03153939-e10b-4570-928e-2ed56971eac9	\N	1194600	C	csv	2025-12-15|Other Income|Community Hall|Hall rental|1194600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
1599caed-9957-402b-b7fc-e131ae19f55b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	03153939-e10b-4570-928e-2ed56971eac9	\N	1576500	C	csv	2026-02-15|Other Income|Community Hall|Hall rental|1576500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
ff26ee61-6bd9-411a-8c32-5a9458d50309	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	03153939-e10b-4570-928e-2ed56971eac9	\N	2325600	C	csv	2026-03-15|Other Income|Community Hall|Hall rental|2325600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
0b472417-93b9-40f8-a438-f7da610b87b8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	03153939-e10b-4570-928e-2ed56971eac9	\N	2591500	C	csv	2026-04-15|Other Income|Community Hall|Hall rental|2591500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
4b972f3a-a6dd-4cfe-8aba-4f195c125f6a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	03153939-e10b-4570-928e-2ed56971eac9	\N	1364800	C	csv	2026-06-15|Other Income|Community Hall|Hall rental|1364800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
567aefeb-5e2d-4697-b77e-5510233149bf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	03153939-e10b-4570-928e-2ed56971eac9	\N	1000000	C	csv	2026-07-15|Other Income|Community Hall|Hall rental|1000000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
eba23725-51aa-4cdb-a9d4-a4a030101ba4	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	f4b5617e-aba2-4b86-868a-5ef578c51a06	\N	978700	C	csv	2025-09-15|Other Income|Community Hall|Event usage charges|978700	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
403a5110-fa37-45bd-a8ba-440a58df5650	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	f4b5617e-aba2-4b86-868a-5ef578c51a06	\N	663500	C	csv	2025-11-15|Other Income|Community Hall|Event usage charges|663500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
2bc21a35-59b8-4c9e-b4a9-b389c3b9cc41	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	f4b5617e-aba2-4b86-868a-5ef578c51a06	\N	168500	C	csv	2026-01-15|Other Income|Community Hall|Event usage charges|168500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
df493079-7a16-4d77-8138-f655c56f18d1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	f4b5617e-aba2-4b86-868a-5ef578c51a06	\N	895600	C	csv	2026-03-15|Other Income|Community Hall|Event usage charges|895600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
a34ae6df-6418-4e5e-ab55-281f62d40f76	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	f4b5617e-aba2-4b86-868a-5ef578c51a06	\N	785500	C	csv	2026-05-15|Other Income|Community Hall|Event usage charges|785500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
2f2545c8-ea0c-43ab-8fbf-9b64a00a7c78	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	14a56339-a987-4511-910f-e4ec13e4a2f4	f4b5617e-aba2-4b86-868a-5ef578c51a06	\N	150000	C	csv	2026-07-15|Other Income|Community Hall|Event usage charges|150000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
fb2063f4-e844-44ed-938c-9e7b33a1506a	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	\N	1200000	C	csv	2025-08-15|Other Income|Signage Rental|Billboard fee|1200000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
5f6553d3-2491-4a5b-b383-a77b71068665	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	\N	1242100	C	csv	2025-09-15|Other Income|Signage Rental|Billboard fee|1242100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
9865f9b0-ac19-4f9e-9f3b-80efe3d2f332	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	\N	1245500	C	csv	2025-10-15|Other Income|Signage Rental|Billboard fee|1245500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
a15737cd-5bf0-498b-a282-d422a3925cdc	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	\N	1207100	C	csv	2025-11-15|Other Income|Signage Rental|Billboard fee|1207100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
14831c1b-a7e4-47ac-9395-c07d7ddc9984	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	\N	1162200	C	csv	2025-12-15|Other Income|Signage Rental|Billboard fee|1162200	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
9bfb37b2-ab30-41fc-a59f-1c85a160d5b7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	\N	1152100	C	csv	2026-01-15|Other Income|Signage Rental|Billboard fee|1152100	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
564902cc-4130-4f38-9164-daa62915407c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	\N	1186000	C	csv	2026-02-15|Other Income|Signage Rental|Billboard fee|1186000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
898e5223-f278-44fb-84a7-8163948a836b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	\N	1232800	C	csv	2026-03-15|Other Income|Signage Rental|Billboard fee|1232800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
4b4cf0e5-eb89-4711-9535-a741fb662609	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	\N	1249500	C	csv	2026-04-15|Other Income|Signage Rental|Billboard fee|1249500	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
99ddadeb-97af-41d9-aa94-309a5d5462e5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	\N	1220600	C	csv	2026-05-15|Other Income|Signage Rental|Billboard fee|1220600	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
27747af7-de95-464f-835b-9bb4b3e00748	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	\N	1172800	C	csv	2026-06-15|Other Income|Signage Rental|Billboard fee|1172800	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
9aff7c22-927a-4290-84a2-3a768cc8af38	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	3c9b72a3-e708-4855-9e3a-d14019b2d825	1ac7ef9c-60f2-431d-9db4-54680f60568a	33eb2ffb-f09f-492b-a964-fcc35a071e66	4408f3cc-f2be-4bbd-8dd8-0ee54f92b835	\N	1150000	C	csv	2026-07-15|Other Income|Signage Rental|Billboard fee|1150000	\N	\N	2026-07-13 13:52:18.235327+00	2026-07-13 13:52:18.235327+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	superadmin
0f0c6024-6c4d-47b3-9012-4f714d448a40	admin
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, community_id, email, name, password_hash, last_login_at, created_at) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	caa11b01-c3a5-4067-a90c-b73b35075def	admin@example.com	Super Admin	$argon2id$v=19$m=65536,t=3,p=4$KsbkwfVlNJ1PmL72o0pW7g$C25ssK2tg9dX2lXAvMAUhSMUBQOlDOucH2zk0Ov7pDk	2026-07-13 13:45:07.51404+00	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, community_id, name, kind) FROM stdin;
f5660094-91f0-4bee-a5df-2e1e0232713a	caa11b01-c3a5-4067-a90c-b73b35075def	Bescom	company
84cd4899-27e5-49ce-9640-f7aa7b497865	caa11b01-c3a5-4067-a90c-b73b35075def	BWSSB	company
5cf9910f-8049-414f-9fd8-d7048e29cb3b	caa11b01-c3a5-4067-a90c-b73b35075def	ABC Enterprise	company
41321aa1-9577-4777-83b3-bac1b57bc85f	caa11b01-c3a5-4067-a90c-b73b35075def	John (Plumber)	individual
d7cc5ac7-b33e-40ce-8b14-ae8b9f09e366	caa11b01-c3a5-4067-a90c-b73b35075def	SafeGuard Services	company
e9a23daf-024e-4651-b1d6-72bfc022091a	caa11b01-c3a5-4067-a90c-b73b35075def	CleanCo	company
af4366dc-211d-44de-adbd-8f335438ef3c	caa11b01-c3a5-4067-a90c-b73b35075def	Office petty cash	individual
34f13af0-1c5f-4527-833d-f937b8eb6655	caa11b01-c3a5-4067-a90c-b73b35075def	Monthly maintenance	company
14a56339-a987-4511-910f-e4ec13e4a2f4	caa11b01-c3a5-4067-a90c-b73b35075def	Community Hall	company
33eb2ffb-f09f-492b-a964-fcc35a071e66	caa11b01-c3a5-4067-a90c-b73b35075def	Signage Rental	individual
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 6, true);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (name);


--
-- Name: allowed_emails allowed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_pkey PRIMARY KEY (email);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: balances balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_pkey PRIMARY KEY (community_id, month);


--
-- Name: categories categories_head_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_name_key UNIQUE (head_id, name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: collections_dues collections_dues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_pkey PRIMARY KEY (flat_id, period_month);


--
-- Name: communities communities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communities
    ADD CONSTRAINT communities_pkey PRIMARY KEY (id);


--
-- Name: dashboard_settings dashboard_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_pkey PRIMARY KEY (community_id, dashboard_key);


--
-- Name: flats flats_community_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_code_key UNIQUE (community_id, code);


--
-- Name: flats flats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_pkey PRIMARY KEY (id);


--
-- Name: heads heads_community_id_kind_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_kind_name_key UNIQUE (community_id, kind, name);


--
-- Name: heads heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_rules import_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_pkey PRIMARY KEY (id);


--
-- Name: import_staging import_staging_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_pkey PRIMARY KEY (batch_id, row_no);


--
-- Name: line_items line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_pkey PRIMARY KEY (id);


--
-- Name: otp_codes magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (email, otp_hash);


--
-- Name: periods periods_community_id_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_month_key UNIQUE (community_id, month);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_source_source_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_source_source_ref_key UNIQUE (source, source_ref);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_community_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_name_key UNIQUE (community_id, name);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_at ON public.audit_log USING btree (at DESC);


--
-- Name: idx_audit_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_entity ON public.audit_log USING btree (entity, entity_id);


--
-- Name: idx_txn_category_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_category_month ON public.transactions USING btree (category_id, period_month);


--
-- Name: idx_txn_community_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_community_month ON public.transactions USING btree (community_id, period_month);


--
-- Name: idx_txn_flat_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_flat_month ON public.transactions USING btree (flat_id, period_month);


--
-- Name: idx_txn_head_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_head_month ON public.transactions USING btree (head_id, period_month);


--
-- Name: idx_txn_vendor_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_vendor_month ON public.transactions USING btree (vendor_id, period_month);


--
-- Name: line_items_cat_vendor_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX line_items_cat_vendor_name_uq ON public.line_items USING btree (category_id, COALESCE(vendor_id, '00000000-0000-0000-0000-000000000000'::uuid), name);


--
-- Name: mv_cat_monthly_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_cat_monthly_idx ON public.mv_category_monthly USING btree (community_id, month);


--
-- Name: mv_monthly_totals_pk; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mv_monthly_totals_pk ON public.mv_monthly_totals USING btree (community_id, month);


--
-- Name: mv_vendor_ranking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_vendor_ranking_idx ON public.mv_vendor_ranking USING btree (community_id, total_expense_paise DESC);


--
-- Name: allowed_emails allowed_emails_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: allowed_emails allowed_emails_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE SET NULL;


--
-- Name: balances balances_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: categories categories_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id) ON DELETE CASCADE;


--
-- Name: collections_dues collections_dues_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE CASCADE;


--
-- Name: dashboard_settings dashboard_settings_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: flats flats_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: heads heads_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: import_rules import_rules_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_staging import_staging_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE SET NULL;


--
-- Name: periods periods_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: transactions transactions_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id);


--
-- Name: transactions transactions_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id);


--
-- Name: transactions transactions_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_line_item_id_fkey FOREIGN KEY (line_item_id) REFERENCES public.line_items(id);


--
-- Name: transactions transactions_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: vendors vendors_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_category_monthly;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_monthly_totals;


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_vendor_ranking;


--
-- PostgreSQL database dump complete
--

\unrestrict MPQb4IpwYw1JMgYn4Q3YYqqmA5YFzRHvi6rdoUAkufUA69Fu5fT8Lv1S5R1oTry

