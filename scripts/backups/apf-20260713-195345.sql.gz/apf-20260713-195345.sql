--
-- PostgreSQL database dump
--

\restrict vxe5j1V7ouUiwjks7PLgC9OEzmQCVlwDLghphytirMVW5KOXLdsVcz5d4eKktU9

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_line_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_batch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_actor_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_community_id_fkey;
DROP INDEX IF EXISTS public.mv_vendor_ranking_idx;
DROP INDEX IF EXISTS public.mv_monthly_totals_pk;
DROP INDEX IF EXISTS public.mv_cat_monthly_idx;
DROP INDEX IF EXISTS public.line_items_cat_vendor_name_uq;
DROP INDEX IF EXISTS public.idx_txn_vendor_month;
DROP INDEX IF EXISTS public.idx_txn_head_month;
DROP INDEX IF EXISTS public.idx_txn_flat_month;
DROP INDEX IF EXISTS public.idx_txn_community_month;
DROP INDEX IF EXISTS public.idx_txn_category_month;
DROP INDEX IF EXISTS public.idx_audit_entity;
DROP INDEX IF EXISTS public.idx_audit_at;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_pkey;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_name_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_source_source_ref_key;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_month_key;
ALTER TABLE IF EXISTS ONLY public.otp_codes DROP CONSTRAINT IF EXISTS magic_links_pkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_pkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_pkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_kind_name_key;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_pkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_code_key;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.communities DROP CONSTRAINT IF EXISTS communities_pkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_name_key;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_pkey;
ALTER TABLE IF EXISTS ONLY public._migrations DROP CONSTRAINT IF EXISTS _migrations_pkey;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.periods;
DROP TABLE IF EXISTS public.otp_codes;
DROP MATERIALIZED VIEW IF EXISTS public.mv_vendor_ranking;
DROP TABLE IF EXISTS public.vendors;
DROP MATERIALIZED VIEW IF EXISTS public.mv_monthly_totals;
DROP MATERIALIZED VIEW IF EXISTS public.mv_category_monthly;
DROP TABLE IF EXISTS public.transactions;
DROP TABLE IF EXISTS public.line_items;
DROP TABLE IF EXISTS public.import_staging;
DROP TABLE IF EXISTS public.import_rules;
DROP TABLE IF EXISTS public.import_batches;
DROP TABLE IF EXISTS public.heads;
DROP TABLE IF EXISTS public.flats;
DROP TABLE IF EXISTS public.dashboard_settings;
DROP TABLE IF EXISTS public.communities;
DROP TABLE IF EXISTS public.collections_dues;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.balances;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP TABLE IF EXISTS public.allowed_emails;
DROP TABLE IF EXISTS public._migrations;
DROP TYPE IF EXISTS public.vendor_kind;
DROP TYPE IF EXISTS public.head_kind;
DROP TYPE IF EXISTS public.app_role;
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'resident',
    'admin',
    'superadmin'
);


--
-- Name: head_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.head_kind AS ENUM (
    'income',
    'expense'
);


--
-- Name: vendor_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vendor_kind AS ENUM (
    'company',
    'individual'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    name text NOT NULL,
    run_at timestamp with time zone DEFAULT now()
);


--
-- Name: allowed_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allowed_emails (
    email text NOT NULL,
    community_id uuid NOT NULL,
    role public.app_role NOT NULL,
    flat_id uuid,
    name text,
    invited_by text,
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    community_id uuid,
    actor_user_id uuid,
    actor_email text,
    entity text NOT NULL,
    entity_id text,
    action text NOT NULL,
    before jsonb,
    after jsonb,
    at timestamp with time zone DEFAULT now() NOT NULL,
    ip text,
    user_agent text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balances (
    community_id uuid NOT NULL,
    month date NOT NULL,
    opening_paise bigint DEFAULT 0 NOT NULL,
    closing_paise bigint DEFAULT 0 NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    head_id uuid NOT NULL,
    name text NOT NULL
);


--
-- Name: collections_dues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections_dues (
    flat_id uuid NOT NULL,
    period_month date NOT NULL,
    dues_paise bigint DEFAULT 0 NOT NULL,
    paid_paise bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'due'::text NOT NULL
);


--
-- Name: communities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    fy_start_month smallint DEFAULT 4 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dashboard_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_settings (
    community_id uuid NOT NULL,
    dashboard_key text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    hidden_widgets text[] DEFAULT '{}'::text[] NOT NULL
);


--
-- Name: flats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    code text NOT NULL,
    owner_email text
);


--
-- Name: heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind public.head_kind NOT NULL,
    name text NOT NULL
);


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    filename text NOT NULL,
    kind text NOT NULL,
    uploaded_by uuid,
    status text DEFAULT 'staged'::text NOT NULL,
    error text,
    row_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind text NOT NULL,
    match jsonb NOT NULL,
    set_fields jsonb NOT NULL,
    priority integer DEFAULT 100 NOT NULL
);


--
-- Name: import_staging; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_staging (
    batch_id uuid NOT NULL,
    row_no integer NOT NULL,
    raw_json jsonb NOT NULL,
    mapped_json jsonb,
    error text
);


--
-- Name: line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    name text NOT NULL,
    first_seen_month date,
    last_seen_month date
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    txn_date date NOT NULL,
    period_month date NOT NULL,
    head_id uuid NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    line_item_id uuid,
    flat_id uuid,
    amount_paise bigint NOT NULL,
    direction character(1) NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    source_ref text,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT transactions_amount_paise_check CHECK ((amount_paise >= 0)),
    CONSTRAINT transactions_direction_check CHECK ((direction = ANY (ARRAY['C'::bpchar, 'D'::bpchar])))
);


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_category_monthly AS
 SELECT t.community_id,
    t.category_id,
    c.name AS category_name,
    h.kind AS head_kind,
    t.period_month AS month,
    (sum(t.amount_paise))::bigint AS amount_paise
   FROM ((public.transactions t
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON ((h.id = t.head_id)))
  GROUP BY t.community_id, t.category_id, c.name, h.kind, t.period_month
  WITH NO DATA;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_monthly_totals AS
 WITH spine AS (
         SELECT c.id AS community_id,
            (date_trunc('month'::text, gs.gs))::date AS month
           FROM (public.communities c
             CROSS JOIN generate_series((( SELECT COALESCE(min(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, (( SELECT COALESCE(max(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, '1 mon'::interval) gs(gs))
        )
 SELECT s.community_id,
    s.month,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric))::bigint AS collection_paise,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric))::bigint AS expense_paise,
    ((COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric) - COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric)))::bigint AS net_paise
   FROM (spine s
     LEFT JOIN public.transactions t ON (((t.community_id = s.community_id) AND (t.period_month = s.month))))
  GROUP BY s.community_id, s.month
  WITH NO DATA;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    name text NOT NULL,
    kind public.vendor_kind DEFAULT 'company'::public.vendor_kind NOT NULL
);


--
-- Name: TABLE vendors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vendors IS 'Vendor dimension. Read-only from admin UI; populated via CSV import + on-the-fly during transaction ingest.';


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_vendor_ranking AS
 SELECT t.community_id,
    v.id AS vendor_id,
    v.name AS vendor_name,
    v.kind AS vendor_kind,
    COALESCE(string_agg(DISTINCT c.name, ', '::text), ''::text) AS categories,
    (sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)))::bigint AS total_expense_paise,
    count(DISTINCT t.period_month) AS months_active
   FROM (((public.transactions t
     JOIN public.vendors v ON ((v.id = t.vendor_id)))
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON (((h.id = t.head_id) AND (h.kind = 'expense'::public.head_kind))))
  GROUP BY t.community_id, v.id, v.name, v.kind
  WITH NO DATA;


--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_codes (
    email text NOT NULL,
    otp_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone
);


--
-- Name: periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    month date NOT NULL,
    status text DEFAULT 'open'::text NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role public.app_role NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    email text NOT NULL,
    name text,
    password_hash text,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._migrations (name, run_at) FROM stdin;
0001_init.sql	2026-07-13 11:13:56.401452+00
0002_indexes.sql	2026-07-13 11:13:56.401452+00
0003_mviews.sql	2026-07-13 11:13:56.401452+00
0004_otp_rename.sql	2026-07-13 11:20:04.500279+00
\.


--
-- Data for Name: allowed_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allowed_emails (email, community_id, role, flat_id, name, invited_by, invited_at, revoked_at) FROM stdin;
treasurer@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	admin	\N	Treasurer	system	2026-07-13 11:20:04.55456+00	\N
resident@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	resident	\N	Demo Resident	system	2026-07-13 11:20:04.55456+00	\N
admin@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	superadmin	\N	Super Admin	system	2026-07-13 11:20:04.55456+00	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, community_id, actor_user_id, actor_email, entity, entity_id, action, before, after, at, ip, user_agent) FROM stdin;
1	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	import_batch	f6f48939-a1b1-439f-988e-e632c26185b2	import	\N	{"kind": "vendors", "rows": 10, "failed": 0, "filename": "vendors.csv", "inserted": 10}	2026-07-13 14:09:23.30833+00	192.168.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
2	caa11b01-c3a5-4067-a90c-b73b35075def	0f0c6024-6c4d-47b3-9012-4f714d448a40	admin@example.com	import_batch	93163091-a074-4a1b-ad75-72d94fee6e76	import	\N	{"kind": "transactions", "rows": 152, "failed": 0, "filename": "transactions.csv", "inserted": 152}	2026-07-13 14:09:36.075718+00	192.168.0.7	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36
\.


--
-- Data for Name: balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.balances (community_id, month, opening_paise, closing_paise) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, head_id, name) FROM stdin;
51d0e12c-1244-4230-81ed-c03937ff473f	96cbaa48-2f3d-4240-a903-036acad06180	Utilities
c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	96cbaa48-2f3d-4240-a903-036acad06180	Maintenance
f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	96cbaa48-2f3d-4240-a903-036acad06180	Security
e932cc05-6cb8-4221-853d-5a5ec60a70f3	96cbaa48-2f3d-4240-a903-036acad06180	Housekeeping
3b966b27-29a9-419f-b31e-11a1395cb650	96cbaa48-2f3d-4240-a903-036acad06180	Petty Cash
c4b8baaf-5ed2-4886-8c91-599458b5db97	c8099030-bf63-443d-bae4-f1a6abac5fae	Maintenance Collections
23002d57-222e-4b19-b795-5104e15a8a77	c8099030-bf63-443d-bae4-f1a6abac5fae	Other Income
\.


--
-- Data for Name: collections_dues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections_dues (flat_id, period_month, dues_paise, paid_paise, status) FROM stdin;
\.


--
-- Data for Name: communities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communities (id, name, currency, fy_start_month, created_at) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	Green Meadows	INR	4	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: dashboard_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_settings (community_id, dashboard_key, enabled, hidden_widgets) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	resident.overview	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.drilldown	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.cashflow	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.income	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.balance	t	{}
\.


--
-- Data for Name: flats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flats (id, community_id, code, owner_email) FROM stdin;
f88d6359-58a8-42b1-8476-24ce41b63802	caa11b01-c3a5-4067-a90c-b73b35075def	A-001	\N
5696d5bf-57f9-44ad-b92d-781cabc4a550	caa11b01-c3a5-4067-a90c-b73b35075def	A-002	\N
5c447f5e-a684-4075-8224-072f1fb12c93	caa11b01-c3a5-4067-a90c-b73b35075def	A-003	\N
6ddf10b7-40ed-44a1-9080-e50c60a08e32	caa11b01-c3a5-4067-a90c-b73b35075def	A-004	\N
5bfe95a5-bc38-4d00-811e-b5a6106e71c7	caa11b01-c3a5-4067-a90c-b73b35075def	A-005	\N
6e67ec18-d2aa-4cd4-8a51-b9a2b33429a2	caa11b01-c3a5-4067-a90c-b73b35075def	A-006	\N
05fbfe69-9195-45aa-bb9a-ef1de36f6fd9	caa11b01-c3a5-4067-a90c-b73b35075def	A-007	\N
7dca9ae9-39f7-4b2c-85b6-f9c820a65f0c	caa11b01-c3a5-4067-a90c-b73b35075def	A-008	\N
24f24d23-6946-4d06-b2d4-7ebe31278f9e	caa11b01-c3a5-4067-a90c-b73b35075def	A-009	\N
39278459-ad85-4e5e-937a-0a36b195c960	caa11b01-c3a5-4067-a90c-b73b35075def	A-010	\N
716bbe4c-f53d-4558-a4b5-caeb642f2c23	caa11b01-c3a5-4067-a90c-b73b35075def	A-011	\N
6dac5232-f75f-44d2-8533-4119c856f0ac	caa11b01-c3a5-4067-a90c-b73b35075def	A-012	\N
ea815ea6-a6d6-4547-bb06-ebfc9497a6f2	caa11b01-c3a5-4067-a90c-b73b35075def	A-013	\N
b441021b-6b42-4350-bd7a-385d23b17015	caa11b01-c3a5-4067-a90c-b73b35075def	A-014	\N
74194275-0229-47a7-9a12-691c228cbf03	caa11b01-c3a5-4067-a90c-b73b35075def	A-015	\N
f9df5252-7643-42fd-9a63-2e839347a52f	caa11b01-c3a5-4067-a90c-b73b35075def	A-016	\N
321b8a10-e82d-4cf6-a6b2-fde3fa7b05b1	caa11b01-c3a5-4067-a90c-b73b35075def	A-017	\N
9c1ddcb5-9b93-4e47-80ac-cbfc3b7f326e	caa11b01-c3a5-4067-a90c-b73b35075def	A-018	\N
f0106df5-f061-40fd-97c8-f6408f268ff9	caa11b01-c3a5-4067-a90c-b73b35075def	A-019	\N
deeb22d9-7a6b-4417-985b-c76049abae2e	caa11b01-c3a5-4067-a90c-b73b35075def	A-020	\N
c2e7bc3c-62db-4d01-aad3-9513cbf2ecbf	caa11b01-c3a5-4067-a90c-b73b35075def	A-021	\N
8c7ed2ff-3fea-4279-a889-c4e44b78ef6e	caa11b01-c3a5-4067-a90c-b73b35075def	A-022	\N
fb52fe46-dded-4f23-975d-3f36184896e9	caa11b01-c3a5-4067-a90c-b73b35075def	A-023	\N
5fc3f4ab-169c-47bc-819a-315c1a244aac	caa11b01-c3a5-4067-a90c-b73b35075def	A-024	\N
\.


--
-- Data for Name: heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heads (id, community_id, kind, name) FROM stdin;
96cbaa48-2f3d-4240-a903-036acad06180	caa11b01-c3a5-4067-a90c-b73b35075def	expense	Expense
c8099030-bf63-443d-bae4-f1a6abac5fae	caa11b01-c3a5-4067-a90c-b73b35075def	income	Income
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, community_id, filename, kind, uploaded_by, status, error, row_count, created_at) FROM stdin;
f6f48939-a1b1-439f-988e-e632c26185b2	caa11b01-c3a5-4067-a90c-b73b35075def	vendors.csv	vendors	0f0c6024-6c4d-47b3-9012-4f714d448a40	committed	\N	10	2026-07-13 14:09:23.297211+00
93163091-a074-4a1b-ad75-72d94fee6e76	caa11b01-c3a5-4067-a90c-b73b35075def	transactions.csv	transactions	0f0c6024-6c4d-47b3-9012-4f714d448a40	committed	\N	152	2026-07-13 14:09:36.069569+00
\.


--
-- Data for Name: import_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_rules (id, community_id, kind, match, set_fields, priority) FROM stdin;
\.


--
-- Data for Name: import_staging; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_staging (batch_id, row_no, raw_json, mapped_json, error) FROM stdin;
f6f48939-a1b1-439f-988e-e632c26185b2	1	{"kind": "company", "name": "Bescom"}	\N	\N
f6f48939-a1b1-439f-988e-e632c26185b2	2	{"kind": "company", "name": "BWSSB"}	\N	\N
f6f48939-a1b1-439f-988e-e632c26185b2	3	{"kind": "company", "name": "ABC Enterprise"}	\N	\N
f6f48939-a1b1-439f-988e-e632c26185b2	4	{"kind": "individual", "name": "John (Plumber)"}	\N	\N
f6f48939-a1b1-439f-988e-e632c26185b2	5	{"kind": "company", "name": "SafeGuard Services"}	\N	\N
f6f48939-a1b1-439f-988e-e632c26185b2	6	{"kind": "company", "name": "CleanCo"}	\N	\N
f6f48939-a1b1-439f-988e-e632c26185b2	7	{"kind": "individual", "name": "Office petty cash"}	\N	\N
f6f48939-a1b1-439f-988e-e632c26185b2	8	{"kind": "company", "name": "Monthly maintenance"}	\N	\N
f6f48939-a1b1-439f-988e-e632c26185b2	9	{"kind": "company", "name": "Community Hall"}	\N	\N
f6f48939-a1b1-439f-988e-e632c26185b2	10	{"kind": "individual", "name": "Signage Rental"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	1	{"date": "2025-08-15", "head": "expense", "amount": "48000", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	2	{"date": "2025-09-15", "head": "expense", "amount": "51366", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	3	{"date": "2025-10-15", "head": "expense", "amount": "51637", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	4	{"date": "2025-11-15", "head": "expense", "amount": "48564", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	5	{"date": "2025-12-15", "head": "expense", "amount": "44973", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	6	{"date": "2026-01-15", "head": "expense", "amount": "44164", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	7	{"date": "2026-02-15", "head": "expense", "amount": "46882", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	8	{"date": "2026-03-15", "head": "expense", "amount": "50628", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	9	{"date": "2026-04-15", "head": "expense", "amount": "51957", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	10	{"date": "2026-05-15", "head": "expense", "amount": "49648", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	11	{"date": "2026-06-15", "head": "expense", "amount": "45824", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	12	{"date": "2026-07-15", "head": "expense", "amount": "44000", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Common area electricity", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	13	{"date": "2025-08-15", "head": "expense", "amount": "12000", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	14	{"date": "2025-09-15", "head": "expense", "amount": "14945", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	15	{"date": "2025-11-15", "head": "expense", "amount": "12494", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	16	{"date": "2025-12-15", "head": "expense", "amount": "9351", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	17	{"date": "2026-01-15", "head": "expense", "amount": "8644", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	18	{"date": "2026-02-15", "head": "expense", "amount": "11022", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	19	{"date": "2026-03-15", "head": "expense", "amount": "14299", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	20	{"date": "2026-05-15", "head": "expense", "amount": "13442", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	21	{"date": "2026-06-15", "head": "expense", "amount": "10096", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	22	{"date": "2026-07-15", "head": "expense", "amount": "8500", "vendor": "Bescom", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Backup usage", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	23	{"date": "2025-08-15", "head": "expense", "amount": "32000", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	24	{"date": "2025-09-15", "head": "expense", "amount": "33683", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	25	{"date": "2025-10-15", "head": "expense", "amount": "33819", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	26	{"date": "2025-11-15", "head": "expense", "amount": "32282", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	27	{"date": "2025-12-15", "head": "expense", "amount": "30486", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	28	{"date": "2026-01-15", "head": "expense", "amount": "30082", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	29	{"date": "2026-02-15", "head": "expense", "amount": "31441", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	30	{"date": "2026-03-15", "head": "expense", "amount": "33314", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	31	{"date": "2026-04-15", "head": "expense", "amount": "33979", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	32	{"date": "2026-05-15", "head": "expense", "amount": "32824", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	33	{"date": "2026-06-15", "head": "expense", "amount": "30912", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	34	{"date": "2026-07-15", "head": "expense", "amount": "30000", "vendor": "BWSSB", "category": "Utilities", "direction": "D", "flat_code": "", "line_item": "Water charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	35	{"date": "2025-08-15", "head": "expense", "amount": "65000", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	36	{"date": "2025-09-15", "head": "expense", "amount": "67524", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	37	{"date": "2025-10-15", "head": "expense", "amount": "67728", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	38	{"date": "2025-11-15", "head": "expense", "amount": "65423", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	39	{"date": "2025-12-15", "head": "expense", "amount": "62730", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	40	{"date": "2026-01-15", "head": "expense", "amount": "62123", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	41	{"date": "2026-02-15", "head": "expense", "amount": "64162", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	42	{"date": "2026-03-15", "head": "expense", "amount": "66971", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	43	{"date": "2026-04-15", "head": "expense", "amount": "67968", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	44	{"date": "2026-05-15", "head": "expense", "amount": "66236", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	45	{"date": "2026-06-15", "head": "expense", "amount": "63368", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	46	{"date": "2026-07-15", "head": "expense", "amount": "62000", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Labour charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	47	{"date": "2025-08-15", "head": "expense", "amount": "18000", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	48	{"date": "2025-10-15", "head": "expense", "amount": "23456", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	49	{"date": "2025-11-15", "head": "expense", "amount": "18847", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	50	{"date": "2026-01-15", "head": "expense", "amount": "12246", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	51	{"date": "2026-02-15", "head": "expense", "amount": "16324", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	52	{"date": "2026-04-15", "head": "expense", "amount": "23936", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	53	{"date": "2026-05-15", "head": "expense", "amount": "20473", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	54	{"date": "2026-06-15", "head": "expense", "amount": "14736", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	55	{"date": "2026-07-15", "head": "expense", "amount": "12000", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Spare parts", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	56	{"date": "2025-10-15", "head": "expense", "amount": "9455", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "STP salt purchase", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	57	{"date": "2026-01-15", "head": "expense", "amount": "8521", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "STP salt purchase", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	58	{"date": "2026-04-15", "head": "expense", "amount": "9495", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "STP salt purchase", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	59	{"date": "2026-07-15", "head": "expense", "amount": "8500", "vendor": "ABC Enterprise", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "STP salt purchase", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	60	{"date": "2025-09-15", "head": "expense", "amount": "7445", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	61	{"date": "2025-11-15", "head": "expense", "amount": "4994", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	62	{"date": "2025-12-15", "head": "expense", "amount": "1851", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	63	{"date": "2026-03-15", "head": "expense", "amount": "6799", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	64	{"date": "2026-05-15", "head": "expense", "amount": "5942", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	65	{"date": "2026-06-15", "head": "expense", "amount": "2596", "vendor": "John (Plumber)", "category": "Maintenance", "direction": "D", "flat_code": "", "line_item": "Plumbing repair", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	66	{"date": "2025-08-15", "head": "expense", "amount": "120000", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	67	{"date": "2025-09-15", "head": "expense", "amount": "121683", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	68	{"date": "2025-10-15", "head": "expense", "amount": "121819", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	69	{"date": "2025-11-15", "head": "expense", "amount": "120282", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	70	{"date": "2025-12-15", "head": "expense", "amount": "118486", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	71	{"date": "2026-01-15", "head": "expense", "amount": "118082", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	72	{"date": "2026-02-15", "head": "expense", "amount": "119441", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	73	{"date": "2026-03-15", "head": "expense", "amount": "121314", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	74	{"date": "2026-04-15", "head": "expense", "amount": "121979", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	75	{"date": "2026-05-15", "head": "expense", "amount": "120824", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	76	{"date": "2026-06-15", "head": "expense", "amount": "118912", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	77	{"date": "2026-07-15", "head": "expense", "amount": "118000", "vendor": "SafeGuard Services", "category": "Security", "direction": "D", "flat_code": "", "line_item": "Guard salaries", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	78	{"date": "2025-08-15", "head": "expense", "amount": "58000", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	79	{"date": "2025-09-15", "head": "expense", "amount": "59262", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	80	{"date": "2025-10-15", "head": "expense", "amount": "59364", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	81	{"date": "2025-11-15", "head": "expense", "amount": "58212", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	82	{"date": "2025-12-15", "head": "expense", "amount": "56865", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	83	{"date": "2026-01-15", "head": "expense", "amount": "56562", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	84	{"date": "2026-02-15", "head": "expense", "amount": "57581", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	85	{"date": "2026-03-15", "head": "expense", "amount": "58985", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	86	{"date": "2026-04-15", "head": "expense", "amount": "59484", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	87	{"date": "2026-05-15", "head": "expense", "amount": "58618", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	88	{"date": "2026-06-15", "head": "expense", "amount": "57184", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	89	{"date": "2026-07-15", "head": "expense", "amount": "56500", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Staff wages", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	90	{"date": "2025-08-15", "head": "expense", "amount": "7500", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	91	{"date": "2025-09-15", "head": "expense", "amount": "8762", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	92	{"date": "2025-10-15", "head": "expense", "amount": "8864", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	93	{"date": "2025-11-15", "head": "expense", "amount": "7712", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	94	{"date": "2025-12-15", "head": "expense", "amount": "6365", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	95	{"date": "2026-01-15", "head": "expense", "amount": "6062", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	96	{"date": "2026-02-15", "head": "expense", "amount": "7081", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	97	{"date": "2026-03-15", "head": "expense", "amount": "8485", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	98	{"date": "2026-04-15", "head": "expense", "amount": "8984", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	99	{"date": "2026-05-15", "head": "expense", "amount": "8118", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	100	{"date": "2026-06-15", "head": "expense", "amount": "6684", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	101	{"date": "2026-07-15", "head": "expense", "amount": "6000", "vendor": "CleanCo", "category": "Housekeeping", "direction": "D", "flat_code": "", "line_item": "Cleaning supplies", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	102	{"date": "2025-08-15", "head": "expense", "amount": "6000", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	103	{"date": "2025-09-15", "head": "expense", "amount": "10628", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	104	{"date": "2025-10-15", "head": "expense", "amount": "11001", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	105	{"date": "2025-11-15", "head": "expense", "amount": "6776", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	106	{"date": "2025-12-15", "head": "expense", "amount": "1838", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	107	{"date": "2026-01-15", "head": "expense", "amount": "726", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	108	{"date": "2026-02-15", "head": "expense", "amount": "4463", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	109	{"date": "2026-03-15", "head": "expense", "amount": "9613", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	110	{"date": "2026-04-15", "head": "expense", "amount": "11441", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	111	{"date": "2026-05-15", "head": "expense", "amount": "8267", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	112	{"date": "2026-06-15", "head": "expense", "amount": "3008", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	113	{"date": "2026-07-15", "head": "expense", "amount": "500", "vendor": "Office petty cash", "category": "Petty Cash", "direction": "D", "flat_code": "", "line_item": "Ad-hoc expenses", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	114	{"date": "2025-08-15", "head": "income", "amount": "340000", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	115	{"date": "2025-09-15", "head": "income", "amount": "352622", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	116	{"date": "2025-10-15", "head": "income", "amount": "353639", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	117	{"date": "2025-11-15", "head": "income", "amount": "342117", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	118	{"date": "2025-12-15", "head": "income", "amount": "328648", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	119	{"date": "2026-01-15", "head": "income", "amount": "325616", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	120	{"date": "2026-02-15", "head": "income", "amount": "335809", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	121	{"date": "2026-03-15", "head": "income", "amount": "349855", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	122	{"date": "2026-04-15", "head": "income", "amount": "354840", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	123	{"date": "2026-05-15", "head": "income", "amount": "346182", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	124	{"date": "2026-06-15", "head": "income", "amount": "331840", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	125	{"date": "2026-07-15", "head": "income", "amount": "325000", "vendor": "Monthly maintenance", "category": "Maintenance Collections", "direction": "C", "flat_code": "", "line_item": "Flat maintenance dues", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	126	{"date": "2025-08-15", "head": "income", "amount": "18000", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	127	{"date": "2025-10-15", "head": "income", "amount": "25274", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	128	{"date": "2025-11-15", "head": "income", "amount": "19129", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	129	{"date": "2025-12-15", "head": "income", "amount": "11946", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	130	{"date": "2026-02-15", "head": "income", "amount": "15765", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	131	{"date": "2026-03-15", "head": "income", "amount": "23256", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	132	{"date": "2026-04-15", "head": "income", "amount": "25915", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	133	{"date": "2026-06-15", "head": "income", "amount": "13648", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	134	{"date": "2026-07-15", "head": "income", "amount": "10000", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Hall rental", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	135	{"date": "2025-09-15", "head": "income", "amount": "9787", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	136	{"date": "2025-11-15", "head": "income", "amount": "6635", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	137	{"date": "2026-01-15", "head": "income", "amount": "1685", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	138	{"date": "2026-03-15", "head": "income", "amount": "8956", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	139	{"date": "2026-05-15", "head": "income", "amount": "7855", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	140	{"date": "2026-07-15", "head": "income", "amount": "1500", "vendor": "Community Hall", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Event usage charges", "source_ref": "", "vendor_kind": "company"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	141	{"date": "2025-08-15", "head": "income", "amount": "12000", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	142	{"date": "2025-09-15", "head": "income", "amount": "12421", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	143	{"date": "2025-10-15", "head": "income", "amount": "12455", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	144	{"date": "2025-11-15", "head": "income", "amount": "12071", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	145	{"date": "2025-12-15", "head": "income", "amount": "11622", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	146	{"date": "2026-01-15", "head": "income", "amount": "11521", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	147	{"date": "2026-02-15", "head": "income", "amount": "11860", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	148	{"date": "2026-03-15", "head": "income", "amount": "12328", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	149	{"date": "2026-04-15", "head": "income", "amount": "12495", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	150	{"date": "2026-05-15", "head": "income", "amount": "12206", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	151	{"date": "2026-06-15", "head": "income", "amount": "11728", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
93163091-a074-4a1b-ad75-72d94fee6e76	152	{"date": "2026-07-15", "head": "income", "amount": "11500", "vendor": "Signage Rental", "category": "Other Income", "direction": "C", "flat_code": "", "line_item": "Billboard fee", "source_ref": "", "vendor_kind": "individual"}	\N	\N
\.


--
-- Data for Name: line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_items (id, category_id, vendor_id, name, first_seen_month, last_seen_month) FROM stdin;
60665b3e-d954-41c6-8755-5f25c7143943	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	Common area electricity	2025-08-01	2026-07-01
a41e49e3-d9de-4e57-a600-84ba6ab55c45	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	Backup usage	2025-08-01	2026-07-01
52731728-9e2c-4c54-80c6-3387733b453e	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	Water charges	2025-08-01	2026-07-01
6839e7e2-f46a-4fe4-a826-08e25ccfd937	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	Labour charges	2025-08-01	2026-07-01
fa4aa685-7538-4e32-99be-5e35ed51bed6	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	Spare parts	2025-08-01	2026-07-01
c7764af5-f804-40e6-a4be-b9ed185a8f04	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	STP salt purchase	2025-10-01	2026-07-01
8daec2f7-8924-4a13-9371-2b47a0cb6296	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	f842fb66-7faf-47e4-b9f5-bab6806dc4e9	Plumbing repair	2025-09-01	2026-06-01
e566e755-a124-4fc4-ad98-96fc47154ec2	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	Guard salaries	2025-08-01	2026-07-01
71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	Staff wages	2025-08-01	2026-07-01
b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	Cleaning supplies	2025-08-01	2026-07-01
973161fa-9526-477c-b0c8-8f37bd0c760c	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	Ad-hoc expenses	2025-08-01	2026-07-01
1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	Flat maintenance dues	2025-08-01	2026-07-01
0ea05533-cd6f-42ee-8733-4ba4a15ca34c	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	Hall rental	2025-08-01	2026-07-01
f2a24868-7364-4bfd-b16f-227a07b97933	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	Event usage charges	2025-09-01	2026-07-01
9176c78d-24a9-4720-9877-369f6d00edc6	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	Billboard fee	2025-08-01	2026-07-01
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp_codes (email, otp_hash, expires_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periods (id, community_id, month, status) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, community_id, txn_date, period_month, head_id, category_id, vendor_id, line_item_id, flat_id, amount_paise, direction, source, source_ref, notes, created_by, created_at, updated_at) FROM stdin;
29e2c814-51c2-4811-bd73-a5c25d54f582	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	60665b3e-d954-41c6-8755-5f25c7143943	\N	4800000	D	csv	2025-08-15|Utilities|Bescom|Common area electricity|4800000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
bad910ee-d9ac-427c-a548-83da834ead15	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	60665b3e-d954-41c6-8755-5f25c7143943	\N	5136600	D	csv	2025-09-15|Utilities|Bescom|Common area electricity|5136600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
e857bf3f-d92b-41e8-82fa-4ed9ecdd315d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	60665b3e-d954-41c6-8755-5f25c7143943	\N	5163700	D	csv	2025-10-15|Utilities|Bescom|Common area electricity|5163700	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
36fffa26-4aa3-4242-bd03-83dfccfd0288	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	60665b3e-d954-41c6-8755-5f25c7143943	\N	4856400	D	csv	2025-11-15|Utilities|Bescom|Common area electricity|4856400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
89b5ff16-69d7-4ba6-a947-7156f409daf1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	60665b3e-d954-41c6-8755-5f25c7143943	\N	4497300	D	csv	2025-12-15|Utilities|Bescom|Common area electricity|4497300	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
7d72d74e-7b6f-46ff-b3ad-86e29d5f35e7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	60665b3e-d954-41c6-8755-5f25c7143943	\N	4416400	D	csv	2026-01-15|Utilities|Bescom|Common area electricity|4416400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
f94f762e-5f53-436a-ad16-970952ad21b7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	60665b3e-d954-41c6-8755-5f25c7143943	\N	4688200	D	csv	2026-02-15|Utilities|Bescom|Common area electricity|4688200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
f71d5a03-9222-476f-a568-945a09967b2e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	60665b3e-d954-41c6-8755-5f25c7143943	\N	5062800	D	csv	2026-03-15|Utilities|Bescom|Common area electricity|5062800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
2c978158-a70d-493d-acb2-94b43243dbc8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	60665b3e-d954-41c6-8755-5f25c7143943	\N	5195700	D	csv	2026-04-15|Utilities|Bescom|Common area electricity|5195700	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
f68449b0-ac51-41fa-98f8-688e98b848ab	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	60665b3e-d954-41c6-8755-5f25c7143943	\N	4964800	D	csv	2026-05-15|Utilities|Bescom|Common area electricity|4964800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
a55cc778-a5e6-430a-b4dc-bd9444da44cb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	60665b3e-d954-41c6-8755-5f25c7143943	\N	4582400	D	csv	2026-06-15|Utilities|Bescom|Common area electricity|4582400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
677b1ddc-2da5-4f81-988b-bf34512cad18	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	60665b3e-d954-41c6-8755-5f25c7143943	\N	4400000	D	csv	2026-07-15|Utilities|Bescom|Common area electricity|4400000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
fd9767a5-6930-4563-9d26-42d5cb1a4f00	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	a41e49e3-d9de-4e57-a600-84ba6ab55c45	\N	1200000	D	csv	2025-08-15|Utilities|Bescom|Backup usage|1200000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
1efa5e45-d81c-4440-b21d-7deee9f03110	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	a41e49e3-d9de-4e57-a600-84ba6ab55c45	\N	1494500	D	csv	2025-09-15|Utilities|Bescom|Backup usage|1494500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
364137b3-14c8-425e-b62d-743d05bfa418	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	a41e49e3-d9de-4e57-a600-84ba6ab55c45	\N	1249400	D	csv	2025-11-15|Utilities|Bescom|Backup usage|1249400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
944c4e60-2897-44ea-a90a-719308be906b	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	a41e49e3-d9de-4e57-a600-84ba6ab55c45	\N	935100	D	csv	2025-12-15|Utilities|Bescom|Backup usage|935100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
97bbe305-689b-4620-a8f5-813a80968410	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	a41e49e3-d9de-4e57-a600-84ba6ab55c45	\N	864400	D	csv	2026-01-15|Utilities|Bescom|Backup usage|864400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
a2d4c466-f79d-4d02-8fcc-c0ba530a130a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	a41e49e3-d9de-4e57-a600-84ba6ab55c45	\N	1102200	D	csv	2026-02-15|Utilities|Bescom|Backup usage|1102200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
966cd3d2-9f0e-4aa5-9480-feec45aa05b0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	a41e49e3-d9de-4e57-a600-84ba6ab55c45	\N	1429900	D	csv	2026-03-15|Utilities|Bescom|Backup usage|1429900	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
959a3d4a-e361-4050-8fb7-f9a36776d04f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	a41e49e3-d9de-4e57-a600-84ba6ab55c45	\N	1344200	D	csv	2026-05-15|Utilities|Bescom|Backup usage|1344200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
25d83dc8-e917-4054-9f7e-bd2cf8eba029	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	a41e49e3-d9de-4e57-a600-84ba6ab55c45	\N	1009600	D	csv	2026-06-15|Utilities|Bescom|Backup usage|1009600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
6093c7c2-396c-475f-a8e0-56cbee3a86e2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	3c759517-93c0-469c-988a-547d95b70e4b	a41e49e3-d9de-4e57-a600-84ba6ab55c45	\N	850000	D	csv	2026-07-15|Utilities|Bescom|Backup usage|850000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
1b0f2338-08ca-407d-9f53-f0bfeca324f5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	52731728-9e2c-4c54-80c6-3387733b453e	\N	3200000	D	csv	2025-08-15|Utilities|BWSSB|Water charges|3200000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
8e359162-f856-49e6-9cbe-748df9df2ca0	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	52731728-9e2c-4c54-80c6-3387733b453e	\N	3368300	D	csv	2025-09-15|Utilities|BWSSB|Water charges|3368300	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
676ddd4a-b5be-4c4b-8123-07d71144e630	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	52731728-9e2c-4c54-80c6-3387733b453e	\N	3381900	D	csv	2025-10-15|Utilities|BWSSB|Water charges|3381900	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
3cc5786a-da8b-43b6-844c-5cd5ea951ef2	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	52731728-9e2c-4c54-80c6-3387733b453e	\N	3228200	D	csv	2025-11-15|Utilities|BWSSB|Water charges|3228200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
b55711a0-1249-4640-9d1d-08730f4e7e93	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	52731728-9e2c-4c54-80c6-3387733b453e	\N	3048600	D	csv	2025-12-15|Utilities|BWSSB|Water charges|3048600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
b22d6632-06df-412e-846f-75bc3444d744	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	52731728-9e2c-4c54-80c6-3387733b453e	\N	3008200	D	csv	2026-01-15|Utilities|BWSSB|Water charges|3008200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
8cfe4e35-6b2c-4234-84fb-2989acb73933	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	52731728-9e2c-4c54-80c6-3387733b453e	\N	3144100	D	csv	2026-02-15|Utilities|BWSSB|Water charges|3144100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
6ec3460f-aea1-4a06-8a34-953c1b99d6fd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	52731728-9e2c-4c54-80c6-3387733b453e	\N	3331400	D	csv	2026-03-15|Utilities|BWSSB|Water charges|3331400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
cecd53a3-6765-4eb3-82b8-3306603a94e3	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	52731728-9e2c-4c54-80c6-3387733b453e	\N	3397900	D	csv	2026-04-15|Utilities|BWSSB|Water charges|3397900	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
df18d7f5-8118-441a-8185-7b3a4e1c1162	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	52731728-9e2c-4c54-80c6-3387733b453e	\N	3282400	D	csv	2026-05-15|Utilities|BWSSB|Water charges|3282400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
a93e8276-7fe9-4585-81e3-2421e967635b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	52731728-9e2c-4c54-80c6-3387733b453e	\N	3091200	D	csv	2026-06-15|Utilities|BWSSB|Water charges|3091200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
f44dc627-a522-40a1-b81f-9290d547774d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	96cbaa48-2f3d-4240-a903-036acad06180	51d0e12c-1244-4230-81ed-c03937ff473f	0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	52731728-9e2c-4c54-80c6-3387733b453e	\N	3000000	D	csv	2026-07-15|Utilities|BWSSB|Water charges|3000000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
bb955792-e515-4283-ba09-62cbd3ea9f3d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	6839e7e2-f46a-4fe4-a826-08e25ccfd937	\N	6500000	D	csv	2025-08-15|Maintenance|ABC Enterprise|Labour charges|6500000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
2ccf93b8-5697-4650-91b9-960605978012	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	6839e7e2-f46a-4fe4-a826-08e25ccfd937	\N	6752400	D	csv	2025-09-15|Maintenance|ABC Enterprise|Labour charges|6752400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
71b62400-eea2-41bc-a69c-c808b11ca631	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	6839e7e2-f46a-4fe4-a826-08e25ccfd937	\N	6772800	D	csv	2025-10-15|Maintenance|ABC Enterprise|Labour charges|6772800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
f73a4c2c-60e4-48fa-95a6-01c4de384116	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	6839e7e2-f46a-4fe4-a826-08e25ccfd937	\N	6542300	D	csv	2025-11-15|Maintenance|ABC Enterprise|Labour charges|6542300	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
cf6735b0-16c6-445b-89e5-616ac18c7804	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	6839e7e2-f46a-4fe4-a826-08e25ccfd937	\N	6273000	D	csv	2025-12-15|Maintenance|ABC Enterprise|Labour charges|6273000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
8e754d68-e817-49d3-9322-4013a2963ae5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	6839e7e2-f46a-4fe4-a826-08e25ccfd937	\N	6212300	D	csv	2026-01-15|Maintenance|ABC Enterprise|Labour charges|6212300	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
9b3616de-2d14-41af-8fb3-db0298836f10	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	6839e7e2-f46a-4fe4-a826-08e25ccfd937	\N	6416200	D	csv	2026-02-15|Maintenance|ABC Enterprise|Labour charges|6416200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
db12fde2-2d33-444c-acf6-106228e65ff6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	6839e7e2-f46a-4fe4-a826-08e25ccfd937	\N	6697100	D	csv	2026-03-15|Maintenance|ABC Enterprise|Labour charges|6697100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
7c08b232-0949-4cdd-888e-20376b301d0f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	6839e7e2-f46a-4fe4-a826-08e25ccfd937	\N	6796800	D	csv	2026-04-15|Maintenance|ABC Enterprise|Labour charges|6796800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
02930c4f-e9b2-4bf4-bd09-2b61754923b7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	6839e7e2-f46a-4fe4-a826-08e25ccfd937	\N	6623600	D	csv	2026-05-15|Maintenance|ABC Enterprise|Labour charges|6623600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
487f5283-98d5-42ef-847f-54a672881ae9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	6839e7e2-f46a-4fe4-a826-08e25ccfd937	\N	6336800	D	csv	2026-06-15|Maintenance|ABC Enterprise|Labour charges|6336800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
e19cff49-9938-43c8-8b2e-6d6ab96b6fe0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	6839e7e2-f46a-4fe4-a826-08e25ccfd937	\N	6200000	D	csv	2026-07-15|Maintenance|ABC Enterprise|Labour charges|6200000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
aa42c50c-999e-4187-a04f-02c767fc49d3	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	fa4aa685-7538-4e32-99be-5e35ed51bed6	\N	1800000	D	csv	2025-08-15|Maintenance|ABC Enterprise|Spare parts|1800000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
6538fa7e-01a3-47b0-8bc1-fadfb01b3f8c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	fa4aa685-7538-4e32-99be-5e35ed51bed6	\N	2345600	D	csv	2025-10-15|Maintenance|ABC Enterprise|Spare parts|2345600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
9068a27b-16af-43e0-86e5-da350e1d61cc	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	fa4aa685-7538-4e32-99be-5e35ed51bed6	\N	1884700	D	csv	2025-11-15|Maintenance|ABC Enterprise|Spare parts|1884700	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
222acd6f-340d-4186-adb8-e17b431c1978	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	fa4aa685-7538-4e32-99be-5e35ed51bed6	\N	1224600	D	csv	2026-01-15|Maintenance|ABC Enterprise|Spare parts|1224600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
36527223-eddb-4405-94b0-0935c2086936	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	fa4aa685-7538-4e32-99be-5e35ed51bed6	\N	1632400	D	csv	2026-02-15|Maintenance|ABC Enterprise|Spare parts|1632400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
3ec71305-df74-4f10-a819-f6f2beaa1065	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	fa4aa685-7538-4e32-99be-5e35ed51bed6	\N	2393600	D	csv	2026-04-15|Maintenance|ABC Enterprise|Spare parts|2393600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
ce611850-5161-4933-9077-b3647e236e06	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	fa4aa685-7538-4e32-99be-5e35ed51bed6	\N	2047300	D	csv	2026-05-15|Maintenance|ABC Enterprise|Spare parts|2047300	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
7aa09206-0deb-4d0a-83f7-37457d336884	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	fa4aa685-7538-4e32-99be-5e35ed51bed6	\N	1473600	D	csv	2026-06-15|Maintenance|ABC Enterprise|Spare parts|1473600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
91ad8efb-300a-47f0-8053-12b56e609357	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	fa4aa685-7538-4e32-99be-5e35ed51bed6	\N	1200000	D	csv	2026-07-15|Maintenance|ABC Enterprise|Spare parts|1200000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
d1501732-17f7-4622-9312-29c5933d24d0	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	c7764af5-f804-40e6-a4be-b9ed185a8f04	\N	945500	D	csv	2025-10-15|Maintenance|ABC Enterprise|STP salt purchase|945500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
52576e43-57ae-4413-986f-e69efea1a8f6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	c7764af5-f804-40e6-a4be-b9ed185a8f04	\N	852100	D	csv	2026-01-15|Maintenance|ABC Enterprise|STP salt purchase|852100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
c17530e9-8ed4-44be-a7cd-29cefee34711	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	c7764af5-f804-40e6-a4be-b9ed185a8f04	\N	949500	D	csv	2026-04-15|Maintenance|ABC Enterprise|STP salt purchase|949500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
df590f4e-2bdf-4351-81fd-208a8ebe7937	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	3f3626c8-174e-43e3-a763-53f5705c023f	c7764af5-f804-40e6-a4be-b9ed185a8f04	\N	850000	D	csv	2026-07-15|Maintenance|ABC Enterprise|STP salt purchase|850000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
2f098475-4b98-406d-a49d-4cf478ac5279	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	f842fb66-7faf-47e4-b9f5-bab6806dc4e9	8daec2f7-8924-4a13-9371-2b47a0cb6296	\N	744500	D	csv	2025-09-15|Maintenance|John (Plumber)|Plumbing repair|744500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
7da79cf0-bc01-4706-ac2f-018f0d6fbd1f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	f842fb66-7faf-47e4-b9f5-bab6806dc4e9	8daec2f7-8924-4a13-9371-2b47a0cb6296	\N	499400	D	csv	2025-11-15|Maintenance|John (Plumber)|Plumbing repair|499400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
2c3369cb-daef-463e-ad79-d853c232ab84	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	f842fb66-7faf-47e4-b9f5-bab6806dc4e9	8daec2f7-8924-4a13-9371-2b47a0cb6296	\N	185100	D	csv	2025-12-15|Maintenance|John (Plumber)|Plumbing repair|185100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
c889ec63-580c-4657-a287-166a5c6123eb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	f842fb66-7faf-47e4-b9f5-bab6806dc4e9	8daec2f7-8924-4a13-9371-2b47a0cb6296	\N	679900	D	csv	2026-03-15|Maintenance|John (Plumber)|Plumbing repair|679900	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
3b0ba522-dd97-4713-a1b0-9620093d4aec	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	f842fb66-7faf-47e4-b9f5-bab6806dc4e9	8daec2f7-8924-4a13-9371-2b47a0cb6296	\N	594200	D	csv	2026-05-15|Maintenance|John (Plumber)|Plumbing repair|594200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
91f1e7e4-f85a-496e-a4d7-1e0c925fac10	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	96cbaa48-2f3d-4240-a903-036acad06180	c9fa3e9e-5406-4f2f-9b77-3e32b096eb49	f842fb66-7faf-47e4-b9f5-bab6806dc4e9	8daec2f7-8924-4a13-9371-2b47a0cb6296	\N	259600	D	csv	2026-06-15|Maintenance|John (Plumber)|Plumbing repair|259600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
9c4e78af-0533-462e-8174-3007b874ed2a	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	96cbaa48-2f3d-4240-a903-036acad06180	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	e566e755-a124-4fc4-ad98-96fc47154ec2	\N	12000000	D	csv	2025-08-15|Security|SafeGuard Services|Guard salaries|12000000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
9d8c5eff-bad7-4a61-9f98-2a5f9912e114	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	96cbaa48-2f3d-4240-a903-036acad06180	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	e566e755-a124-4fc4-ad98-96fc47154ec2	\N	12168300	D	csv	2025-09-15|Security|SafeGuard Services|Guard salaries|12168300	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
bbfccb6f-6444-49cf-8927-8cbb0c35a3fc	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	96cbaa48-2f3d-4240-a903-036acad06180	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	e566e755-a124-4fc4-ad98-96fc47154ec2	\N	12181900	D	csv	2025-10-15|Security|SafeGuard Services|Guard salaries|12181900	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
ea923852-ef8d-4614-a79a-f1c114a15575	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	96cbaa48-2f3d-4240-a903-036acad06180	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	e566e755-a124-4fc4-ad98-96fc47154ec2	\N	12028200	D	csv	2025-11-15|Security|SafeGuard Services|Guard salaries|12028200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
5149e33a-5bda-4071-a902-4d9727fb2711	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	96cbaa48-2f3d-4240-a903-036acad06180	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	e566e755-a124-4fc4-ad98-96fc47154ec2	\N	11848600	D	csv	2025-12-15|Security|SafeGuard Services|Guard salaries|11848600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
a3cf8e2b-0f0b-48ce-9263-ba3935a3ff7d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	96cbaa48-2f3d-4240-a903-036acad06180	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	e566e755-a124-4fc4-ad98-96fc47154ec2	\N	11808200	D	csv	2026-01-15|Security|SafeGuard Services|Guard salaries|11808200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
f6832212-0393-4d58-a6a8-b9bc2016b679	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	96cbaa48-2f3d-4240-a903-036acad06180	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	e566e755-a124-4fc4-ad98-96fc47154ec2	\N	11944100	D	csv	2026-02-15|Security|SafeGuard Services|Guard salaries|11944100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
6f1e92b5-e61e-4b07-9a8b-23c7efab698a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	96cbaa48-2f3d-4240-a903-036acad06180	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	e566e755-a124-4fc4-ad98-96fc47154ec2	\N	12131400	D	csv	2026-03-15|Security|SafeGuard Services|Guard salaries|12131400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
1d872cca-9f80-4f66-ba5d-b468c98f0cd7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	96cbaa48-2f3d-4240-a903-036acad06180	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	e566e755-a124-4fc4-ad98-96fc47154ec2	\N	12197900	D	csv	2026-04-15|Security|SafeGuard Services|Guard salaries|12197900	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
97c82015-3fc5-408a-b919-6971faa3182b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	96cbaa48-2f3d-4240-a903-036acad06180	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	e566e755-a124-4fc4-ad98-96fc47154ec2	\N	12082400	D	csv	2026-05-15|Security|SafeGuard Services|Guard salaries|12082400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
0ad84c03-2218-4463-a4d9-aef80a333e1e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	96cbaa48-2f3d-4240-a903-036acad06180	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	e566e755-a124-4fc4-ad98-96fc47154ec2	\N	11891200	D	csv	2026-06-15|Security|SafeGuard Services|Guard salaries|11891200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
38265b5c-7b33-4c65-942a-0fef09c7cd0d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	96cbaa48-2f3d-4240-a903-036acad06180	f0562d5d-9e0e-4af7-a86f-4dee1285cd4f	67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	e566e755-a124-4fc4-ad98-96fc47154ec2	\N	11800000	D	csv	2026-07-15|Security|SafeGuard Services|Guard salaries|11800000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
2d6f4ea4-e158-4568-8ea6-9afdd21f83ce	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	\N	5800000	D	csv	2025-08-15|Housekeeping|CleanCo|Staff wages|5800000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
4cd57d3d-e582-4ac9-893b-53c4deac0f49	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	\N	5926200	D	csv	2025-09-15|Housekeeping|CleanCo|Staff wages|5926200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
23e7bd04-b43f-42b3-bbf9-9f2e578f6ff3	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	\N	5936400	D	csv	2025-10-15|Housekeeping|CleanCo|Staff wages|5936400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
d0081015-bb03-41af-b6f6-719842ccfbe9	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	\N	5821200	D	csv	2025-11-15|Housekeeping|CleanCo|Staff wages|5821200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
712cf2f2-096f-4a5c-a6d9-1e053bff9d33	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	\N	5686500	D	csv	2025-12-15|Housekeeping|CleanCo|Staff wages|5686500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
4cbd66bf-e552-48c4-8b08-4dbb289704cf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	\N	5656200	D	csv	2026-01-15|Housekeeping|CleanCo|Staff wages|5656200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
ee9a48ee-97d9-43b7-8f7f-8b539ad9a063	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	\N	5758100	D	csv	2026-02-15|Housekeeping|CleanCo|Staff wages|5758100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
d31ca040-f067-40be-87a9-8b1d7a6f8c05	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	\N	5898500	D	csv	2026-03-15|Housekeeping|CleanCo|Staff wages|5898500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
f9bbac09-73fb-45bb-bb8c-a6e72d738aab	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	\N	5948400	D	csv	2026-04-15|Housekeeping|CleanCo|Staff wages|5948400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
c11957d9-04fd-471a-a7ce-770cd8b709a4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	\N	5861800	D	csv	2026-05-15|Housekeeping|CleanCo|Staff wages|5861800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
7adfd499-d071-47cb-922e-0d16087f1d44	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	\N	5718400	D	csv	2026-06-15|Housekeeping|CleanCo|Staff wages|5718400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
4627bae7-2df8-4e98-b90f-88b91b1b5237	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	71c2aaab-bacf-4a5c-afde-c1d7b4cfd002	\N	5650000	D	csv	2026-07-15|Housekeeping|CleanCo|Staff wages|5650000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
c61baf7d-a581-424e-a611-8c7d8dcd87d5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	\N	750000	D	csv	2025-08-15|Housekeeping|CleanCo|Cleaning supplies|750000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
3e25b64c-730e-47e4-acb3-1b5850b6b2f5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	\N	876200	D	csv	2025-09-15|Housekeeping|CleanCo|Cleaning supplies|876200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
1e8bc1fe-a3ad-4e74-a5cf-7fb5c3366411	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	\N	886400	D	csv	2025-10-15|Housekeeping|CleanCo|Cleaning supplies|886400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
72ef0692-6926-49ca-9e1c-ba105547a81e	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	\N	771200	D	csv	2025-11-15|Housekeeping|CleanCo|Cleaning supplies|771200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
433a3c68-23d3-4275-aa5e-7943a99c4755	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	\N	636500	D	csv	2025-12-15|Housekeeping|CleanCo|Cleaning supplies|636500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
2b664c59-b5e9-46f4-861f-31e5c4765f24	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	\N	606200	D	csv	2026-01-15|Housekeeping|CleanCo|Cleaning supplies|606200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
eb08bd29-0515-40ff-b6bd-fa01a170b1c9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	\N	708100	D	csv	2026-02-15|Housekeeping|CleanCo|Cleaning supplies|708100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
c2915d39-f443-4e8a-af7b-482eb611c00e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	\N	848500	D	csv	2026-03-15|Housekeeping|CleanCo|Cleaning supplies|848500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
6c95feea-3cce-432f-bf41-341917fc1616	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	\N	898400	D	csv	2026-04-15|Housekeeping|CleanCo|Cleaning supplies|898400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
da468fde-2af5-436a-ae87-b28dafc3e6dd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	\N	811800	D	csv	2026-05-15|Housekeeping|CleanCo|Cleaning supplies|811800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
2a4c4e31-ad3f-4ab0-93dd-30be713d282d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	\N	668400	D	csv	2026-06-15|Housekeeping|CleanCo|Cleaning supplies|668400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
b5ccf398-d67c-446c-8fc3-6abf84a2a661	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	96cbaa48-2f3d-4240-a903-036acad06180	e932cc05-6cb8-4221-853d-5a5ec60a70f3	3fb4f987-bc91-46fe-9f58-088163d57ccb	b35d7b28-229c-4bfd-bb3c-7fa2a27f697b	\N	600000	D	csv	2026-07-15|Housekeeping|CleanCo|Cleaning supplies|600000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
2b5584ed-8b25-43cc-9a1d-5c60b53a0781	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	96cbaa48-2f3d-4240-a903-036acad06180	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	973161fa-9526-477c-b0c8-8f37bd0c760c	\N	600000	D	csv	2025-08-15|Petty Cash|Office petty cash|Ad-hoc expenses|600000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
1079138c-854e-4452-885b-fb25923faf49	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	96cbaa48-2f3d-4240-a903-036acad06180	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	973161fa-9526-477c-b0c8-8f37bd0c760c	\N	1062800	D	csv	2025-09-15|Petty Cash|Office petty cash|Ad-hoc expenses|1062800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
7cc382b5-f01d-48c2-b251-f3e5702adb16	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	96cbaa48-2f3d-4240-a903-036acad06180	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	973161fa-9526-477c-b0c8-8f37bd0c760c	\N	1100100	D	csv	2025-10-15|Petty Cash|Office petty cash|Ad-hoc expenses|1100100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
8718d2c1-e34f-4ae8-9d39-4056641aeaa7	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	96cbaa48-2f3d-4240-a903-036acad06180	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	973161fa-9526-477c-b0c8-8f37bd0c760c	\N	677600	D	csv	2025-11-15|Petty Cash|Office petty cash|Ad-hoc expenses|677600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
9179812c-4c95-4610-a859-8a1f2050c64d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	96cbaa48-2f3d-4240-a903-036acad06180	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	973161fa-9526-477c-b0c8-8f37bd0c760c	\N	183800	D	csv	2025-12-15|Petty Cash|Office petty cash|Ad-hoc expenses|183800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
059ee6c8-665d-4289-bfb6-e9026fa74bcd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	96cbaa48-2f3d-4240-a903-036acad06180	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	973161fa-9526-477c-b0c8-8f37bd0c760c	\N	72600	D	csv	2026-01-15|Petty Cash|Office petty cash|Ad-hoc expenses|72600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
a4d57d01-918c-46fd-8f91-768824f36ec2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	96cbaa48-2f3d-4240-a903-036acad06180	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	973161fa-9526-477c-b0c8-8f37bd0c760c	\N	446300	D	csv	2026-02-15|Petty Cash|Office petty cash|Ad-hoc expenses|446300	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
20aeefa3-75a5-4805-8556-eeb57e8ef444	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	96cbaa48-2f3d-4240-a903-036acad06180	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	973161fa-9526-477c-b0c8-8f37bd0c760c	\N	961300	D	csv	2026-03-15|Petty Cash|Office petty cash|Ad-hoc expenses|961300	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
ba3b63bc-4b64-4513-a9e2-9f62db5d9824	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	96cbaa48-2f3d-4240-a903-036acad06180	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	973161fa-9526-477c-b0c8-8f37bd0c760c	\N	1144100	D	csv	2026-04-15|Petty Cash|Office petty cash|Ad-hoc expenses|1144100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
851dfb98-580d-4497-b973-18050184f661	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	96cbaa48-2f3d-4240-a903-036acad06180	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	973161fa-9526-477c-b0c8-8f37bd0c760c	\N	826700	D	csv	2026-05-15|Petty Cash|Office petty cash|Ad-hoc expenses|826700	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
3a9f186f-493e-4a7f-90ac-6e8471b580c4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	96cbaa48-2f3d-4240-a903-036acad06180	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	973161fa-9526-477c-b0c8-8f37bd0c760c	\N	300800	D	csv	2026-06-15|Petty Cash|Office petty cash|Ad-hoc expenses|300800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
608cd01c-6207-4e0b-a240-9a4a3432cbc6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	96cbaa48-2f3d-4240-a903-036acad06180	3b966b27-29a9-419f-b31e-11a1395cb650	9687565c-25aa-46d5-a5da-9a9b409ee16d	973161fa-9526-477c-b0c8-8f37bd0c760c	\N	50000	D	csv	2026-07-15|Petty Cash|Office petty cash|Ad-hoc expenses|50000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
008f3fd6-70ee-4fce-9dfc-e3a59e138038	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	c8099030-bf63-443d-bae4-f1a6abac5fae	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	\N	34000000	C	csv	2025-08-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|34000000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
b311bd7c-0461-457b-bc59-46291dce3866	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	c8099030-bf63-443d-bae4-f1a6abac5fae	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	\N	35262200	C	csv	2025-09-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|35262200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
8a1aaa05-03bb-4bbf-a671-53a6ea89a558	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	c8099030-bf63-443d-bae4-f1a6abac5fae	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	\N	35363900	C	csv	2025-10-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|35363900	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
4a72409d-8bdb-47eb-93ac-1fd9776b13ed	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	c8099030-bf63-443d-bae4-f1a6abac5fae	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	\N	34211700	C	csv	2025-11-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|34211700	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
a536d16a-eea3-4c5b-9076-2b292fe0273a	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	c8099030-bf63-443d-bae4-f1a6abac5fae	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	\N	32864800	C	csv	2025-12-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|32864800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
018c094d-01b6-4ff0-9b96-d5f96b2a09c7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	c8099030-bf63-443d-bae4-f1a6abac5fae	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	\N	32561600	C	csv	2026-01-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|32561600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
bf86a427-dfaf-45ab-ad67-4402e927a141	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	c8099030-bf63-443d-bae4-f1a6abac5fae	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	\N	33580900	C	csv	2026-02-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|33580900	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
a5aa51e5-925c-46e0-b2f8-93613cc00f9a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	c8099030-bf63-443d-bae4-f1a6abac5fae	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	\N	34985500	C	csv	2026-03-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|34985500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
1ac47d2c-50b8-4c88-a319-dcabce0fa6bd	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	c8099030-bf63-443d-bae4-f1a6abac5fae	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	\N	35484000	C	csv	2026-04-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|35484000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
443004ed-eb07-46cb-a90a-92e58642afe1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	c8099030-bf63-443d-bae4-f1a6abac5fae	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	\N	34618200	C	csv	2026-05-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|34618200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
5d9bfb48-2024-4182-a187-b5cf111e01b5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	c8099030-bf63-443d-bae4-f1a6abac5fae	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	\N	33184000	C	csv	2026-06-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|33184000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
a6b3c2f4-c9a7-48fb-a82b-ca6e0e648867	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	c8099030-bf63-443d-bae4-f1a6abac5fae	c4b8baaf-5ed2-4886-8c91-599458b5db97	174cbd45-e4c1-471f-872d-082ecbf6d96b	1d53f52f-0e0b-42de-91c7-17ff4b3be4c1	\N	32500000	C	csv	2026-07-15|Maintenance Collections|Monthly maintenance|Flat maintenance dues|32500000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
ad442d30-3d49-4a8b-acc5-e6a174f65893	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	0ea05533-cd6f-42ee-8733-4ba4a15ca34c	\N	1800000	C	csv	2025-08-15|Other Income|Community Hall|Hall rental|1800000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
d88620f6-75f5-4fd8-9058-0225bd1523d2	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	0ea05533-cd6f-42ee-8733-4ba4a15ca34c	\N	2527400	C	csv	2025-10-15|Other Income|Community Hall|Hall rental|2527400	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
c88a181e-379f-4ade-8a18-1cf2e05859e8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	0ea05533-cd6f-42ee-8733-4ba4a15ca34c	\N	1912900	C	csv	2025-11-15|Other Income|Community Hall|Hall rental|1912900	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
c03637a9-1fe6-4a40-9bce-b7b66493e659	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	0ea05533-cd6f-42ee-8733-4ba4a15ca34c	\N	1194600	C	csv	2025-12-15|Other Income|Community Hall|Hall rental|1194600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
7ed1ffc3-dd25-4a9d-9f6d-cae1fd72c2c4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	0ea05533-cd6f-42ee-8733-4ba4a15ca34c	\N	1576500	C	csv	2026-02-15|Other Income|Community Hall|Hall rental|1576500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
05468f70-1c80-483b-9968-f9966f3d92e5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	0ea05533-cd6f-42ee-8733-4ba4a15ca34c	\N	2325600	C	csv	2026-03-15|Other Income|Community Hall|Hall rental|2325600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
5f0fa162-b374-4b7b-bcef-6c803c2b410c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	0ea05533-cd6f-42ee-8733-4ba4a15ca34c	\N	2591500	C	csv	2026-04-15|Other Income|Community Hall|Hall rental|2591500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
889004c0-6e2e-4e86-9176-55d60419ec94	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	0ea05533-cd6f-42ee-8733-4ba4a15ca34c	\N	1364800	C	csv	2026-06-15|Other Income|Community Hall|Hall rental|1364800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
df3be48d-beca-45da-b6e1-f6d717c385eb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	0ea05533-cd6f-42ee-8733-4ba4a15ca34c	\N	1000000	C	csv	2026-07-15|Other Income|Community Hall|Hall rental|1000000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
7ebd2647-d132-49e4-b199-9459a1522943	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	f2a24868-7364-4bfd-b16f-227a07b97933	\N	978700	C	csv	2025-09-15|Other Income|Community Hall|Event usage charges|978700	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
6f78a341-d1b5-4204-b7aa-7502f8293dd9	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	f2a24868-7364-4bfd-b16f-227a07b97933	\N	663500	C	csv	2025-11-15|Other Income|Community Hall|Event usage charges|663500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
109399eb-5513-4841-bfd4-a68ea382318c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	f2a24868-7364-4bfd-b16f-227a07b97933	\N	168500	C	csv	2026-01-15|Other Income|Community Hall|Event usage charges|168500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
252cdfca-bf41-40ae-b6f5-2320f5c5ca57	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	f2a24868-7364-4bfd-b16f-227a07b97933	\N	895600	C	csv	2026-03-15|Other Income|Community Hall|Event usage charges|895600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
549ca66d-acf3-48e0-a6bc-aa97c9a42e86	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	f2a24868-7364-4bfd-b16f-227a07b97933	\N	785500	C	csv	2026-05-15|Other Income|Community Hall|Event usage charges|785500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
151cf5dc-be82-4de0-a806-f272c43dc268	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	765156b0-3a01-42ce-b9bd-5651de6a8c1a	f2a24868-7364-4bfd-b16f-227a07b97933	\N	150000	C	csv	2026-07-15|Other Income|Community Hall|Event usage charges|150000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
dcb4bb5b-a35a-4a40-a8d1-25ceccae08b6	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	9176c78d-24a9-4720-9877-369f6d00edc6	\N	1200000	C	csv	2025-08-15|Other Income|Signage Rental|Billboard fee|1200000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
80fbea4d-2a71-47c9-94c5-546d0c34662c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	9176c78d-24a9-4720-9877-369f6d00edc6	\N	1242100	C	csv	2025-09-15|Other Income|Signage Rental|Billboard fee|1242100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
600c24e4-f35f-454c-a3a5-df6ef7a0ccf9	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	9176c78d-24a9-4720-9877-369f6d00edc6	\N	1245500	C	csv	2025-10-15|Other Income|Signage Rental|Billboard fee|1245500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
5e754372-83c8-44a2-a995-f9cd5d712d89	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	9176c78d-24a9-4720-9877-369f6d00edc6	\N	1207100	C	csv	2025-11-15|Other Income|Signage Rental|Billboard fee|1207100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
89d1b80f-7f72-414a-9e33-a7eadb020b04	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	9176c78d-24a9-4720-9877-369f6d00edc6	\N	1162200	C	csv	2025-12-15|Other Income|Signage Rental|Billboard fee|1162200	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
98b03b99-613f-410f-a06d-89ec7c37e495	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	9176c78d-24a9-4720-9877-369f6d00edc6	\N	1152100	C	csv	2026-01-15|Other Income|Signage Rental|Billboard fee|1152100	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
519cbc6d-059f-4b5d-b462-e44464bf2a5c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	9176c78d-24a9-4720-9877-369f6d00edc6	\N	1186000	C	csv	2026-02-15|Other Income|Signage Rental|Billboard fee|1186000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
94d18b72-931d-4f33-b7d0-9e4ddf778fdb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	9176c78d-24a9-4720-9877-369f6d00edc6	\N	1232800	C	csv	2026-03-15|Other Income|Signage Rental|Billboard fee|1232800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
48bb99f6-b661-4069-99d7-59db3fee1891	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	9176c78d-24a9-4720-9877-369f6d00edc6	\N	1249500	C	csv	2026-04-15|Other Income|Signage Rental|Billboard fee|1249500	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
6157435f-9925-4d2f-a23c-5ed3c72a7529	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	9176c78d-24a9-4720-9877-369f6d00edc6	\N	1220600	C	csv	2026-05-15|Other Income|Signage Rental|Billboard fee|1220600	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
8ab7fab9-e8d7-416f-982b-300b507a8bce	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	9176c78d-24a9-4720-9877-369f6d00edc6	\N	1172800	C	csv	2026-06-15|Other Income|Signage Rental|Billboard fee|1172800	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
5bd8fb68-4da1-4d97-9946-11dde3c6ff90	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	c8099030-bf63-443d-bae4-f1a6abac5fae	23002d57-222e-4b19-b795-5104e15a8a77	ca4596af-9279-4293-8de2-31f486d28f2b	9176c78d-24a9-4720-9877-369f6d00edc6	\N	1150000	C	csv	2026-07-15|Other Income|Signage Rental|Billboard fee|1150000	\N	\N	2026-07-13 14:09:36.075718+00	2026-07-13 14:09:36.075718+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	superadmin
0f0c6024-6c4d-47b3-9012-4f714d448a40	admin
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, community_id, email, name, password_hash, last_login_at, created_at) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	caa11b01-c3a5-4067-a90c-b73b35075def	admin@example.com	Super Admin	$argon2id$v=19$m=65536,t=3,p=4$lU8bY9DkqJpqPlfdxQknpA$WIQ5sQR/iqY+0PYR5nUFGT+LLrlwQ/9chr/EwWoRago	2026-07-13 13:45:07.51404+00	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, community_id, name, kind) FROM stdin;
3c759517-93c0-469c-988a-547d95b70e4b	caa11b01-c3a5-4067-a90c-b73b35075def	Bescom	company
0f87501e-b7b0-4618-a7bd-a40b4f07fbcf	caa11b01-c3a5-4067-a90c-b73b35075def	BWSSB	company
3f3626c8-174e-43e3-a763-53f5705c023f	caa11b01-c3a5-4067-a90c-b73b35075def	ABC Enterprise	company
f842fb66-7faf-47e4-b9f5-bab6806dc4e9	caa11b01-c3a5-4067-a90c-b73b35075def	John (Plumber)	individual
67e247fd-6ad9-4cd5-a7f5-4e10ca2b37c1	caa11b01-c3a5-4067-a90c-b73b35075def	SafeGuard Services	company
3fb4f987-bc91-46fe-9f58-088163d57ccb	caa11b01-c3a5-4067-a90c-b73b35075def	CleanCo	company
9687565c-25aa-46d5-a5da-9a9b409ee16d	caa11b01-c3a5-4067-a90c-b73b35075def	Office petty cash	individual
174cbd45-e4c1-471f-872d-082ecbf6d96b	caa11b01-c3a5-4067-a90c-b73b35075def	Monthly maintenance	company
765156b0-3a01-42ce-b9bd-5651de6a8c1a	caa11b01-c3a5-4067-a90c-b73b35075def	Community Hall	company
ca4596af-9279-4293-8de2-31f486d28f2b	caa11b01-c3a5-4067-a90c-b73b35075def	Signage Rental	individual
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 2, true);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (name);


--
-- Name: allowed_emails allowed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_pkey PRIMARY KEY (email);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: balances balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_pkey PRIMARY KEY (community_id, month);


--
-- Name: categories categories_head_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_name_key UNIQUE (head_id, name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: collections_dues collections_dues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_pkey PRIMARY KEY (flat_id, period_month);


--
-- Name: communities communities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communities
    ADD CONSTRAINT communities_pkey PRIMARY KEY (id);


--
-- Name: dashboard_settings dashboard_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_pkey PRIMARY KEY (community_id, dashboard_key);


--
-- Name: flats flats_community_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_code_key UNIQUE (community_id, code);


--
-- Name: flats flats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_pkey PRIMARY KEY (id);


--
-- Name: heads heads_community_id_kind_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_kind_name_key UNIQUE (community_id, kind, name);


--
-- Name: heads heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_rules import_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_pkey PRIMARY KEY (id);


--
-- Name: import_staging import_staging_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_pkey PRIMARY KEY (batch_id, row_no);


--
-- Name: line_items line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_pkey PRIMARY KEY (id);


--
-- Name: otp_codes magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (email, otp_hash);


--
-- Name: periods periods_community_id_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_month_key UNIQUE (community_id, month);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_source_source_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_source_source_ref_key UNIQUE (source, source_ref);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_community_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_name_key UNIQUE (community_id, name);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_at ON public.audit_log USING btree (at DESC);


--
-- Name: idx_audit_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_entity ON public.audit_log USING btree (entity, entity_id);


--
-- Name: idx_txn_category_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_category_month ON public.transactions USING btree (category_id, period_month);


--
-- Name: idx_txn_community_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_community_month ON public.transactions USING btree (community_id, period_month);


--
-- Name: idx_txn_flat_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_flat_month ON public.transactions USING btree (flat_id, period_month);


--
-- Name: idx_txn_head_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_head_month ON public.transactions USING btree (head_id, period_month);


--
-- Name: idx_txn_vendor_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_vendor_month ON public.transactions USING btree (vendor_id, period_month);


--
-- Name: line_items_cat_vendor_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX line_items_cat_vendor_name_uq ON public.line_items USING btree (category_id, COALESCE(vendor_id, '00000000-0000-0000-0000-000000000000'::uuid), name);


--
-- Name: mv_cat_monthly_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_cat_monthly_idx ON public.mv_category_monthly USING btree (community_id, month);


--
-- Name: mv_monthly_totals_pk; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mv_monthly_totals_pk ON public.mv_monthly_totals USING btree (community_id, month);


--
-- Name: mv_vendor_ranking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_vendor_ranking_idx ON public.mv_vendor_ranking USING btree (community_id, total_expense_paise DESC);


--
-- Name: allowed_emails allowed_emails_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: allowed_emails allowed_emails_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE SET NULL;


--
-- Name: balances balances_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: categories categories_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id) ON DELETE CASCADE;


--
-- Name: collections_dues collections_dues_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE CASCADE;


--
-- Name: dashboard_settings dashboard_settings_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: flats flats_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: heads heads_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: import_rules import_rules_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_staging import_staging_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE SET NULL;


--
-- Name: periods periods_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: transactions transactions_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id);


--
-- Name: transactions transactions_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id);


--
-- Name: transactions transactions_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_line_item_id_fkey FOREIGN KEY (line_item_id) REFERENCES public.line_items(id);


--
-- Name: transactions transactions_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: vendors vendors_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_category_monthly;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_monthly_totals;


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_vendor_ranking;


--
-- PostgreSQL database dump complete
--

\unrestrict vxe5j1V7ouUiwjks7PLgC9OEzmQCVlwDLghphytirMVW5KOXLdsVcz5d4eKktU9

