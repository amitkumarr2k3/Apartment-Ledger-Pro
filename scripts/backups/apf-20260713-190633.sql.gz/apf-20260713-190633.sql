--
-- PostgreSQL database dump
--

\restrict jF6tkUuYDKMQSq7URsXjB7lf8EzEtkp4rNikgyI7j2zbKSM5g3OjHKUG6q0TEr0

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_line_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_vendor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_batch_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_uploaded_by_fkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_fkey;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_community_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_actor_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_flat_id_fkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_community_id_fkey;
DROP INDEX IF EXISTS public.mv_vendor_ranking_idx;
DROP INDEX IF EXISTS public.mv_monthly_totals_pk;
DROP INDEX IF EXISTS public.mv_cat_monthly_idx;
DROP INDEX IF EXISTS public.line_items_cat_vendor_name_uq;
DROP INDEX IF EXISTS public.idx_txn_vendor_month;
DROP INDEX IF EXISTS public.idx_txn_head_month;
DROP INDEX IF EXISTS public.idx_txn_flat_month;
DROP INDEX IF EXISTS public.idx_txn_community_month;
DROP INDEX IF EXISTS public.idx_txn_category_month;
DROP INDEX IF EXISTS public.idx_audit_entity;
DROP INDEX IF EXISTS public.idx_audit_at;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_pkey;
ALTER TABLE IF EXISTS ONLY public.vendors DROP CONSTRAINT IF EXISTS vendors_community_id_name_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_source_source_ref_key;
ALTER TABLE IF EXISTS ONLY public.transactions DROP CONSTRAINT IF EXISTS transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_pkey;
ALTER TABLE IF EXISTS ONLY public.periods DROP CONSTRAINT IF EXISTS periods_community_id_month_key;
ALTER TABLE IF EXISTS ONLY public.otp_codes DROP CONSTRAINT IF EXISTS magic_links_pkey;
ALTER TABLE IF EXISTS ONLY public.line_items DROP CONSTRAINT IF EXISTS line_items_pkey;
ALTER TABLE IF EXISTS ONLY public.import_staging DROP CONSTRAINT IF EXISTS import_staging_pkey;
ALTER TABLE IF EXISTS ONLY public.import_rules DROP CONSTRAINT IF EXISTS import_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.import_batches DROP CONSTRAINT IF EXISTS import_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_pkey;
ALTER TABLE IF EXISTS ONLY public.heads DROP CONSTRAINT IF EXISTS heads_community_id_kind_name_key;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_pkey;
ALTER TABLE IF EXISTS ONLY public.flats DROP CONSTRAINT IF EXISTS flats_community_id_code_key;
ALTER TABLE IF EXISTS ONLY public.dashboard_settings DROP CONSTRAINT IF EXISTS dashboard_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.communities DROP CONSTRAINT IF EXISTS communities_pkey;
ALTER TABLE IF EXISTS ONLY public.collections_dues DROP CONSTRAINT IF EXISTS collections_dues_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_head_id_name_key;
ALTER TABLE IF EXISTS ONLY public.balances DROP CONSTRAINT IF EXISTS balances_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.allowed_emails DROP CONSTRAINT IF EXISTS allowed_emails_pkey;
ALTER TABLE IF EXISTS ONLY public._migrations DROP CONSTRAINT IF EXISTS _migrations_pkey;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP TABLE IF EXISTS public.periods;
DROP TABLE IF EXISTS public.otp_codes;
DROP MATERIALIZED VIEW IF EXISTS public.mv_vendor_ranking;
DROP TABLE IF EXISTS public.vendors;
DROP MATERIALIZED VIEW IF EXISTS public.mv_monthly_totals;
DROP MATERIALIZED VIEW IF EXISTS public.mv_category_monthly;
DROP TABLE IF EXISTS public.transactions;
DROP TABLE IF EXISTS public.line_items;
DROP TABLE IF EXISTS public.import_staging;
DROP TABLE IF EXISTS public.import_rules;
DROP TABLE IF EXISTS public.import_batches;
DROP TABLE IF EXISTS public.heads;
DROP TABLE IF EXISTS public.flats;
DROP TABLE IF EXISTS public.dashboard_settings;
DROP TABLE IF EXISTS public.communities;
DROP TABLE IF EXISTS public.collections_dues;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.balances;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP TABLE IF EXISTS public.allowed_emails;
DROP TABLE IF EXISTS public._migrations;
DROP TYPE IF EXISTS public.vendor_kind;
DROP TYPE IF EXISTS public.head_kind;
DROP TYPE IF EXISTS public.app_role;
DROP EXTENSION IF EXISTS pgcrypto;
--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'resident',
    'admin',
    'superadmin'
);


--
-- Name: head_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.head_kind AS ENUM (
    'income',
    'expense'
);


--
-- Name: vendor_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vendor_kind AS ENUM (
    'company',
    'individual'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._migrations (
    name text NOT NULL,
    run_at timestamp with time zone DEFAULT now()
);


--
-- Name: allowed_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.allowed_emails (
    email text NOT NULL,
    community_id uuid NOT NULL,
    role public.app_role NOT NULL,
    flat_id uuid,
    name text,
    invited_by text,
    invited_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    community_id uuid,
    actor_user_id uuid,
    actor_email text,
    entity text NOT NULL,
    entity_id text,
    action text NOT NULL,
    before jsonb,
    after jsonb,
    at timestamp with time zone DEFAULT now() NOT NULL,
    ip text,
    user_agent text
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.balances (
    community_id uuid NOT NULL,
    month date NOT NULL,
    opening_paise bigint DEFAULT 0 NOT NULL,
    closing_paise bigint DEFAULT 0 NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    head_id uuid NOT NULL,
    name text NOT NULL
);


--
-- Name: collections_dues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collections_dues (
    flat_id uuid NOT NULL,
    period_month date NOT NULL,
    dues_paise bigint DEFAULT 0 NOT NULL,
    paid_paise bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'due'::text NOT NULL
);


--
-- Name: communities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    currency text DEFAULT 'INR'::text NOT NULL,
    fy_start_month smallint DEFAULT 4 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dashboard_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_settings (
    community_id uuid NOT NULL,
    dashboard_key text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    hidden_widgets text[] DEFAULT '{}'::text[] NOT NULL
);


--
-- Name: flats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    code text NOT NULL,
    owner_email text
);


--
-- Name: heads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind public.head_kind NOT NULL,
    name text NOT NULL
);


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    filename text NOT NULL,
    kind text NOT NULL,
    uploaded_by uuid,
    status text DEFAULT 'staged'::text NOT NULL,
    error text,
    row_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    kind text NOT NULL,
    match jsonb NOT NULL,
    set_fields jsonb NOT NULL,
    priority integer DEFAULT 100 NOT NULL
);


--
-- Name: import_staging; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_staging (
    batch_id uuid NOT NULL,
    row_no integer NOT NULL,
    raw_json jsonb NOT NULL,
    mapped_json jsonb,
    error text
);


--
-- Name: line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.line_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    name text NOT NULL,
    first_seen_month date,
    last_seen_month date
);


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    txn_date date NOT NULL,
    period_month date NOT NULL,
    head_id uuid NOT NULL,
    category_id uuid NOT NULL,
    vendor_id uuid,
    line_item_id uuid,
    flat_id uuid,
    amount_paise bigint NOT NULL,
    direction character(1) NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    source_ref text,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT transactions_amount_paise_check CHECK ((amount_paise >= 0)),
    CONSTRAINT transactions_direction_check CHECK ((direction = ANY (ARRAY['C'::bpchar, 'D'::bpchar])))
);


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_category_monthly AS
 SELECT t.community_id,
    t.category_id,
    c.name AS category_name,
    h.kind AS head_kind,
    t.period_month AS month,
    (sum(t.amount_paise))::bigint AS amount_paise
   FROM ((public.transactions t
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON ((h.id = t.head_id)))
  GROUP BY t.community_id, t.category_id, c.name, h.kind, t.period_month
  WITH NO DATA;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_monthly_totals AS
 WITH spine AS (
         SELECT c.id AS community_id,
            (date_trunc('month'::text, gs.gs))::date AS month
           FROM (public.communities c
             CROSS JOIN generate_series((( SELECT COALESCE(min(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, (( SELECT COALESCE(max(transactions.period_month), CURRENT_DATE) AS "coalesce"
                   FROM public.transactions))::timestamp with time zone, '1 mon'::interval) gs(gs))
        )
 SELECT s.community_id,
    s.month,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric))::bigint AS collection_paise,
    (COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric))::bigint AS expense_paise,
    ((COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'C'::bpchar)), (0)::numeric) - COALESCE(sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)), (0)::numeric)))::bigint AS net_paise
   FROM (spine s
     LEFT JOIN public.transactions t ON (((t.community_id = s.community_id) AND (t.period_month = s.month))))
  GROUP BY s.community_id, s.month
  WITH NO DATA;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    name text NOT NULL,
    kind public.vendor_kind DEFAULT 'company'::public.vendor_kind NOT NULL
);


--
-- Name: TABLE vendors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.vendors IS 'Vendor dimension. Read-only from admin UI; populated via CSV import + on-the-fly during transaction ingest.';


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.mv_vendor_ranking AS
 SELECT t.community_id,
    v.id AS vendor_id,
    v.name AS vendor_name,
    v.kind AS vendor_kind,
    COALESCE(string_agg(DISTINCT c.name, ', '::text), ''::text) AS categories,
    (sum(t.amount_paise) FILTER (WHERE (t.direction = 'D'::bpchar)))::bigint AS total_expense_paise,
    count(DISTINCT t.period_month) AS months_active
   FROM (((public.transactions t
     JOIN public.vendors v ON ((v.id = t.vendor_id)))
     JOIN public.categories c ON ((c.id = t.category_id)))
     JOIN public.heads h ON (((h.id = t.head_id) AND (h.kind = 'expense'::public.head_kind))))
  GROUP BY t.community_id, v.id, v.name, v.kind
  WITH NO DATA;


--
-- Name: otp_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otp_codes (
    email text NOT NULL,
    otp_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone
);


--
-- Name: periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.periods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    month date NOT NULL,
    status text DEFAULT 'open'::text NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role public.app_role NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    community_id uuid NOT NULL,
    email text NOT NULL,
    name text,
    password_hash text,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Data for Name: _migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._migrations (name, run_at) FROM stdin;
0001_init.sql	2026-07-13 11:13:56.401452+00
0002_indexes.sql	2026-07-13 11:13:56.401452+00
0003_mviews.sql	2026-07-13 11:13:56.401452+00
0004_otp_rename.sql	2026-07-13 11:20:04.500279+00
\.


--
-- Data for Name: allowed_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.allowed_emails (email, community_id, role, flat_id, name, invited_by, invited_at, revoked_at) FROM stdin;
treasurer@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	admin	\N	Treasurer	system	2026-07-13 11:20:04.55456+00	\N
resident@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	resident	\N	Demo Resident	system	2026-07-13 11:20:04.55456+00	\N
admin@example.com	caa11b01-c3a5-4067-a90c-b73b35075def	superadmin	\N	Super Admin	system	2026-07-13 11:20:04.55456+00	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, community_id, actor_user_id, actor_email, entity, entity_id, action, before, after, at, ip, user_agent) FROM stdin;
\.


--
-- Data for Name: balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.balances (community_id, month, opening_paise, closing_paise) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-01	85000000	85350000
caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-01	85350000	85303200
caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-01	85303200	85725700
caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-01	85725700	86162300
caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-01	86162300	88089400
caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-01	88089400	87250400
caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-01	87250400	87754100
caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-01	87754100	90152800
caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-01	90152800	90555500
caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-01	90555500	88740600
caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-01	88740600	89130200
caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-01	89130200	89330200
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, head_id, name) FROM stdin;
4db1f281-893e-499d-8159-c67e91fb74dd	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	Utilities
2662ae57-f003-43fc-a8cc-350681b3b09a	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	Maintenance
e6cb183b-e0b3-4d5c-894c-b72a425e4e68	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	Security
8a6265b8-59f4-4258-8868-0b4c119ecbfb	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	Housekeeping
23f237cd-673f-41cf-a90b-72a819a008fc	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	Petty Cash
e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	9df23939-7428-4dc4-b512-9bb82cb4238c	Maintenance Collections
f9f8a74a-8bac-4438-88d2-2cf1475dff65	9df23939-7428-4dc4-b512-9bb82cb4238c	Other Income
\.


--
-- Data for Name: collections_dues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collections_dues (flat_id, period_month, dues_paise, paid_paise, status) FROM stdin;
\.


--
-- Data for Name: communities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communities (id, name, currency, fy_start_month, created_at) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	Green Meadows	INR	4	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: dashboard_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_settings (community_id, dashboard_key, enabled, hidden_widgets) FROM stdin;
caa11b01-c3a5-4067-a90c-b73b35075def	resident.overview	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.drilldown	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.cashflow	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.income	t	{}
caa11b01-c3a5-4067-a90c-b73b35075def	resident.balance	t	{}
\.


--
-- Data for Name: flats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flats (id, community_id, code, owner_email) FROM stdin;
f88d6359-58a8-42b1-8476-24ce41b63802	caa11b01-c3a5-4067-a90c-b73b35075def	A-001	\N
5696d5bf-57f9-44ad-b92d-781cabc4a550	caa11b01-c3a5-4067-a90c-b73b35075def	A-002	\N
5c447f5e-a684-4075-8224-072f1fb12c93	caa11b01-c3a5-4067-a90c-b73b35075def	A-003	\N
6ddf10b7-40ed-44a1-9080-e50c60a08e32	caa11b01-c3a5-4067-a90c-b73b35075def	A-004	\N
5bfe95a5-bc38-4d00-811e-b5a6106e71c7	caa11b01-c3a5-4067-a90c-b73b35075def	A-005	\N
6e67ec18-d2aa-4cd4-8a51-b9a2b33429a2	caa11b01-c3a5-4067-a90c-b73b35075def	A-006	\N
05fbfe69-9195-45aa-bb9a-ef1de36f6fd9	caa11b01-c3a5-4067-a90c-b73b35075def	A-007	\N
7dca9ae9-39f7-4b2c-85b6-f9c820a65f0c	caa11b01-c3a5-4067-a90c-b73b35075def	A-008	\N
24f24d23-6946-4d06-b2d4-7ebe31278f9e	caa11b01-c3a5-4067-a90c-b73b35075def	A-009	\N
39278459-ad85-4e5e-937a-0a36b195c960	caa11b01-c3a5-4067-a90c-b73b35075def	A-010	\N
716bbe4c-f53d-4558-a4b5-caeb642f2c23	caa11b01-c3a5-4067-a90c-b73b35075def	A-011	\N
6dac5232-f75f-44d2-8533-4119c856f0ac	caa11b01-c3a5-4067-a90c-b73b35075def	A-012	\N
ea815ea6-a6d6-4547-bb06-ebfc9497a6f2	caa11b01-c3a5-4067-a90c-b73b35075def	A-013	\N
b441021b-6b42-4350-bd7a-385d23b17015	caa11b01-c3a5-4067-a90c-b73b35075def	A-014	\N
74194275-0229-47a7-9a12-691c228cbf03	caa11b01-c3a5-4067-a90c-b73b35075def	A-015	\N
f9df5252-7643-42fd-9a63-2e839347a52f	caa11b01-c3a5-4067-a90c-b73b35075def	A-016	\N
321b8a10-e82d-4cf6-a6b2-fde3fa7b05b1	caa11b01-c3a5-4067-a90c-b73b35075def	A-017	\N
9c1ddcb5-9b93-4e47-80ac-cbfc3b7f326e	caa11b01-c3a5-4067-a90c-b73b35075def	A-018	\N
f0106df5-f061-40fd-97c8-f6408f268ff9	caa11b01-c3a5-4067-a90c-b73b35075def	A-019	\N
deeb22d9-7a6b-4417-985b-c76049abae2e	caa11b01-c3a5-4067-a90c-b73b35075def	A-020	\N
c2e7bc3c-62db-4d01-aad3-9513cbf2ecbf	caa11b01-c3a5-4067-a90c-b73b35075def	A-021	\N
8c7ed2ff-3fea-4279-a889-c4e44b78ef6e	caa11b01-c3a5-4067-a90c-b73b35075def	A-022	\N
fb52fe46-dded-4f23-975d-3f36184896e9	caa11b01-c3a5-4067-a90c-b73b35075def	A-023	\N
5fc3f4ab-169c-47bc-819a-315c1a244aac	caa11b01-c3a5-4067-a90c-b73b35075def	A-024	\N
\.


--
-- Data for Name: heads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heads (id, community_id, kind, name) FROM stdin;
20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	caa11b01-c3a5-4067-a90c-b73b35075def	expense	Operating Expenses
9df23939-7428-4dc4-b512-9bb82cb4238c	caa11b01-c3a5-4067-a90c-b73b35075def	income	Operating Income
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, community_id, filename, kind, uploaded_by, status, error, row_count, created_at) FROM stdin;
\.


--
-- Data for Name: import_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_rules (id, community_id, kind, match, set_fields, priority) FROM stdin;
\.


--
-- Data for Name: import_staging; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_staging (batch_id, row_no, raw_json, mapped_json, error) FROM stdin;
\.


--
-- Data for Name: line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.line_items (id, category_id, vendor_id, name, first_seen_month, last_seen_month) FROM stdin;
d4096b51-b5e1-474f-b92c-a14423f1ec2a	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	Common area electricity	2025-08-01	2026-07-01
0ea27bf9-8055-4580-9820-752bdf2f5041	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	Backup usage	2025-08-01	2026-07-01
79e10070-139a-47df-8cac-6db896965f6f	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	Water charges	2025-08-01	2026-07-01
5414c3f2-4a74-4064-b345-8ceddbd3d1db	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	Labour charges	2025-08-01	2026-07-01
351bfa00-9d82-4d01-9b01-5acf8b3eab19	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	Spare parts	2025-08-01	2026-07-01
c8c58993-543d-4094-8139-838dbcf2d2b2	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	STP salt purchase	2025-10-01	2026-07-01
cea11cd2-f83a-4afa-9282-779eb47f7031	2662ae57-f003-43fc-a8cc-350681b3b09a	97323209-a30d-4919-806c-6d1e00986a9e	Plumbing repair	2025-09-01	2026-06-01
c26407c6-db9a-466b-ab08-c40421402fb5	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	Guard salaries	2025-08-01	2026-07-01
bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	Staff wages	2025-08-01	2026-07-01
185905ac-b627-4193-90cf-9b90584b93d7	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	Cleaning supplies	2025-08-01	2026-07-01
4b591384-fe25-4cda-a70c-6a27cfda4b1f	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	Ad-hoc expenses	2025-08-01	2026-07-01
f61b5c1e-7431-4447-af34-38da3726a4c6	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	Flat maintenance dues	2025-08-01	2026-07-01
edb47adf-7adc-4c0e-963a-28138c0e6d29	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	Hall rental	2025-08-01	2026-07-01
db44f80c-086d-43e9-85a1-64068da7621d	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	Event usage charges	2025-09-01	2026-07-01
dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	Billboard fee	2025-08-01	2026-07-01
\.


--
-- Data for Name: otp_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.otp_codes (email, otp_hash, expires_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.periods (id, community_id, month, status) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, community_id, txn_date, period_month, head_id, category_id, vendor_id, line_item_id, flat_id, amount_paise, direction, source, source_ref, notes, created_by, created_at, updated_at) FROM stdin;
40c4119a-96ef-41c2-9991-a6ee47c4ff6f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	d4096b51-b5e1-474f-b92c-a14423f1ec2a	\N	4800000	D	seed	seed|Utilities|Bescom|Common area electricity|2025-08-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
3342b611-aeeb-46e5-8adf-29df1372b02c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	d4096b51-b5e1-474f-b92c-a14423f1ec2a	\N	5136600	D	seed	seed|Utilities|Bescom|Common area electricity|2025-09-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
1cd9cd77-6da0-4edd-8f4b-107d12ce4252	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	d4096b51-b5e1-474f-b92c-a14423f1ec2a	\N	5163700	D	seed	seed|Utilities|Bescom|Common area electricity|2025-10-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
ecc02345-274f-4387-b376-215a8aecb241	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	d4096b51-b5e1-474f-b92c-a14423f1ec2a	\N	4856400	D	seed	seed|Utilities|Bescom|Common area electricity|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
136e8e84-0c02-4f13-9e37-49c98975ee56	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	d4096b51-b5e1-474f-b92c-a14423f1ec2a	\N	4497300	D	seed	seed|Utilities|Bescom|Common area electricity|2025-12-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
fdb34694-586d-47bc-9858-7c87626f0e71	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	d4096b51-b5e1-474f-b92c-a14423f1ec2a	\N	4416400	D	seed	seed|Utilities|Bescom|Common area electricity|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
3d9368cc-d1c2-44af-b925-e8010c6458fb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	d4096b51-b5e1-474f-b92c-a14423f1ec2a	\N	4688200	D	seed	seed|Utilities|Bescom|Common area electricity|2026-02-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
4ea45dae-40d2-4e66-8775-5793f3932053	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	d4096b51-b5e1-474f-b92c-a14423f1ec2a	\N	5062800	D	seed	seed|Utilities|Bescom|Common area electricity|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
a4e75084-df82-41ea-a75d-cd19447f507a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	d4096b51-b5e1-474f-b92c-a14423f1ec2a	\N	5195700	D	seed	seed|Utilities|Bescom|Common area electricity|2026-04-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
b2fa8429-f468-495e-80a8-85e4ed56aae6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	d4096b51-b5e1-474f-b92c-a14423f1ec2a	\N	4964800	D	seed	seed|Utilities|Bescom|Common area electricity|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
29be318a-b2ea-42c4-89ae-e175c35b8a7f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	d4096b51-b5e1-474f-b92c-a14423f1ec2a	\N	4582400	D	seed	seed|Utilities|Bescom|Common area electricity|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
c84ee8af-d3d5-43f6-a91b-1b3c74b08315	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	d4096b51-b5e1-474f-b92c-a14423f1ec2a	\N	4400000	D	seed	seed|Utilities|Bescom|Common area electricity|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
b8f9ff7e-627f-474b-b4fc-57e909b3859a	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	0ea27bf9-8055-4580-9820-752bdf2f5041	\N	1200000	D	seed	seed|Utilities|Bescom|Backup usage|2025-08-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
a2190cde-ca8d-4482-8a82-c0024fbad482	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	0ea27bf9-8055-4580-9820-752bdf2f5041	\N	1494500	D	seed	seed|Utilities|Bescom|Backup usage|2025-09-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
cc721e27-0ece-45f5-8fbd-da120f73d475	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	0ea27bf9-8055-4580-9820-752bdf2f5041	\N	1249400	D	seed	seed|Utilities|Bescom|Backup usage|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
4e3f14cd-645a-4606-a745-4ca268cd15d2	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	0ea27bf9-8055-4580-9820-752bdf2f5041	\N	935100	D	seed	seed|Utilities|Bescom|Backup usage|2025-12-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
59099107-6ad8-4ec6-86e6-2ed235b3e4c8	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	0ea27bf9-8055-4580-9820-752bdf2f5041	\N	864400	D	seed	seed|Utilities|Bescom|Backup usage|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
131a2a2d-205b-4d77-adbc-75ac49ed8755	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	0ea27bf9-8055-4580-9820-752bdf2f5041	\N	1102200	D	seed	seed|Utilities|Bescom|Backup usage|2026-02-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
370213d4-dd85-4a36-87e0-add82f2aafe5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	0ea27bf9-8055-4580-9820-752bdf2f5041	\N	1429900	D	seed	seed|Utilities|Bescom|Backup usage|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
862093c8-abcc-4d4c-9d59-e8364af33f0a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	0ea27bf9-8055-4580-9820-752bdf2f5041	\N	1344200	D	seed	seed|Utilities|Bescom|Backup usage|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
c526a393-d807-43a1-a089-b208e26d65fa	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	0ea27bf9-8055-4580-9820-752bdf2f5041	\N	1009600	D	seed	seed|Utilities|Bescom|Backup usage|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
443e0c2c-83cd-405d-b8b8-5743f63d2e1f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	7a9f1aa6-1807-458f-9c7d-b197f59405c7	0ea27bf9-8055-4580-9820-752bdf2f5041	\N	850000	D	seed	seed|Utilities|Bescom|Backup usage|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
e50b0c01-f5c2-4848-9de9-d790a8bb2b4c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	79e10070-139a-47df-8cac-6db896965f6f	\N	3200000	D	seed	seed|Utilities|BWSSB|Water charges|2025-08-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
c351e710-ff7c-4375-a0d0-c32dfebf1e5c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	79e10070-139a-47df-8cac-6db896965f6f	\N	3368300	D	seed	seed|Utilities|BWSSB|Water charges|2025-09-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
fd67b79e-6cdc-417e-a8dc-e70bd448bded	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	79e10070-139a-47df-8cac-6db896965f6f	\N	3381900	D	seed	seed|Utilities|BWSSB|Water charges|2025-10-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
25d796b5-47b2-4c36-9412-d60957abbb70	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	79e10070-139a-47df-8cac-6db896965f6f	\N	3228200	D	seed	seed|Utilities|BWSSB|Water charges|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
70aa9c8e-e87d-447b-9472-5ad65cc71697	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	79e10070-139a-47df-8cac-6db896965f6f	\N	3048600	D	seed	seed|Utilities|BWSSB|Water charges|2025-12-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
15361aca-2b14-433e-b5b6-d69831618a3b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	79e10070-139a-47df-8cac-6db896965f6f	\N	3008200	D	seed	seed|Utilities|BWSSB|Water charges|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
837365f0-98d6-4fb7-a038-d87c105b533f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	79e10070-139a-47df-8cac-6db896965f6f	\N	3144100	D	seed	seed|Utilities|BWSSB|Water charges|2026-02-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
83f174ee-54de-42f3-b783-9f7af50ecfd6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	79e10070-139a-47df-8cac-6db896965f6f	\N	3331400	D	seed	seed|Utilities|BWSSB|Water charges|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
b3aca1c8-b202-4eba-8141-4e83b6f5d64f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	79e10070-139a-47df-8cac-6db896965f6f	\N	3397900	D	seed	seed|Utilities|BWSSB|Water charges|2026-04-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
822b8710-ea23-4016-843f-1d9d23f2f719	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	79e10070-139a-47df-8cac-6db896965f6f	\N	3282400	D	seed	seed|Utilities|BWSSB|Water charges|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
ac52a1f0-47b1-4544-84b5-8aa4f851d35c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	79e10070-139a-47df-8cac-6db896965f6f	\N	3091200	D	seed	seed|Utilities|BWSSB|Water charges|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
78ebca1e-3dc5-4887-90a3-4a4839cda71f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	4db1f281-893e-499d-8159-c67e91fb74dd	07e183d9-ab9f-4f93-8416-439ae2a1ee76	79e10070-139a-47df-8cac-6db896965f6f	\N	3000000	D	seed	seed|Utilities|BWSSB|Water charges|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
568d625b-8100-45a5-bf21-b22d1be81599	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	5414c3f2-4a74-4064-b345-8ceddbd3d1db	\N	6500000	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2025-08-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
ba64031a-79d9-4088-a300-a05121f2c6c8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	5414c3f2-4a74-4064-b345-8ceddbd3d1db	\N	6752400	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2025-09-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
6bbba773-3f43-451d-942a-8d7e6ebf5eff	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	5414c3f2-4a74-4064-b345-8ceddbd3d1db	\N	6772800	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2025-10-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
5f76b9b2-737d-4ae3-944e-e30ce318971e	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	5414c3f2-4a74-4064-b345-8ceddbd3d1db	\N	6542300	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
074f0b93-2799-4929-9b6d-8d540e03e1a9	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	5414c3f2-4a74-4064-b345-8ceddbd3d1db	\N	6273000	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2025-12-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
99599ac3-18cf-4aae-830d-68e2f292eeef	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	5414c3f2-4a74-4064-b345-8ceddbd3d1db	\N	6212300	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
aa4a1bd3-86a9-47ab-a303-747e36389831	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	5414c3f2-4a74-4064-b345-8ceddbd3d1db	\N	6416200	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-02-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
f97242a7-59d8-4908-ad12-9654a3e8fbfa	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	5414c3f2-4a74-4064-b345-8ceddbd3d1db	\N	6697100	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
65164ac3-19f9-4e3d-9b2a-ae8343093421	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	5414c3f2-4a74-4064-b345-8ceddbd3d1db	\N	6796800	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-04-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
4e1da315-a17d-40e7-a91d-d4e8fee1910e	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	5414c3f2-4a74-4064-b345-8ceddbd3d1db	\N	6623600	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
cd27c3a1-b94e-472b-a24f-40c7c4ce16d5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	5414c3f2-4a74-4064-b345-8ceddbd3d1db	\N	6336800	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
e6e57248-0774-4fc8-a636-2824a788816f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	5414c3f2-4a74-4064-b345-8ceddbd3d1db	\N	6200000	D	seed	seed|Maintenance|ABC Enterprise|Labour charges|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
3f52b168-156f-49a3-b0c4-5f7fe46c5de5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	351bfa00-9d82-4d01-9b01-5acf8b3eab19	\N	1800000	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2025-08-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
3dd90f1a-2727-4fca-ab79-1df408637574	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	351bfa00-9d82-4d01-9b01-5acf8b3eab19	\N	2345600	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2025-10-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
82c31134-e100-4f56-aa10-f805ae0ff3b1	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	351bfa00-9d82-4d01-9b01-5acf8b3eab19	\N	1884700	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
937c8dc9-ffb1-44cd-835e-5a8b4e1c028a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	351bfa00-9d82-4d01-9b01-5acf8b3eab19	\N	1224600	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
3ce3f203-7c6d-4fb2-9068-7ec2594dcbcf	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	351bfa00-9d82-4d01-9b01-5acf8b3eab19	\N	1632400	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2026-02-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
4fd5826f-a55e-47c8-af81-3dd4640b8ff1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	351bfa00-9d82-4d01-9b01-5acf8b3eab19	\N	2393600	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2026-04-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
653c88ab-2626-4ec6-9f43-d2f7165c7656	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	351bfa00-9d82-4d01-9b01-5acf8b3eab19	\N	2047300	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
f8ba4735-aaf1-47d7-aba5-4b2f4c962bc6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	351bfa00-9d82-4d01-9b01-5acf8b3eab19	\N	1473600	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
b1785b48-66d5-4f19-bd08-cf7221cfb9f7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	351bfa00-9d82-4d01-9b01-5acf8b3eab19	\N	1200000	D	seed	seed|Maintenance|ABC Enterprise|Spare parts|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
02a55848-1282-49bb-a967-caeeda10868b	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	c8c58993-543d-4094-8139-838dbcf2d2b2	\N	945500	D	seed	seed|Maintenance|ABC Enterprise|STP salt purchase|2025-10-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
39ad7def-3e25-4dc8-80bc-30ac2ce676d4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	c8c58993-543d-4094-8139-838dbcf2d2b2	\N	852100	D	seed	seed|Maintenance|ABC Enterprise|STP salt purchase|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
11438a70-3646-4ce7-8c6e-05ce0c2c919b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	c8c58993-543d-4094-8139-838dbcf2d2b2	\N	949500	D	seed	seed|Maintenance|ABC Enterprise|STP salt purchase|2026-04-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
82abb675-f340-4536-8217-d3a68b845909	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	e949bd36-fc1d-4a79-9961-12feb7c743fd	c8c58993-543d-4094-8139-838dbcf2d2b2	\N	850000	D	seed	seed|Maintenance|ABC Enterprise|STP salt purchase|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
860a1818-4e97-4fea-bae0-b313f2a75c0c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	97323209-a30d-4919-806c-6d1e00986a9e	cea11cd2-f83a-4afa-9282-779eb47f7031	\N	744500	D	seed	seed|Maintenance|John (Plumber)|Plumbing repair|2025-09-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
fcf8d2e6-59e1-4182-ac4c-6e1e3c6f4386	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	97323209-a30d-4919-806c-6d1e00986a9e	cea11cd2-f83a-4afa-9282-779eb47f7031	\N	499400	D	seed	seed|Maintenance|John (Plumber)|Plumbing repair|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
207162e0-c109-4df9-ae28-fb82f64029fc	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	97323209-a30d-4919-806c-6d1e00986a9e	cea11cd2-f83a-4afa-9282-779eb47f7031	\N	185100	D	seed	seed|Maintenance|John (Plumber)|Plumbing repair|2025-12-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
c6248240-6bf7-4026-af46-b800ebba9575	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	97323209-a30d-4919-806c-6d1e00986a9e	cea11cd2-f83a-4afa-9282-779eb47f7031	\N	679900	D	seed	seed|Maintenance|John (Plumber)|Plumbing repair|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
29022ba4-2e81-43c4-ae9b-2d364ca2dcb5	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	97323209-a30d-4919-806c-6d1e00986a9e	cea11cd2-f83a-4afa-9282-779eb47f7031	\N	594200	D	seed	seed|Maintenance|John (Plumber)|Plumbing repair|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
d0947a17-911e-473d-9307-f4c260676d67	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	2662ae57-f003-43fc-a8cc-350681b3b09a	97323209-a30d-4919-806c-6d1e00986a9e	cea11cd2-f83a-4afa-9282-779eb47f7031	\N	259600	D	seed	seed|Maintenance|John (Plumber)|Plumbing repair|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
6d6754b2-f5ed-4db2-80c0-81b18b3e0161	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	c26407c6-db9a-466b-ab08-c40421402fb5	\N	12000000	D	seed	seed|Security|SafeGuard Services|Guard salaries|2025-08-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
772b8374-b28e-41a9-8f0e-73f9ff7fe3b2	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	c26407c6-db9a-466b-ab08-c40421402fb5	\N	12168300	D	seed	seed|Security|SafeGuard Services|Guard salaries|2025-09-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
cbbe885f-9cbf-46e6-a539-8533d3b8ec7c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	c26407c6-db9a-466b-ab08-c40421402fb5	\N	12181900	D	seed	seed|Security|SafeGuard Services|Guard salaries|2025-10-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
aa7ff29e-6616-45cb-8cef-f761797bc5e7	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	c26407c6-db9a-466b-ab08-c40421402fb5	\N	12028200	D	seed	seed|Security|SafeGuard Services|Guard salaries|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
715a108a-0bcf-47ff-acf2-6cbbaf85d3e0	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	c26407c6-db9a-466b-ab08-c40421402fb5	\N	11848600	D	seed	seed|Security|SafeGuard Services|Guard salaries|2025-12-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
a684ef39-754b-4ce1-83aa-2e0394868ca4	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	c26407c6-db9a-466b-ab08-c40421402fb5	\N	11808200	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
a2891ccf-473f-48a9-a4bd-364bfa0dae06	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	c26407c6-db9a-466b-ab08-c40421402fb5	\N	11944100	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-02-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
64418bee-3d15-4452-8a5c-526ee7ce333b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	c26407c6-db9a-466b-ab08-c40421402fb5	\N	12131400	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
2d759013-228b-4df9-8a32-37e9c7be799b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	c26407c6-db9a-466b-ab08-c40421402fb5	\N	12197900	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-04-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
4a466467-ecfc-4943-9fc8-5afa6aab3f74	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	c26407c6-db9a-466b-ab08-c40421402fb5	\N	12082400	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
ddba0ff2-9dda-42ba-84c1-ddf9cbadd786	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	c26407c6-db9a-466b-ab08-c40421402fb5	\N	11891200	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
e3412c4f-672e-47d9-851a-e5af1239dadb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	e6cb183b-e0b3-4d5c-894c-b72a425e4e68	68f48e74-f597-49ca-ab53-10e065e65182	c26407c6-db9a-466b-ab08-c40421402fb5	\N	11800000	D	seed	seed|Security|SafeGuard Services|Guard salaries|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
d24d9e37-5c6a-4154-974c-16c91b386b43	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	\N	5800000	D	seed	seed|Housekeeping|CleanCo|Staff wages|2025-08-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
2a2547f1-a823-4ec7-846d-a4f92ef0e191	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	\N	5926200	D	seed	seed|Housekeeping|CleanCo|Staff wages|2025-09-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
508d4bde-dbb2-4aad-b00b-bd90ba03ddd7	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	\N	5936400	D	seed	seed|Housekeeping|CleanCo|Staff wages|2025-10-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
1c671b6b-b5a9-4133-bac2-c8101278ea80	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	\N	5821200	D	seed	seed|Housekeeping|CleanCo|Staff wages|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
a6a5c22f-c21e-48c5-bfba-e5e2a54b0d9a	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	\N	5686500	D	seed	seed|Housekeeping|CleanCo|Staff wages|2025-12-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
dbf9e857-6352-476c-b410-616b70bda2ac	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	\N	5656200	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
fb9613c8-e74a-429b-bdfa-585869c7355a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	\N	5758100	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-02-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
5a0f7b90-e073-43c1-b3c8-04e5c7d0d630	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	\N	5898500	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
e0a952bd-a85e-4c55-8a32-01348d23d616	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	\N	5948400	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-04-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
25415d8b-db63-458a-9480-d568dc823b91	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	\N	5861800	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
a9df88cc-14fa-4e2f-8f57-bc57b99b4ef0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	\N	5718400	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
f41433e6-cca8-41fb-a02e-a484c38a078d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	bc40a108-cd8f-4e5d-b6af-b4df57ccdbd2	\N	5650000	D	seed	seed|Housekeeping|CleanCo|Staff wages|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
c4404e1c-5f15-4483-909c-891ce680c051	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	185905ac-b627-4193-90cf-9b90584b93d7	\N	750000	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2025-08-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
4581537b-78c3-4f57-b98c-a6985a55c768	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	185905ac-b627-4193-90cf-9b90584b93d7	\N	876200	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2025-09-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
466e0429-7887-4552-bf7e-208adefb3490	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	185905ac-b627-4193-90cf-9b90584b93d7	\N	886400	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2025-10-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
259e188b-9558-42b7-b4bd-72e53b1caefc	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	185905ac-b627-4193-90cf-9b90584b93d7	\N	771200	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
42c50ecc-5989-49a0-abea-7ddab0a64d91	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	185905ac-b627-4193-90cf-9b90584b93d7	\N	636500	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2025-12-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
1b732101-39f9-4b9f-8cea-b6c712763b00	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	185905ac-b627-4193-90cf-9b90584b93d7	\N	606200	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
dc9981f3-bde2-481d-9bf2-cde663464ec7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	185905ac-b627-4193-90cf-9b90584b93d7	\N	708100	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-02-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
7713216d-5483-4918-8787-f0eacd7d4c92	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	185905ac-b627-4193-90cf-9b90584b93d7	\N	848500	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
a62c9632-5db8-4683-a1fd-68060db325a6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	185905ac-b627-4193-90cf-9b90584b93d7	\N	898400	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-04-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
04ae9a5c-93b3-4ca8-9278-8a1f8e2c6779	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	185905ac-b627-4193-90cf-9b90584b93d7	\N	811800	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
047119c6-9ccd-466b-8674-44acf563c23d	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	185905ac-b627-4193-90cf-9b90584b93d7	\N	668400	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
7028d0d0-4a35-4a47-8d98-3088adc3b7c6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	8a6265b8-59f4-4258-8868-0b4c119ecbfb	b4b7081c-3677-49c9-89f9-e3ca9440ba15	185905ac-b627-4193-90cf-9b90584b93d7	\N	600000	D	seed	seed|Housekeeping|CleanCo|Cleaning supplies|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
2f3f837c-54fb-4200-9eab-e92ded5fa114	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	4b591384-fe25-4cda-a70c-6a27cfda4b1f	\N	600000	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2025-08-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
54ab1189-e92c-48a0-aaf1-741798f13718	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	4b591384-fe25-4cda-a70c-6a27cfda4b1f	\N	1062800	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2025-09-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
cc17dd71-f427-457d-80fe-6fa6507a3954	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	4b591384-fe25-4cda-a70c-6a27cfda4b1f	\N	1100100	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2025-10-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
45d46af4-52ca-43b9-81d3-b896f489c841	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	4b591384-fe25-4cda-a70c-6a27cfda4b1f	\N	677600	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
366a0a5c-6c39-42ed-88a2-995d4710f52f	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	4b591384-fe25-4cda-a70c-6a27cfda4b1f	\N	183800	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2025-12-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
f42b73af-f159-4510-aa8d-70a125813335	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	4b591384-fe25-4cda-a70c-6a27cfda4b1f	\N	72600	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
3cda7c30-a1cb-479c-afbf-57674b2d843b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	4b591384-fe25-4cda-a70c-6a27cfda4b1f	\N	446300	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-02-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
41418319-9cfc-4c2d-a03e-f9fb23a8d52c	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	4b591384-fe25-4cda-a70c-6a27cfda4b1f	\N	961300	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
8cd0b61c-8f88-4342-afce-432d73ba16f2	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	4b591384-fe25-4cda-a70c-6a27cfda4b1f	\N	1144100	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-04-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
9b0b960d-b9ad-4a58-b86d-919acdd018bb	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	4b591384-fe25-4cda-a70c-6a27cfda4b1f	\N	826700	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
8f31b3a5-3a2a-4dc0-8910-27ee0954abd9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	4b591384-fe25-4cda-a70c-6a27cfda4b1f	\N	300800	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
4a82e9c1-2fe7-486f-b3cb-73c129662dc7	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	20ebdf74-0f2f-4404-983d-c17fe1c4cf3b	23f237cd-673f-41cf-a90b-72a819a008fc	aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	4b591384-fe25-4cda-a70c-6a27cfda4b1f	\N	50000	D	seed	seed|Petty Cash|Office petty cash|Ad-hoc expenses|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
a2e63afe-38cb-4efe-a0b8-71322de67af5	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	9df23939-7428-4dc4-b512-9bb82cb4238c	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	f61b5c1e-7431-4447-af34-38da3726a4c6	\N	34000000	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2025-08-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
8f01fbea-9db7-4f27-8376-9f960480c275	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	9df23939-7428-4dc4-b512-9bb82cb4238c	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	f61b5c1e-7431-4447-af34-38da3726a4c6	\N	35262200	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2025-09-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
a53748d1-7d78-46ed-b42f-adf20ecd0a91	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	9df23939-7428-4dc4-b512-9bb82cb4238c	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	f61b5c1e-7431-4447-af34-38da3726a4c6	\N	35363900	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2025-10-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
b7532b94-e52e-4aa5-8041-7d9b75a74d77	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	9df23939-7428-4dc4-b512-9bb82cb4238c	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	f61b5c1e-7431-4447-af34-38da3726a4c6	\N	34211700	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
2960f4b7-94d1-4c8b-af7a-897283a7d141	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	9df23939-7428-4dc4-b512-9bb82cb4238c	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	f61b5c1e-7431-4447-af34-38da3726a4c6	\N	32864800	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2025-12-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
8ea2f5b6-4d69-46d7-bbc3-636c91d916c6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	9df23939-7428-4dc4-b512-9bb82cb4238c	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	f61b5c1e-7431-4447-af34-38da3726a4c6	\N	32561600	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
e18cf6f2-0fa9-4397-aee9-22bf05ce5651	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	9df23939-7428-4dc4-b512-9bb82cb4238c	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	f61b5c1e-7431-4447-af34-38da3726a4c6	\N	33580900	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-02-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
1b01e40d-b418-48d2-95cf-a87ac3282e0f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	9df23939-7428-4dc4-b512-9bb82cb4238c	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	f61b5c1e-7431-4447-af34-38da3726a4c6	\N	34985500	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
4485829a-b0ec-4354-8fae-3f663e2e4462	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	9df23939-7428-4dc4-b512-9bb82cb4238c	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	f61b5c1e-7431-4447-af34-38da3726a4c6	\N	35484000	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-04-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
57f11eaf-12e6-4c32-a29f-55062a8e2f4f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	9df23939-7428-4dc4-b512-9bb82cb4238c	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	f61b5c1e-7431-4447-af34-38da3726a4c6	\N	34618200	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
3567126c-7b4c-49df-a79b-23c33206347a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	9df23939-7428-4dc4-b512-9bb82cb4238c	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	f61b5c1e-7431-4447-af34-38da3726a4c6	\N	33184000	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
f435d1ee-d009-4439-b0ab-51c131c0ad69	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	9df23939-7428-4dc4-b512-9bb82cb4238c	e9e3ac9d-fd4d-4c1a-8121-a037c9f3df6f	1d45caaa-aea4-467e-956c-9037f3ef6835	f61b5c1e-7431-4447-af34-38da3726a4c6	\N	32500000	C	seed	seed|Maintenance Collections|Monthly maintenance|Flat maintenance dues|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
05d8d30b-0439-4d08-8205-c78c9ce702c9	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	edb47adf-7adc-4c0e-963a-28138c0e6d29	\N	1800000	C	seed	seed|Other Income|Community Hall|Hall rental|2025-08-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
8c63f421-a434-4c16-86c2-8ffddc6281ae	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	edb47adf-7adc-4c0e-963a-28138c0e6d29	\N	2527400	C	seed	seed|Other Income|Community Hall|Hall rental|2025-10-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
451a3c2e-960b-4262-962c-7033251e3f6c	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	edb47adf-7adc-4c0e-963a-28138c0e6d29	\N	1912900	C	seed	seed|Other Income|Community Hall|Hall rental|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
5671dd4e-9faf-4c0c-9ff3-b1fc68607669	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	edb47adf-7adc-4c0e-963a-28138c0e6d29	\N	1194600	C	seed	seed|Other Income|Community Hall|Hall rental|2025-12-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
5511715c-7eb8-4b4e-bdc0-f0c28ba2b091	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	edb47adf-7adc-4c0e-963a-28138c0e6d29	\N	1576500	C	seed	seed|Other Income|Community Hall|Hall rental|2026-02-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
49b83605-2ccb-4c61-a8fe-ccdad3639ad1	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	edb47adf-7adc-4c0e-963a-28138c0e6d29	\N	2325600	C	seed	seed|Other Income|Community Hall|Hall rental|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
950d4eae-606f-47aa-a432-f4dfb9faa898	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	edb47adf-7adc-4c0e-963a-28138c0e6d29	\N	2591500	C	seed	seed|Other Income|Community Hall|Hall rental|2026-04-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
50b8fb2c-58ef-43f4-9c2d-ef92e897d886	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	edb47adf-7adc-4c0e-963a-28138c0e6d29	\N	1364800	C	seed	seed|Other Income|Community Hall|Hall rental|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
3dc29244-f10a-4f65-9c65-9b93cc39dcd0	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	edb47adf-7adc-4c0e-963a-28138c0e6d29	\N	1000000	C	seed	seed|Other Income|Community Hall|Hall rental|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
110d377c-418e-410c-9bcb-44c774ca60c8	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	db44f80c-086d-43e9-85a1-64068da7621d	\N	978700	C	seed	seed|Other Income|Community Hall|Event usage charges|2025-09-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
5dd1f8b2-7035-455f-8a0a-7bc1f15accf9	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	db44f80c-086d-43e9-85a1-64068da7621d	\N	663500	C	seed	seed|Other Income|Community Hall|Event usage charges|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
9ffacadf-b627-4518-aef4-0de5a75b1536	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	db44f80c-086d-43e9-85a1-64068da7621d	\N	168500	C	seed	seed|Other Income|Community Hall|Event usage charges|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
c90864c9-c347-43fd-9c8d-f7453a220745	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	db44f80c-086d-43e9-85a1-64068da7621d	\N	895600	C	seed	seed|Other Income|Community Hall|Event usage charges|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
e8449346-9802-47f0-9256-c5b3e34e5f00	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	db44f80c-086d-43e9-85a1-64068da7621d	\N	785500	C	seed	seed|Other Income|Community Hall|Event usage charges|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
cf694ad8-ce6b-4d1d-8766-9dc19e8a7db6	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	db44f80c-086d-43e9-85a1-64068da7621d	\N	150000	C	seed	seed|Other Income|Community Hall|Event usage charges|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
f996646b-92fd-4a50-a97f-3783a41ef1df	caa11b01-c3a5-4067-a90c-b73b35075def	2025-08-15	2025-08-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	\N	1200000	C	seed	seed|Other Income|Signage Rental|Billboard fee|2025-08-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
afe5b350-2aba-4a6e-a84d-124f88059596	caa11b01-c3a5-4067-a90c-b73b35075def	2025-09-15	2025-09-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	\N	1242100	C	seed	seed|Other Income|Signage Rental|Billboard fee|2025-09-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
be0474bf-ed5a-4bc3-9404-2d99e774907b	caa11b01-c3a5-4067-a90c-b73b35075def	2025-10-15	2025-10-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	\N	1245500	C	seed	seed|Other Income|Signage Rental|Billboard fee|2025-10-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
09f062ae-4fd0-431e-bc54-d5a8efdf5e0d	caa11b01-c3a5-4067-a90c-b73b35075def	2025-11-15	2025-11-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	\N	1207100	C	seed	seed|Other Income|Signage Rental|Billboard fee|2025-11-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
a7749cc1-da41-41fd-a94b-58b21e0f8538	caa11b01-c3a5-4067-a90c-b73b35075def	2025-12-15	2025-12-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	\N	1162200	C	seed	seed|Other Income|Signage Rental|Billboard fee|2025-12-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
acecb9b7-2bbc-4afd-9ff0-d0cb9bf3a3d9	caa11b01-c3a5-4067-a90c-b73b35075def	2026-01-15	2026-01-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	\N	1152100	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-01-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
6b5756d4-db38-47c5-ac78-9bf8bf807f72	caa11b01-c3a5-4067-a90c-b73b35075def	2026-02-15	2026-02-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	\N	1186000	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-02-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
a2b7cd8a-d925-4e0c-a590-2d5edd483c0f	caa11b01-c3a5-4067-a90c-b73b35075def	2026-03-15	2026-03-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	\N	1232800	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-03-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
e9ecd341-bb45-43ee-9822-30d15bb9460a	caa11b01-c3a5-4067-a90c-b73b35075def	2026-04-15	2026-04-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	\N	1249500	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-04-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
e09178e6-1c03-49af-bbf0-20289433871b	caa11b01-c3a5-4067-a90c-b73b35075def	2026-05-15	2026-05-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	\N	1220600	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-05-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
62370823-8dfa-46d4-af17-913a1b5f9f86	caa11b01-c3a5-4067-a90c-b73b35075def	2026-06-15	2026-06-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	\N	1172800	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-06-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
6c9f50e4-4473-43d9-a74b-33981b3d8216	caa11b01-c3a5-4067-a90c-b73b35075def	2026-07-15	2026-07-01	9df23939-7428-4dc4-b512-9bb82cb4238c	f9f8a74a-8bac-4438-88d2-2cf1475dff65	83b1c58a-b26b-497b-afc9-364c3c61db01	dcf7982e-9fa7-43e8-a93f-b6fb4088f9e1	\N	1150000	C	seed	seed|Other Income|Signage Rental|Billboard fee|2026-07-01	\N	\N	2026-07-13 11:20:04.55456+00	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	superadmin
0f0c6024-6c4d-47b3-9012-4f714d448a40	admin
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, community_id, email, name, password_hash, last_login_at, created_at) FROM stdin;
0f0c6024-6c4d-47b3-9012-4f714d448a40	caa11b01-c3a5-4067-a90c-b73b35075def	admin@example.com	Super Admin	$argon2id$v=19$m=65536,t=3,p=4$cpn4k+axzNsRKRcX1qifeg$17B/FJaMZ3+6UVZxpx4HSK7N/7e7GIKGxV116ngZWP8	\N	2026-07-13 11:20:04.55456+00
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, community_id, name, kind) FROM stdin;
7a9f1aa6-1807-458f-9c7d-b197f59405c7	caa11b01-c3a5-4067-a90c-b73b35075def	Bescom	company
07e183d9-ab9f-4f93-8416-439ae2a1ee76	caa11b01-c3a5-4067-a90c-b73b35075def	BWSSB	company
e949bd36-fc1d-4a79-9961-12feb7c743fd	caa11b01-c3a5-4067-a90c-b73b35075def	ABC Enterprise	company
97323209-a30d-4919-806c-6d1e00986a9e	caa11b01-c3a5-4067-a90c-b73b35075def	John (Plumber)	individual
68f48e74-f597-49ca-ab53-10e065e65182	caa11b01-c3a5-4067-a90c-b73b35075def	SafeGuard Services	company
b4b7081c-3677-49c9-89f9-e3ca9440ba15	caa11b01-c3a5-4067-a90c-b73b35075def	CleanCo	company
aa51e83b-3dfb-4703-b6a0-f8b7e6985e84	caa11b01-c3a5-4067-a90c-b73b35075def	Office petty cash	individual
1d45caaa-aea4-467e-956c-9037f3ef6835	caa11b01-c3a5-4067-a90c-b73b35075def	Monthly maintenance	company
cc3cc63d-21cc-4a31-a4bb-cb394fc44f31	caa11b01-c3a5-4067-a90c-b73b35075def	Community Hall	company
83b1c58a-b26b-497b-afc9-364c3c61db01	caa11b01-c3a5-4067-a90c-b73b35075def	Signage Rental	individual
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: _migrations _migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._migrations
    ADD CONSTRAINT _migrations_pkey PRIMARY KEY (name);


--
-- Name: allowed_emails allowed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_pkey PRIMARY KEY (email);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: balances balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_pkey PRIMARY KEY (community_id, month);


--
-- Name: categories categories_head_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_name_key UNIQUE (head_id, name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: collections_dues collections_dues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_pkey PRIMARY KEY (flat_id, period_month);


--
-- Name: communities communities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communities
    ADD CONSTRAINT communities_pkey PRIMARY KEY (id);


--
-- Name: dashboard_settings dashboard_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_pkey PRIMARY KEY (community_id, dashboard_key);


--
-- Name: flats flats_community_id_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_code_key UNIQUE (community_id, code);


--
-- Name: flats flats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_pkey PRIMARY KEY (id);


--
-- Name: heads heads_community_id_kind_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_kind_name_key UNIQUE (community_id, kind, name);


--
-- Name: heads heads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_rules import_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_pkey PRIMARY KEY (id);


--
-- Name: import_staging import_staging_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_pkey PRIMARY KEY (batch_id, row_no);


--
-- Name: line_items line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_pkey PRIMARY KEY (id);


--
-- Name: otp_codes magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otp_codes
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (email, otp_hash);


--
-- Name: periods periods_community_id_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_month_key UNIQUE (community_id, month);


--
-- Name: periods periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_source_source_ref_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_source_source_ref_key UNIQUE (source, source_ref);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_community_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_name_key UNIQUE (community_id, name);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_at ON public.audit_log USING btree (at DESC);


--
-- Name: idx_audit_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_entity ON public.audit_log USING btree (entity, entity_id);


--
-- Name: idx_txn_category_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_category_month ON public.transactions USING btree (category_id, period_month);


--
-- Name: idx_txn_community_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_community_month ON public.transactions USING btree (community_id, period_month);


--
-- Name: idx_txn_flat_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_flat_month ON public.transactions USING btree (flat_id, period_month);


--
-- Name: idx_txn_head_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_head_month ON public.transactions USING btree (head_id, period_month);


--
-- Name: idx_txn_vendor_month; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_txn_vendor_month ON public.transactions USING btree (vendor_id, period_month);


--
-- Name: line_items_cat_vendor_name_uq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX line_items_cat_vendor_name_uq ON public.line_items USING btree (category_id, COALESCE(vendor_id, '00000000-0000-0000-0000-000000000000'::uuid), name);


--
-- Name: mv_cat_monthly_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_cat_monthly_idx ON public.mv_category_monthly USING btree (community_id, month);


--
-- Name: mv_monthly_totals_pk; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX mv_monthly_totals_pk ON public.mv_monthly_totals USING btree (community_id, month);


--
-- Name: mv_vendor_ranking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX mv_vendor_ranking_idx ON public.mv_vendor_ranking USING btree (community_id, total_expense_paise DESC);


--
-- Name: allowed_emails allowed_emails_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: allowed_emails allowed_emails_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.allowed_emails
    ADD CONSTRAINT allowed_emails_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE SET NULL;


--
-- Name: balances balances_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: categories categories_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id) ON DELETE CASCADE;


--
-- Name: collections_dues collections_dues_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collections_dues
    ADD CONSTRAINT collections_dues_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id) ON DELETE CASCADE;


--
-- Name: dashboard_settings dashboard_settings_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_settings
    ADD CONSTRAINT dashboard_settings_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: flats flats_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flats
    ADD CONSTRAINT flats_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: heads heads_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heads
    ADD CONSTRAINT heads_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: import_rules import_rules_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_rules
    ADD CONSTRAINT import_rules_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: import_staging import_staging_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_staging
    ADD CONSTRAINT import_staging_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: line_items line_items_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.line_items
    ADD CONSTRAINT line_items_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE SET NULL;


--
-- Name: periods periods_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.periods
    ADD CONSTRAINT periods_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: transactions transactions_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: transactions transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: transactions transactions_flat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_flat_id_fkey FOREIGN KEY (flat_id) REFERENCES public.flats(id);


--
-- Name: transactions transactions_head_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_head_id_fkey FOREIGN KEY (head_id) REFERENCES public.heads(id);


--
-- Name: transactions transactions_line_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_line_item_id_fkey FOREIGN KEY (line_item_id) REFERENCES public.line_items(id);


--
-- Name: transactions transactions_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: vendors vendors_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: mv_category_monthly; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_category_monthly;


--
-- Name: mv_monthly_totals; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_monthly_totals;


--
-- Name: mv_vendor_ranking; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.mv_vendor_ranking;


--
-- PostgreSQL database dump complete
--

\unrestrict jF6tkUuYDKMQSq7URsXjB7lf8EzEtkp4rNikgyI7j2zbKSM5g3OjHKUG6q0TEr0

